use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::net::{IpAddr, Ipv4Addr, SocketAddr};
use std::time::Duration;

pub const LOCALSEND_MULTICAST_ADDR: Ipv4Addr = Ipv4Addr::new(224, 0, 0, 167);
pub const LOCALSEND_DEFAULT_PORT: u16 = 53317;
pub const LOCALSEND_MDNS_SERVICE: &str = "_localsend._tcp.local.";
pub const LOCALSEND_PROTOCOL_VERSION: &str = "2.1";
pub const NOVA_EXTENSION_VERSION: &str = "1.0";

/// Standard LocalSend v2.1 announcement & `/api/localsend/v2/info` payload
/// with optional backward-compatible `nova` extension block (ignored by stock LocalSend clients).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PeerAnnouncement {
    pub alias: String,
    pub version: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub device_model: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub device_type: Option<String>,
    pub fingerprint: String,
    pub port: u16,
    pub protocol: String, // "https" | "http"
    pub download: bool,
    pub announce: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub nova: Option<NovaCapabilities>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NovaCapabilities {
    pub nova_version: String,
    pub parallel_ranges: bool,
    pub max_streams: u8,
    pub chunk_resume_blake3: bool,
    pub pipeline_small_files: bool,
    pub pre_connect_approval: bool,
    pub split_apk_session: bool,
    pub watch_together_v1: bool,
    pub max_perf_mac_mode: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub avatar_thumb_b64: Option<String>,
    pub avatar_accent_hex: String,
}

/// Sent by receiver in `/api/nova/v1/device-caps` so sender filters only needed APK splits
/// (preserving original Play/developer signatures via PackageInstaller.Session).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ReceiverApkCapabilities {
    pub supported_abis: Vec<String>,   // e.g. ["arm64-v8a", "armeabi-v7a"]
    pub density_dpi: u32,              // e.g. 420 or 280 (Galaxy A20)
    pub sdk_int: u32,                  // e.g. 24..=36
    pub locales: Vec<String>,          // e.g. ["ar", "en"]
    pub supports_multi_apk_session: bool,
}

impl ReceiverApkCapabilities {
    /// Selects exact subset of split APK filenames required by the receiver device.
    pub fn filter_required_splits(&self, available_splits: &[String]) -> Vec<String> {
        let primary_abi = self
            .supported_abis
            .first()
            .map(|s| s.replace('-', "_"))
            .unwrap_or_default();
        let dpi_bucket = match self.density_dpi {
            0..=140 => "ldpi",
            141..=200 => "mdpi",
            201..=280 => "hdpi",
            281..=380 => "xhdpi",
            381..=520 => "xxhdpi",
            _ => "xxxhdpi",
        };

        available_splits
            .iter()
            .filter(|name| {
                if *name == "base.apk" || !name.starts_with("split_config.") {
                    return true;
                }
                let tag = name
                    .trim_start_matches("split_config.")
                    .trim_end_matches(".apk");
                if ["arm64_v8a", "armeabi_v7a", "armeabi", "x86_64", "x86"].contains(&tag) {
                    return tag == primary_abi;
                }
                if ["ldpi", "mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"].contains(&tag) {
                    return tag == dpi_bucket;
                }
                if tag.len() == 2 {
                    return self.locales.iter().any(|l| l.starts_with(tag));
                }
                true
            })
            .cloned()
            .collect()
    }
}

/// Standard LocalSend v2.1 `/api/localsend/v2/prepare-upload` request body.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PrepareUploadRequest {
    pub info: PeerAnnouncement,
    pub files: HashMap<String, FileMetadataDto>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FileMetadataDto {
    pub id: String,
    pub file_name: String,
    pub size: u64,
    pub file_type: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sha256: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub blake3: Option<String>,
}

/// Avoids wasting CPU compressing already-compressed media/packages in streaming ZIP & transfer.
pub fn is_already_compressed(file_name: &str) -> bool {
    let ext = file_name
        .rsplit('.')
        .next()
        .unwrap_or("")
        .to_ascii_lowercase();
    matches!(
        ext.as_str(),
        "jpg" | "jpeg" | "png" | "webp" | "heic" | "avif"
            | "mp4" | "mkv" | "mov" | "webm" | "avi"
            | "mp3" | "aac" | "m4a" | "flac" | "opus" | "ogg"
            | "apk" | "xapk" | "apks" | "apkm" | "obb"
            | "zip" | "7z" | "rar" | "gz" | "xz" | "zst" | "pdf" | "docx" | "pptx"
    )
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ApIsolationDiagnosis {
    Reachable,
    SuspectedApIsolation,
    UnreachableNoAnnouncement,
}

/// Diagnoses Router AP Isolation: when multicast/mDNS/BLE sees a peer on the same subnet
/// yet direct TCP SYN times out consistently, prompts instant switch to Wi-Fi Direct / Hotspot.
pub async fn probe_peer_ap_isolation(
    peer_ip: IpAddr,
    peer_port: u16,
    heard_via_discovery: bool,
) -> ApIsolationDiagnosis {
    let addr = SocketAddr::new(peer_ip, peer_port);
    match tokio::time::timeout(Duration::from_millis(1400), tokio::net::TcpStream::connect(addr)).await {
        Ok(Ok(stream)) => {
            let _ = stream.set_nodelay(true);
            ApIsolationDiagnosis::Reachable
        }
        _ if heard_via_discovery => ApIsolationDiagnosis::SuspectedApIsolation,
        _ => ApIsolationDiagnosis::UnreachableNoAnnouncement,
    }
}

/// Generates a ZIP64 STORE (method 0, zero temp file) Local File Header for streaming multi-file
/// browser downloads over HTTP without buffering files in RAM or flash.
pub fn build_streaming_zip64_local_header(entry_name: &str) -> Vec<u8> {
    let name_bytes = entry_name.as_bytes();
    let mut hdr = Vec::with_capacity(30 + name_bytes.len());
    hdr.extend_from_slice(&0x04034b50u32.to_le_bytes()); // Local file header signature
    hdr.extend_from_slice(&45u16.to_le_bytes()); // Version needed: 4.5 (ZIP64)
    hdr.extend_from_slice(&0x0808u16.to_le_bytes()); // Bit 3 (data descriptor) + Bit 11 (UTF-8)
    hdr.extend_from_slice(&0u16.to_le_bytes()); // Method 0 = STORE (no wasteful re-compression)
    hdr.extend_from_slice(&0u16.to_le_bytes()); // Mod time
    hdr.extend_from_slice(&0u16.to_le_bytes()); // Mod date
    hdr.extend_from_slice(&0u32.to_le_bytes()); // CRC-32 written in trailing ZIP64 descriptor
    hdr.extend_from_slice(&0xFFFF_FFFFu32.to_le_bytes()); // ZIP64 marker
    hdr.extend_from_slice(&0xFFFF_FFFFu32.to_le_bytes()); // ZIP64 marker
    hdr.extend_from_slice(&(name_bytes.len() as u16).to_le_bytes());
    hdr.extend_from_slice(&0u16.to_le_bytes());
    hdr.extend_from_slice(name_bytes);
    hdr
}

pub fn build_streaming_zip64_data_descriptor(crc32: u32, exact_size: u64) -> [u8; 24] {
    let mut out = [0u8; 24];
    out[0..4].copy_from_slice(&0x08074b50u32.to_le_bytes());
    out[4..8].copy_from_slice(&crc32.to_le_bytes());
    out[8..16].copy_from_slice(&exact_size.to_le_bytes());
    out[16..24].copy_from_slice(&exact_size.to_le_bytes());
    out
}
