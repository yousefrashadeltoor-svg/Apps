use parking_lot::Mutex;
use serde::{Deserialize, Serialize};
use std::fs::File;
use std::io;
use std::sync::Arc;
use std::time::Instant;
use thiserror::Error;

#[cfg(unix)]
use std::os::unix::fs::FileExt;
#[cfg(unix)]
use std::os::unix::io::{AsRawFd, FromRawFd, RawFd};

pub const FAT32_MAX_FILE_BYTES: u64 = 4_294_967_295; // 4 GiB - 1 byte
pub const SAFETY_FREE_MARGIN_BYTES: u64 = 64 * 1024 * 1024; // 64 MiB safety margin

#[derive(Debug, Error)]
pub enum TransferError {
    #[error("المساحة المتاحة غير كافية: مطلوب {required} بايت، المتاح {available} بايت")]
    InsufficientStorage { required: u64, available: u64 },
    #[error("حجم الملف ({size} بايت) يتجاوز حد نظام ملفات FAT32 البالغ 4GB")]
    Fat32SizeLimitExceeded { size: u64 },
    #[error("فشل التحقق من سلامة المقطع {chunk_index} عبر BLAKE3")]
    ChunkIntegrityFailed { chunk_index: u32 },
    #[error("خطأ إدخال/إخراج في النواة: {0}")]
    Io(#[from] io::Error),
}

/// Reusable fixed-size buffer pool — eliminates per-chunk heap allocation on 3GB RAM devices (A20).
pub struct BufferPool {
    buf_size: usize,
    max_pooled: usize,
    free: Mutex<Vec<Vec<u8>>>,
}

impl BufferPool {
    pub fn new(buf_size: usize, preallocate: usize, max_pooled: usize) -> Arc<Self> {
        let mut vecs = Vec::with_capacity(max_pooled);
        for _ in 0..preallocate {
            vecs.push(vec![0u8; buf_size]);
        }
        Arc::new(Self {
            buf_size,
            max_pooled,
            free: Mutex::new(vecs),
        })
    }

    pub fn acquire(&self) -> Vec<u8> {
        self.free.lock().pop().unwrap_or_else(|| vec![0u8; self.buf_size])
    }

    pub fn release(&self, buf: Vec<u8>) {
        if buf.len() == self.buf_size {
            let mut guard = self.free.lock();
            if guard.len() < self.max_pooled {
                guard.push(buf);
            }
        }
    }
}

/// Adaptive parallel connection & buffer sizing tuned via self-benchmark and live ThermalStatus.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdaptiveLinkTuner {
    pub active_streams: u8,
    pub buffer_bytes: usize,
    pub range_chunk_bytes: u64,
    pub is_low_end_device: bool,
    pub link_speed_mbps: u32,
    pub thermal_level: u8, // 0=none, 1=light, 2=moderate, 3+=severe
    last_throughput_bps: f64,
}

impl AdaptiveLinkTuner {
    pub fn initial(is_low_end_device: bool, link_speed_mbps: u32) -> Self {
        // Start conservatively at 2 streams (never assume more helps on single-radio 2.4GHz like A20)
        let buffer_bytes = if is_low_end_device {
            128 * 1024
        } else if link_speed_mbps >= 400 {
            1024 * 1024
        } else {
            256 * 1024
        };
        let range_chunk_bytes = if is_low_end_device {
            4 * 1024 * 1024
        } else {
            16 * 1024 * 1024
        };
        Self {
            active_streams: 2,
            buffer_bytes,
            range_chunk_bytes,
            is_low_end_device,
            link_speed_mbps,
            thermal_level: 0,
            last_throughput_bps: 0.0,
        }
    }

    /// Physical expected ceiling shown honestly in UI (accounts for 802.11 MAC + TCP/TLS overhead ~58-65%).
    pub fn expected_ceiling_mbs(&self) -> f64 {
        let efficiency = if self.link_speed_mbps <= 150 { 0.56 } else { 0.64 };
        (self.link_speed_mbps as f64 / 8.0) * efficiency
    }

    /// Adjusts parallel streams (2..=8) based on measured gain (>8%), packet loss, and device heat.
    pub fn observe_sample(&mut self, throughput_bps: f64, retransmits: u32, thermal_level: u8) {
        self.thermal_level = thermal_level;
        if thermal_level >= 2 || retransmits > 4 {
            self.active_streams = (self.active_streams.saturating_sub(1)).max(1);
            self.last_throughput_bps = throughput_bps;
            return;
        }
        let max_streams = if self.is_low_end_device { 4 } else { 8 };
        if self.last_throughput_bps > 0.0 && throughput_bps > self.last_throughput_bps * 1.08 {
            self.active_streams = (self.active_streams + 1).min(max_streams);
        }
        self.last_throughput_bps = throughput_bps;
    }
}

/// Chunk-level persistent resume manifest stored in SQLite on pause, crash, or Android 15 onTimeout.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResumeManifest {
    pub session_id: String,
    pub file_id: String,
    pub total_bytes: u64,
    pub chunk_bytes: u64,
    pub completed_chunks: Vec<bool>,
    pub chunk_blake3: Vec<Option<String>>,
}

impl ResumeManifest {
    pub fn new(session_id: String, file_id: String, total_bytes: u64, chunk_bytes: u64) -> Self {
        let count = total_bytes.div_ceil(chunk_bytes.max(1)).max(1) as usize;
        Self {
            session_id,
            file_id,
            total_bytes,
            chunk_bytes,
            completed_chunks: vec![false; count],
            chunk_blake3: vec![None; count],
        }
    }

    pub fn mark_verified(&mut self, index: u32, hash_hex: String) {
        if let Some(slot) = self.completed_chunks.get_mut(index as usize) {
            *slot = true;
            self.chunk_blake3[index as usize] = Some(hash_hex);
        }
    }

    pub fn missing_indices(&self) -> Vec<u32> {
        self.completed_chunks
            .iter()
            .enumerate()
            .filter_map(|(i, done)| if !*done { Some(i as u32) } else { None })
            .collect()
    }

    pub fn completed_bytes(&self) -> u64 {
        let mut sum = 0u64;
        for (i, done) in self.completed_chunks.iter().enumerate() {
            if *done {
                let start = (i as u64) * self.chunk_bytes;
                let end = (start + self.chunk_bytes).min(self.total_bytes);
                sum += end.saturating_sub(start);
            }
        }
        sum
    }
}

/// Exponential Moving Average (alpha = 0.25) throughput & ETA calculator for jitter-free 1Hz notifications.
pub struct EmaProgressTracker {
    total_bytes: u64,
    last_bytes: u64,
    last_tick: Instant,
    ema_bps: f64,
}

impl EmaProgressTracker {
    pub fn new(total_bytes: u64, initial_bytes: u64) -> Self {
        Self {
            total_bytes,
            last_bytes: initial_bytes,
            last_tick: Instant::now(),
            ema_bps: 0.0,
        }
    }

    pub fn update(&mut self, current_bytes: u64) -> (f64, Option<u64>, u8) {
        let now = Instant::now();
        let dt = (now - self.last_tick).as_secs_f64().max(0.001);
        let delta = current_bytes.saturating_sub(self.last_bytes) as f64;
        let instant_bps = delta / dt;
        self.ema_bps = if self.ema_bps <= 1.0 {
            instant_bps
        } else {
            0.25 * instant_bps + 0.75 * self.ema_bps
        };
        self.last_bytes = current_bytes;
        self.last_tick = now;

        let remaining = self.total_bytes.saturating_sub(current_bytes);
        let eta_secs = if self.ema_bps > 1024.0 {
            Some((remaining as f64 / self.ema_bps).ceil() as u64)
        } else {
            None
        };
        let percent = if self.total_bytes == 0 {
            100
        } else {
            ((current_bytes.saturating_mul(100)) / self.total_bytes).min(100) as u8
        };
        (self.ema_bps, eta_secs, percent)
    }
}

/// Checks storage headroom and FAT32 4GB file-size boundary BEFORE accepting transfer.
pub fn preflight_storage_check(
    file_size: u64,
    available_bytes: u64,
    is_fat32_volume: bool,
) -> Result<(), TransferError> {
    if is_fat32_volume && file_size > FAT32_MAX_FILE_BYTES {
        return Err(TransferError::Fat32SizeLimitExceeded { size: file_size });
    }
    let required = file_size.saturating_add(SAFETY_FREE_MARGIN_BYTES);
    if available_bytes < required {
        return Err(TransferError::InsufficientStorage {
            required,
            available: available_bytes,
        });
    }
    Ok(())
}

/// Wraps a detached Android ParcelFileDescriptor (`content://` MediaStore or SAF) for parallel pwrite/pread
/// without ever copying file bytes through Java/Dart heaps.
pub struct NativeDescriptorTarget {
    file: File,
}

impl NativeDescriptorTarget {
    /// # Safety
    /// Caller transfers exclusive ownership of an open, valid POSIX file descriptor (from `detachFd()`).
    #[cfg(unix)]
    pub unsafe fn from_detached_android_fd(raw_fd: RawFd) -> Self {
        Self {
            file: unsafe { File::from_raw_fd(raw_fd) },
        }
    }

    pub fn from_file(file: File) -> Self {
        Self { file }
    }

    /// Pre-allocates full target length via `posix_fallocate` / `set_len` to expose ENOSPC early
    /// and prevent flash fragmentation on parallel range writes.
    pub fn preallocate(&self, total_bytes: u64) -> Result<(), TransferError> {
        if total_bytes == 0 {
            return Ok(());
        }
        #[cfg(target_os = "android")]
        {
            let rc = unsafe { libc::posix_fallocate64(self.file.as_raw_fd(), 0, total_bytes as libc::off64_t) };
            if rc == libc::ENOSPC {
                return Err(TransferError::InsufficientStorage {
                    required: total_bytes,
                    available: 0,
                });
            }
            if rc == libc::EFBIG {
                return Err(TransferError::Fat32SizeLimitExceeded { size: total_bytes });
            }
            if rc == 0 {
                return Ok(());
            }
        }
        self.file.set_len(total_bytes)?;
        Ok(())
    }

    /// Thread-safe positional write (`pwrite`) with optional BLAKE3 verification.
    #[cfg(unix)]
    pub fn write_verified_range(
        &self,
        chunk_index: u32,
        offset: u64,
        data: &[u8],
        expected_blake3_hex: Option<&str>,
    ) -> Result<String, TransferError> {
        let digest = blake3::hash(data).to_hex().to_string();
        if let Some(expected) = expected_blake3_hex {
            if !digest.eq_ignore_ascii_case(expected) {
                return Err(TransferError::ChunkIntegrityFailed { chunk_index });
            }
        }
        self.file.write_all_at(data, offset)?;
        Ok(digest)
    }

    /// Thread-safe positional read (`pread`) used by parallel senders and single-read Multi-send broadcaster.
    #[cfg(unix)]
    pub fn read_range_into(&self, offset: u64, buf: &mut [u8]) -> Result<usize, TransferError> {
        Ok(self.file.read_at(buf, offset)?)
    }

    pub fn sync_before_atomic_publish(&self) -> Result<(), TransferError> {
        self.file.sync_data()?;
        Ok(())
    }
}
