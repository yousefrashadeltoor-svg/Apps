use parking_lot::RwLock;
use rcgen::{BasicConstraints, CertificateParams, DistinguishedName, DnType, IsCa, KeyPair, SanType};
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::net::{IpAddr, Ipv4Addr};
use std::path::{Component, Path, PathBuf};
use std::time::{Duration, Instant};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum SecurityError {
    #[error("اتصال مرفوض: العنوان خارج نطاق الشبكة المحلية")]
    NonPrivateAddress,
    #[error("الجهاز محظور بواسطة البصمة")]
    BlockedFingerprint,
    #[error("تعارض بصمة الشهادة مع البصمة المثبّتة مسبقًا (احتمال اعتراض)")]
    FingerprintMismatch,
    #[error("مسار ملف غير آمن أو يحتوي انتقالًا خارج مجلد JOPRO")]
    UnsafeRelativePath,
    #[error("تجاوز الحد المسموح لمحاولات رمز PIN، انتظر {retry_after_secs} ثانية")]
    PinRateLimited { retry_after_secs: u64 },
    #[error("رمز PIN غير صحيح")]
    InvalidPin,
    #[error("فشل مصادقة المقطع (BLAKE3-MAC)")]
    ChunkMacMismatch,
    #[error("فشل توليد الشهادة المحلية: {0}")]
    CertGeneration(String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CipherProfile {
    Tls13Aes256GcmHardware,
    Tls13ChaCha20Poly1305,
    MaxPerfAuthenticatedCleartext,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrustedPeer {
    pub fingerprint: String,
    pub alias: String,
    pub auto_accept: bool,
    pub pinned_unix_secs: u64,
}

/// Strictly confines all sockets to RFC1918, Link-Local, Wi-Fi Direct (192.168.49.x), and ULA.
pub fn is_private_lan_ip(ip: IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => {
            v4.is_private()
                || v4.is_link_local()
                || v4.is_loopback()
                || v4 == Ipv4Addr::new(224, 0, 0, 167)
        }
        IpAddr::V6(v6) => {
            let seg0 = v6.segments()[0];
            v6.is_loopback() || (seg0 & 0xfe00) == 0xfc00 || (seg0 & 0xffc0) == 0xfe80
        }
    }
}

/// Sanitizes incoming file paths from peers or browser uploads to prevent path traversal,
/// NUL injection, absolute paths, and Windows/Unix reserved names.
pub fn sanitize_receive_path(base_dir: &Path, untrusted_rel: &str) -> Result<PathBuf, SecurityError> {
    if untrusted_rel.is_empty() || untrusted_rel.contains('\0') {
        return Err(SecurityError::UnsafeRelativePath);
    }
    let normalized = untrusted_rel.replace('\\', "/");
    let mut clean = PathBuf::from(base_dir);
    let mut depth = 0usize;

    for comp in Path::new(&normalized).components() {
        match comp {
            Component::Normal(seg) => {
                let s = seg.to_string_lossy();
                let trimmed = s.trim();
                if trimmed.is_empty() || trimmed == "." || trimmed == ".." || trimmed.starts_with(".jopro_tmp") {
                    return Err(SecurityError::UnsafeRelativePath);
                }
                clean.push(trimmed);
                depth += 1;
                if depth > 12 {
                    return Err(SecurityError::UnsafeRelativePath);
                }
            }
            _ => return Err(SecurityError::UnsafeRelativePath),
        }
    }

    if depth == 0 || !clean.starts_with(base_dir) {
        return Err(SecurityError::UnsafeRelativePath);
    }
    Ok(clean)
}

/// Detects ARMv8 Crypto Extensions / x86 AES-NI so low-end chips without hardware AES
/// automatically select ChaCha20-Poly1305 for 2.5x higher TLS throughput.
pub fn select_optimal_cipher(max_perf_opted_in: bool) -> CipherProfile {
    if max_perf_opted_in {
        return CipherProfile::MaxPerfAuthenticatedCleartext;
    }
    if has_hardware_aes() {
        CipherProfile::Tls13Aes256GcmHardware
    } else {
        CipherProfile::Tls13ChaCha20Poly1305
    }
}

pub fn has_hardware_aes() -> bool {
    #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
    {
        return std::arch::is_x86_feature_detected!("aes");
    }
    #[cfg(any(target_arch = "aarch64", target_arch = "arm"))]
    {
        if let Ok(cpuinfo) = std::fs::read_to_string("/proc/cpuinfo") {
            let lower = cpuinfo.to_ascii_lowercase();
            return lower.contains(" aes ") || lower.ends_with(" aes") || lower.contains("pmull");
        }
        false
    }
    #[cfg(not(any(
        target_arch = "x86",
        target_arch = "x86_64",
        target_arch = "aarch64",
        target_arch = "arm"
    )))]
    {
        false
    }
}

/// Authenticates each range chunk in Max-Performance mode using BLAKE3 keyed-hash
/// derived from the TLS-negotiated 32-byte session secret (prevents LAN packet injection).
pub fn compute_chunk_mac(session_key: &[u8; 32], file_id: &str, chunk_index: u64, data: &[u8]) -> [u8; 32] {
    let mut hasher = blake3::Hasher::new_keyed(session_key);
    hasher.update(file_id.as_bytes());
    hasher.update(&chunk_index.to_le_bytes());
    hasher.update(&(data.len() as u64).to_le_bytes());
    hasher.update(data);
    *hasher.finalize().as_bytes()
}

pub fn verify_chunk_mac(
    session_key: &[u8; 32],
    file_id: &str,
    chunk_index: u64,
    data: &[u8],
    expected_mac: &[u8; 32],
) -> Result<(), SecurityError> {
    let actual = compute_chunk_mac(session_key, file_id, chunk_index, data);
    // Constant-time comparison via blake3::Hash PartialEq
    let a = blake3::Hash::from_bytes(actual);
    let b = blake3::Hash::from_bytes(*expected_mac);
    if a == b {
        Ok(())
    } else {
        Err(SecurityError::ChunkMacMismatch)
    }
}

struct PinAttemptState {
    failures: u32,
    locked_until: Option<Instant>,
}

pub struct TrustStore {
    blocked_fingerprints: RwLock<HashSet<String>>,
    trusted_peers: RwLock<HashMap<String, TrustedPeer>>,
    pin_attempts: RwLock<HashMap<String, PinAttemptState>>,
}

impl Default for TrustStore {
    fn default() -> Self {
        Self::new()
    }
}

impl TrustStore {
    pub fn new() -> Self {
        Self {
            blocked_fingerprints: RwLock::new(HashSet::new()),
            trusted_peers: RwLock::new(HashMap::new()),
            pin_attempts: RwLock::new(HashMap::new()),
        }
    }

    /// Blocked peers receive zero discovery responses and immediate handshake drop.
    pub fn is_blocked(&self, fingerprint: &str) -> bool {
        self.blocked_fingerprints.read().contains(fingerprint)
    }

    pub fn block_peer(&self, fingerprint: String) {
        self.trusted_peers.write().remove(&fingerprint);
        self.blocked_fingerprints.write().insert(fingerprint);
    }

    pub fn unblock_peer(&self, fingerprint: &str) -> bool {
        self.blocked_fingerprints.write().remove(fingerprint)
    }

    pub fn pin_peer(&self, peer: TrustedPeer) {
        self.blocked_fingerprints.write().remove(&peer.fingerprint);
        self.trusted_peers.write().insert(peer.fingerprint.clone(), peer);
    }

    pub fn verify_peer_identity(&self, claimed_id: &str, cert_fingerprint: &str) -> Result<bool, SecurityError> {
        if self.is_blocked(cert_fingerprint) {
            return Err(SecurityError::BlockedFingerprint);
        }
        let trusted = self.trusted_peers.read();
        if let Some(existing) = trusted.get(claimed_id) {
            if existing.fingerprint != cert_fingerprint {
                return Err(SecurityError::FingerprintMismatch);
            }
            return Ok(existing.auto_accept);
        }
        Ok(false)
    }

    /// Exponential lock-out after 5 failed PIN guesses per fingerprint/IP.
    pub fn verify_session_pin(&self, client_key: &str, expected: &str, provided: &str) -> Result<(), SecurityError> {
        let now = Instant::now();
        let mut map = self.pin_attempts.write();
        let entry = map.entry(client_key.to_string()).or_insert(PinAttemptState {
            failures: 0,
            locked_until: None,
        });

        if let Some(until) = entry.locked_until {
            if until > now {
                return Err(SecurityError::PinRateLimited {
                    retry_after_secs: (until - now).as_secs().max(1),
                });
            }
        }

        let exp_hash = blake3::hash(expected.as_bytes());
        let prv_hash = blake3::hash(provided.as_bytes());
        if exp_hash == prv_hash {
            entry.failures = 0;
            entry.locked_until = None;
            Ok(())
        } else {
            entry.failures = entry.failures.saturating_add(1);
            if entry.failures >= 5 {
                let backoff = 15u64.saturating_mul(1u64 << (entry.failures - 5).min(5));
                entry.locked_until = Some(now + Duration::from_secs(backoff));
                Err(SecurityError::PinRateLimited {
                    retry_after_secs: backoff,
                })
            } else {
                Err(SecurityError::InvalidPin)
            }
        }
    }
}

pub struct LocalCaBundle {
    pub ca_cert_pem: String,
    pub server_cert_pem: String,
    pub server_key_pem: String,
    pub fingerprint_hex: String,
}

/// Generates a device-local Root CA + leaf certificate with IP SAN and jopro.local DNS SAN
/// so browsers can unlock Secure Context APIs completely offline.
pub fn generate_local_ca_and_leaf(lan_ip: IpAddr, device_alias: &str) -> Result<LocalCaBundle, SecurityError> {
    let ca_key = KeyPair::generate().map_err(|e| SecurityError::CertGeneration(e.to_string()))?;
    let mut ca_params = CertificateParams::default();
    ca_params.is_ca = IsCa::Ca(BasicConstraints::Constrained(0));
    let mut ca_dn = DistinguishedName::new();
    ca_dn.push(DnType::CommonName, format!("SISI Share Local CA ({device_alias})"));
    ca_dn.push(DnType::OrganizationName, "JOPRO Offline LAN");
    ca_params.distinguished_name = ca_dn;
    let ca_cert = ca_params
        .self_signed(&ca_key)
        .map_err(|e| SecurityError::CertGeneration(e.to_string()))?;

    let leaf_key = KeyPair::generate().map_err(|e| SecurityError::CertGeneration(e.to_string()))?;
    let mut leaf_params = CertificateParams::default();
    leaf_params.subject_alt_names = vec![
        SanType::IpAddress(lan_ip),
        SanType::DnsName("jopro.local".try_into().map_err(|e: rcgen::Error| SecurityError::CertGeneration(e.to_string()))?),
    ];
    let mut leaf_dn = DistinguishedName::new();
    leaf_dn.push(DnType::CommonName, device_alias);
    leaf_params.distinguished_name = leaf_dn;

    let leaf_cert = leaf_params
        .signed_by(&leaf_key, &ca_cert, &ca_key)
        .map_err(|e| SecurityError::CertGeneration(e.to_string()))?;

    let fp = blake3::hash(leaf_cert.der().as_ref()).to_hex().to_string();
    Ok(LocalCaBundle {
        ca_cert_pem: ca_cert.pem(),
        server_cert_pem: leaf_cert.pem(),
        server_key_pem: leaf_key.serialize_pem(),
        fingerprint_hex: fp[..32].to_ascii_uppercase(),
    })
}
