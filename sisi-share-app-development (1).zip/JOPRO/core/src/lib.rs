pub mod protocol;
pub mod security;
pub mod transfer;
pub mod watch;

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::{IpAddr, Ipv4Addr};
    use std::path::Path;

    #[test]
    fn rejects_path_traversal_and_accepts_jopro_subfolders() {
        let base = Path::new("/storage/emulated/0/Download/JOPRO");
        assert!(security::sanitize_receive_path(base, "../DCIM/evil.apk").is_err());
        assert!(security::sanitize_receive_path(base, "Images/../../secret").is_err());
        assert!(security::sanitize_receive_path(base, "/etc/passwd").is_err());
        assert!(security::sanitize_receive_path(base, "a\0b.jpg").is_err());

        let ok = security::sanitize_receive_path(base, "Videos/trip_4k.mkv").unwrap();
        assert_eq!(ok, base.join("Videos").join("trip_4k.mkv"));
    }

    #[test]
    fn confines_network_strictly_to_local_lan() {
        assert!(security::is_private_lan_ip(IpAddr::V4(Ipv4Addr::new(192, 168, 1, 42))));
        assert!(security::is_private_lan_ip(IpAddr::V4(Ipv4Addr::new(192, 168, 49, 1)))); // Wi-Fi Direct GO
        assert!(security::is_private_lan_ip(IpAddr::V4(Ipv4Addr::new(224, 0, 0, 167)))); // LocalSend Multicast
        assert!(!security::is_private_lan_ip(IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8))));
    }

    #[test]
    fn enforces_fingerprint_blocklist_and_tofu_pinning() {
        let store = security::TrustStore::new();
        store.pin_peer(security::TrustedPeer {
            fingerprint: "FP_ALICE_01".into(),
            alias: "Galaxy S24".into(),
            auto_accept: true,
            pinned_unix_secs: 1_740_000_000,
        });
        assert!(store.verify_peer_identity("FP_ALICE_01", "FP_ALICE_01").unwrap());
        assert!(store.verify_peer_identity("FP_ALICE_01", "FP_SPOOFED").is_err());

        store.block_peer("FP_ALICE_01".into());
        assert!(store.is_blocked("FP_ALICE_01"));
        assert!(store.verify_peer_identity("FP_ALICE_01", "FP_ALICE_01").is_err());
    }

    #[test]
    fn verifies_max_perf_blake3_chunk_mac() {
        let key = [0x42u8; 32];
        let payload = b"JOPRO zero-copy range payload";
        let mac = security::compute_chunk_mac(&key, "file_7", 3, payload);
        assert!(security::verify_chunk_mac(&key, "file_7", 3, payload, &mac).is_ok());
        assert!(security::verify_chunk_mac(&key, "file_7", 4, payload, &mac).is_err());
    }

    #[test]
    fn detects_fat32_4gb_limit_and_tracks_chunk_resume() {
        let five_gb = 5 * 1024 * 1024 * 1024u64;
        let twenty_gb = 20 * 1024 * 1024 * 1024u64;
        assert!(transfer::preflight_storage_check(five_gb, twenty_gb, true).is_err());
        assert!(transfer::preflight_storage_check(five_gb, twenty_gb, false).is_ok());

        let mut manifest = transfer::ResumeManifest::new("s1".into(), "f1".into(), 10_000_000, 4_000_000);
        assert_eq!(manifest.missing_indices(), vec![0, 1, 2]);
        manifest.mark_verified(0, "abc".into());
        manifest.mark_verified(2, "def".into());
        assert_eq!(manifest.missing_indices(), vec![1]);
        assert_eq!(manifest.completed_bytes(), 6_000_000);
    }

    #[test]
    fn filters_split_apks_by_receiver_device_capabilities() {
        let a20 = protocol::ReceiverApkCapabilities {
            supported_abis: vec!["arm64-v8a".into(), "armeabi-v7a".into()],
            density_dpi: 280, // hdpi
            sdk_int: 30,
            locales: vec!["ar".into(), "en".into()],
            supports_multi_apk_session: true,
        };
        let splits = vec![
            "base.apk".into(),
            "split_config.arm64_v8a.apk".into(),
            "split_config.x86_64.apk".into(),
            "split_config.hdpi.apk".into(),
            "split_config.xxxhdpi.apk".into(),
            "split_config.ar.apk".into(),
            "split_config.ja.apk".into(),
        ];
        let selected = a20.filter_required_splits(&splits);
        assert_eq!(
            selected,
            vec![
                "base.apk",
                "split_config.arm64_v8a.apk",
                "split_config.hdpi.apk",
                "split_config.ar.apk"
            ]
        );
    }

    #[test]
    fn parses_watch_ranges_and_computes_ntp_sync() {
        assert_eq!(watch::parse_http_byte_range("bytes=0-1023", 50_000), Some((0, 1023)));
        assert_eq!(watch::parse_http_byte_range("bytes=49000-", 50_000), Some((49000, 49999)));
        let sample = watch::compute_ntp_offset(1000, 1012, 1013, 1017);
        assert_eq!(sample.rtt_ms, 16);
        assert_eq!(sample.clock_offset_ms, 4);

        let tier = watch::select_browser_playback_tier(false, true, false, false, true);
        assert_eq!(tier, watch::BrowserPlaybackTier::Tier3AudioOnlyAacRemux);
    }
}
