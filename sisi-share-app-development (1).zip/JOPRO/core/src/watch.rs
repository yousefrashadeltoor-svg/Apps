use parking_lot::RwLock;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Parses RFC 9110 `Range: bytes=start-end` header for zero-disk-save streaming of 50GB+ files.
pub fn parse_http_byte_range(header: &str, file_size: u64) -> Option<(u64, u64)> {
    if file_size == 0 {
        return None;
    }
    let spec = header.trim().strip_prefix("bytes=")?;
    let first = spec.split(',').next()?.trim();
    let (start_s, end_s) = first.split_once('-')?;

    if start_s.is_empty() {
        // Suffix byte range: bytes=-N
        let suffix: u64 = end_s.parse().ok()?;
        if suffix == 0 {
            return None;
        }
        let start = file_size.saturating_sub(suffix);
        return Some((start, file_size - 1));
    }

    let start: u64 = start_s.parse().ok()?;
    if start >= file_size {
        return None;
    }
    let end = if end_s.is_empty() {
        file_size - 1
    } else {
        end_s.parse::<u64>().ok()?.min(file_size - 1)
    };
    if start > end {
        None
    } else {
        Some((start, end))
    }
}

/// NTP-style 4-timestamp clock offset & round-trip delay estimator (milliseconds).
/// t1 = viewer send, t2 = host recv, t3 = host send, t4 = viewer recv.
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct NtpSyncSample {
    pub clock_offset_ms: i64,
    pub rtt_ms: i64,
}

pub fn compute_ntp_offset(t1_ms: i64, t2_ms: i64, t3_ms: i64, t4_ms: i64) -> NtpSyncSample {
    let rtt = (t4_ms - t1_ms) - (t3_ms - t2_ms);
    let offset = ((t2_ms - t1_ms) + (t3_ms - t4_ms)) / 2;
    NtpSyncSample {
        clock_offset_ms: offset,
        rtt_ms: rtt.max(0),
    }
}

/// Drift correction policy: micro rate nudge for 45..450ms drift, hard seek only above 450ms.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum DriftAction {
    InSync,
    AdjustPlaybackRate(f32),
    HardSeekToMs(u64),
}

pub fn evaluate_drift(expected_pos_ms: u64, actual_pos_ms: u64, base_rate: f32) -> DriftAction {
    let diff_ms = expected_pos_ms as i64 - actual_pos_ms as i64;
    let abs = diff_ms.unsigned_abs();
    if abs <= 45 {
        DriftAction::InSync
    } else if abs <= 450 {
        let factor = if diff_ms > 0 { 1.04 } else { 0.96 };
        DriftAction::AdjustPlaybackRate((base_rate * factor).clamp(0.5, 2.0))
    } else {
        DriftAction::HardSeekToMs(expected_pos_ms)
    }
}

/// Capability Ladder (Section 18.7) for browser Watch Together playback.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BrowserPlaybackTier {
    Tier1DirectHttpRange,
    Tier2FragmentedMp4Remux,
    Tier3AudioOnlyAacRemux,
    Tier4OptInHardwareTranscode,
    Tier5OpenInNativeApp,
}

pub fn select_browser_playback_tier(
    container_supported_directly: bool,
    mse_video_codec_supported: bool,
    mse_audio_codec_supported: bool,
    user_explicitly_allowed_hw_transcode: bool,
    is_low_end_host: bool,
) -> BrowserPlaybackTier {
    if container_supported_directly && mse_video_codec_supported && mse_audio_codec_supported {
        BrowserPlaybackTier::Tier1DirectHttpRange
    } else if mse_video_codec_supported && mse_audio_codec_supported {
        BrowserPlaybackTier::Tier2FragmentedMp4Remux
    } else if mse_video_codec_supported && !mse_audio_codec_supported {
        // Common MKV (H.264/HEVC + AC3/DTS) -> remux video untouched + lightweight AAC audio
        BrowserPlaybackTier::Tier3AudioOnlyAacRemux
    } else if user_explicitly_allowed_hw_transcode && !is_low_end_host {
        BrowserPlaybackTier::Tier4OptInHardwareTranscode
    } else {
        BrowserPlaybackTier::Tier5OpenInNativeApp
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WatchViewerState {
    pub viewer_id: String,
    pub alias: String,
    pub drift_ms: i64,
    pub using_shared_ring: bool,
}

/// Shared single-read bounded ring window (default 16 MiB). Viewers falling behind the window
/// automatically detach to an independent `pread` cursor without stalling synchronized viewers.
pub struct SharedReadRing {
    window_bytes: u64,
    state: RwLock<(u64, Vec<u8>)>, // (base_file_offset, window_data)
    viewers: RwLock<HashMap<String, WatchViewerState>>,
}

impl SharedReadRing {
    pub fn new(window_bytes: usize) -> Self {
        Self {
            window_bytes: window_bytes as u64,
            state: RwLock::new((0, Vec::with_capacity(window_bytes))),
            viewers: RwLock::new(HashMap::new()),
        }
    }

    pub fn try_serve_from_ring(&self, viewer_id: &str, file_offset: u64, max_len: usize) -> Option<Vec<u8>> {
        let guard = self.state.read();
        let (base, ref buf) = *guard;
        let end = base + (buf.len() as u64);
        let hit = file_offset >= base && file_offset < end;
        if let Some(v) = self.viewers.write().get_mut(viewer_id) {
            v.using_shared_ring = hit;
        }
        if !hit {
            return None;
        }
        let rel = (file_offset - base) as usize;
        let take = (buf.len() - rel).min(max_len);
        Some(buf[rel..rel + take].to_vec())
    }

    pub fn advance_window(&self, new_base_offset: u64, chunk: &[u8]) {
        let mut guard = self.state.write();
        let capped = if (chunk.len() as u64) > self.window_bytes {
            &chunk[..self.window_bytes as usize]
        } else {
            chunk
        };
        guard.0 = new_base_offset;
        guard.1.clear();
        guard.1.extend_from_slice(capped);
    }
}
