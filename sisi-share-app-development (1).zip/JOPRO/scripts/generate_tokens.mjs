#!/usr/bin/env node
/**
 * JOPRO Design Token Compiler (Zero-dependency Node.js script)
 * Single source of truth: JOPRO/design/tokens.json
 * Outputs:
 *   1. JOPRO/css/tokens.css
 *   2. src/styles/tokens.css (if running inside preview workspace)
 *   3. JOPRO/app/lib/theme/jopro_tokens.g.dart
 *   4. JOPRO/app/android/app/src/main/res/values/tokens.xml
 *   5. JOPRO/app/android/app/src/main/res/values-night/tokens.xml
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const joproRoot = path.resolve(__dirname, '..');
const workspaceRoot = path.resolve(joproRoot, '..');
const tokensPath = path.join(joproRoot, 'design', 'tokens.json');
const tokens = JSON.parse(fs.readFileSync(tokensPath, 'utf8'));

function toKebab(str) {
  return str.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
}

function writeOut(filePath, content) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, 'utf8');
  console.log(`[tokens] generated -> ${path.relative(workspaceRoot, filePath)}`);
}

// 1. Generate CSS Tokens
function buildCss() {
  const lines = [
    '/* AUTO-GENERATED FROM JOPRO/design/tokens.json — DO NOT EDIT MANUALLY */',
    ':root, [data-theme="dark"] {',
    '  --jp-speed-factor: 1;',
  ];
  for (const [k, v] of Object.entries(tokens.color.dark)) {
    lines.push(`  --jp-${toKebab(k)}: ${v};`);
  }
  for (const [k, v] of Object.entries(tokens.elevation.dark)) {
    lines.push(`  --jp-shadow-${toKebab(k)}: ${v};`);
  }
  lines.push(`  --jp-font-ar: ${tokens.typography.fontFamilyArabic};`);
  lines.push(`  --jp-font-en: ${tokens.typography.fontFamilyLatin};`);
  lines.push(`  --jp-font-mono: ${tokens.typography.fontFamilyMono};`);
  for (const [k, v] of Object.entries(tokens.radius)) {
    lines.push(`  --jp-radius-${toKebab(k)}: ${v}px;`);
  }
  for (const [k, v] of Object.entries(tokens.spacing)) {
    lines.push(`  --jp-space-${toKebab(k)}: ${v}px;`);
  }
  for (const [k, v] of Object.entries(tokens.motion.duration)) {
    const clean = toKebab(k).replace(/-ms$/, '');
    lines.push(`  --jp-dur-${clean}: calc(${v}ms * var(--jp-speed-factor));`);
  }
  for (const [k, v] of Object.entries(tokens.motion.easing)) {
    lines.push(`  --jp-ease-${toKebab(k)}: ${v};`);
  }
  lines.push('  --jp-backdrop-blur: 14px;');
  lines.push('}');
  lines.push('');
  lines.push('[data-theme="light"] {');
  for (const [k, v] of Object.entries(tokens.color.light)) {
    lines.push(`  --jp-${toKebab(k)}: ${v};`);
  }
  for (const [k, v] of Object.entries(tokens.elevation.light)) {
    lines.push(`  --jp-shadow-${toKebab(k)}: ${v};`);
  }
  lines.push('}');
  lines.push('');
  lines.push('/* Galaxy A20 / Low-End Device Protection (no heavy blur, crisp lightweight shadows) */');
  lines.push('[data-low-end="true"] {');
  for (const [k, v] of Object.entries(tokens.elevation.lowEnd)) {
    lines.push(`  --jp-shadow-${toKebab(k)}: ${v};`);
  }
  lines.push('  --jp-backdrop-blur: 0px;');
  lines.push('}');
  lines.push('');
  lines.push('/* Accessibility: System or user Reduce Motion */');
  lines.push('[data-reduce-motion="true"] {');
  for (const k of Object.keys(tokens.motion.duration)) {
    const clean = toKebab(k).replace(/-ms$/, '');
    lines.push(`  --jp-dur-${clean}: 1ms;`);
  }
  lines.push('}');
  lines.push('@media (prefers-reduced-motion: reduce) {');
  lines.push('  :root:not([data-reduce-motion="false"]) {');
  for (const k of Object.keys(tokens.motion.duration)) {
    const clean = toKebab(k).replace(/-ms$/, '');
    lines.push(`    --jp-dur-${clean}: 1ms;`);
  }
  lines.push('  }');
  lines.push('}');
  return lines.join('\n') + '\n';
}

// 2. Generate Flutter Dart Tokens
function hexToDartColor(hex) {
  const clean = hex.replace('#', '');
  return `Color(0xFF${clean.toUpperCase()})`;
}

function buildDart() {
  const h = tokens.color.androidSolidHex;
  const r = tokens.radius;
  const s = tokens.spacing;
  const d = tokens.motion.duration;
  return `// AUTO-GENERATED FROM JOPRO/design/tokens.json — DO NOT EDIT MANUALLY
import 'package:flutter/material.dart';

abstract final class JoproTokens {
  static const String appDisplayName = 'SISI Share';
  static const String defaultReceiveFolder = '${tokens.meta.defaultReceiveFolder}';
  static const double minTouchTarget = ${tokens.meta.minTouchTargetDp}.0;

  // Dark Palette
  static const Color darkBgCanvas = ${hexToDartColor(h.darkBgCanvas)};
  static const Color darkBgSurface = ${hexToDartColor(h.darkBgSurface)};
  static const Color darkBgElevated = ${hexToDartColor(h.darkBgElevated)};
  static const Color darkTextPrimary = ${hexToDartColor(h.darkTextPrimary)};
  static const Color darkTextSecondary = ${hexToDartColor(h.darkTextSecondary)};
  static const Color darkAccentPrimary = ${hexToDartColor(h.darkAccentPrimary)};
  static const Color darkAccentSignal = ${hexToDartColor(h.darkAccentSignal)};
  static const Color darkStatusSuccess = ${hexToDartColor(h.darkStatusSuccess)};
  static const Color darkStatusDanger = ${hexToDartColor(h.darkStatusDanger)};

  // Light Palette
  static const Color lightBgCanvas = ${hexToDartColor(h.lightBgCanvas)};
  static const Color lightBgSurface = ${hexToDartColor(h.lightBgSurface)};
  static const Color lightBgElevated = ${hexToDartColor(h.lightBgElevated)};
  static const Color lightTextPrimary = ${hexToDartColor(h.lightTextPrimary)};
  static const Color lightTextSecondary = ${hexToDartColor(h.lightTextSecondary)};
  static const Color lightAccentPrimary = ${hexToDartColor(h.lightAccentPrimary)};
  static const Color lightAccentSignal = ${hexToDartColor(h.lightAccentSignal)};
  static const Color lightStatusSuccess = ${hexToDartColor(h.lightStatusSuccess)};
  static const Color lightStatusDanger = ${hexToDartColor(h.lightStatusDanger)};

  // Radii
  static const double radiusXs = ${r.xs}.0;
  static const double radiusSm = ${r.sm}.0;
  static const double radiusMd = ${r.md}.0;
  static const double radiusLg = ${r.lg}.0;
  static const double radiusXl = ${r.xl}.0;
  static const double radiusWidget = ${r.widget}.0;
  static const double radiusPill = ${r.pill}.0;

  // Spacing
  static const double spaceXxs = ${s.xxs}.0;
  static const double spaceXs = ${s.xs}.0;
  static const double spaceSm = ${s.sm}.0;
  static const double spaceMd = ${s.md}.0;
  static const double spaceLg = ${s.lg}.0;
  static const double spaceXl = ${s.xl}.0;
  static const double spaceXxl = ${s.xxl}.0;

  // Motion Durations (respects MediaQuery.disableAnimations & A20 low-end tier)
  static const Duration durInstant = Duration(milliseconds: ${d.instantMs});
  static const Duration durFast = Duration(milliseconds: ${d.fastMs});
  static const Duration durNormal = Duration(milliseconds: ${d.normalMs});
  static const Duration durEmphasized = Duration(milliseconds: ${d.emphasizedMs});
  static const Duration durHero = Duration(milliseconds: ${d.heroMs});
  static const Duration durRadarCycle = Duration(milliseconds: ${d.radarCycleMs});

  // Motion Curves
  static const Curve easeStandard = Cubic(0.2, 0.0, 0.0, 1.0);
  static const Curve easeDecelerate = Cubic(0.05, 0.7, 0.1, 1.0);
  static const Curve easeAccelerate = Cubic(0.3, 0.0, 0.8, 0.15);
  static const Curve easeSpring = Cubic(0.22, 1.0, 0.36, 1.0);

  static Duration resolveDuration(
    Duration base, {
    required bool disableAnimations,
    required bool isLowEndDevice,
  }) {
    if (disableAnimations) return Duration.zero;
    if (isLowEndDevice) {
      return Duration(
        milliseconds: (base.inMilliseconds * ${tokens.motion.lowEndMultiplier}).round(),
      );
    }
    return base;
  }

  static ThemeData buildTheme({
    required Brightness brightness,
    ColorScheme? dynamicScheme,
    required bool isArabic,
  }) {
    final isDark = brightness == Brightness.dark;
    final baseScheme = dynamicScheme ??
        ColorScheme(
          brightness: brightness,
          primary: isDark ? darkAccentPrimary : lightAccentPrimary,
          onPrimary: Colors.white,
          secondary: isDark ? darkAccentSignal : lightAccentSignal,
          onSecondary: Colors.white,
          error: isDark ? darkStatusDanger : lightStatusDanger,
          onError: Colors.white,
          surface: isDark ? darkBgSurface : lightBgSurface,
          onSurface: isDark ? darkTextPrimary : lightTextPrimary,
        );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: baseScheme,
      scaffoldBackgroundColor: isDark ? darkBgCanvas : lightBgCanvas,
      fontFamily: isArabic ? 'IBMPlexSansArabic' : 'Inter',
      materialTapTargetSize: MaterialTapTargetSize.padded,
      cardTheme: CardThemeData(
        color: isDark ? darkBgSurface : lightBgSurface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusLg),
        ),
      ),
    );
  }
}
`;
}

// 3. Generate Android XML Tokens (values & values-night)
function buildAndroidXml(isNight) {
  const h = tokens.color.androidSolidHex;
  const p = isNight ? 'dark' : 'light';
  const lines = [
    '<?xml version="1.0" encoding="utf-8"?>',
    '<!-- AUTO-GENERATED FROM JOPRO/design/tokens.json — DO NOT EDIT MANUALLY -->',
    '<resources>',
    `    <color name="jopro_bg_canvas">${h[`${p}BgCanvas`]}</color>`,
    `    <color name="jopro_bg_surface">${h[`${p}BgSurface`]}</color>`,
    `    <color name="jopro_bg_elevated">${h[`${p}BgElevated`]}</color>`,
    `    <color name="jopro_text_primary">${h[`${p}TextPrimary`]}</color>`,
    `    <color name="jopro_text_secondary">${h[`${p}TextSecondary`]}</color>`,
    `    <color name="jopro_accent_primary">${h[`${p}AccentPrimary`]}</color>`,
    `    <color name="jopro_accent_signal">${h[`${p}AccentSignal`]}</color>`,
    `    <color name="jopro_status_success">${h[`${p}StatusSuccess`]}</color>`,
    `    <color name="jopro_status_danger">${h[`${p}StatusDanger`]}</color>`,
  ];
  if (!isNight) {
    lines.push(`    <dimen name="jopro_radius_sm">${tokens.radius.sm}dp</dimen>`);
    lines.push(`    <dimen name="jopro_radius_md">${tokens.radius.md}dp</dimen>`);
    lines.push(`    <dimen name="jopro_radius_lg">${tokens.radius.lg}dp</dimen>`);
    lines.push(`    <dimen name="jopro_radius_widget">${tokens.radius.widget}dp</dimen>`);
    lines.push(`    <dimen name="jopro_space_xs">${tokens.spacing.xs}dp</dimen>`);
    lines.push(`    <dimen name="jopro_space_sm">${tokens.spacing.sm}dp</dimen>`);
    lines.push(`    <dimen name="jopro_space_md">${tokens.spacing.md}dp</dimen>`);
    lines.push(`    <dimen name="jopro_touch_min">${tokens.meta.minTouchTargetDp}dp</dimen>`);
  }
  lines.push('</resources>');
  return lines.join('\n') + '\n';
}

const css = buildCss();
writeOut(path.join(joproRoot, 'css', 'tokens.css'), css);
if (fs.existsSync(path.join(workspaceRoot, 'src'))) {
  writeOut(path.join(workspaceRoot, 'src', 'styles', 'tokens.css'), css);
}
writeOut(path.join(joproRoot, 'app', 'lib', 'theme', 'jopro_tokens.g.dart'), buildDart());
writeOut(
  path.join(joproRoot, 'app', 'android', 'app', 'src', 'main', 'res', 'values', 'tokens.xml'),
  buildAndroidXml(false)
);
writeOut(
  path.join(joproRoot, 'app', 'android', 'app', 'src', 'main', 'res', 'values-night', 'tokens.xml'),
  buildAndroidXml(true)
);
