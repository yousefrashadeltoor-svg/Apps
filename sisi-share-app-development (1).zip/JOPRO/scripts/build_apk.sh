#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FLAVOR="${1:-both}" # play | full | both
MODE="${2:-release}" # debug | release

echo "==> [1/5] Generating unified Design Tokens (CSS + Dart + Android XML)"
node "$ROOT_DIR/scripts/generate_tokens.mjs"

echo "==> [2/5] Cross-compiling Rust Core (arm64-v8a, armeabi-v7a, x86_64) with 16KB page alignment"
pushd "$ROOT_DIR/core" >/dev/null
cargo ndk \
  -t arm64-v8a \
  -t armeabi-v7a \
  -t x86_64 \
  -o "$ROOT_DIR/app/android/app/src/main/jniLibs" \
  build --release
popd >/dev/null

echo "==> [3/5] Verifying 16KB (0x4000) ELF LOAD segment alignment on 64-bit .so libraries"
READELF="${ANDROID_NDK_HOME:-}/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf"
if [[ ! -x "$READELF" ]]; then
  READELF="$(command -v readelf)"
fi
for ABI in arm64-v8a x86_64; do
  SO_FILE="$ROOT_DIR/app/android/app/src/main/jniLibs/$ABI/libjopro_core.so"
  UNALIGNED="$("$READELF" -l "$SO_FILE" | awk '/LOAD/ { if ($NF != "0x4000" && $NF != "0x10000") print $0 }')"
  if [[ -n "$UNALIGNED" ]]; then
    echo "ERROR: $SO_FILE failed 16KB page alignment check:"
    echo "$UNALIGNED"
    exit 1
  fi
  echo "    [OK] $ABI/libjopro_core.so verified 16KB aligned"
done

echo "==> [4/5] Building offline embedded Web Client (--no-web-resources-cdn + gzip/brotli)"
bash "$ROOT_DIR/scripts/build_web.sh"

echo "==> [5/5] Building SISI Share Android APK ($FLAVOR / $MODE)"
pushd "$ROOT_DIR/app" >/dev/null
build_one() {
  local flv="$1"
  flutter build apk "--$MODE" --flavor "$flv" --split-per-abi
  echo "    [OK] Built APK splits for flavor=$flv ($MODE)"
}
if [[ "$FLAVOR" == "both" ]]; then
  build_one "play"
  build_one "full"
else
  build_one "$FLAVOR"
fi
popd >/dev/null
