#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/app/assets/web_client"

echo "==> Building offline Flutter Web Client (zero CDN, local CanvasKit)"
pushd "$ROOT_DIR/app" >/dev/null
flutter build web \
  --release \
  --no-web-resources-cdn \
  --pwa-strategy=none \
  --target=lib/web_client_main.dart \
  --output="$OUT_DIR"
popd >/dev/null

echo "==> Pre-compressing static assets (gzip -9 & brotli -q 11) for zero-CPU serving on phone"
find "$OUT_DIR" -type f \( -name "*.js" -o -name "*.wasm" -o -name "*.css" -o -name "*.html" -o -name "*.json" -o -name "*.ttf" \) | while read -r f; do
  gzip -9 -k -f "$f"
  if command -v brotli >/dev/null 2>&1; then
    brotli -q 11 -k -f "$f"
  fi
done
echo "==> Offline Web Client ready in $OUT_DIR (never imports preview files from root index.html)"
