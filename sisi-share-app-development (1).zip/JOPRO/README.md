# SISI Share — مشروع `JOPRO`

تطبيق Android أصلي عالي الأداء لمشاركة الملفات، ومشاركة الويب عبر المتصفح، والمشاهدة المشتركة الحية (Watch Together) عبر الشبكة المحلية **بدون إنترنت 100%**، متوافق مع بروتوكول **LocalSend v2.1** ومعزَّز بنواة **Rust (`Nova v1`)** وتصميم جديد كليًا.

## 1. هيكل المشروع
- `index.html` + `css/` + `js/`: **تطبيق ويب المعاينة (القسم 14)** — معاينة تصميم فقط ببيانات عيّنة، يُفتح بالنقر المزدوج عبر `file://` بدون خادم ولا يدخل أي سطر منه في الـ APK أو في `web_client/`.
- `design/tokens.json` + `design/design-spec.md`: المصدر الوحيد لنظام التصميم والمواصفات البصرية.
- `core/`: نواة Rust (`tokio` + `axum/hyper` + `rustls` + `mdns-sd` + `blake3`).
- `bridge/`: جسر `flutter_rust_bridge` بلا نسخ (تمرير `RawFd` والمسارات فقط).
- `app/`: تطبيق Flutter + طبقة Android الأصلية بـ Kotlin (مجلد الاستقبال الافتراضي `Download/JOPRO`).
- `scripts/`: سكربتات توليد الـ tokens وبناء الـ APK (مع فحص محاذاة **16KB**) وبناء عميل الويب بدون CDN.
- `docs/`: `ARCHITECTURE.md` و`LIMITATIONS.md` و`BENCHMARK.md`.

## 2. إنشاء مفتاح التوقيع المحلي وبناء الـ APK
```bash
# 1) إنشاء مفتاح توقيع Release محلي (لا يُرفع إلى Git)
keytool -genkeypair -v \
  -keystore app/android/jopro-release.jks \
  -keyalg RSA -keysize 4096 -validity 10000 \
  -alias sisi_share_release

# 2) توليد ملفات التصميم الموحدة (CSS + Dart + Android XML)
node scripts/generate_tokens.mjs

# 3) تشغيل اختبارات نواة Rust
(cd core && cargo test --release)

# 4) بناء كلتا النكهتين (play و full) مع التحقق من صفحات الذاكرة 16KB
bash scripts/build_apk.sh both release
```

## 3. نكهتا التوزيع وسياسات Google Play
| الميزة | نكهة `play` (متجر Google Play) | نكهة `full` (تثبيت مباشر / F-Droid) |
|---|---|---|
| مجلد الاستقبال | `Download/JOPRO` عبر MediaStore + مجلدات SAF | مثل `play` + خيار `/sdcard/JOPRO` عبر `MANAGE_EXTERNAL_STORAGE` (اختياري) |
| قائمة التطبيقات | `<queries>` لتطبيقات المشغّل بدون `QUERY_ALL_PACKAGES` | قائمة كاملة مع خيار إظهار تطبيقات النظام |
| تثبيت الحزم وXAPK | `PackageInstaller.Session` بتأكيد المستخدم (`REQUEST_INSTALL_PACKAGES`) | مثل `play` + طبقة Shizuku الاختيارية المعطّلة افتراضيًا |
| التحليلات / الإنترنت | صفر تحليلات، صفر CDN، شبكة محلية فقط | صفر تحليلات، صفر CDN، شبكة محلية فقط |

### إرشادات تعبئة نماذج Google Play Console
1. **الخدمة الأمامية (`connectedDevice` و`mediaPlayback`)**: وضّح أن المستخدم يبدأ نقل الملفات عبر Wi-Fi Direct/LAN أو غرفة المشاهدة المشتركة بإرادته، مع إشعار حي قابل للإيقاف.
2. **التخزين**: نكهة `play` لا تطلب `MANAGE_EXTERNAL_STORAGE` إطلاقًا وتعتمد كليًا على `MediaStore` (`Download/JOPRO`) و`SAF` والوصول الجزئي للوسائط (`READ_MEDIA_VISUAL_USER_SELECTED`).
3. **تثبيت الحزم (`REQUEST_INSTALL_PACKAGES`)**: يُستخدم حصريًا عندما ينقر المستخدم زر "تثبيت" على حزمة تطبيق استلمها محليًا من جهاز موثوق.
