//! flutter_rust_bridge v2 zero-copy API surface.
//! File payloads NEVER cross the Dart <-> Rust boundary; only detached POSIX RawFds,
//! session identifiers, and throttled (<= 1Hz) EMA progress snapshots pass through FFI.

use jopro_core::protocol::ReceiverApkCapabilities;
use jopro_core::security::{select_optimal_cipher, CipherProfile, TrustStore};
use jopro_core::transfer::{preflight_storage_check, AdaptiveLinkTuner, NativeDescriptorTarget};
use serde::{Deserialize, Serialize};
use std::sync::OnceLock;

static TRUST_STORE: OnceLock<TrustStore> = OnceLock::new();

fn trust() -> &'static TrustStore {
    TRUST_STORE.get_or_init(TrustStore::new)
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EngineProfileSnapshot {
    pub cipher_profile: CipherProfile,
    pub hardware_aes: bool,
    pub active_streams: u8,
    pub buffer_kb: u32,
    pub expected_ceiling_mbs: f64,
}

pub fn probe_device_engine_profile(
    is_low_end_device: bool,
    link_speed_mbps: u32,
    max_perf_opted_in: bool,
) -> EngineProfileSnapshot {
    let tuner = AdaptiveLinkTuner::initial(is_low_end_device, link_speed_mbps);
    EngineProfileSnapshot {
        cipher_profile: select_optimal_cipher(max_perf_opted_in),
        hardware_aes: jopro_core::security::has_hardware_aes(),
        active_streams: tuner.active_streams,
        buffer_kb: (tuner.buffer_bytes / 1024) as u32,
        expected_ceiling_mbs: (tuner.expected_ceiling_mbs() * 10.0).round() / 10.0,
    }
}

/// Accepts an Android `ParcelFileDescriptor.detachFd()` for `Download/JOPRO` (`IS_PENDING=1`)
/// and runs upfront `fallocate` + FAT32 check in Rust before accepting network ranges.
#[cfg(unix)]
pub fn prepare_receive_descriptor(
    detached_fd: i32,
    file_size: u64,
    available_bytes: u64,
    is_fat32_volume: bool,
) -> Result<(), String> {
    preflight_storage_check(file_size, available_bytes, is_fat32_volume).map_err(|e| e.to_string())?;
    let target = unsafe { NativeDescriptorTarget::from_detached_android_fd(detached_fd) };
    target.preallocate(file_size).map_err(|e| e.to_string())?;
    target.sync_before_atomic_publish().map_err(|e| e.to_string())
}

pub fn block_peer_by_fingerprint(fingerprint: String) {
    trust().block_peer(fingerprint);
}

pub fn unblock_peer_by_fingerprint(fingerprint: String) -> bool {
    trust().unblock_peer(&fingerprint)
}

pub fn compute_required_apk_splits(
    caps: ReceiverApkCapabilities,
    available_splits: Vec<String>,
) -> Vec<String> {
    caps.filter_required_splits(&available_splits)
}
