plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
}

import java.util.Properties

val keystoreProps = Properties()
val keystoreFile = rootProject.file("key.properties")
if (keystoreFile.exists()) {
    keystoreFile.inputStream().use { keystoreProps.load(it) }
}

android {
    namespace = "dev.jopro.sisishare"
    compileSdk = 35
    ndkVersion = "27.2.12479018" // NDK r27 LTS: native 16KB ELF page alignment support

    defaultConfig {
        applicationId = "dev.jopro.sisishare"
        minSdk = 24
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0"

        externalNativeBuild {
            cmake {
                arguments += listOf("-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON")
            }
        }
    }

    flavorDimensions += "distribution"
    productFlavors {
        create("play") {
            dimension = "distribution"
            buildConfigField("Boolean", "ENABLE_PRIVILEGED_HELPER", "false")
            buildConfigField("Boolean", "ALLOW_ALL_FILES_ACCESS", "false")
            resValue("string", "app_name", "SISI Share")
        }
        create("full") {
            dimension = "distribution"
            buildConfigField("Boolean", "ENABLE_PRIVILEGED_HELPER", "true")
            buildConfigField("Boolean", "ALLOW_ALL_FILES_ACCESS", "true")
            resValue("string", "app_name", "SISI Share")
        }
    }

    signingConfigs {
        create("release") {
            if (keystoreFile.exists()) {
                storeFile = file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        getByName("debug") {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = if (keystoreFile.exists()) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }

    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a", "x86_64")
            isUniversalApk = true
        }
    }

    packaging {
        jniLibs {
            // Required for 16KB memory page size compatibility on Android 15+
            useLegacyPackaging = false
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    implementation("androidx.glance:glance-appwidget:1.1.1")
    implementation("androidx.glance:glance-material3:1.1.1")
    // Bundled offline barcode scanner (zero Play Services runtime download)
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    // Shizuku optional privileged helper included strictly in `full` flavor
    "fullImplementation"("dev.rikka.shizuku:api:13.1.5")
    "fullImplementation"("dev.rikka.shizuku:provider:13.1.5")
}
