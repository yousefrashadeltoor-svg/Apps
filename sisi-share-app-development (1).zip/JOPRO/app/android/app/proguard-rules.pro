# Flutter & JNI bridge rules
-keep class io.flutter.** { *; }
-keep class com.flutter_rust_bridge.** { *; }
-keep class dev.jopro.sisishare.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
# ML Kit offline bundled barcode scanner
-keep class com.google.mlkit.** { *; }
# Shizuku optional helper (full flavor)
-dontwarn rikka.shizuku.**
-keep class rikka.shizuku.** { *; }
