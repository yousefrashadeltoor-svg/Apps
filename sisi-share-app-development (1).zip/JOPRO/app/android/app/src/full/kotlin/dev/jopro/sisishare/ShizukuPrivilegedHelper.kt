package dev.jopro.sisishare

/**
 * Section 18.1 Optional Privileged Helper (`full` flavor only, disabled by default).
 * SECURITY INVARIANT:
 * 1. Only fixed enum-mapped operations in [AllowedOperation] can execute.
 * 2. Zero network-supplied strings are ever accepted or interpolated.
 * 3. SSID/Passphrase inputs for local SoftAP are restricted to strict ASCII `[A-Za-z0-9_-]{8,32}`.
 * 4. Entire SISI Share app operates 100% cleanly without this helper using Tiers 2..5.
 */
object ShizukuPrivilegedHelper {

    enum class AllowedOperation {
        START_CUSTOM_SOFTAP,
        STOP_CUSTOM_SOFTAP,
        SILENT_SESSION_INSTALL,
        VERIFY_AND_PLACE_LOCAL_OBB
    }

    private val STRICT_LOCAL_TOKEN = Regex("^[A-Za-z0-9_-]{4,32}$")
    private val STRICT_PACKAGE_NAME = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$")

    fun buildValidatedSoftApArgs(userLocalSsid: String, userLocalPassphrase: String, prefer5Ghz: Boolean): List<String> {
        require(STRICT_LOCAL_TOKEN.matches(userLocalSsid)) { "اسم الشبكة يقبل أحرفًا لاتينية وأرقامًا فقط (4–32)" }
        require(userLocalPassphrase.length in 8..32 && STRICT_LOCAL_TOKEN.matches(userLocalPassphrase)) {
            "كلمة المرور تقبل أحرفًا لاتينية وأرقامًا فقط (8–32)"
        }
        val bandFlag = if (prefer5Ghz) "5" else "2"
        // Passed as discrete argv array (never through `sh -c`)
        return listOf("cmd", "wifi", "start-softap", userLocalSsid, "wpa2", userLocalPassphrase, "-b", bandFlag)
    }

    fun validateLocalPackageName(pkg: String): Boolean = STRICT_PACKAGE_NAME.matches(pkg)
}
