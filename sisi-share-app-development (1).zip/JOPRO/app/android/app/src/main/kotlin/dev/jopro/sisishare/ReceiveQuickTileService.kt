package dev.jopro.sisishare

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Quick Settings Tile ("الاستقبال"): explicit two-state visibility toggle.
 * Allowed foreground-service start exemption on Android 12+ (API 31+) upon user tile tap.
 */
class ReceiveQuickTileService : TileService() {

    private fun isReceiveEnabled(): Boolean =
        getSharedPreferences("jopro_state", MODE_PRIVATE).getBoolean("receive_active", false)

    private fun setReceiveEnabled(enabled: Boolean) {
        getSharedPreferences("jopro_state", MODE_PRIVATE).edit().putBoolean("receive_active", enabled).apply()
    }

    override fun onStartListening() {
        super.onStartListening()
        syncTileVisual(isReceiveEnabled())
    }

    override fun onClick() {
        super.onClick()
        val next = !isReceiveEnabled()
        setReceiveEnabled(next)
        val svcIntent = Intent(this, JoproForegroundService::class.java)
        if (next) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svcIntent)
            } else {
                startService(svcIntent)
            }
        } else {
            stopService(svcIntent)
        }
        syncTileVisual(next)
    }

    private fun syncTileVisual(active: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "SISI الاستقبال"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (active) "مرئي · JOPRO" else "متوقف"
        }
        tile.updateTile()
    }
}
