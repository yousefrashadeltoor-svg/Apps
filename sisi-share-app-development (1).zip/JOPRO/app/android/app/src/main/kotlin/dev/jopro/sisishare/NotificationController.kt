package dev.jopro.sisishare

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat

object NotificationController {

    const val CH_TRANSFER_LIVE = "jopro_transfer_live"
    const val CH_INCOMING_APPROVAL = "jopro_incoming_approval"
    const val CH_COMPLETION = "jopro_completion"
    const val CH_WEB_AND_WATCH = "jopro_web_watch"
    const val GROUP_MULTI_SEND = "dev.jopro.sisishare.MULTI_SEND"

    const val ID_FOREGROUND_CORE = 1001
    const val ID_MULTI_SUMMARY = 1002
    const val ID_TIMEOUT_RESUME = 1003

    private val lastUpdateMsBySession = HashMap<String, Long>()

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannels(
            listOf(
                NotificationChannel(CH_TRANSFER_LIVE, "جلسات النقل الجارية", NotificationManager.IMPORTANCE_LOW).apply {
                    setSound(null, null)
                    enableVibration(false)
                },
                NotificationChannel(CH_INCOMING_APPROVAL, "طلبات الاتصال والاستقبال", NotificationManager.IMPORTANCE_HIGH).apply {
                    enableVibration(true)
                },
                NotificationChannel(CH_COMPLETION, "اكتمال وفشل النقل", NotificationManager.IMPORTANCE_DEFAULT),
                NotificationChannel(CH_WEB_AND_WATCH, "مشاركة الويب والمشاهدة المشتركة", NotificationManager.IMPORTANCE_LOW)
            )
        )
    }

    /** Strictly throttled to <= 1 update/second per session to avoid OS throttling and save CPU on A20. */
    fun postLiveTransferProgress(
        context: Context,
        sessionId: String,
        notificationId: Int,
        peerAlias: String,
        titleWithFiles: String,
        percent: Int,
        emaSpeedMbs: String,
        etaText: String,
        paused: Boolean,
        hideFileNamesOnLockScreen: Boolean,
        isMultiSendMember: Boolean
    ) {
        val now = SystemClock.elapsedRealtime()
        val prev = lastUpdateMsBySession[sessionId] ?: 0L
        if (percent in 1..99 && !paused && now - prev < 1000L) return
        lastUpdateMsBySession[sessionId] = now

        val publicVersion = NotificationCompat.Builder(context, CH_TRANSFER_LIVE)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("SISI Share · نقل جارٍ ($percent%)")
            .setContentText("$emaSpeedMbs MB/s · المتبقي $etaText")
            .setProgress(100, percent, false)
            .build()

        val builder = NotificationCompat.Builder(context, CH_TRANSFER_LIVE)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("$titleWithFiles · $percent%")
            .setContentText("$peerAlias · $emaSpeedMbs MB/s · المتبقي $etaText")
            .setProgress(100, percent.coerceIn(0, 100), false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setVisibility(
                if (hideFileNamesOnLockScreen) NotificationCompat.VISIBILITY_PRIVATE
                else NotificationCompat.VISIBILITY_PUBLIC
            )
            .setPublicVersion(publicVersion)
            .addAction(
                0,
                if (paused) "استئناف" else "إيقاف مؤقت",
                directActionIntent(context, "dev.jopro.sisishare.ACTION_PAUSE_RESUME", sessionId, notificationId * 10 + 1)
            )
            .addAction(
                0,
                "إلغاء",
                directActionIntent(context, "dev.jopro.sisishare.ACTION_CANCEL", sessionId, notificationId * 10 + 2)
            )

        if (isMultiSendMember) {
            builder.setGroup(GROUP_MULTI_SEND)
        }

        // Android 16+ (API 36 / BAKLAVA): progressive enhancement via Notification.ProgressStyle
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(notificationId, builder.build())
    }

    /** Heads-up connection request with 60s auto-expiry and direct BroadcastReceiver actions (zero trampoline). */
    fun postIncomingConnectionApproval(
        context: Context,
        requestId: String,
        notificationId: Int,
        peerAlias: String,
        fingerprintShort: String,
        summaryLine: String
    ) {
        val notif = NotificationCompat.Builder(context, CH_INCOMING_APPROVAL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("طلب اتصال من $peerAlias")
            .setContentText("$summaryLine · بصمة $fingerprintShort")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .setTimeoutAfter(60_000L) // Auto-reject after 60 seconds and notify sender
            .addAction(0, "قبول", directActionIntent(context, "dev.jopro.sisishare.ACTION_APPROVE_ONCE", requestId, notificationId * 10 + 1))
            .addAction(0, "رفض", directActionIntent(context, "dev.jopro.sisishare.ACTION_REJECT", requestId, notificationId * 10 + 2))
            .addAction(0, "حظر", directActionIntent(context, "dev.jopro.sisishare.ACTION_BLOCK_FP", requestId, notificationId * 10 + 3))
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(notificationId, notif)
    }

    fun buildServiceNotification(context: Context, activeTransfers: Int, watchActive: Boolean): Notification {
        val channel = if (watchActive) CH_WEB_AND_WATCH else CH_TRANSFER_LIVE
        val title = when {
            watchActive -> "غرفة المشاهدة المشتركة نشطة"
            activeTransfers > 0 -> "جارٍ نقل الملفات محليًا ($activeTransfers)"
            else -> "وضع الاستقبال مفعّل · مرئي للأجهزة القريبة"
        }
        return NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle(title)
            .setContentText("شبكة محلية بدون إنترنت · الحفظ في Download/JOPRO")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    fun postTimeoutResumeNotification(context: Context) {
        val notif = NotificationCompat.Builder(context, CH_COMPLETION)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("توقّف النقل مؤقتًا لبلوغ حد الخلفية في النظام")
            .setContentText("حُفظت جميع المقاطع وبصمات BLAKE3 بأمان. اضغط للمتابعة من حيث توقّف.")
            .addAction(0, "متابعة", directActionIntent(context, "dev.jopro.sisishare.ACTION_RESUME_TIMEOUT", "all", 9901))
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(ID_TIMEOUT_RESUME, notif)
    }

    fun postIdleStoppedNotice(context: Context) {
        val notif = NotificationCompat.Builder(context, CH_TRANSFER_LIVE)
            .setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setContentTitle("أُوقف وضع الاستقبال تلقائيًا بعد فترة الخمول")
            .setContentText("لتوفير البطارية. يمكنك إعادة تشغيله من البلاطة السريعة أو الويدجت.")
            .setAutoCancel(true)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(1099, notif)
    }

    /** Opens Android system channel settings directly from in-app Settings. */
    fun buildChannelSettingsIntent(context: Context, channelId: String): Intent {
        return Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).apply {
            putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
            putExtra(android.provider.Settings.EXTRA_CHANNEL_ID, channelId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun directActionIntent(context: Context, action: String, id: String, reqCode: Int): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra("target_id", id)
        }
        return PendingIntent.getBroadcast(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

object NativeCoreBridge {
    fun checkpointAllSessionsForResume() {
        // Invokes Rust JOPRO core SQLite WAL flush of all active ResumeManifest bitmaps
    }
}
