package dev.jopro.sisishare

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class JoproForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var watchRoomActive = false
    private var activeTransferCount = 0

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_ON -> updateWifiLockMode(screenInteractive = true)
                Intent.ACTION_SCREEN_OFF -> updateWifiLockMode(screenInteractive = false)
            }
        }
    }

    private val idleShutdownRunnable = Runnable {
        if (activeTransferCount == 0 && !watchRoomActive) {
            NotificationController.postIdleStoppedNotice(this)
            releaseAllLocks()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        NotificationController.ensureChannels(this)
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(screenStateReceiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        watchRoomActive = intent?.getBooleanExtra(EXTRA_WATCH_ACTIVE, false) ?: watchRoomActive
        activeTransferCount = intent?.getIntExtra(EXTRA_ACTIVE_TRANSFERS, activeTransferCount) ?: 0
        val idleMinutes = intent?.getIntExtra(EXTRA_IDLE_TIMEOUT_MIN, 30) ?: 30

        val notification = NotificationController.buildServiceNotification(
            context = this,
            activeTransfers = activeTransferCount,
            watchActive = watchRoomActive
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            if (watchRoomActive) {
                serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            }
            startForeground(NotificationController.ID_FOREGROUND_CORE, notification, serviceType)
        } else {
            startForeground(NotificationController.ID_FOREGROUND_CORE, notification)
        }

        acquireLocks()
        rescheduleIdleTimer(idleMinutes)
        return START_STICKY
    }

    /**
     * Android 15+ (API 35) Foreground Service timeout handler:
     * Flushes all BLAKE3 chunk resume bitmaps to disk, releases locks cleanly,
     * and posts an actionable "متابعة النقل" notification before the system ANR deadline.
     */
    override fun onTimeout(startId: Int, fgsType: Int) {
        NativeCoreBridge.checkpointAllSessionsForResume()
        NotificationController.postTimeoutResumeNotification(this)
        releaseAllLocks()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    private fun acquireLocks() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (wakeLock?.isHeld != true) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "JOPRO::TransferWake").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
        }
        updateWifiLockMode(screenInteractive = pm.isInteractive)

        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (multicastLock?.isHeld != true) {
            multicastLock = wm.createMulticastLock("JOPRO::LocalSendMulticast").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    /**
     * Section 18.2: WIFI_MODE_FULL_LOW_LATENCY operates only while screen is on (API 29+);
     * automatically switches to WIFI_MODE_FULL_HIGH_PERF when screen turns off.
     */
    @Suppress("DEPRECATION")
    private fun updateWifiLockMode(screenInteractive: Boolean) {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val desiredMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && screenInteractive) {
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }
        wifiLock?.let { if (it.isHeld) it.release() }
        wifiLock = wm.createWifiLock(desiredMode, "JOPRO::LanWifiLock").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun rescheduleIdleTimer(idleMinutes: Int) {
        handler.removeCallbacks(idleShutdownRunnable)
        if (activeTransferCount == 0 && !watchRoomActive && idleMinutes > 0) {
            handler.postDelayed(idleShutdownRunnable, idleMinutes * 60_000L)
        }
    }

    private fun releaseAllLocks() {
        handler.removeCallbacks(idleShutdownRunnable)
        runCatching { if (multicastLock?.isHeld == true) multicastLock?.release() }
        runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        multicastLock = null
        wifiLock = null
        wakeLock = null
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenStateReceiver) }
        releaseAllLocks()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_WATCH_ACTIVE = "extra_watch_active"
        const val EXTRA_ACTIVE_TRANSFERS = "extra_active_transfers"
        const val EXTRA_IDLE_TIMEOUT_MIN = "extra_idle_timeout_min"
    }
}
