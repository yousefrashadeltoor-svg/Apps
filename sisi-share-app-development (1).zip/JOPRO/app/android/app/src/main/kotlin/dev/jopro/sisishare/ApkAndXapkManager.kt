package dev.jopro.sisishare

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File

object ApkAndXapkManager {

    data class InstalledAppBundle(
        val packageName: String,
        val label: String,
        val baseApkPath: String,
        val splitApkPaths: List<String>,
        val totalBytes: Long,
        val hasSplits: Boolean
    )

    fun inspectInstalledPackage(context: Context, packageName: String): InstalledAppBundle {
        val pm = context.packageManager
        val appInfo = pm.getApplicationInfo(packageName, 0)
        val splits = appInfo.splitSourceDirs?.toList().orEmpty()
        val allFiles = listOf(appInfo.sourceDir) + splits
        val bytes = allFiles.sumOf { File(it).length() }
        return InstalledAppBundle(
            packageName = packageName,
            label = pm.getApplicationLabel(appInfo).toString(),
            baseApkPath = appInfo.sourceDir,
            splitApkPaths = splits,
            totalBytes = bytes,
            hasSplits = splits.isNotEmpty()
        )
    }

    fun canRequestPackageInstalls(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.packageManager.canRequestPackageInstalls()
        } else {
            true
        }
    }

    fun buildUnknownSourcesSettingsIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /**
     * Ladder Tier 1: Installs a single APK or full multi-split bundle inside ONE atomic
     * `PackageInstaller.Session`, keeping 100% original developer signatures intact so updates succeed.
     */
    fun commitMultiSplitSession(context: Context, apkFiles: List<File>): Int {
        require(apkFiles.isNotEmpty()) { "لا توجد ملفات APK صالحة للتثبيت" }
        val installer = context.packageManager.packageInstaller
        val totalSize = apkFiles.sumOf { it.length() }
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            setSize(totalSize)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            }
        }
        val sessionId = installer.createSession(params)
        installer.openSession(sessionId).use { session ->
            for (apk in apkFiles) {
                apk.inputStream().use { input ->
                    session.openWrite(apk.name, 0, apk.length()).use { out ->
                        input.copyTo(out, bufferSize = 256 * 1024)
                        session.fsync(out)
                    }
                }
            }
            val callbackIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = "dev.jopro.sisishare.ACTION_INSTALL_STATUS"
            }
            val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pendingIntent = PendingIntent.getBroadcast(context, sessionId, callbackIntent, piFlags)
            session.commit(pendingIntent.intentSender)
        }
        return sessionId
    }

    /**
     * Verifies actual OBB presence on disk before declaring XAPK+OBB install successful (Section 18.4 & 18.10).
     */
    fun placeAndVerifyObb(packageName: String, sourceObb: File): Boolean {
        val obbDir = File(Environment.getExternalStorageDirectory(), "Android/obb/$packageName")
        return runCatching {
            if (!obbDir.exists() && !obbDir.mkdirs()) return false
            val dest = File(obbDir, sourceObb.name)
            sourceObb.copyTo(dest, overwrite = true, bufferSize = 512 * 1024)
            dest.exists() && dest.length() == sourceObb.length()
        }.getOrDefault(false)
    }
}
