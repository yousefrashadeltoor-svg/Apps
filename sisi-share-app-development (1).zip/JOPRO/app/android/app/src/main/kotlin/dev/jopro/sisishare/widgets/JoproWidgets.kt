package dev.jopro.sisishare.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import dev.jopro.sisishare.MainActivity

/**
 * Section 5: 5 Event-Driven Home Screen Widgets (`updatePeriodMillis=0`, zero background polling).
 * Updates are pushed exclusively from [dev.jopro.sisishare.JoproForegroundService] throttled to <= 1Hz
 * during active transfers, honoring user filename-privacy preference and `FLAG_IMMUTABLE`.
 */
object JoproWidgetDispatcher {
    private var lastLivePushMs = 0L

    fun pushTransferState(context: Context, percent: Int, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && percent in 1..99 && now - lastLivePushMs < 1000L) return
        lastLivePushMs = now
        val mgr = AppWidgetManager.getInstance(context)
        val receivers = listOf(
            QuickSendWidgetReceiver::class.java,
            ReceiveStatusWidgetReceiver::class.java,
            LiveTransferWidgetReceiver::class.java,
            WebShareWidgetReceiver::class.java,
            RecentHistoryWidgetReceiver::class.java
        )
        for (cls in receivers) {
            val ids = mgr.getAppWidgetIds(ComponentName(context, cls))
            if (ids.isNotEmpty()) {
                val update = Intent(context, cls).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(update)
            }
        }
    }

    fun routePendingIntent(context: Context, route: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("initial_route", route)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun formatPrivacySafeTitle(context: Context, rawFileName: String, count: Int): String {
        val showNames = context.getSharedPreferences("jopro_prefs", Context.MODE_PRIVATE)
            .getBoolean("widget_show_filenames", false)
        return if (showNames) rawFileName else "نقل $count ملف محليًا"
    }
}

class QuickSendWidgetReceiver : AppWidgetProvider()
class ReceiveStatusWidgetReceiver : AppWidgetProvider()
class LiveTransferWidgetReceiver : AppWidgetProvider()
class WebShareWidgetReceiver : AppWidgetProvider()
class RecentHistoryWidgetReceiver : AppWidgetProvider()
