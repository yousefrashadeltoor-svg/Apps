package dev.jopro.sisishare

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Direct background notification action handler (Android 12+ compliant — zero activity trampolines).
 */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val targetId = intent.getStringExtra("target_id") ?: return
        val svc = Intent(context, JoproForegroundService::class.java).apply {
            putExtra("bridge_action", action)
            putExtra("target_id", targetId)
        }
        when (action) {
            "dev.jopro.sisishare.ACTION_APPROVE_ONCE",
            "dev.jopro.sisishare.ACTION_APPROVE_TRUST",
            "dev.jopro.sisishare.ACTION_PAUSE_RESUME",
            "dev.jopro.sisishare.ACTION_RESUME_TIMEOUT" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(svc)
                } else {
                    context.startService(svc)
                }
            }
            "dev.jopro.sisishare.ACTION_REJECT",
            "dev.jopro.sisishare.ACTION_BLOCK_FP",
            "dev.jopro.sisishare.ACTION_CANCEL",
            "dev.jopro.sisishare.ACTION_END_WATCH_ROOM" -> {
                context.startService(svc)
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(targetId.hashCode())
            }
        }
    }
}
