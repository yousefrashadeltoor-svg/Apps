package dev.jopro.sisishare

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.aware.WifiAwareManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Looper
import android.provider.Settings

data class LiveWifiDiagnostics(
    val linkSpeedMbps: Int,
    val frequencyMhz: Int,
    val rssiDbm: Int,
    val is5Ghz: Boolean,
    val expectedCeilingMbs: Double,
    val activeTierLabel: String,
    val upgradeReasonAr: String?
)

class NetworkLadderManager(private val context: Context) {

    private val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var activeCallback: ConnectivityManager.NetworkCallback? = null
    private var localHotspotReservation: WifiManager.LocalOnlyHotspotReservation? = null

    /**
     * Prevents Android from dropping or bypassing an offline Wi-Fi / Hotspot LAN in favor of mobile data.
     */
    fun pinSocketsToOfflineWifi(onBound: (Network) -> Unit) {
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                connectivity.bindProcessToNetwork(network)
                onBound(network)
            }

            override fun onLost(network: Network) {
                connectivity.bindProcessToNetwork(null)
            }
        }
        activeCallback = cb
        connectivity.requestNetwork(request, cb)
    }

    fun releasePinnedNetwork() {
        connectivity.bindProcessToNetwork(null)
        activeCallback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
        activeCallback = null
    }

    /**
     * Ladder Tier 2: Wi-Fi Direct Legacy-AP (fixed Group Owner IP 192.168.49.1, custom `DIRECT-JP-...` SSID
     * & passphrase on Android 10+, forcing 5GHz when supported; falls back cleanly to 2.4GHz on A20).
     */
    @SuppressLint("MissingPermission")
    fun startWifiDirectLegacyAp(
        customSuffix: String,
        passphrase: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val p2p = context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
            ?: return onResult(false, "الجهاز لا يدعم Wi-Fi Direct")
        val channel = p2p.initialize(context, Looper.getMainLooper(), null)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val safeSuffix = customSuffix.filter { it.isLetterOrDigit() || it == '-' }.take(18).ifEmpty { "SISI" }
            val ssid = "DIRECT-JP-$safeSuffix"
            val band = if (wifiManager.is5GHzBandSupported) {
                WifiP2pConfig.GROUP_OWNER_BAND_5GHZ
            } else {
                WifiP2pConfig.GROUP_OWNER_BAND_2GHZ
            }
            val config = WifiP2pConfig.Builder()
                .setNetworkName(ssid)
                .setPassphrase(passphrase.padEnd(8, '0').take(63))
                .enablePersistentMode(false)
                .setGroupOperatingBand(band)
                .build()
            p2p.createGroup(channel, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = onResult(true, "WIFI:T:WPA;S:$ssid;P:$passphrase;;")
                override fun onFailure(reason: Int) =
                    onResult(false, "تعذّر إنشاء مجموعة Wi-Fi Direct (رمز $reason)، جارٍ النزول إلى LocalOnlyHotspot")
            })
        } else {
            p2p.createGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = onResult(true, "DIRECT_LEGACY_STARTED")
                override fun onFailure(reason: Int) = onResult(false, "رمز خطأ Wi-Fi Direct: $reason")
            })
        }
    }

    /** Ladder Tier 3: LocalOnlyHotspot (system-generated SSID/password — cannot be customized on stock Android). */
    @SuppressLint("MissingPermission")
    fun startLocalOnlyHotspot(onReady: (ssid: String, password: String, wifiQr: String) -> Unit, onFail: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return onFail("LocalOnlyHotspot يتطلب Android 8.0 فأحدث")
        }
        wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
            override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation) {
                localHotspotReservation = reservation
                val ssid: String
                val pass: String
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val cfg = reservation.softApConfiguration
                    ssid = cfg.ssid ?: "AndroidShare"
                    pass = cfg.passphrase ?: ""
                } else {
                    @Suppress("DEPRECATION")
                    val cfg = reservation.wifiConfiguration
                    ssid = cfg?.SSID ?: "AndroidShare"
                    pass = cfg?.preSharedKey ?: ""
                }
                onReady(ssid, pass, "WIFI:T:WPA;S:$ssid;P:$pass;;")
            }

            override fun onFailed(reason: Int) {
                onFail("تعذّر تشغيل النقطة المحلية (رمز $reason). افتح إعدادات الهوتسبوت اليدوية.")
            }
        }, null)
    }

    fun stopLocalOnlyHotspot() {
        localHotspotReservation?.close()
        localHotspotReservation = null
    }

    /** Ladder Tier 4: Direct system panel / tethering settings jump (no silent downgrade). */
    fun buildSystemWifiPanelIntent(): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } else {
            Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /** Ladder Tier 5: Hardware Wi-Fi Aware (NAN) check — completely hidden in UI if unsupported. */
    fun isWifiAwareAvailable(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_AWARE)) return false
        val mgr = context.getSystemService(Context.WIFI_AWARE_SERVICE) as? WifiAwareManager
        return mgr?.isAvailable == true
    }

    /** Reads real linkSpeed, frequency & RSSI and computes honest physical transfer ceiling. */
    @Suppress("DEPRECATION")
    fun readLiveWifiDiagnostics(activeTier: String, upgradeReason: String?): LiveWifiDiagnostics {
        val info = wifiManager.connectionInfo
        val speed = (info?.linkSpeed ?: 0).coerceAtLeast(0)
        val freq = (info?.frequency ?: 0).coerceAtLeast(0)
        val rssi = info?.rssi ?: -100
        val is5 = freq in 4900..5900
        val efficiency = if (speed <= 150) 0.56 else 0.64
        val ceiling = ((speed / 8.0) * efficiency * 10.0).toInt() / 10.0
        return LiveWifiDiagnostics(speed, freq, rssi, is5, ceiling, activeTier, upgradeReason)
    }
}
