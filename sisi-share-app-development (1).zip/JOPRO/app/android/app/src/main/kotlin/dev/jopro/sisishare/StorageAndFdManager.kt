package dev.jopro.sisishare

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import java.io.File

object StorageAndFdManager {

    const val DEFAULT_ROOT_FOLDER = "Download/JOPRO"

    data class PendingReceiveHandle(
        val uri: Uri,
        val detachedRawFd: Int,
        val relativeFolder: String,
        val availableBytes: Long
    )

    fun resolveSubfolder(mimeType: String, fileName: String, autoCategorize: Boolean): String {
        if (!autoCategorize) return DEFAULT_ROOT_FOLDER
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val bucket = when {
            mimeType.startsWith("image/") -> "Images"
            mimeType.startsWith("video/") -> "Videos"
            mimeType.startsWith("audio/") -> "Music"
            ext in setOf("apk", "xapk", "apks", "apkm", "obb") -> "Apps"
            ext == "vcf" -> "Contacts"
            ext in setOf("zip", "7z", "rar", "tar", "gz", "xz") -> "Archives"
            else -> "Documents"
        }
        return "$DEFAULT_ROOT_FOLDER/$bucket"
    }

    /**
     * Opens an atomic `IS_PENDING=1` entry inside `Download/JOPRO/...` (zero permission on API 29+)
     * and detaches its native file descriptor for direct Rust `fallocate` + `pwrite`.
     */
    fun openAtomicJoproReceiveFd(
        context: Context,
        displayName: String,
        mimeType: String,
        autoCategorize: Boolean
    ): PendingReceiveHandle {
        val folder = resolveSubfolder(mimeType, displayName, autoCategorize)
        val stat = StatFs(Environment.getExternalStorageDirectory().path)
        val available = stat.availableBytes

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, "$folder/")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("تعذّر حجز الملف داخل $folder عبر MediaStore")
            val pfd = resolver.openFileDescriptor(uri, "rw")
                ?: error("تعذّر فتح معرّف الملف للكتابة المباشرة")
            return PendingReceiveHandle(
                uri = uri,
                detachedRawFd = pfd.detachFd(),
                relativeFolder = folder,
                availableBytes = available
            )
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                folder.removePrefix("Download/")
            ).apply { mkdirs() }
            val target = resolveUniqueLegacyFile(dir, displayName)
            val uri = Uri.fromFile(target)
            val pfd = context.contentResolver.openFileDescriptor(uri, "rw")
                ?: error("تعذّر فتح ملف الاستقبال على التخزين")
            return PendingReceiveHandle(uri, pfd.detachFd(), folder, available)
        }
    }

    /** Publishes the received file ONLY after Rust verifies full size and BLAKE3 integrity. */
    fun commitAtomicJoproFile(context: Context, uri: Uri, absolutePathIfLegacy: String? = null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && uri.scheme == "content") {
            val values = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            val updated = context.contentResolver.update(uri, values, null, null)
            check(updated > 0) { "فشل نشر الملف المستلم داخل مجلد JOPRO" }
        } else if (absolutePathIfLegacy != null) {
            val file = File(absolutePathIfLegacy)
            check(file.exists() && file.length() > 0L) { "الملف المستلم غير موجود بعد الكتابة" }
            MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), null, null)
        }
    }

    /** Detaches read-only FD for Share Target (`content://`) or SAF URIs — zero temp copy. */
    fun detachReadOnlyFd(context: Context, sourceUri: Uri): Int {
        val pfd = context.contentResolver.openFileDescriptor(sourceUri, "r")
            ?: error("تعذّر فتح الملف المصدر للقراءة المباشرة")
        return pfd.detachFd()
    }

    /** Persists SAF tree access for Custom File Manager Tabs and optional `/sdcard/JOPRO` pick. */
    fun persistSafFolderGrant(context: Context, treeUri: Uri, allowWrite: Boolean) {
        var flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (allowWrite) flags = flags or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        context.contentResolver.takePersistableUriPermission(treeUri, flags)
    }

    private fun resolveUniqueLegacyFile(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val stem = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        var counter = 1
        while (candidate.exists()) {
            candidate = File(dir, "$stem ($counter)$ext")
            counter++
        }
        return candidate
    }
}
