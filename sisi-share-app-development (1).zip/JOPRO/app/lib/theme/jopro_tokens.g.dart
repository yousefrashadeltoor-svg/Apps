// AUTO-GENERATED FROM JOPRO/design/tokens.json — DO NOT EDIT MANUALLY
import 'package:flutter/material.dart';

abstract final class JoproTokens {
  static const String appDisplayName = 'SISI Share';
  static const String defaultReceiveFolder = 'Download/JOPRO';
  static const double minTouchTarget = 48.0;

  // Dark Palette
  static const Color darkBgCanvas = Color(0xFF0B0E14);
  static const Color darkBgSurface = Color(0xFF121722);
  static const Color darkBgElevated = Color(0xFF19202E);
  static const Color darkTextPrimary = Color(0xFFF2F6FC);
  static const Color darkTextSecondary = Color(0xFF9BA7BC);
  static const Color darkAccentPrimary = Color(0xFF2F7CF6);
  static const Color darkAccentSignal = Color(0xFFF59E0B);
  static const Color darkStatusSuccess = Color(0xFF10B981);
  static const Color darkStatusDanger = Color(0xFFEF4444);

  // Light Palette
  static const Color lightBgCanvas = Color(0xFFF2F5FA);
  static const Color lightBgSurface = Color(0xFFFFFFFF);
  static const Color lightBgElevated = Color(0xFFEAF0F8);
  static const Color lightTextPrimary = Color(0xFF0D1421);
  static const Color lightTextSecondary = Color(0xFF435269);
  static const Color lightAccentPrimary = Color(0xFF1B62D6);
  static const Color lightAccentSignal = Color(0xFFC47600);
  static const Color lightStatusSuccess = Color(0xFF067E56);
  static const Color lightStatusDanger = Color(0xFFCF291D);

  // Radii
  static const double radiusXs = 6.0;
  static const double radiusSm = 10.0;
  static const double radiusMd = 14.0;
  static const double radiusLg = 18.0;
  static const double radiusXl = 24.0;
  static const double radiusWidget = 22.0;
  static const double radiusPill = 999.0;

  // Spacing
  static const double spaceXxs = 4.0;
  static const double spaceXs = 8.0;
  static const double spaceSm = 12.0;
  static const double spaceMd = 16.0;
  static const double spaceLg = 20.0;
  static const double spaceXl = 24.0;
  static const double spaceXxl = 32.0;

  // Motion Durations (respects MediaQuery.disableAnimations & A20 low-end tier)
  static const Duration durInstant = Duration(milliseconds: 90);
  static const Duration durFast = Duration(milliseconds: 160);
  static const Duration durNormal = Duration(milliseconds: 260);
  static const Duration durEmphasized = Duration(milliseconds: 380);
  static const Duration durHero = Duration(milliseconds: 420);
  static const Duration durRadarCycle = Duration(milliseconds: 3200);

  // Motion Curves
  static const Curve easeStandard = Cubic(0.2, 0.0, 0.0, 1.0);
  static const Curve easeDecelerate = Cubic(0.05, 0.7, 0.1, 1.0);
  static const Curve easeAccelerate = Cubic(0.3, 0.0, 0.8, 0.15);
  static const Curve easeSpring = Cubic(0.22, 1.0, 0.36, 1.0);

  static Duration resolveDuration(
    Duration base, {
    required bool disableAnimations,
    required bool isLowEndDevice,
  }) {
    if (disableAnimations) return Duration.zero;
    if (isLowEndDevice) {
      return Duration(
        milliseconds: (base.inMilliseconds * 0.6).round(),
      );
    }
    return base;
  }

  static ThemeData buildTheme({
    required Brightness brightness,
    ColorScheme? dynamicScheme,
    required bool isArabic,
  }) {
    final isDark = brightness == Brightness.dark;
    final baseScheme = dynamicScheme ??
        ColorScheme(
          brightness: brightness,
          primary: isDark ? darkAccentPrimary : lightAccentPrimary,
          onPrimary: Colors.white,
          secondary: isDark ? darkAccentSignal : lightAccentSignal,
          onSecondary: Colors.white,
          error: isDark ? darkStatusDanger : lightStatusDanger,
          onError: Colors.white,
          surface: isDark ? darkBgSurface : lightBgSurface,
          onSurface: isDark ? darkTextPrimary : lightTextPrimary,
        );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: baseScheme,
      scaffoldBackgroundColor: isDark ? darkBgCanvas : lightBgCanvas,
      fontFamily: isArabic ? 'IBMPlexSansArabic' : 'Inter',
      materialTapTargetSize: MaterialTapTargetSize.padded,
      cardTheme: CardThemeData(
        color: isDark ? darkBgSurface : lightBgSurface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusLg),
        ),
      ),
    );
  }
}
