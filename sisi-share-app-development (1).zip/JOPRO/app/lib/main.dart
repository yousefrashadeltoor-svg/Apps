import 'package:dynamic_color/dynamic_color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'theme/jopro_tokens.g.dart';

const MethodChannel _androidBridge = MethodChannel('dev.jopro.sisishare/native');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  final bool isLowEnd =
      await _androidBridge.invokeMethod<bool>('isLowRamOrA20Tier').catchError((_) => false) ?? false;
  runApp(SisiShareApp(isLowEndDevice: isLowEnd));
}

class SisiShareApp extends StatefulWidget {
  final bool isLowEndDevice;
  const SisiShareApp({super.key, required this.isLowEndDevice});

  @override
  State<SisiShareApp> createState() => _SisiShareAppState();
}

class _SisiShareAppState extends State<SisiShareApp> {
  Locale _locale = const Locale('ar');
  ThemeMode _themeMode = ThemeMode.dark;
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final isArabic = _locale.languageCode == 'ar';
    return DynamicColorBuilder(
      builder: (ColorScheme? lightDyn, ColorScheme? darkDyn) {
        return MaterialApp(
          title: JoproTokens.appDisplayName,
          debugShowCheckedModeBanner: false,
          locale: _locale,
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          themeMode: _themeMode,
          theme: JoproTokens.buildTheme(
            brightness: Brightness.light,
            dynamicScheme: lightDyn,
            isArabic: isArabic,
          ),
          darkTheme: JoproTokens.buildTheme(
            brightness: Brightness.dark,
            dynamicScheme: darkDyn,
            isArabic: isArabic,
          ),
          home: LayoutBuilder(
            builder: (context, constraints) {
              final isWide = constraints.maxWidth >= 640;
              final destinations = [
                (Icons.radar_rounded, isArabic ? 'الرادار' : 'Radar'),
                (Icons.folder_copy_rounded, isArabic ? 'الملفات' : 'Files'),
                (Icons.swap_vert_circle_rounded, isArabic ? 'النقل' : 'Transfer'),
                (Icons.tune_rounded, isArabic ? 'الإعدادات' : 'Settings'),
              ];

              final body = SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(JoproTokens.spaceMd),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            JoproTokens.appDisplayName,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                          ),
                          Row(
                            children: [
                              IconButton(
                                tooltip: isArabic ? 'تغيير اللغة' : 'Switch language',
                                onPressed: () => setState(() {
                                  _locale = isArabic ? const Locale('en') : const Locale('ar');
                                }),
                                icon: const Icon(Icons.translate_rounded),
                              ),
                              IconButton(
                                tooltip: isArabic ? 'تغيير الثيم' : 'Toggle theme',
                                onPressed: () => setState(() {
                                  _themeMode = _themeMode == ThemeMode.dark
                                      ? ThemeMode.light
                                      : ThemeMode.dark;
                                }),
                                icon: Icon(
                                  _themeMode == ThemeMode.dark
                                      ? Icons.light_mode_rounded
                                      : Icons.dark_mode_rounded,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: JoproTokens.spaceSm),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(JoproTokens.spaceMd),
                          child: Text(
                            isArabic
                                ? 'مجلد الاستقبال الذري: ${JoproTokens.defaultReceiveFolder} · محرك Rust جاهز'
                                : 'Atomic receive path: ${JoproTokens.defaultReceiveFolder} · Rust core ready',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );

              if (isWide) {
                return Scaffold(
                  body: Row(
                    children: [
                      NavigationRail(
                        selectedIndex: _selectedIndex,
                        onDestinationSelected: (i) => setState(() => _selectedIndex = i),
                        labelType: NavigationRailLabelType.all,
                        destinations: [
                          for (final d in destinations)
                            NavigationRailDestination(icon: Icon(d.$1), label: Text(d.$2)),
                        ],
                      ),
                      const VerticalDivider(width: 1),
                      Expanded(child: body),
                    ],
                  ),
                );
              }

              return Scaffold(
                body: body,
                bottomNavigationBar: NavigationBar(
                  selectedIndex: _selectedIndex,
                  onDestinationSelected: (i) => setState(() => _selectedIndex = i),
                  destinations: [
                    for (final d in destinations)
                      NavigationDestination(icon: Icon(d.$1), label: d.$2),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }
}
