# وثيقة المعمارية — SISI Share (`JOPRO`)

## 1. نظرة عامة على الطبقات

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Flutter UI Layer (JOPRO/app + JOPRO/web_client)                         │
│ - كود واجهة موحّد + jopro_tokens.g.dart (مولّد من design/tokens.json)   │
│ - Isolates مستقلة للصور المصغرة والفهرسة · حماية 60fps لـ Galaxy A20    │
│ - Web Client: --no-web-resources-cdn + BLAKE3 WASM + libass WASM        │
└───────────────────┬─────────────────────────────────┬───────────────────┘
                    │ flutter_rust_bridge (مسارات/FD)  │ MethodChannel / EventChannel
┌───────────────────▼───────────────────┐ ┌───────────▼───────────────────┐
│ Rust Core (JOPRO/core)                │ │ Kotlin Native (android/)      │
│ - LocalSend v2/v2.1 (224.0.0.167:53317│ │ - UIDT Job + ForegroundService│
│   /api/localsend/v2/*)                │ │   (connectedDevice/playback)  │
│ - Nova v1 (/api/nova/v1/*):           │ │ - StorageBridge: Download/JOPRO│
│   Parallel Ranges (2..8), Resume,     │ │   IS_PENDING=1 + detachFd()   │
│   BLAKE3 integrity & Max-Perf MAC     │ │ - NetworkLadderManager (5 مستويات)
│ - Self-Benchmark: HW AES-GCM vs       │ │   + bindProcessToNetwork + BLE│
│   ChaCha20-Poly1305 + Buffer Pool     │ │ - ApkSplitInstaller (Sessions │
│ - Zero-copy: from_raw_fd, fallocate,  │ │   + ARSCLib merge + OBB)      │
│   pread/pwrite, sendfile              │ │ - Notifications (4 قنوات، 1Hz │
│ - Multi-send single-read broadcaster  │ │   EMA، Android 16 Progress)   │
│ - Watch Together: HTTP Range, Shared  │ │ - 5 Home Widgets (update=0)   │
│   Ring Buffer, NTP WS sync, fMP4 remux│ │ - Quick Tile + Share Target   │
│ - Web Server: Streaming ZIP64, Local  │ │ - ShizukuHelper (full flavor) │
│   CA generator, Chunked Upload        │ │ - Flavors: play | full        │
└───────────────────────────────────────┘ └───────────────────────────────┘
```

## 2. التوافق المزدوج في البروتوكول
1. **المسار القياسي (متوافق 100% مع LocalSend الأصلي)**:
   - اكتشاف UDP Multicast على `224.0.0.167:53317` + mDNS `_localsend._tcp.local.` + مسح HTTP للشبكة الفرعية.
   - واجهات REST: `/api/localsend/v2/info`، `/register`، `/prepare-upload`، `/upload`، `/cancel`.
2. **مسار Nova الاحترافي (يُفعَّل تلقائيًا عند تبادل حقل `novaCapabilities`)**:
   - `/api/nova/v1/handshake`: موافقة الاتصال المسبقة قبل كشف أسماء الملفات + تثبيت بصمة الشهادة (TOFU Pinning) + التحقق من قائمة الحظر بالبصمة + PIN بمحدد محاولات + قياس ذاتي سريع (1.2 ثانية).
   - `/api/nova/v1/range-upload` و`/resume-bitmap`: تقسيم الملفات الكبيرة إلى مقاطع (4MB–16MB) عبر 2 إلى 8 اتصالات متكيفة مع استئناف دقيق على مستوى المقطع وبصمة BLAKE3 لكل مقطع.
   - `/api/nova/v1/pipeline-batch`: دفق مجمّع للملفات الصغيرة الكثيرة فوق اتصال واحد بدون مصافحة متكررة.
   - `/api/nova/v1/device-caps`: تبادل ABI وDPI وSDK واللغات لإرسال الـ Split APKs اللازمة فقط بتوقيعها الأصلي.
   - `/api/nova/v1/watch/{stream,ws,remux}`: بث Range من مخزن حلقي مشترك + مزامنة ساعة NTP عبر WebSocket + إعادة تغليف fMP4 فورية.

## 3. محاذاة صفحات الذاكرة 16KB وبناء المكتبات الأصلية
- تُبنى `libjopro_core.so` للمعماريات `arm64-v8a` و`armeabi-v7a` و`x86_64` مع راية الرابط `-C link-arg=-Wl,-z,max-page-size=16384`.
- يتحقق سكربت `scripts/build_apk.sh` آليًا عبر `llvm-readelf -l` من أن جميع مقاطع `LOAD` محاذاة على `0x4000` (16384 بايت) قبل تمرير إصدار Release.

## 4. الأمان والخصوصية بلا إنترنت
- صلاحية `INTERNET` مقصورة حصريًا على مآخذ الشبكة المحلية (RFC1918 / Link-Local / Wi-Fi Direct `192.168.49.0/24`)؛ يرفض جدار النواة الداخلي (`security::is_private_lan_ip`) أي اتصال وارد أو صادر لعنوان عام.
- لا توجد أي حزمة تحليلات أو إعلانات أو تقارير أعطال سحابية أو خطوط CDN.
- تخزين المفتاح الخاص لشهادة الجهاز محمي بـ Android Keystore مع `android:allowBackup="false"` لمجلد المفاتيح.
