# سجل القيود الصريح وسلّم القدرات — `JOPRO/docs/LIMITATIONS.md`

> عملاً بالقاعدة الصارمة رقم 3 والقسم 18: لا يُخفى أي قيد في Android أو المتصفح، ولا يحدث أي نزول صامت بين المستويات.

## 1. جدول سلّم القدرات (Capability Ladder)

| الميزة | المستويات (من الأقوى إلى الأضمن) | شرط كل مستوى | سلوك الواجهة عند النزول |
|---|---|---|---|
| **إنشاء شبكة بدون راوتر** | 1. هوتسبوت مخصص عبر Shizuku (`full`)<br>2. Wi-Fi Direct Legacy-AP (`DIRECT-JP-...` + 5GHz، IP ثابت `192.168.49.1`)<br>3. `LocalOnlyHotspot` (اسم وكلمة من النظام)<br>4. إعدادات الهوتسبوت اليدوية مع كشف التفعيل<br>5. Wi-Fi Aware (NAN) عند دعم العتاد | 1. تفعيل Shizuku بموافقة صريحة<br>2. Android 10+ وصلاحية `NEARBY_WIFI_DEVICES`<br>3. Android 8+<br>4. متاح دائمًا (API 24+)<br>5. `FEATURE_WIFI_AWARE` | شارة واضحة بالمستوى الفعّال + سبب عدم توفر الأعلى (مثل: "Android يمنع تغيير اسم LocalOnlyHotspot برمجيًا") + QR انضمام فوري |
| **مجلد الاستقبال `JOPRO`** | 1. `Download/JOPRO/<Subfolder>` ذري عبر MediaStore (`IS_PENDING=1`)<br>2. مجلد SAF يختاره المستخدم بصلاحية دائمة<br>3. `/sdcard/JOPRO` مباشر (`full` فقط) | 1. بدون أي صلاحية على Android 10+ (`WRITE_EXTERNAL_STORAGE` على API 24–28)<br>2. اختيار المستخدم في منتقي النظام<br>3. `MANAGE_EXTERNAL_STORAGE` | لا يُطلب الوصول لكل الملفات افتراضيًا؛ يُشرح قيد Scoped Storage بوضوح داخل إعدادات المجلد |
| **الخلفية والنقل الطويل** | 1. User-Initiated Data Transfer (`RUN_USER_INITIATED_JOBS`)<br>2. خدمة أمامية `connectedDevice` (و`mediaPlayback` للمشاهدة)<br>3. خدمة `dataSync` مع معالجة `onTimeout` (~6 ساعات في Android 15+) | 1. Android 14+ بمبادرة المستخدم<br>2. تشغيل وضع الاستقبال من التطبيق/البلاطة/الويدجت<br>3. حفظ خريطة المقاطع وبصمات BLAKE3 قبل الإيقاف | عند `onTimeout` تُحفَظ كل المقاطع ويظهر إشعار "توقّف لبلوغ حد النظام — اضغط للمتابعة" |
| **مشاركة التطبيقات وXAPK** | 1. Splits أصلية مفلترة حسب (ABI/DPI/SDK/Locale) عبر `PackageInstaller.Session`<br>2. APK واحد مدمج (ARSCLib + apksig v1/v2/v3)<br>3. حزمة كاملة مع OBB + تحقق فعلي | 1. المستقبل يستخدم SISI Share<br>2. المستقبل متصفح أو تطبيق آخر (بدون OBB)<br>3. وجود ملفات OBB | تحذير صريح في المستوى 2 بأن التوقيع يتغير وقد يمنع تحديث نسخة مثبتة مسبقًا؛ منع إرسال APK ناقص عند وجود OBB |
| **تطبيق الويب (HTTP/HTTPS)** | 1. HTTPS محلي بشهادة CA مولّدة على الهاتف (IP SAN)<br>2. HTTP محلي كامل ببدائل مضمّنة (BLAKE3 WASM + تنزيل مباشر + رفع `Blob.slice`) | 1. تثبيت CA مرة أو قبول تحذير المتصفح<br>2. يعمل فورًا على كل متصفح وتلفاز بدون إعداد | لا يعتمد الوضع الأساسي على `ServiceWorker` أو `crypto.subtle`؛ يُعرض رابط IP دائمًا بجانب `jopro.local` |
| **المشاهدة المشتركة في المتصفح** | 1. تشغيل HTTP Range مباشر<br>2. إعادة تغليف فورية MKV→fMP4 عبر MSE<br>3. تحويل الصوت فقط (AC3/DTS→AAC)<br>4. تحويل الفيديو بالعتاد (اختياري بتحذير الحرارة)<br>5. فتح في تطبيق SISI Share (`media_kit`) | فحص `MediaSource.isTypeSupported` قبل البدء؛ يُمنع التفعيل التلقائي للمستوى 4 على الأجهزة الضعيفة | رسالة دقيقة توضح الترميز غير المدعوم في المتصفح والبديل الفعّال |
| **التشفير وأداء الأجهزة الضعيفة** | 1. TLS 1.3 `AES-256-GCM` بالتسريع العتادي<br>2. TLS 1.3 `ChaCha20-Poly1305` عند غياب AES العتادي<br>3. وضع الأداء الأقصى (بدون تشفير نقل + مصادقة `BLAKE3-MAC` لكل مقطع) | فحص `/proc/cpuinfo` + قياس أول 1.2 ثانية | على Galaxy A20 (Wi-Fi 4 بنطاق 2.4GHz ورابط 72Mbps) يُعرض السقف الحقيقي `~5.0–6.2 MB/s` دون وعود زائفة |

## 2. مصفوفة توافق إصدارات Android المستهدفة

| الإصدار | API | مسارات التحقق الحرجة |
|---|---|---|
| Android 7.0 / 7.1 | 24–25 | `WRITE_EXTERNAL_STORAGE` لمجلد `Download/JOPRO`، ويدجتس RemoteViews، إشعارات قبل القنوات |
| Android 10 | 29 | MediaStore `IS_PENDING=1` بدون صلاحية، `WifiP2pConfig` بالبادئة `DIRECT-JP-`، `WIFI_MODE_FULL_LOW_LATENCY` |
| Android 11 (Galaxy A20) | 30 | تخفيف الحركات تلقائيًا (3GB RAM)، قراءة `detachFd()`، استقرار Wi-Fi 2.4GHz، `bindProcessToNetwork` |
| Android 12 / 12L | 31–32 | منع Notification Trampolines، استثناء بدء الخدمة من الويدجت والبلاطة و`ACTION_SEND`، Material You |
| Android 13 | 33 | `POST_NOTIFICATIONS` عند أول نقل، `NEARBY_WIFI_DEVICES (neverForLocation)`، أيقونة Monochrome |
| Android 14 | 34 | الوصول الجزئي `READ_MEDIA_VISUAL_USER_SELECTED` + زر "السماح بالمزيد"، UIDT، Predictive Back |
| Android 15 | 35 | محاذاة صفحات الذاكرة **16KB** (`0x4000`)، معالجة `Service.onTimeout`، معاينات الويدجتس المولّدة |
| Android 16 | 36 | التحسين التدريجي لإشعارات النقل الحية عبر `Notification.ProgressStyle` مع بديل كامل للأقدم |

## 3. ملاحظة صريحة حول بيئة البناء والاختبار الفعلي
- بيئة المعاينة الحالية تحتوي Node.js لبناء وتشغيل العقد البصري وتوليد `tokens` الموحدة؛ لتنفيذ التجميع العابر `cargo ndk` و`flutter build apk --release --flavor play|full` واختبار الأجهزة الحقيقية شغّل `bash JOPRO/scripts/build_apk.sh both release` على مضيف مثبت عليه Flutter 3.27+ وRust 1.83+ وAndroid SDK 35 / NDK r27.
