import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Bell,
  Clock,
  Code2,
  Cpu,
  Folder,
  Gauge,
  Globe,
  Languages,
  Laptop,
  Menu,
  Moon,
  Package,
  Play,
  QrCode,
  Radio,
  Settings,
  Shield,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Sun,
  Tablet,
  Wifi,
  X,
} from 'lucide-react';
import {
  DeviceFrame,
  INITIAL_PEERS,
  INITIAL_PERMISSIONS,
  Locale,
  PeerDevice,
  PermissionEntry,
  PermState,
  ScreenId,
  ThemeMode,
} from './data/previewData';
import { BrandMark, DeviceAvatar } from './components/QrAndArtwork';
import {
  AppsAndXapkScreen,
  FileManagerScreen,
  RadarHomeScreen,
} from './components/ScreensCore';
import {
  LiveProgressScreen,
  QrAndScannerScreen,
  ReadinessTransferScreen,
  ReceiveApprovalScreen,
} from './components/ScreensTransfer';
import {
  HistoryScreen,
  TrustBlocklistScreen,
  WatchTogetherScreen,
  WebShareScreen,
} from './components/ScreensFeatures';
import {
  AdvancedSettingsScreen,
  EmptyAndErrorStatesGallery,
  NotificationsAndWidgetsGallery,
  PermissionsJitScreen,
} from './components/ScreensSystem';
import {
  EmbeddedWebClientView,
  JoproBlueprintView,
} from './components/WebClientAndBlueprint';

const SPEED_STEPS = [1, 0.5, 0.25, 1.5] as const;

export function App() {
  const [theme, setTheme] = useState<ThemeMode>('dark');
  const [locale, setLocale] = useState<Locale>('ar');
  const [frame, setFrame] = useState<DeviceFrame>('phone');
  const [isLowEnd, setIsLowEnd] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [speedIdx, setSpeedIdx] = useState(0);
  const [activeScreen, setActiveScreen] = useState<ScreenId>('radar');
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Interactive sample preview state
  const [deviceAlias, setDeviceAlias] = useState('SISI · هاتفي الرئيسي');
  const [receiveOn, setReceiveOn] = useState(true);
  const [webServerOn, setWebServerOn] = useState(true);
  const [flavor, setFlavor] = useState<'play' | 'full'>('full');
  const [hidePrivateNames, setHidePrivateNames] = useState(true);
  const [peers, setPeers] = useState<PeerDevice[]>(INITIAL_PEERS);
  const [selectedPeerIds, setSelectedPeerIds] = useState<string[]>(['peer-s24']);
  const [selectedFileIds, setSelectedFileIds] = useState<string[]>(['img-1', 'vid-1']);
  const [permissions, setPermissions] = useState<PermissionEntry[]>(INITIAL_PERMISSIONS);
  const [headsUpVisible, setHeadsUpVisible] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const ar = locale === 'ar';
  const speedFactor = SPEED_STEPS[speedIdx];

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', theme);
    root.setAttribute('dir', ar ? 'rtl' : 'ltr');
    root.setAttribute('lang', locale);
    root.setAttribute('data-low-end', String(isLowEnd));
    root.setAttribute('data-reduce-motion', String(reduceMotion));
    root.style.setProperty('--jp-speed-factor', String(1 / speedFactor));
  }, [theme, locale, ar, isLowEnd, reduceMotion, speedFactor]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    window.setTimeout(() => {
      setToastMsg((curr) => (curr === msg ? null : curr));
    }, 2800);
  };

  const togglePeer = (id: string) => {
    setSelectedPeerIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleFile = (id: string) => {
    setSelectedFileIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const updatePerm = (id: string, next: PermState) => {
    setPermissions((prev) => prev.map((p) => (p.id === id ? { ...p, state: next } : p)));
  };

  const handleApprovalDecision = (action: 'once' | 'trust' | 'reject' | 'block') => {
    setHeadsUpVisible(false);
    if (action === 'once') {
      showToast(ar ? 'قُبل الاتصال لهذه الجلسة — يبدأ الحفظ الذري في Download/JOPRO' : 'Accepted once — saving to Download/JOPRO');
      setActiveScreen('progress');
    } else if (action === 'trust') {
      setPeers((prev) =>
        prev.map((p) => (p.id === 'peer-tab' ? { ...p, trusted: true, autoAccept: true } : p))
      );
      showToast(ar ? 'ثُبّتت بصمة الشهادة (TOFU) وأُضيف لقائمة الموثوقين' : 'Pinned certificate fingerprint (TOFU)');
      setActiveScreen('progress');
    } else if (action === 'reject') {
      showToast(ar ? 'رُفض الاتصال قبل كشف أي ملفات وأُبلغ المرسل' : 'Connection rejected cleanly');
    } else {
      setPeers((prev) =>
        prev.map((p) => (p.id === 'peer-tab' ? { ...p, blocked: true, trusted: false } : p))
      );
      showToast(ar ? 'حُظرت بصمة الجهاز (لن يرى حتى إعلانات الاكتشاف)' : 'Blocked device fingerprint');
      setActiveScreen('trust');
    }
  };

  const partialMedia = permissions.find((p) => p.id === 'media')?.state === 'partial';

  const navGroups: {
    title: string;
    items: { id: ScreenId; label: string; icon: React.ReactNode }[];
  }[] = [
    {
      title: ar ? 'شاشات التطبيق' : 'App Screens',
      items: [
        { id: 'radar', label: ar ? 'الرئيسية والرادار' : 'Home & Radar', icon: <Radio className="h-4 w-4" /> },
        { id: 'files', label: ar ? 'مدير الملفات (9+ تبويبات)' : 'File Manager (9+ Tabs)', icon: <Folder className="h-4 w-4" /> },
        { id: 'apps', label: ar ? 'التطبيقات وXAPK/Splits' : 'Apps & XAPK Splits', icon: <Package className="h-4 w-4" /> },
        { id: 'readiness', label: ar ? 'النقل وقائمة الجاهزية' : 'Readiness Checklist', icon: <ShieldCheck className="h-4 w-4" /> },
        { id: 'progress', label: ar ? 'التقدم (فردي ومتعدد)' : 'Live Progress (1 & Multi)', icon: <Activity className="h-4 w-4" /> },
        { id: 'receive', label: ar ? 'الاستقبال وموافقة الاتصال' : 'Receive & Approval', icon: <Shield className="h-4 w-4" /> },
        { id: 'qr', label: ar ? 'رمز QR والماسح والشبكة' : 'QR Hub & Scanner', icon: <QrCode className="h-4 w-4" /> },
        { id: 'web', label: ar ? 'مشاركة الويب (HTTP/CA)' : 'Web Share (HTTP/CA)', icon: <Globe className="h-4 w-4" /> },
        { id: 'watch', label: ar ? 'المشاهدة المشتركة الحية' : 'Watch Together Live', icon: <Play className="h-4 w-4" /> },
        { id: 'history', label: ar ? 'السجل ومجلد JOPRO' : 'History (JOPRO)', icon: <Clock className="h-4 w-4" /> },
        { id: 'trust', label: ar ? 'الحظر والأجهزة الموثوقة' : 'Blocklist & Trusted', icon: <ShieldCheck className="h-4 w-4" /> },
        { id: 'permissions', label: ar ? 'الأذونات (Just-in-Time)' : 'Permissions (JIT)', icon: <Sparkles className="h-4 w-4" /> },
        { id: 'settings', label: ar ? 'الإعدادات وسلّم القدرات' : 'Settings & Ladder', icon: <Settings className="h-4 w-4" /> },
      ],
    },
    {
      title: ar ? 'تكامل Android والحالات' : 'Android System & States',
      items: [
        { id: 'system', label: ar ? 'الإشعارات والويدجتس (5)' : 'Notifications & 5 Widgets', icon: <Bell className="h-4 w-4" /> },
        { id: 'states', label: ar ? 'الحالات الفارغة والأخطاء' : 'Empty & Error States', icon: <AlertTriangle className="h-4 w-4" /> },
      ],
    },
    {
      title: ar ? 'المشروع والمعمارية' : 'JOPRO Engineering',
      items: [
        { id: 'blueprint', label: ar ? 'معمارية وكود JOPRO (0–8)' : 'JOPRO Code & Benchmark', icon: <Code2 className="h-4 w-4" /> },
      ],
    },
  ];

  const allNavItems = navGroups.flatMap((g) => g.items);
  const currentTitle = allNavItems.find((i) => i.id === activeScreen)?.label ?? 'SISI Share';

  const primaryShellTabs: { id: ScreenId; label: string; icon: React.ReactNode }[] = [
    { id: 'radar', label: ar ? 'الرادار' : 'Radar', icon: <Radio className="h-4 w-4" /> },
    { id: 'files', label: ar ? 'الملفات' : 'Files', icon: <Folder className="h-4 w-4" /> },
    { id: 'progress', label: ar ? 'النقل' : 'Transfer', icon: <Activity className="h-4 w-4" /> },
    { id: 'settings', label: ar ? 'الإعدادات' : 'Settings', icon: <Settings className="h-4 w-4" /> },
  ];

  const renderActiveScreen = () => {
    switch (activeScreen) {
      case 'radar':
        return (
          <RadarHomeScreen
            locale={locale}
            isLowEnd={isLowEnd}
            isTablet={frame === 'tablet'}
            receiveOn={receiveOn}
            onToggleReceive={() => setReceiveOn((r) => !r)}
            peers={peers}
            selectedPeerIds={selectedPeerIds}
            onTogglePeer={togglePeer}
            onNavigate={setActiveScreen}
            onTriggerIncoming={() => setHeadsUpVisible(true)}
            deviceAlias={deviceAlias}
          />
        );
      case 'files':
        return (
          <FileManagerScreen
            locale={locale}
            selectedFileIds={selectedFileIds}
            onToggleFile={toggleFile}
            onSetSelectedFiles={setSelectedFileIds}
            onNavigate={setActiveScreen}
            partialMediaAccess={partialMedia}
            onExpandPartialMedia={() => {
              updatePerm('media', 'granted');
              showToast(ar ? 'مُنح الوصول لجميع الصور والفيديو عبر MediaStore' : 'Granted full media access');
            }}
          />
        );
      case 'apps':
        return <AppsAndXapkScreen locale={locale} onNavigate={setActiveScreen} onToast={showToast} />;
      case 'readiness':
        return (
          <ReadinessTransferScreen
            locale={locale}
            isLowEnd={isLowEnd}
            selectedFileIds={selectedFileIds}
            peers={peers}
            selectedPeerIds={selectedPeerIds}
            onTogglePeer={togglePeer}
            onNavigate={setActiveScreen}
            onToast={showToast}
          />
        );
      case 'progress':
        return (
          <LiveProgressScreen
            locale={locale}
            isLowEnd={isLowEnd}
            reduceMotion={reduceMotion}
            onToast={showToast}
          />
        );
      case 'receive':
        return (
          <ReceiveApprovalScreen
            locale={locale}
            receiveOn={receiveOn}
            onToggleReceive={() => setReceiveOn((r) => !r)}
            onDecision={handleApprovalDecision}
          />
        );
      case 'qr':
        return <QrAndScannerScreen locale={locale} onToast={showToast} />;
      case 'web':
        return (
          <WebShareScreen
            locale={locale}
            webServerOn={webServerOn}
            onToggleWebServer={() => setWebServerOn((w) => !w)}
            onSwitchFrame={setFrame}
            onToast={showToast}
          />
        );
      case 'watch':
        return <WatchTogetherScreen locale={locale} isLowEnd={isLowEnd} onToast={showToast} />;
      case 'history':
        return <HistoryScreen locale={locale} onToast={showToast} />;
      case 'trust':
        return (
          <TrustBlocklistScreen
            locale={locale}
            peers={peers}
            onToggleAutoAccept={(id) =>
              setPeers((prev) =>
                prev.map((p) => (p.id === id ? { ...p, autoAccept: !p.autoAccept } : p))
              )
            }
            onToggleBlock={(id) =>
              setPeers((prev) =>
                prev.map((p) => (p.id === id ? { ...p, blocked: !p.blocked } : p))
              )
            }
          />
        );
      case 'permissions':
        return (
          <PermissionsJitScreen
            locale={locale}
            flavor={flavor}
            permissions={permissions}
            onUpdatePerm={updatePerm}
            onToast={showToast}
          />
        );
      case 'settings':
        return (
          <AdvancedSettingsScreen
            locale={locale}
            isLowEnd={isLowEnd}
            deviceAlias={deviceAlias}
            onChangeAlias={setDeviceAlias}
            flavor={flavor}
            onChangeFlavor={setFlavor}
            hidePrivateNames={hidePrivateNames}
            onToggleHideNames={() => setHidePrivateNames((h) => !h)}
            onNavigate={setActiveScreen}
            onToast={showToast}
          />
        );
      case 'system':
        return (
          <NotificationsAndWidgetsGallery
            locale={locale}
            hidePrivateNames={hidePrivateNames}
            onToggleHideNames={() => setHidePrivateNames((h) => !h)}
            receiveOn={receiveOn}
            onToggleReceive={() => setReceiveOn((r) => !r)}
            onToast={showToast}
          />
        );
      case 'states':
        return <EmptyAndErrorStatesGallery locale={locale} onToast={showToast} />;
      case 'blueprint':
        return (
          <JoproBlueprintView
            locale={locale}
            onNavigate={setActiveScreen}
            onToast={showToast}
          />
        );
    }
  };

  return (
    <div
      className="flex min-h-screen flex-col"
      style={{ backgroundColor: 'var(--jp-bg-canvas)', color: 'var(--jp-text-primary)' }}
    >
      {/* ====================================================================
       * SECTION 14.1 & 14.2 PREVIEW STUDIO CONTROL BAR + HONESTY BADGE
       * ==================================================================== */}
      <header
        className="jp-glass sticky top-0 z-40 border-b px-3 py-2 lg:px-5"
        style={{ borderColor: 'var(--jp-border-subtle)' }}
      >
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setDrawerOpen((o) => !o)}
              className="jp-elevated flex h-9 w-9 items-center justify-center rounded-xl lg:hidden cursor-pointer"
              aria-label="Toggle screen menu"
            >
              {drawerOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
            <BrandMark size={32} />
            <div className="leading-tight">
              <div className="flex items-center gap-1.5">
                <span className="text-[14px] font-extrabold tracking-tight">SISI Share</span>
                <span
                  className="jp-mono rounded px-1.5 py-0.5 text-[10px] font-bold"
                  style={{ backgroundColor: 'var(--jp-bg-elevated)', color: 'var(--jp-text-secondary)' }}
                >
                  JOPRO
                </span>
              </div>
              {/* Mandatory Permanent Section 14.2 Badge */}
              <div
                className="text-[10.5px] font-bold"
                style={{ color: 'var(--jp-accent-signal)' }}
              >
                {ar
                  ? 'معاينة تصميم · بيانات عيّنة · لا تنقل ملفات فعليًا'
                  : 'Design Preview · Sample Data · Does Not Transfer Files'}
              </div>
            </div>
          </div>

          {/* Interactive Preview Controls */}
          <div className="flex flex-wrap items-center gap-1.5 text-[11.5px]">
            {/* Device Frame Switcher */}
            <div className="jp-elevated flex items-center rounded-xl p-0.5">
              {[
                { id: 'phone' as const, l: ar ? 'هاتف' : 'Phone', ic: <Smartphone className="h-3.5 w-3.5" /> },
                { id: 'tablet' as const, l: ar ? 'تابلت' : 'Tablet', ic: <Tablet className="h-3.5 w-3.5" /> },
                { id: 'web' as const, l: ar ? 'ويب' : 'Web', ic: <Laptop className="h-3.5 w-3.5" /> },
              ].map((df) => (
                <button
                  key={df.id}
                  type="button"
                  onClick={() => setFrame(df.id)}
                  className="flex h-8 items-center gap-1 rounded-lg px-2.5 font-semibold cursor-pointer"
                  style={{
                    backgroundColor: frame === df.id ? 'var(--jp-accent-primary)' : 'transparent',
                    color: frame === df.id ? '#FFFFFF' : 'var(--jp-text-secondary)',
                  }}
                >
                  {df.ic}
                  <span className="hidden sm:inline">{df.l}</span>
                </button>
              ))}
            </div>

            {/* Galaxy A20 Low-End Mode */}
            <button
              type="button"
              onClick={() => setIsLowEnd((v) => !v)}
              className="flex h-9 items-center gap-1 rounded-xl px-2.5 font-semibold cursor-pointer"
              style={{
                backgroundColor: isLowEnd ? 'var(--jp-accent-signal)' : 'var(--jp-bg-elevated)',
                color: isLowEnd ? '#FFFFFF' : 'var(--jp-text-secondary)',
                border: '1px solid var(--jp-border-subtle)',
              }}
              title={ar ? 'وضع الجهاز الضعيف (Galaxy A20: بدون blur + 2.4GHz)' : 'Low-end Galaxy A20 mode'}
            >
              <Cpu className="h-3.5 w-3.5" />
              <span>A20</span>
            </button>

            {/* Reduce Motion */}
            <button
              type="button"
              onClick={() => setReduceMotion((r) => !r)}
              className="hidden sm:flex h-9 items-center gap-1 rounded-xl px-2.5 font-semibold cursor-pointer"
              style={{
                backgroundColor: reduceMotion ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                color: reduceMotion ? '#FFFFFF' : 'var(--jp-text-secondary)',
                border: '1px solid var(--jp-border-subtle)',
              }}
            >
              <span>{ar ? 'تقليل الحركة' : 'Still'}</span>
            </button>

            {/* Animation Speed Multiplier */}
            <button
              type="button"
              onClick={() => setSpeedIdx((i) => (i + 1) % SPEED_STEPS.length)}
              className="jp-elevated jp-num hidden md:flex h-9 items-center gap-1 rounded-xl px-2.5 font-semibold cursor-pointer"
              title={ar ? 'سرعة الحركة للمراجعة' : 'Review motion speed'}
            >
              <Gauge className="h-3.5 w-3.5" />
              <span>{speedFactor}×</span>
            </button>

            {/* Locale RTL / LTR */}
            <button
              type="button"
              onClick={() => setLocale((l) => (l === 'ar' ? 'en' : 'ar'))}
              className="jp-elevated flex h-9 items-center gap-1 rounded-xl px-2.5 font-bold cursor-pointer"
            >
              <Languages className="h-3.5 w-3.5" />
              <span>{ar ? 'EN' : 'عربي'}</span>
            </button>

            {/* Theme Dark / Light */}
            <button
              type="button"
              onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
              className="jp-elevated flex h-9 w-9 items-center justify-center rounded-xl cursor-pointer"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* ====================================================================
       * WORKSPACE: SIDEBAR NAVIGATOR + DEVICE VIEWPORT
       * ==================================================================== */}
      <div className="mx-auto flex w-full max-w-[1440px] flex-1 gap-4 px-3 py-4 lg:px-5">
        {/* Side Screen Navigator */}
        <aside
          className={`${
            drawerOpen ? 'fixed inset-y-14 start-0 z-30 w-72 p-3' : 'hidden'
          } lg:static lg:block lg:w-64 lg:shrink-0`}
          style={{
            backgroundColor: drawerOpen ? 'var(--jp-bg-surface)' : 'transparent',
            borderInlineEnd: drawerOpen ? '1px solid var(--jp-border-subtle)' : 'none',
          }}
        >
          <nav className="jp-scroll max-h-[calc(100vh-5.5rem)] space-y-4 overflow-y-auto pe-1">
            {navGroups.map((group, gi) => (
              <div key={gi} className="space-y-1">
                <div
                  className="px-2.5 text-[10.5px] font-bold uppercase tracking-wider"
                  style={{ color: 'var(--jp-text-muted)' }}
                >
                  {group.title}
                </div>
                {group.items.map((item) => {
                  const active = activeScreen === item.id && frame !== 'web';
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        if (frame === 'web') setFrame('phone');
                        setActiveScreen(item.id);
                        setDrawerOpen(false);
                      }}
                      className="jp-transition flex min-h-[40px] w-full items-center gap-2.5 rounded-xl px-2.5 text-start text-[12px] font-semibold cursor-pointer"
                      style={{
                        backgroundColor: active ? 'var(--jp-accent-primary)' : 'transparent',
                        color: active ? '#FFFFFF' : 'var(--jp-text-secondary)',
                      }}
                    >
                      {item.icon}
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            ))}
          </nav>
        </aside>

        {/* Center Device Canvas */}
        <main className="flex flex-1 items-start justify-center">
          {frame === 'web' ? (
            <EmbeddedWebClientView
              locale={locale}
              deviceAlias={deviceAlias}
              onJumpWatch={() => {
                setFrame('tablet');
                setActiveScreen('watch');
              }}
              onToast={showToast}
            />
          ) : (
            <div
              className={`relative flex flex-col overflow-hidden transition-all ${
                frame === 'tablet'
                  ? 'w-full max-w-[920px] rounded-[30px]'
                  : 'w-full max-w-[404px] rounded-[38px]'
              }`}
              style={{
                backgroundColor: 'var(--jp-bg-canvas)',
                border: '6px solid var(--jp-bg-elevated)',
                boxShadow: 'var(--jp-shadow-modal)',
                height: frame === 'tablet' ? '700px' : '780px',
              }}
            >
              {/* Android Edge-to-Edge Status Bar */}
              <div
                className="flex h-8 shrink-0 items-center justify-between px-5 text-[11px] font-semibold"
                style={{ backgroundColor: 'var(--jp-bg-surface)', color: 'var(--jp-text-secondary)' }}
              >
                <span className="jp-mono">09:42</span>
                <div className="flex items-center gap-2">
                  {receiveOn && (
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ backgroundColor: 'var(--jp-status-success)' }}
                      title="Foreground Service Active"
                    />
                  )}
                  <Wifi className="h-3.5 w-3.5" />
                  <span className="jp-mono text-[10px]">{isLowEnd ? '2.4G' : '5G-WiFi'}</span>
                  <span className="jp-mono text-[10px]">94%</span>
                </div>
              </div>

              {/* Interactive Heads-Up Connection Request Overlay (Section 4.3) */}
              {headsUpVisible && (
                <div className="jp-headsup-enter absolute inset-x-3 top-9 z-30 rounded-2xl p-3 shadow-xl" style={{ backgroundColor: 'var(--jp-bg-surface)', border: '1.5px solid var(--jp-accent-primary)' }}>
                  <div className="flex items-center gap-2.5">
                    <DeviceAvatar seed={11} initials="ت" accent="#F59E0B" size={36} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[12px] font-bold">
                        {ar ? 'طلب اتصال: تابلت الاستوديو' : 'Incoming: Studio Pad Pro'}
                      </div>
                      <div className="jp-mono text-[10px]" style={{ color: 'var(--jp-text-secondary)' }}>
                        4 files (1.18 GB) · FP C712:88B4 · 60s
                      </div>
                    </div>
                  </div>
                  <div className="mt-2.5 grid grid-cols-3 gap-1.5 text-[11px] font-bold">
                    <button
                      type="button"
                      onClick={() => handleApprovalDecision('once')}
                      className="min-h-[36px] rounded-xl text-white cursor-pointer"
                      style={{ backgroundColor: 'var(--jp-status-success)' }}
                    >
                      {ar ? 'قبول' : 'Accept'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApprovalDecision('reject')}
                      className="jp-elevated min-h-[36px] rounded-xl cursor-pointer"
                    >
                      {ar ? 'رفض' : 'Reject'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApprovalDecision('block')}
                      className="min-h-[36px] rounded-xl cursor-pointer"
                      style={{ backgroundColor: 'var(--jp-status-danger-soft)', color: 'var(--jp-status-danger)' }}
                    >
                      {ar ? 'حظر' : 'Block'}
                    </button>
                  </div>
                </div>
              )}

              {/* Body: Tablet NavigationRail + Content OR Phone TopBar + Content */}
              <div className="flex min-h-0 flex-1">
                {frame === 'tablet' && (
                  <div
                    className="flex w-[78px] shrink-0 flex-col items-center justify-between border-e py-4"
                    style={{ backgroundColor: 'var(--jp-bg-surface)', borderColor: 'var(--jp-border-subtle)' }}
                  >
                    <div className="flex flex-col items-center gap-3">
                      {primaryShellTabs.map((t) => {
                        const on = activeScreen === t.id;
                        return (
                          <button
                            key={t.id}
                            type="button"
                            onClick={() => setActiveScreen(t.id)}
                            className="flex min-h-[52px] w-16 flex-col items-center justify-center gap-1 rounded-2xl text-[10.5px] font-bold cursor-pointer"
                            style={{
                              backgroundColor: on ? 'var(--jp-accent-primary-soft)' : 'transparent',
                              color: on ? 'var(--jp-accent-primary)' : 'var(--jp-text-secondary)',
                            }}
                          >
                            {t.icon}
                            <span>{t.label}</span>
                          </button>
                        );
                      })}
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveScreen('qr')}
                      className="flex h-11 w-11 items-center justify-center rounded-2xl text-white cursor-pointer"
                      style={{ backgroundColor: 'var(--jp-accent-primary)' }}
                      aria-label="QR"
                    >
                      <QrCode className="h-4 w-4" />
                    </button>
                  </div>
                )}

                <div className="flex min-w-0 flex-1 flex-col">
                  {/* App Top Bar */}
                  <div
                    className="flex h-12 shrink-0 items-center justify-between border-b px-3.5"
                    style={{ backgroundColor: 'var(--jp-bg-surface)', borderColor: 'var(--jp-border-subtle)' }}
                  >
                    <div className="flex min-w-0 items-center gap-2">
                      {activeScreen !== 'radar' && (
                        <button
                          type="button"
                          onClick={() => setActiveScreen('radar')}
                          className="jp-elevated flex h-8 w-8 items-center justify-center rounded-xl cursor-pointer"
                          aria-label="Predictive back"
                        >
                          {ar ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
                        </button>
                      )}
                      <h1 className="truncate text-[14px] font-bold">{currentTitle}</h1>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {isLowEnd && (
                        <span
                          className="rounded-md px-1.5 py-0.5 text-[9.5px] font-bold"
                          style={{ backgroundColor: 'var(--jp-accent-signal-soft)', color: 'var(--jp-accent-signal)' }}
                        >
                          A20 Lite
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={() => setActiveScreen('qr')}
                        className="jp-elevated flex h-8 w-8 items-center justify-center rounded-xl cursor-pointer"
                        aria-label="Open QR Hub"
                      >
                        <QrCode className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Scrollable Active Screen */}
                  <div key={activeScreen} className="jp-scroll relative flex-1 overflow-y-auto">
                    {renderActiveScreen()}
                  </div>
                </div>
              </div>

              {/* Toast Banner inside Device Frame */}
              {toastMsg && (
                <div
                  className="pointer-events-none absolute inset-x-4 bottom-20 z-30 rounded-2xl px-3.5 py-2.5 text-center text-[11.5px] font-bold text-white shadow-lg"
                  style={{ backgroundColor: 'var(--jp-accent-primary)' }}
                >
                  {toastMsg}
                </div>
              )}

              {/* Phone Bottom Navigation Bar (48dp+ touch targets) */}
              {frame === 'phone' && (
                <div
                  className="shrink-0 border-t px-2 pt-1.5 pb-2"
                  style={{ backgroundColor: 'var(--jp-bg-surface)', borderColor: 'var(--jp-border-subtle)' }}
                >
                  <div className="grid grid-cols-4 gap-1">
                    {primaryShellTabs.map((t) => {
                      const on = activeScreen === t.id;
                      return (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => setActiveScreen(t.id)}
                          className="jp-transition flex min-h-[48px] flex-col items-center justify-center gap-0.5 rounded-2xl text-[10.5px] font-bold cursor-pointer"
                          style={{
                            backgroundColor: on ? 'var(--jp-accent-primary-soft)' : 'transparent',
                            color: on ? 'var(--jp-accent-primary)' : 'var(--jp-text-secondary)',
                          }}
                        >
                          {t.icon}
                          <span>{t.label}</span>
                        </button>
                      );
                    })}
                  </div>
                  {/* Android Edge-to-Edge Gesture Handle */}
                  <div
                    className="mx-auto mt-1.5 h-1 w-24 rounded-full opacity-40"
                    style={{ backgroundColor: 'var(--jp-text-muted)' }}
                  />
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
