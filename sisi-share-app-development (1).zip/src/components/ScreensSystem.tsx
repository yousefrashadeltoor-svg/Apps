import React, { useState } from 'react';
import {
  AlertOctagon,
  ArrowDownLeft,
  ArrowUpRight,
  Bell,
  CheckCircle2,
  Cpu,
  ExternalLink,
  EyeOff,
  Folder,
  HardDrive,
  Info,
  Layers,
  Lock,
  Pause,
  QrCode,
  Radio,
  RefreshCw,
  Send,
  Settings,
  ShieldAlert,
  Terminal,
  Thermometer,
  Wifi,
  X,
} from 'lucide-react';
import {
  Locale,
  PermissionEntry,
  PermState,
  ScreenId,
} from '../data/previewData';
import { BrandMark, DeviceAvatar, RealQrCode } from './QrAndArtwork';

/* ============================================================================
 * 12. JUST-IN-TIME PERMISSIONS & GRACEFUL DEGRADATION (Sections 3.1 & 3.2)
 * ============================================================================ */
export const PermissionsJitScreen: React.FC<{
  locale: Locale;
  flavor: 'play' | 'full';
  permissions: PermissionEntry[];
  onUpdatePerm: (id: string, next: PermState) => void;
  onToast: (msg: string) => void;
}> = ({ locale, flavor, permissions, onUpdatePerm, onToast }) => {
  const ar = locale === 'ar';
  const [explaining, setExplaining] = useState<PermissionEntry | null>(null);

  const visible = permissions.filter((p) => (flavor === 'play' ? !p.fullFlavorOnly : true));

  const badgeFor = (st: PermState) => {
    switch (st) {
      case 'granted':
        return { l: ar ? 'ممنوحة' : 'Granted', bg: 'var(--jp-status-success-soft)', fg: 'var(--jp-status-success)' };
      case 'partial':
        return { l: ar ? 'وصول جزئي (API 34+)' : 'Partial (API 34+)', bg: 'var(--jp-accent-primary-soft)', fg: 'var(--jp-accent-primary)' };
      case 'denied':
        return { l: ar ? 'مرفوضة مؤقتًا' : 'Denied', bg: 'var(--jp-status-warning-soft)', fg: 'var(--jp-status-warning)' };
      case 'permanently_denied':
        return { l: ar ? 'مرفوضة دائمًا' : 'Settings Only', bg: 'var(--jp-status-danger-soft)', fg: 'var(--jp-status-danger)' };
      default:
        return { l: ar ? 'لم تُطلب بعد (JIT)' : 'Not asked yet (JIT)', bg: 'var(--jp-bg-elevated)', fg: 'var(--jp-text-secondary)' };
    }
  };

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      <div className="jp-elevated rounded-2xl p-3 text-[11.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
        {ar
          ? `الوضع الحالي: نكهة (${flavor.toUpperCase()}). لا تُطلب أي صلاحية عند فتح التطبيق؛ كل صلاحية تُشرح أولًا عند الحاجة الفعلية.`
          : `Active flavor: ${flavor.toUpperCase()}. Zero upfront prompts — every permission shows a clear rationale just-in-time.`}
      </div>

      {visible.map((p) => {
        const b = badgeFor(p.state);
        return (
          <div key={p.id} className="jp-surface rounded-2xl p-3 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[12.5px] font-bold">{ar ? p.titleAr : p.titleEn}</div>
                <div className="jp-mono text-[10px]" style={{ color: 'var(--jp-text-muted)' }}>
                  {p.manifestName} · {p.apiScope}
                </div>
              </div>
              <span
                className="shrink-0 rounded-full px-2.5 py-0.5 text-[10px] font-bold"
                style={{ backgroundColor: b.bg, color: b.fg }}
              >
                {b.l}
              </span>
            </div>

            <div className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
              <strong>{ar ? 'متى تُطلب:' : 'Asked:'}</strong> {ar ? p.triggerAr : p.triggerEn}
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-0.5">
              {p.state === 'partial' && (
                <button
                  type="button"
                  onClick={() => {
                    onUpdatePerm(p.id, 'granted');
                    onToast(ar ? 'فُتح منتقي Android 14+ لاختيار صور إضافية أو منح الكل' : 'Expanded media selection');
                  }}
                  className="min-h-[36px] rounded-xl px-3 text-[11px] font-bold text-white cursor-pointer"
                  style={{ backgroundColor: 'var(--jp-accent-primary)' }}
                >
                  {ar ? 'السماح بالمزيد' : 'Allow More'}
                </button>
              )}
              {p.state === 'permanently_denied' && (
                <button
                  type="button"
                  onClick={() => {
                    onUpdatePerm(p.id, 'granted');
                    onToast(ar ? 'فُتحت إعدادات التطبيق وتحدّثت الحالة تلقائيًا عند العودة' : 'Opened App Settings & refreshed on resume');
                  }}
                  className="flex min-h-[36px] items-center gap-1 rounded-xl px-3 text-[11px] font-bold text-white cursor-pointer"
                  style={{ backgroundColor: 'var(--jp-accent-primary)' }}
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  <span>{ar ? 'فتح إعدادات التطبيق' : 'Open App Settings'}</span>
                </button>
              )}
              {(p.state === 'not_requested' || p.state === 'denied') && (
                <button
                  type="button"
                  onClick={() => setExplaining(p)}
                  className="min-h-[36px] rounded-xl px-3 text-[11px] font-bold text-white cursor-pointer"
                  style={{ backgroundColor: 'var(--jp-accent-primary)' }}
                >
                  {ar ? 'معاينة شاشة الشرح وطلبها' : 'Show JIT Rationale'}
                </button>
              )}
              {p.state === 'granted' && (
                <button
                  type="button"
                  onClick={() => onUpdatePerm(p.id, p.supportsPartial ? 'partial' : 'denied')}
                  className="jp-elevated min-h-[34px] rounded-xl px-2.5 text-[10.5px] font-semibold cursor-pointer"
                >
                  {ar ? 'محاكاة السحب أثناء التشغيل' : 'Simulate Runtime Revoke'}
                </button>
              )}
            </div>
          </div>
        );
      })}

      {/* Pre-Request JIT Rationale Modal */}
      {explaining && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'var(--jp-bg-overlay)' }}
          onClick={() => setExplaining(null)}
        >
          <div
            className="jp-hero-enter jp-surface w-full max-w-sm rounded-3xl p-4 space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[14px] font-bold">
                <Info className="h-4 w-4" style={{ color: 'var(--jp-accent-primary)' }} />
                {ar ? explaining.titleAr : explaining.titleEn}
              </span>
              <button type="button" onClick={() => setExplaining(null)} className="cursor-pointer">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="jp-elevated rounded-2xl p-3 space-y-2 text-[11.5px]">
              <div>
                <div className="font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
                  {ar ? 'لماذا نحتاج هذه الصلاحية؟' : 'Why do we need it?'}
                </div>
                <p style={{ color: 'var(--jp-text-secondary)' }}>
                  {ar ? explaining.whyAr : explaining.whyEn}
                </p>
              </div>
              <div>
                <div className="font-bold" style={{ color: 'var(--jp-status-success)' }}>
                  {ar ? 'ماذا يحدث لو رفضتها؟' : 'What if you decline?'}
                </div>
                <p style={{ color: 'var(--jp-text-secondary)' }}>
                  {ar ? explaining.ifDeniedAr : explaining.ifDeniedEn}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  onUpdatePerm(explaining.id, 'granted');
                  setExplaining(null);
                }}
                className="flex-1 min-h-[44px] rounded-xl text-[12px] font-bold text-white cursor-pointer"
                style={{ backgroundColor: 'var(--jp-accent-primary)' }}
              >
                {ar ? 'متابعة ومنح الصلاحية' : 'Continue & Grant'}
              </button>
              <button
                type="button"
                onClick={() => {
                  onUpdatePerm(explaining.id, 'denied');
                  setExplaining(null);
                }}
                className="jp-elevated min-h-[44px] rounded-xl px-3.5 text-[12px] font-semibold cursor-pointer"
              >
                {ar ? 'ليس الآن' : 'Not Now'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
 * 13. ADVANCED SETTINGS, SHIZUKU HELPER & LIVE CAPABILITY LADDER (16 & 18)
 * ============================================================================ */
export const AdvancedSettingsScreen: React.FC<{
  locale: Locale;
  isLowEnd: boolean;
  deviceAlias: string;
  onChangeAlias: (v: string) => void;
  flavor: 'play' | 'full';
  onChangeFlavor: (f: 'play' | 'full') => void;
  hidePrivateNames: boolean;
  onToggleHideNames: () => void;
  onNavigate: (s: ScreenId) => void;
  onToast: (msg: string) => void;
}> = ({
  locale,
  isLowEnd,
  deviceAlias,
  onChangeAlias,
  flavor,
  onChangeFlavor,
  hidePrivateNames,
  onToggleHideNames,
  onNavigate,
  onToast,
}) => {
  const ar = locale === 'ar';
  const [folderMode, setFolderMode] = useState<'mediastore' | 'saf' | 'root'>('mediastore');
  const [approvalMode, setApprovalMode] = useState<'always' | 'new_only' | 'trusted_auto'>('trusted_auto');
  const [shizukuOn, setShizukuOn] = useState(false);
  const [idleMin, setIdleMin] = useState(30);
  const [blake3On, setBlake3On] = useState(true);

  const systemLadder = [
    {
      feat: ar ? 'إنشاء الشبكة' : 'Network Creation',
      level: shizukuOn && flavor === 'full' ? 'Tier 1: SoftAP (Shizuku)' : 'Tier 2: Wi-Fi Direct 5GHz',
      note: shizukuOn ? (ar ? 'اسم وكلمة مخصصان' : 'Custom SSID') : ar ? 'IP ثابت 192.168.49.1' : 'Fixed 192.168.49.1',
    },
    {
      feat: ar ? 'الخدمة الخلفية' : 'Background Engine',
      level: isLowEnd ? 'Tier 2: connectedDevice (API 30)' : 'Tier 1: UIDT Job (API 35)',
      note: isLowEnd ? (ar ? 'إشعار خفيف + استئناف' : 'Resumable FGS') : ar ? 'بدون حد 6 ساعات + onTimeout' : 'No 6h cap + onTimeout',
    },
    {
      feat: ar ? 'التخزين وJOPRO' : 'Storage I/O',
      level: 'RawFd + fallocate + pwrite',
      note: folderMode === 'mediastore' ? 'Download/JOPRO (IS_PENDING)' : folderMode === 'saf' ? 'SAF Persistable' : '/sdcard/JOPRO (full)',
    },
    {
      feat: ar ? 'التشفير والصفحات' : 'Crypto & ELF',
      level: isLowEnd ? 'TLS 1.3 ChaCha20 · 2 Streams' : 'TLS 1.3 AES-GCM HW · 16KB ELF',
      note: isLowEnd ? '2.4GHz (~5.2 MB/s)' : '5GHz (~68 MB/s)',
    },
  ];

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      {/* Profile & Port */}
      <div className="jp-surface rounded-2xl p-3.5 space-y-2.5 text-[12px]">
        <div className="font-bold">{ar ? 'الملف الشخصي والمنفذ' : 'Identity & Port'}</div>
        <div className="flex gap-2">
          <input
            type="text"
            value={deviceAlias}
            onChange={(e) => onChangeAlias(e.target.value)}
            className="jp-elevated flex-1 rounded-xl px-3 py-2 text-[12.5px] outline-none"
          />
          <span className="jp-elevated jp-mono flex items-center rounded-xl px-3 text-[11.5px] font-bold">
            :53317
          </span>
        </div>
      </div>

      {/* Download/JOPRO Receive Folder Ladder */}
      <div className="jp-surface rounded-2xl p-3.5 space-y-2 text-[11.5px]">
        <div className="flex items-center gap-1.5 font-bold text-[12px]">
          <Folder className="h-4 w-4" style={{ color: 'var(--jp-accent-primary)' }} />
          <span>{ar ? 'مجلد الاستقبال JOPRO (متوافق مع Scoped Storage)' : 'JOPRO Receive Folder'}</span>
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          <button
            type="button"
            onClick={() => setFolderMode('mediastore')}
            className="min-h-[38px] rounded-xl px-2 text-[10.5px] font-bold cursor-pointer"
            style={{
              backgroundColor: folderMode === 'mediastore' ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
              color: folderMode === 'mediastore' ? '#FFF' : 'var(--jp-text-secondary)',
            }}
          >
            Download/JOPRO
          </button>
          <button
            type="button"
            onClick={() => setFolderMode('saf')}
            className="min-h-[38px] rounded-xl px-2 text-[10.5px] font-bold cursor-pointer"
            style={{
              backgroundColor: folderMode === 'saf' ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
              color: folderMode === 'saf' ? '#FFF' : 'var(--jp-text-secondary)',
            }}
          >
            SAF (JOPRO)
          </button>
          <button
            type="button"
            disabled={flavor === 'play'}
            onClick={() => setFolderMode('root')}
            className="min-h-[38px] rounded-xl px-2 text-[10.5px] font-bold disabled:opacity-40 cursor-pointer"
            style={{
              backgroundColor: folderMode === 'root' ? 'var(--jp-accent-signal)' : 'var(--jp-bg-elevated)',
              color: folderMode === 'root' ? '#FFF' : 'var(--jp-text-secondary)',
            }}
          >
            /sdcard/JOPRO
          </button>
        </div>
        <p className="text-[10.5px]" style={{ color: 'var(--jp-text-muted)' }}>
          {ar
            ? 'الافتراضي Download/JOPRO يعمل عبر MediaStore دون أي صلاحية. جذر /sdcard/JOPRO مقيّد في Android 11+ ويتاح عبر SAF أو في نكهة full.'
            : 'Default Download/JOPRO needs zero permission via MediaStore. Root /sdcard/JOPRO requires SAF or `full` flavor.'}
        </p>
      </div>

      {/* Security, Privacy, Notifications & Widgets */}
      <div className="jp-surface rounded-2xl p-3.5 space-y-2.5 text-[11.5px]">
        <div className="font-bold text-[12px]">
          {ar ? 'الأمان والإشعارات والويدجتس والخلفية' : 'Security, Notifications & Widgets'}
        </div>
        <div className="grid grid-cols-3 gap-1 text-[10.5px]">
          {[
            { id: 'always' as const, l: ar ? 'موافقة دائمًا' : 'Ask Always' },
            { id: 'new_only' as const, l: ar ? 'للجدد فقط' : 'New Peers' },
            { id: 'trusted_auto' as const, l: ar ? 'تلقائي للموثوق' : 'Trusted Auto' },
          ].map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setApprovalMode(m.id)}
              className="min-h-[34px] rounded-lg font-semibold cursor-pointer"
              style={{
                backgroundColor: approvalMode === m.id ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                color: approvalMode === m.id ? '#FFF' : 'var(--jp-text-secondary)',
              }}
            >
              {m.l}
            </button>
          ))}
        </div>

        <label className="flex items-center justify-between cursor-pointer">
          <span>{ar ? 'إخفاء أسماء الملفات في شاشة القفل والويدجتس' : 'Hide filenames on Lockscreen & Widgets'}</span>
          <input type="checkbox" checked={hidePrivateNames} onChange={onToggleHideNames} className="h-4 w-4 accent-[#2F7CF6]" />
        </label>

        <label className="flex items-center justify-between cursor-pointer">
          <span>{ar ? 'فحص سلامة المقاطع BLAKE3 افتراضيًا' : 'BLAKE3 chunk integrity check'}</span>
          <input type="checkbox" checked={blake3On} onChange={(e) => setBlake3On(e.target.checked)} className="h-4 w-4 accent-[#2F7CF6]" />
        </label>

        <div className="flex items-center justify-between">
          <span>{ar ? 'إيقاف الاستقبال بعد خمول:' : 'Auto-stop Receive after idle:'}</span>
          <select
            value={idleMin}
            onChange={(e) => setIdleMin(Number(e.target.value))}
            className="jp-elevated rounded-lg px-2 py-1 text-[11px]"
          >
            <option value={15}>15 min</option>
            <option value={30}>30 min</option>
            <option value={60}>60 min</option>
          </select>
        </div>

        <div className="flex gap-2 pt-1">
          <button
            type="button"
            onClick={() => onNavigate('permissions')}
            className="jp-elevated flex-1 min-h-[38px] rounded-xl text-[11px] font-bold cursor-pointer"
          >
            {ar ? 'شاشة الأذونات الحية' : 'Live Permissions'}
          </button>
          <button
            type="button"
            onClick={() => onToast(ar ? 'فُتحت قنوات إشعارات النظام (4 قنوات مستقلة) ونصائح Samsung/Xiaomi' : 'Opened Android Notification Channels')}
            className="jp-elevated flex-1 min-h-[38px] rounded-xl text-[11px] font-bold cursor-pointer"
          >
            {ar ? 'قنوات الإشعارات (4)' : '4 Notif Channels'}
          </button>
        </div>
      </div>

      {/* Distribution Flavor & Optional Shizuku Helper (Sections 18.1 & 18.9) */}
      <div className="jp-surface rounded-2xl p-3.5 space-y-2.5 text-[11.5px]">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-bold text-[12px]">
            <Terminal className="h-4 w-4" style={{ color: 'var(--jp-accent-signal)' }} />
            {ar ? 'نكهة البناء ومساعد Shizuku الاختياري' : 'Build Flavor & Optional Shizuku'}
          </span>
          <div className="jp-elevated flex rounded-lg p-0.5 text-[10.5px] font-bold">
            <button
              type="button"
              onClick={() => {
                onChangeFlavor('play');
                setShizukuOn(false);
                if (folderMode === 'root') setFolderMode('mediastore');
              }}
              className="rounded-md px-2 py-1 cursor-pointer"
              style={{ backgroundColor: flavor === 'play' ? 'var(--jp-accent-primary)' : 'transparent', color: flavor === 'play' ? '#FFF' : 'var(--jp-text-secondary)' }}
            >
              play
            </button>
            <button
              type="button"
              onClick={() => onChangeFlavor('full')}
              className="rounded-md px-2 py-1 cursor-pointer"
              style={{ backgroundColor: flavor === 'full' ? 'var(--jp-accent-signal)' : 'transparent', color: flavor === 'full' ? '#FFF' : 'var(--jp-text-secondary)' }}
            >
              full
            </button>
          </div>
        </div>

        {flavor === 'full' ? (
          <label className="jp-elevated flex items-start justify-between gap-2 rounded-xl p-2.5 cursor-pointer">
            <div>
              <div className="font-bold">{ar ? 'تفعيل Shizuku (اختياري · قائمة بيضاء ثابتة)' : 'Enable Shizuku (Opt-in Allowlist)'}</div>
              <p className="text-[10.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
                {ar
                  ? 'يفتح هوتسبوت باسم مخصص وتثبيت صامت ونسخ OBB. لا يُمرَّر أي نص من الشبكة لأي أمر، والتطبيق يعمل كاملًا بدونه.'
                  : 'Unlocks custom SoftAP, silent install & OBB copy. Strict static command allowlist; app runs 100% without it.'}
              </p>
            </div>
            <input
              type="checkbox"
              checked={shizukuOn}
              onChange={(e) => setShizukuOn(e.target.checked)}
              className="mt-1 h-4 w-4 accent-[#F59E0B]"
            />
          </label>
        ) : (
          <p className="text-[10.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
            {ar
              ? 'نكهة Google Play خالية تمامًا من MANAGE_EXTERNAL_STORAGE وQUERY_ALL_PACKAGES وShizuku.'
              : '`play` flavor excludes MANAGE_EXTERNAL_STORAGE, QUERY_ALL_PACKAGES, and Shizuku.'}
          </p>
        )}
      </div>

      {/* Section 18.10 Live System Capability Status Table */}
      <div className="jp-surface rounded-2xl p-3.5 space-y-2 text-[11px]">
        <div className="flex items-center gap-1.5 text-[12px] font-bold">
          <Layers className="h-4 w-4" style={{ color: 'var(--jp-status-success)' }} />
          <span>{ar ? 'حالة النظام: المستوى الفعّال لكل ميزة' : 'System Status: Active Capability Ladder'}</span>
        </div>
        {systemLadder.map((row, idx) => (
          <div key={idx} className="jp-elevated flex items-center justify-between gap-2 rounded-xl px-2.5 py-2">
            <span className="font-semibold">{row.feat}</span>
            <div className="text-end">
              <div className="jp-mono text-[10.5px] font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
                {row.level}
              </div>
              <div className="text-[10px]" style={{ color: 'var(--jp-text-muted)' }}>
                {row.note}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

/* ============================================================================
 * 14. NOTIFICATIONS SHADE & 5 HOME SCREEN WIDGETS GALLERY (Sections 4, 5 & 14)
 * ============================================================================ */
type WidgetStateMode = 'active' | 'empty' | 'loading' | 'error' | 'stopped';

export const NotificationsAndWidgetsGallery: React.FC<{
  locale: Locale;
  hidePrivateNames: boolean;
  onToggleHideNames: () => void;
  receiveOn: boolean;
  onToggleReceive: () => void;
  onToast: (msg: string) => void;
}> = ({ locale, hidePrivateNames, onToggleHideNames, receiveOn, onToggleReceive, onToast }) => {
  const ar = locale === 'ar';
  const [sub, setSub] = useState<'widgets' | 'notifications'>('widgets');
  const [widgetState, setWidgetState] = useState<WidgetStateMode>('active');
  const [lockscreenView, setLockscreenView] = useState(false);

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      <div className="jp-elevated grid grid-cols-2 gap-1 rounded-2xl p-1 text-[12px] font-bold">
        <button
          type="button"
          onClick={() => setSub('widgets')}
          className="min-h-[40px] rounded-xl cursor-pointer"
          style={{
            backgroundColor: sub === 'widgets' ? 'var(--jp-bg-surface)' : 'transparent',
            color: sub === 'widgets' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          {ar ? 'الويدجتس (5) + البلاطة' : '5 Widgets + Quick Tile'}
        </button>
        <button
          type="button"
          onClick={() => setSub('notifications')}
          className="min-h-[40px] rounded-xl cursor-pointer"
          style={{
            backgroundColor: sub === 'notifications' ? 'var(--jp-bg-surface)' : 'transparent',
            color: sub === 'notifications' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          {ar ? 'ظل الإشعارات (Android 16)' : 'Notification Shade'}
        </button>
      </div>

      {sub === 'widgets' ? (
        <div className="space-y-3">
          {/* Widget State Switcher + Privacy Toggle */}
          <div className="flex flex-wrap items-center justify-between gap-1.5">
            {(['active', 'empty', 'loading', 'error', 'stopped'] as WidgetStateMode[]).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setWidgetState(st)}
                className="rounded-full px-2.5 py-1 text-[10.5px] font-bold cursor-pointer"
                style={{
                  backgroundColor: widgetState === st ? 'var(--jp-accent-primary)' : 'var(--jp-bg-surface)',
                  color: widgetState === st ? '#FFF' : 'var(--jp-text-secondary)',
                }}
              >
                {st === 'active'
                  ? ar ? 'نشط' : 'Active'
                  : st === 'empty'
                    ? ar ? 'فارغ' : 'Empty'
                    : st === 'loading'
                      ? ar ? 'تحميل' : 'Loading'
                      : st === 'error'
                        ? ar ? 'صلاحية/خطأ' : 'Error'
                        : ar ? 'متوقف' : 'Stopped'}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={onToggleHideNames}
            className="jp-elevated flex w-full items-center justify-between rounded-xl px-3 py-2 text-[11px] cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <EyeOff className="h-3.5 w-3.5" style={{ color: 'var(--jp-accent-primary)' }} />
              {ar ? 'خصوصية الويدجت: إخفاء أسماء الملفات' : 'Widget Privacy: Hide file names'}
            </span>
            <span className="font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
              {hidePrivateNames ? (ar ? 'مخفية (افتراضي)' : 'Hidden') : ar ? 'ظاهرة' : 'Shown'}
            </span>
          </button>

          {/* Quick Settings Tile */}
          <button
            type="button"
            onClick={onToggleReceive}
            className="flex w-full min-h-[54px] items-center justify-between rounded-[22px] px-4 text-start cursor-pointer"
            style={{
              backgroundColor: receiveOn ? 'var(--jp-accent-primary)' : 'var(--jp-bg-surface)',
              color: receiveOn ? '#FFFFFF' : 'var(--jp-text-primary)',
              border: '1px solid var(--jp-border-subtle)',
            }}
          >
            <div className="flex items-center gap-2.5">
              <Radio className="h-4 w-4" />
              <div>
                <div className="text-[12px] font-bold">
                  {ar ? 'بلاطة الإعدادات السريعة: الاستقبال' : 'Quick Settings Tile: Receive'}
                </div>
                <div className="text-[10.5px] opacity-85">
                  {receiveOn ? (ar ? 'مرئي · Download/JOPRO' : 'Visible · Download/JOPRO') : ar ? 'متوقف' : 'Off'}
                </div>
              </div>
            </div>
            <span className="text-[11px] font-bold">{receiveOn ? 'ON' : 'OFF'}</span>
          </button>

          {/* WIDGET 1: Quick Send (4x1) */}
          <div className="jp-surface rounded-[22px] p-3 space-y-2">
            <div className="flex items-center justify-between text-[10px]" style={{ color: 'var(--jp-text-muted)' }}>
              <span>{ar ? '1. ويدجت الإرسال السريع (4×1)' : '1. Quick Send Widget (4×1)'}</span>
              <span className="jp-mono">FLAG_IMMUTABLE</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { l: ar ? 'إرسال' : 'Send', ic: <Send className="h-4 w-4" />, c: 'var(--jp-accent-primary)' },
                { l: ar ? 'مسح QR' : 'Scan QR', ic: <QrCode className="h-4 w-4" />, c: 'var(--jp-accent-signal)' },
                { l: ar ? 'استقبال' : 'Receive', ic: <Radio className="h-4 w-4" />, c: 'var(--jp-status-success)' },
              ].map((b, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => onToast(ar ? `ضغطة ويدجت: ${b.l} (مسار مسموح على Android 12+)` : `Widget action: ${b.l}`)}
                  className="jp-elevated flex min-h-[48px] items-center justify-center gap-1.5 rounded-2xl text-[11.5px] font-bold cursor-pointer"
                >
                  <span style={{ color: b.c }}>{b.ic}</span>
                  <span>{b.l}</span>
                </button>
              ))}
            </div>
          </div>

          {/* WIDGET 2 (Receive 2x2) + WIDGET 4 (Web Share + Real QR 2x2) */}
          <div className="grid grid-cols-2 gap-2.5">
            {/* Widget 2 */}
            <div className="jp-surface flex flex-col justify-between rounded-[22px] p-3 space-y-2">
              <div className="flex items-center justify-between">
                <DeviceAvatar seed={2} initials="SJ" accent="#2F7CF6" size={34} />
                <span
                  className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                  style={{
                    backgroundColor: widgetState === 'stopped' ? 'var(--jp-bg-elevated)' : 'var(--jp-status-success-soft)',
                    color: widgetState === 'stopped' ? 'var(--jp-text-muted)' : 'var(--jp-status-success)',
                  }}
                >
                  {widgetState === 'stopped' ? (ar ? 'متوقف' : 'Off') : '5GHz'}
                </span>
              </div>
              <div>
                <div className="text-[11.5px] font-bold">{ar ? '2. حالة الاستقبال (2×2)' : '2. Receive (2×2)'}</div>
                <div className="jp-mono text-[10px]" style={{ color: 'var(--jp-text-secondary)' }}>
                  {widgetState === 'error'
                    ? ar ? 'افتح Wi-Fi للمتابعة' : 'Enable Wi-Fi'
                    : '192.168.1.42'}
                </div>
              </div>
            </div>

            {/* Widget 4: Real Locally Generated QR */}
            <div className="jp-surface flex flex-col items-center justify-between rounded-[22px] p-3 text-center space-y-1.5">
              <div className="text-[10.5px] font-bold">{ar ? '4. ويب + QR (3×3)' : '4. Web QR (3×3)'}</div>
              {widgetState === 'stopped' || widgetState === 'empty' ? (
                <div className="py-3 text-[10.5px]" style={{ color: 'var(--jp-text-muted)' }}>
                  {ar ? 'الخادم متوقف · اضغط للتشغيل' : 'Server stopped · Tap to start'}
                </div>
              ) : (
                <RealQrCode value="http://192.168.1.42:53317" size={68} className="p-1.5" />
              )}
              <div className="jp-mono text-[9.5px]" style={{ color: 'var(--jp-accent-primary)' }}>
                192.168.1.42:53317
              </div>
            </div>
          </div>

          {/* WIDGET 3: Live Transfer (4x2) */}
          <div className="jp-surface rounded-[22px] p-3.5 space-y-2">
            <div className="flex items-center justify-between text-[10.5px]">
              <span className="font-bold">{ar ? '3. ويدجت النقل الحي (4×2 · updatePeriodMillis=0)' : '3. Live Transfer (4×2 · Event-Driven)'}</span>
              <span className="jp-num font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
                {widgetState === 'active' ? '68% · 64.2 MB/s' : ''}
              </span>
            </div>
            {widgetState === 'active' && (
              <>
                <div className="text-[11.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
                  {hidePrivateNames
                    ? ar ? 'نقل 3 ملفات إلى هاتف طارق · متبقي 00:14' : '3 files to Tariq S24 · ETA 00:14'
                    : 'Desert_Odyssey_4K.mkv → Tariq S24 · 00:14'}
                </div>
                <div className="h-2.5 overflow-hidden rounded-full" style={{ backgroundColor: 'var(--jp-bg-elevated)' }}>
                  <div className="h-full w-[68%] rounded-full" style={{ backgroundColor: 'var(--jp-accent-primary)' }} />
                </div>
              </>
            )}
            {widgetState === 'empty' && (
              <div className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                {ar ? 'لا جلسات نشطة · آخر نقل مكتمل: 1.34 GB منذ 12 دقيقة ✓' : 'Idle · Last completed: 1.34 GB 12m ago ✓'}
              </div>
            )}
            {widgetState === 'loading' && (
              <div className="text-[11px]" style={{ color: 'var(--jp-text-muted)' }}>
                {ar ? 'جارٍ مزامنة حالة الخدمة الأمامية...' : 'Syncing Foreground Service state...'}
              </div>
            )}
            {(widgetState === 'error' || widgetState === 'stopped') && (
              <div className="text-[11px]" style={{ color: 'var(--jp-status-warning)' }}>
                {ar ? 'الخدمة متوقفة أو الصلاحية ناقصة — اضغط لإعادة التشغيل' : 'Service stopped / permission needed — Tap to fix'}
              </div>
            )}
          </div>

          {/* WIDGET 5: Scrollable Recent History (4x3) */}
          <div className="jp-surface rounded-[22px] p-3.5 space-y-2">
            <div className="text-[11px] font-bold">
              {ar ? '5. ويدجت السجل الأخير القابل للتمرير (4×3)' : '5. Scrollable History Widget (4×3)'}
            </div>
            <div className="max-h-28 space-y-1.5 overflow-y-auto jp-scroll text-[11px]">
              {[
                { dir: 'in', title: hidePrivateNames ? (ar ? 'تطبيق مستلم (92 MB)' : 'Received App (92 MB)') : 'OsmAnd_Splits (92 MB)', ok: true },
                { dir: 'out', title: hidePrivateNames ? (ar ? '48 صورة مرسلة (1.3 GB)' : '48 Photos Sent (1.3 GB)') : 'Wadi_Rum_RAW (1.3 GB)', ok: true },
                { dir: 'in', title: hidePrivateNames ? (ar ? 'أرشيف (74% استئناف)' : 'Archive (74% resume)') : 'Backup_2026.zip (74%)', ok: false },
              ].map((r, i) => (
                <div key={i} className="jp-elevated flex items-center justify-between rounded-xl px-2.5 py-1.5">
                  <span className="flex items-center gap-1.5">
                    {r.dir === 'in' ? (
                      <ArrowDownLeft className="h-3.5 w-3.5" style={{ color: 'var(--jp-status-success)' }} />
                    ) : (
                      <ArrowUpRight className="h-3.5 w-3.5" style={{ color: 'var(--jp-accent-primary)' }} />
                    )}
                    <span>{r.title}</span>
                  </span>
                  <span style={{ color: r.ok ? 'var(--jp-status-success)' : 'var(--jp-accent-signal)' }}>
                    {r.ok ? '✓' : '↻'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* Android 15/16 Notification Shade Showcase */
        <div className="space-y-2.5">
          <label className="jp-elevated flex items-center justify-between rounded-xl px-3 py-2 text-[11px] cursor-pointer">
            <span className="flex items-center gap-1.5">
              <Lock className="h-3.5 w-3.5" style={{ color: 'var(--jp-accent-primary)' }} />
              {ar ? 'معاينة النسخة العامة على شاشة القفل (بدون أسماء ملفات)' : 'Preview Lockscreen Public Version'}
            </span>
            <input type="checkbox" checked={lockscreenView} onChange={(e) => setLockscreenView(e.target.checked)} className="h-4 w-4 accent-[#2F7CF6]" />
          </label>

          {/* 1. Heads-Up Incoming Approval */}
          <div className="jp-surface rounded-2xl p-3 space-y-2" style={{ borderColor: 'var(--jp-accent-signal)' }}>
            <div className="flex items-center justify-between text-[10px]" style={{ color: 'var(--jp-accent-signal)' }}>
              <span className="flex items-center gap-1 font-bold">
                <BrandMark size={16} /> SISI Share · Heads-Up (60s)
              </span>
              <span className="jp-mono">BroadcastReceiver</span>
            </div>
            <div className="text-[12px] font-bold">
              {ar ? 'طلب اتصال من تابلت الاستوديو' : 'Connection request from Studio Pad'}
            </div>
            <div className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
              {lockscreenView
                ? ar ? 'طلب استقبال محلي في انتظار موافقتك' : 'Incoming LAN request awaiting approval'
                : ar ? '4 ملفات (1.18 GB) · بصمة C712:88B4' : '4 files (1.18 GB) · FP C712:88B4'}
            </div>
            <div className="flex gap-2 pt-0.5 text-[11px] font-bold">
              <button type="button" onClick={() => onToast(ar ? 'قُبل الطلب في الخلفية بدون فتح التطبيق' : 'Accepted in background')} className="rounded-lg px-2.5 py-1 text-white cursor-pointer" style={{ backgroundColor: 'var(--jp-status-success)' }}>{ar ? 'قبول' : 'Accept'}</button>
              <button type="button" onClick={() => onToast(ar ? 'رُفض الطلب وأُبلغ المرسل' : 'Rejected')} className="jp-elevated rounded-lg px-2.5 py-1 cursor-pointer">{ar ? 'رفض' : 'Reject'}</button>
              <button type="button" onClick={() => onToast(ar ? 'حُظرت بصمة الجهاز فورًا' : 'Blocked fingerprint')} className="rounded-lg px-2.5 py-1 cursor-pointer" style={{ backgroundColor: 'var(--jp-status-danger-soft)', color: 'var(--jp-status-danger)' }}>{ar ? 'حظر' : 'Block'}</button>
            </div>
          </div>

          {/* 2. Live Progress (Android 16 ProgressStyle + 1Hz EMA) */}
          <div className="jp-surface rounded-2xl p-3 space-y-2">
            <div className="flex items-center justify-between text-[10px]" style={{ color: 'var(--jp-text-muted)' }}>
              <span>{ar ? 'قناة النقل الجاري · 1Hz EMA · ProgressStyle' : 'Live Transfer · 1Hz EMA · ProgressStyle'}</span>
              <span className="jp-num font-bold" style={{ color: 'var(--jp-accent-primary)' }}>72%</span>
            </div>
            <div className="text-[12px] font-bold">
              {lockscreenView
                ? ar ? 'نقل محلي جارٍ (72%)' : 'Local transfer in progress (72%)'
                : 'Desert_Odyssey_4K.mkv → Tariq S24'}
            </div>
            <div className="jp-num text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
              66.8 MB/s · {ar ? 'المتبقي 00:12' : 'ETA 00:12'}
            </div>
            <div className="h-2 overflow-hidden rounded-full" style={{ backgroundColor: 'var(--jp-bg-elevated)' }}>
              <div className="h-full w-[72%] rounded-full" style={{ backgroundColor: 'var(--jp-accent-primary)' }} />
            </div>
            <div className="flex gap-3 text-[11px] font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
              <button type="button" className="flex items-center gap-1 cursor-pointer"><Pause className="h-3 w-3" />{ar ? 'إيقاف مؤقت' : 'Pause'}</button>
              <button type="button" className="cursor-pointer" style={{ color: 'var(--jp-status-danger)' }}>{ar ? 'إلغاء' : 'Cancel'}</button>
            </div>
          </div>

          {/* 3. Multi-send Group Summary */}
          <div className="jp-surface rounded-2xl p-3 space-y-1.5 text-[11px]">
            <div className="font-bold text-[12px]">{ar ? 'إرسال متعدد مجمّع (3 أجهزة · 81%)' : 'Multi-Send Summary (3 Peers · 81%)'}</div>
            <div style={{ color: 'var(--jp-text-secondary)' }}>• S24 (94%) · • Studio Pad (100% ✓) · • Galaxy A20 (49%)</div>
          </div>

          {/* 4. Completion + APK Install & Android 15 onTimeout */}
          <div className="jp-surface rounded-2xl p-3 space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between font-bold text-[12px]">
              <span style={{ color: 'var(--jp-status-success)' }}>{ar ? 'اكتمل الاستلام في Download/JOPRO/Apps' : 'Saved in Download/JOPRO/Apps'}</span>
              <CheckCircle2 className="h-4 w-4" style={{ color: 'var(--jp-status-success)' }} />
            </div>
            <div className="flex gap-3 pt-1 font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
              <span>{ar ? 'تثبيت' : 'Install'}</span>
              <span>{ar ? 'إظهار في المجلد' : 'Folder'}</span>
              <span>{ar ? 'مشاركة' : 'Share'}</span>
            </div>
          </div>

          <div className="jp-surface rounded-2xl p-3 space-y-1 text-[11px]">
            <div className="font-bold text-[12px]" style={{ color: 'var(--jp-status-warning)' }}>
              {ar ? 'Android 15 onTimeout: حُفظت حالة الاستئناف بأمان' : 'Android 15 onTimeout: Checkpoint Saved'}
            </div>
            <div style={{ color: 'var(--jp-text-secondary)' }}>
              {ar ? 'بلغت الخدمة حد الخلفية اليومي؛ جميع بصمات BLAKE3 محفوظة. [متابعة النقل]' : 'FGS time limit reached; all BLAKE3 chunks saved. [Resume]'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
 * 15. EMPTY, DEGRADED & ERROR STATES (Section 18.10: What + Why + Action)
 * ============================================================================ */
export const EmptyAndErrorStatesGallery: React.FC<{
  locale: Locale;
  onToast: (msg: string) => void;
}> = ({ locale, onToast }) => {
  const ar = locale === 'ar';

  const states = [
    {
      icon: <HardDrive className="h-4 w-4" />,
      tone: 'var(--jp-status-danger)',
      what: ar ? 'تعذّر قبول الاستلام: المساحة غير كافية' : 'Cannot accept: Insufficient storage',
      why: ar ? 'كشف fallocate أن الملف يتطلب 14.8 GB بينما المتاح 6.2 GB فقط.' : 'Upfront fallocate needs 14.8 GB; only 6.2 GB free.',
      action: ar ? 'تغيير المجلد / تفريغ مساحة' : 'Free Space / Pick SAF',
    },
    {
      icon: <AlertOctagon className="h-4 w-4" />,
      tone: 'var(--jp-status-warning)',
      what: ar ? 'قيد FAT32: الملف أكبر من 4.0 GB' : 'FAT32 Limit: File exceeds 4.0 GB',
      why: ar ? 'بطاقة SD المختارة بنظام FAT32 لا تقبل ملفًا بحجم 4.96 GB.' : 'Selected FAT32 SD card rejects files > 4 GiB.',
      action: ar ? 'الحفظ في Download/JOPRO الداخلي' : 'Save to Internal JOPRO',
    },
    {
      icon: <Wifi className="h-4 w-4" />,
      tone: 'var(--jp-accent-signal)',
      what: ar ? 'الراوتر يعزل الأجهزة (AP Isolation)' : 'Router AP Isolation Detected',
      why: ar ? 'وصل إعلان الجهاز لكن الراوتر حجب اتصال TCP المباشر بينكما.' : 'Discovery packet received, but router blocked peer TCP.',
      action: ar ? 'إنشاء شبكة Wi-Fi Direct فورًا' : 'Start Wi-Fi Direct AP',
    },
    {
      icon: <Thermometer className="h-4 w-4" />,
      tone: 'var(--jp-accent-primary)',
      what: ar ? 'تم خفض الاتصالات المتوازية (6 → 2)' : 'Thermal Protection: Streams 6 → 2',
      why: ar ? 'رصد ThermalStatus ارتفاع حرارة الجهاز؛ خُفّض الحمل للحفاظ على البطارية دون قطع النقل.' : 'ThermalStatus elevated; throttled streams safely without dropping session.',
      action: ar ? 'إبقاء الوضع الهادئ' : 'Keep Cool Mode',
    },
    {
      icon: <ShieldAlert className="h-4 w-4" />,
      tone: 'var(--jp-text-secondary)',
      what: ar ? 'تبويب جهات الاتصال غير مفعّل (حالة فارغة)' : 'Contacts Tab Disabled (Empty State)',
      why: ar ? 'لم تُمنح صلاحية READ_CONTACTS بعد؛ بقية مدير الملفات يعمل طبيعيًا.' : 'READ_CONTACTS not granted; all other tabs work normally.',
      action: ar ? 'تفعيل جهات الاتصال' : 'Enable Contacts',
    },
  ];

  return (
    <div className="jp-screen-enter space-y-2.5 p-3.5">
      <div className="text-[11.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
        {ar
          ? 'قاعدة القسم 18.10: كل حالة تعرض (1) ماذا حدث، (2) لماذا، (3) الإجراء المقترح بزر مباشر.'
          : 'Section 18.10 rule: Every error shows What happened, Why, and a direct Action.'}
      </div>
      {states.map((s, idx) => (
        <div key={idx} className="jp-surface rounded-2xl p-3 space-y-2">
          <div className="flex items-center gap-2 text-[12.5px] font-bold" style={{ color: s.tone }}>
            {s.icon}
            <span>{s.what}</span>
          </div>
          <p className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
            {s.why}
          </p>
          <button
            type="button"
            onClick={() => onToast(s.action)}
            className="jp-elevated min-h-[36px] rounded-xl px-3 text-[11px] font-bold cursor-pointer"
            style={{ color: 'var(--jp-accent-primary)' }}
          >
            {s.action}
          </button>
        </div>
      ))}
    </div>
  );
};

export { Bell, Cpu, RefreshCw, Settings };
