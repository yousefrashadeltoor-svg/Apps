import React, { useMemo, useState } from 'react';
import {
  Archive,
  Check,
  CheckSquare,
  Contact,
  Download,
  FileText,
  Film,
  Folder,
  FolderPlus,
  Globe,
  Grid,
  Image as ImageIcon,
  Layers,
  List,
  Music,
  Package,
  Play,
  QrCode,
  Radio,
  Search,
  Send,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Trash2,
  Wifi,
  X,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import {
  CustomFolderTab,
  formatBytes,
  Locale,
  PeerDevice,
  SAMPLE_APPS,
  SAMPLE_FILES,
  SampleAppItem,
  SampleFileItem,
  ScreenId,
} from '../data/previewData';
import { DeviceAvatar, GenerativeArtThumb } from './QrAndArtwork';

interface RadarProps {
  locale: Locale;
  isLowEnd: boolean;
  isTablet: boolean;
  receiveOn: boolean;
  onToggleReceive: () => void;
  peers: PeerDevice[];
  selectedPeerIds: string[];
  onTogglePeer: (id: string) => void;
  onNavigate: (s: ScreenId) => void;
  onTriggerIncoming: () => void;
  deviceAlias: string;
}

export const RadarHomeScreen: React.FC<RadarProps> = ({
  locale,
  isLowEnd,
  isTablet,
  receiveOn,
  onToggleReceive,
  peers,
  selectedPeerIds,
  onTogglePeer,
  onNavigate,
  onTriggerIncoming,
  deviceAlias,
}) => {
  const ar = locale === 'ar';
  const visiblePeers = peers.filter((p) => !p.blocked);
  const [inspectedPeer, setInspectedPeer] = useState<PeerDevice>(visiblePeers[0]);

  const linkBadge = isLowEnd
    ? {
        band: '2.4 GHz · Wi-Fi 4',
        mbps: '72 Mbps',
        ceil: '~5.2 MB/s',
        note: ar ? 'سقف Galaxy A20 الفيزيائي الحقيقي' : 'Honest Galaxy A20 physical ceiling',
      }
    : {
        band: '5 GHz · 80 MHz',
        mbps: '866 Mbps',
        ceil: '~68 MB/s',
        note: ar ? 'WifiLock: LOW_LATENCY مفعّل' : 'WifiLock: LOW_LATENCY active',
      };

  const quickActions: { id: ScreenId; label: string; icon: React.ReactNode; tone: string }[] = [
    {
      id: 'files',
      label: ar ? 'إرسال ملفات' : 'Send Files',
      icon: <Send className="h-4 w-4" />,
      tone: 'var(--jp-accent-primary)',
    },
    {
      id: 'qr',
      label: ar ? 'QR والشبكة' : 'QR & Direct',
      icon: <QrCode className="h-4 w-4" />,
      tone: 'var(--jp-accent-signal)',
    },
    {
      id: 'web',
      label: ar ? 'مشاركة الويب' : 'Web Share',
      icon: <Globe className="h-4 w-4" />,
      tone: 'var(--jp-status-success)',
    },
    {
      id: 'watch',
      label: ar ? 'مشاهدة مشتركة' : 'Watch Live',
      icon: <Play className="h-4 w-4" />,
      tone: 'var(--jp-status-info)',
    },
  ];

  return (
    <div className={`jp-screen-enter space-y-3.5 p-3.5 ${isTablet ? 'grid grid-cols-12 gap-4 space-y-0 p-5' : ''}`}>
      {/* Left / Main Radar Column */}
      <div className={isTablet ? 'col-span-7 space-y-3.5' : 'space-y-3.5'}>
        {/* Personal Identity & Live Link Ceiling Capsule */}
        <div className="jp-surface rounded-[18px] p-3.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <DeviceAvatar seed={2} initials="SJ" accent="#2F7CF6" size={44} trusted />
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h2 className="truncate text-[15px] font-bold">{deviceAlias}</h2>
                  <span
                    className="jp-mono rounded-md px-1.5 py-0.5 text-[10px] font-semibold"
                    style={{
                      backgroundColor: 'var(--jp-accent-primary-soft)',
                      color: 'var(--jp-accent-primary)',
                    }}
                  >
                    #7B3E
                  </span>
                </div>
                <p className="truncate text-[11.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
                  <span className="jp-mono">192.168.1.42:53317</span> ·{' '}
                  {receiveOn
                    ? ar
                      ? 'مرئي للأجهزة القريبة'
                      : 'Visible on LAN'
                    : ar
                      ? 'مخفي (الاستقبال متوقف)'
                      : 'Hidden (Receive off)'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onToggleReceive}
              aria-pressed={receiveOn}
              className="jp-transition flex min-h-[44px] shrink-0 items-center gap-1.5 rounded-full px-3.5 text-[12px] font-semibold cursor-pointer"
              style={{
                backgroundColor: receiveOn ? 'var(--jp-status-success-soft)' : 'var(--jp-bg-elevated)',
                color: receiveOn ? 'var(--jp-status-success)' : 'var(--jp-text-secondary)',
                border: `1px solid ${receiveOn ? 'var(--jp-status-success)' : 'var(--jp-border-subtle)'}`,
              }}
            >
              <Radio className="h-3.5 w-3.5" />
              <span>{receiveOn ? (ar ? 'نشط' : 'On') : ar ? 'متوقف' : 'Off'}</span>
            </button>
          </div>

          {/* Live Link Ceiling Bar (Section 18.2 & 18.8 Honest Speed) */}
          <div
            className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl px-3 py-2 text-[11px]"
            style={{ backgroundColor: 'var(--jp-bg-elevated)' }}
          >
            <div className="flex items-center gap-1.5">
              <Wifi className="h-3.5 w-3.5" style={{ color: 'var(--jp-accent-primary)' }} />
              <span className="jp-num font-semibold">{linkBadge.band}</span>
              <span style={{ color: 'var(--jp-text-muted)' }}>·</span>
              <span className="jp-num" style={{ color: 'var(--jp-text-secondary)' }}>
                {linkBadge.mbps}
              </span>
            </div>
            <div className="flex items-center gap-1.5 font-semibold" style={{ color: 'var(--jp-status-success)' }}>
              <span>{ar ? 'السقف المتوقع:' : 'Est. ceiling:'}</span>
              <span className="jp-num">{linkBadge.ceil}</span>
            </div>
          </div>
        </div>

        {/* Orbital Acoustic Radar */}
        <div
          className="jp-surface relative overflow-hidden rounded-[22px] p-4"
          style={{ minHeight: 248 }}
        >
          <div className="relative z-10 flex items-center justify-between text-[11px]">
            <span
              className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-semibold"
              style={{
                backgroundColor: 'var(--jp-bg-elevated)',
                color: 'var(--jp-text-secondary)',
              }}
            >
              <span
                className="h-2 w-2 rounded-full"
                style={{ backgroundColor: 'var(--jp-status-success)' }}
              />
              {ar
                ? `${visiblePeers.length} أجهزة · Multicast + mDNS`
                : `${visiblePeers.length} peers · Multicast + mDNS`}
            </span>
            <button
              type="button"
              onClick={onTriggerIncoming}
              className="jp-transition rounded-full px-2.5 py-1 font-semibold cursor-pointer"
              style={{
                backgroundColor: 'var(--jp-accent-signal-soft)',
                color: 'var(--jp-accent-signal)',
              }}
            >
              {ar ? 'تجربة طلب وارد' : 'Test Incoming'}
            </button>
          </div>

          {/* Radar Concentric Rings (60fps transform/opacity only) */}
          <div className="relative mx-auto my-2 flex h-[196px] w-[260px] items-center justify-center">
            <div
              className="pointer-events-none absolute h-[186px] w-[186px] rounded-full border"
              style={{ borderColor: 'var(--jp-radar-ring)' }}
            />
            <div
              className="pointer-events-none absolute h-[126px] w-[126px] rounded-full border border-dashed"
              style={{ borderColor: 'var(--jp-radar-ring)' }}
            />
            <div
              className="pointer-events-none absolute h-[66px] w-[66px] rounded-full border"
              style={{ borderColor: 'var(--jp-radar-ring)' }}
            />

            {receiveOn && (
              <>
                <div
                  className="jp-radar-wave pointer-events-none absolute h-[188px] w-[188px] rounded-full border-2"
                  style={{
                    borderColor: 'var(--jp-accent-primary)',
                    backgroundColor: 'var(--jp-radar-sweep)',
                  }}
                />
                {/* Low-End Galaxy A20 protection: single wave instead of triple overlapping waves */}
                {!isLowEnd && (
                  <div
                    className="jp-radar-wave jp-radar-wave-delay-1 pointer-events-none absolute h-[188px] w-[188px] rounded-full border"
                    style={{ borderColor: 'var(--jp-accent-primary)' }}
                  />
                )}
              </>
            )}

            {/* Center Node */}
            <div
              className="relative z-10 flex h-11 w-11 items-center justify-center rounded-full border-2 text-xs font-bold text-white shadow-md"
              style={{
                backgroundColor: 'var(--jp-accent-primary)',
                borderColor: 'var(--jp-bg-surface)',
              }}
            >
              {ar ? 'أنا' : 'ME'}
            </div>

            {/* Discovered Peer Nodes */}
            {visiblePeers.map((peer) => {
              const rad = (peer.orbitAngle * Math.PI) / 180;
              const rx = Math.cos(rad) * peer.orbitRadius * 114;
              const ry = Math.sin(rad) * peer.orbitRadius * 82;
              const selected = selectedPeerIds.includes(peer.id);
              return (
                <button
                  key={peer.id}
                  type="button"
                  onClick={() => {
                    setInspectedPeer(peer);
                    onTogglePeer(peer.id);
                  }}
                  style={{
                    transform: `translate(${rx}px, ${ry}px)`,
                  }}
                  className="jp-transition group absolute z-20 flex min-h-[48px] min-w-[48px] flex-col items-center justify-center cursor-pointer focus:outline-none"
                  aria-label={ar ? peer.aliasAr : peer.aliasEn}
                >
                  <div
                    className="rounded-2xl p-0.5 transition-transform group-hover:scale-105"
                    style={{
                      boxShadow: selected ? '0 0 0 2.5px var(--jp-accent-primary)' : 'none',
                    }}
                  >
                    <DeviceAvatar
                      seed={peer.seed}
                      initials={peer.initials}
                      accent={peer.accent}
                      size={38}
                      trusted={peer.trusted}
                    />
                  </div>
                  <span
                    className="mt-1 max-w-[92px] truncate rounded-md px-1.5 py-0.5 text-[10px] font-semibold"
                    style={{
                      backgroundColor: selected ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                      color: selected ? '#FFFFFF' : 'var(--jp-text-primary)',
                    }}
                  >
                    {(ar ? peer.aliasAr : peer.aliasEn).split('·')[0]}
                  </span>
                </button>
              );
            })}
          </div>

          <p className="text-center text-[11px]" style={{ color: 'var(--jp-text-muted)' }}>
            {ar
              ? 'انقر على جهاز أو أكثر للإرسال المتعدد (قراءة واحدة للملف)'
              : 'Tap one or multiple peers for single-read Multi-Send'}
          </p>
        </div>

        {/* 4 Quick Actions */}
        <div className="grid grid-cols-4 gap-2">
          {quickActions.map((act) => (
            <button
              key={act.id}
              type="button"
              onClick={() => onNavigate(act.id)}
              className="jp-surface jp-transition flex min-h-[66px] flex-col items-center justify-center gap-1.5 rounded-2xl p-2 text-center hover:opacity-95 active:scale-[0.98] cursor-pointer"
            >
              <span
                className="flex h-8 w-8 items-center justify-center rounded-xl text-white"
                style={{ backgroundColor: act.tone }}
              >
                {act.icon}
              </span>
              <span className="text-[11px] font-semibold leading-tight">{act.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Right / Bottom Discovered Devices List */}
      <div className={isTablet ? 'col-span-5 space-y-2.5' : 'space-y-2'}>
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[13px] font-bold">
            {ar ? 'الأجهزة القريبة وقدراتها' : 'Nearby Peers & Capabilities'}
          </h3>
          {selectedPeerIds.length > 0 && (
            <button
              type="button"
              onClick={() => onNavigate('readiness')}
              className="rounded-full px-3 py-1 text-[11.5px] font-bold text-white cursor-pointer"
              style={{ backgroundColor: 'var(--jp-accent-primary)' }}
            >
              {ar ? `إرسال إلى (${selectedPeerIds.length})` : `Send to (${selectedPeerIds.length})`}
            </button>
          )}
        </div>

        {visiblePeers.map((peer) => {
          const isSel = selectedPeerIds.includes(peer.id);
          return (
            <div
              key={peer.id}
              onClick={() => {
                setInspectedPeer(peer);
                onTogglePeer(peer.id);
              }}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && onTogglePeer(peer.id)}
              className="jp-surface jp-transition flex min-h-[64px] items-center justify-between gap-2.5 rounded-2xl p-3 cursor-pointer"
              style={{
                borderColor: isSel ? 'var(--jp-accent-primary)' : 'var(--jp-border-subtle)',
                backgroundColor: isSel ? 'var(--jp-accent-primary-soft)' : 'var(--jp-bg-surface)',
              }}
            >
              <div className="flex min-w-0 items-center gap-2.5">
                <DeviceAvatar
                  seed={peer.seed}
                  initials={peer.initials}
                  accent={peer.accent}
                  size={40}
                  trusted={peer.trusted}
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate text-[13px] font-semibold">
                      {ar ? peer.aliasAr : peer.aliasEn}
                    </span>
                  </div>
                  <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[10.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
                    <span
                      className="rounded px-1.5 py-0.2 font-semibold"
                      style={{
                        backgroundColor: 'var(--jp-bg-elevated)',
                        color: peer.protocol.startsWith('Nova') ? 'var(--jp-accent-primary)' : 'var(--jp-text-secondary)',
                      }}
                    >
                      {peer.protocol}
                    </span>
                    <span className="jp-num">{peer.band}</span>
                    <span className="jp-num" style={{ color: 'var(--jp-status-success)' }}>
                      ~{peer.ceilingMbs} MB/s
                    </span>
                  </div>
                </div>
              </div>
              <div
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border"
                style={{
                  borderColor: isSel ? 'var(--jp-accent-primary)' : 'var(--jp-border-strong)',
                  backgroundColor: isSel ? 'var(--jp-accent-primary)' : 'transparent',
                  color: '#FFFFFF',
                }}
              >
                {isSel && <Check className="h-3.5 w-3.5" />}
              </div>
            </div>
          );
        })}

        {isTablet && inspectedPeer && (
          <div className="jp-elevated rounded-2xl p-3 text-[11.5px]">
            <div className="font-bold">{ar ? 'بصمة الشهادة المثبتة (TOFU):' : 'Pinned TOFU Certificate:'}</div>
            <div className="jp-mono mt-1 text-[11px]" style={{ color: 'var(--jp-accent-primary)' }}>
              {inspectedPeer.fingerprint}
            </div>
            <div className="mt-1" style={{ color: 'var(--jp-text-secondary)' }}>
              {inspectedPeer.model} · {inspectedPeer.abi} · {linkBadge.note}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/* ============================================================================
 * 2. LOCAL FILE MANAGER (9 Tabs + Custom SAF Tabs + Drag-Select + Hero Zoom)
 * ============================================================================ */
interface FileManagerProps {
  locale: Locale;
  selectedFileIds: string[];
  onToggleFile: (id: string) => void;
  onSetSelectedFiles: (ids: string[]) => void;
  onNavigate: (s: ScreenId) => void;
  partialMediaAccess: boolean;
  onExpandPartialMedia: () => void;
}

export const FileManagerScreen: React.FC<FileManagerProps> = ({
  locale,
  selectedFileIds,
  onToggleFile,
  onSetSelectedFiles,
  onNavigate,
  partialMediaAccess,
  onExpandPartialMedia,
}) => {
  const ar = locale === 'ar';
  const [activeTab, setActiveTab] = useState<string>('photos');
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'name' | 'size'>('size');
  const [isDraggingSelect, setIsDraggingSelect] = useState(false);
  const [heroItem, setHeroItem] = useState<SampleFileItem | null>(null);
  const [showAddTab, setShowAddTab] = useState(false);
  const [newTabName, setNewTabName] = useState('');
  const [newTabIcon, setNewTabIcon] = useState<CustomFolderTab['icon']>('folder');
  const [customTabs, setCustomTabs] = useState<CustomFolderTab[]>([
    {
      id: 'custom-raw',
      labelAr: 'مشاريع هندسية (SAF)',
      labelEn: 'CAD Projects (SAF)',
      uriPath: 'content://com.android.externalstorage/tree/primary:Work_CAD',
      mode: 'SAF Persistable',
      icon: 'code',
    },
  ]);

  const builtInTabs = [
    { id: 'photos', label: ar ? 'صور' : 'Photos', icon: <ImageIcon className="h-3.5 w-3.5" /> },
    { id: 'videos', label: ar ? 'فيديو' : 'Videos', icon: <Film className="h-3.5 w-3.5" /> },
    { id: 'music', label: ar ? 'موسيقى' : 'Music', icon: <Music className="h-3.5 w-3.5" /> },
    { id: 'docs', label: ar ? 'مستندات' : 'Docs', icon: <FileText className="h-3.5 w-3.5" /> },
    { id: 'archives', label: ar ? 'مضغوطة' : 'Archives', icon: <Archive className="h-3.5 w-3.5" /> },
    { id: 'apps_jump', label: ar ? 'تطبيقات' : 'Apps', icon: <Package className="h-3.5 w-3.5" /> },
    { id: 'contacts', label: ar ? 'جهات اتصال' : 'Contacts', icon: <Contact className="h-3.5 w-3.5" /> },
    { id: 'downloads', label: ar ? 'JOPRO' : 'JOPRO', icon: <Download className="h-3.5 w-3.5" /> },
  ];

  const items = useMemo(() => {
    const base = SAMPLE_FILES.filter((f) =>
      activeTab.startsWith('custom-')
        ? f.category === activeTab || f.category === 'custom-raw'
        : f.category === activeTab
    );
    const filtered = search.trim()
      ? base.filter((f) => f.name.toLowerCase().includes(search.toLowerCase()))
      : base;
    return [...filtered].sort((a, b) =>
      sortBy === 'size' ? b.sizeBytes - a.sizeBytes : a.name.localeCompare(b.name)
    );
  }, [activeTab, search, sortBy]);

  const selectedBytes = useMemo(
    () =>
      SAMPLE_FILES.filter((f) => selectedFileIds.includes(f.id)).reduce(
        (acc, f) => acc + f.sizeBytes,
        0
      ),
    [selectedFileIds]
  );

  const handleSelectAllInTab = () => {
    const tabIds = items.map((i) => i.id);
    const allChosen = tabIds.every((id) => selectedFileIds.includes(id));
    if (allChosen) {
      onSetSelectedFiles(selectedFileIds.filter((id) => !tabIds.includes(id)));
    } else {
      onSetSelectedFiles(Array.from(new Set([...selectedFileIds, ...tabIds])));
    }
  };

  const addCustomTab = () => {
    const clean = newTabName.trim();
    if (!clean) return;
    const id = `custom-${Date.now()}`;
    setCustomTabs((prev) => [
      ...prev,
      {
        id,
        labelAr: clean,
        labelEn: clean,
        uriPath: `content://com.android.externalstorage/tree/primary:${clean.replace(/\s+/g, '_')}`,
        mode: 'SAF Persistable',
        icon: newTabIcon,
      },
    ]);
    setActiveTab(id);
    setNewTabName('');
    setShowAddTab(false);
  };

  const moveCustomTab = (idx: number, dir: -1 | 1) => {
    const target = idx + dir;
    if (target < 0 || target >= customTabs.length) return;
    const next = [...customTabs];
    [next[idx], next[target]] = [next[target], next[idx]];
    setCustomTabs(next);
  };

  return (
    <div
      className="jp-screen-enter space-y-3 p-3.5 pb-24"
      onMouseUp={() => setIsDraggingSelect(false)}
      onMouseLeave={() => setIsDraggingSelect(false)}
    >
      {/* Search + View Mode + Sort */}
      <div className="flex items-center gap-2">
        <div className="jp-surface flex min-h-[44px] flex-1 items-center gap-2 rounded-xl px-3">
          <Search className="h-4 w-4 shrink-0" style={{ color: 'var(--jp-text-muted)' }} />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={ar ? 'ابحث في MediaStore (فهرسة تدريجية)...' : 'Search MediaStore (lazy paged)...'}
            className="w-full bg-transparent text-[12.5px] outline-none"
          />
        </div>
        <button
          type="button"
          onClick={() => setSortBy((s) => (s === 'size' ? 'name' : 'size'))}
          className="jp-surface min-h-[44px] rounded-xl px-2.5 text-[11px] font-semibold cursor-pointer"
          title={ar ? 'تبديل الفرز' : 'Toggle Sort'}
        >
          {sortBy === 'size' ? (ar ? 'الحجم' : 'Size') : ar ? 'الاسم' : 'Name'}
        </button>
        <button
          type="button"
          onClick={() => setViewMode((v) => (v === 'grid' ? 'list' : 'grid'))}
          className="jp-surface flex h-[44px] w-[44px] items-center justify-center rounded-xl cursor-pointer"
          aria-label="Toggle layout"
        >
          {viewMode === 'grid' ? <List className="h-4 w-4" /> : <Grid className="h-4 w-4" />}
        </button>
      </div>

      {/* Scrollable Category Tabs + Custom SAF Tabs */}
      <div className="jp-no-scrollbar flex items-center gap-1.5 overflow-x-auto pb-1">
        {builtInTabs.map((t) => {
          const active = activeTab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => (t.id === 'apps_jump' ? onNavigate('apps') : setActiveTab(t.id))}
              className="jp-transition flex min-h-[38px] shrink-0 items-center gap-1.5 rounded-full px-3 text-[12px] font-semibold cursor-pointer"
              style={{
                backgroundColor: active ? 'var(--jp-accent-primary)' : 'var(--jp-bg-surface)',
                color: active ? '#FFFFFF' : 'var(--jp-text-secondary)',
                border: `1px solid ${active ? 'var(--jp-accent-primary)' : 'var(--jp-border-subtle)'}`,
              }}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          );
        })}
        {customTabs.map((ct) => {
          const active = activeTab === ct.id;
          return (
            <button
              key={ct.id}
              type="button"
              onClick={() => setActiveTab(ct.id)}
              className="jp-transition flex min-h-[38px] shrink-0 items-center gap-1.5 rounded-full px-3 text-[12px] font-semibold cursor-pointer"
              style={{
                backgroundColor: active ? 'var(--jp-accent-signal)' : 'var(--jp-accent-signal-soft)',
                color: active ? '#FFFFFF' : 'var(--jp-accent-signal)',
              }}
            >
              <Folder className="h-3.5 w-3.5" />
              <span>{ar ? ct.labelAr : ct.labelEn}</span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setShowAddTab(true)}
          className="jp-surface flex min-h-[38px] shrink-0 items-center gap-1 rounded-full px-3 text-[11.5px] font-semibold cursor-pointer"
          style={{ color: 'var(--jp-accent-primary)' }}
        >
          <FolderPlus className="h-3.5 w-3.5" />
          <span>{ar ? '+ تبويب مخصص' : '+ Custom Tab'}</span>
        </button>
      </div>

      {/* Android 14+ Partial Visual Media Access Banner (Section 3.1) */}
      {partialMediaAccess && (activeTab === 'photos' || activeTab === 'videos') && (
        <div
          className="flex items-center justify-between gap-2 rounded-2xl px-3 py-2.5 text-[11.5px]"
          style={{
            backgroundColor: 'var(--jp-accent-primary-soft)',
            border: '1px solid var(--jp-accent-primary)',
          }}
        >
          <div>
            <div className="font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
              {ar ? 'وصول جزئي للوسائط (Android 14+)' : 'Partial Media Access (Android 14+)'}
            </div>
            <div style={{ color: 'var(--jp-text-secondary)' }}>
              {ar
                ? 'نعرض فقط الصور التي اخترتها (VISUAL_USER_SELECTED).'
                : 'Showing only photos granted via VISUAL_USER_SELECTED.'}
            </div>
          </div>
          <button
            type="button"
            onClick={onExpandPartialMedia}
            className="shrink-0 rounded-xl px-3 py-1.5 text-[11px] font-bold text-white cursor-pointer"
            style={{ backgroundColor: 'var(--jp-accent-primary)' }}
          >
            {ar ? 'السماح بالمزيد' : 'Allow More'}
          </button>
        </div>
      )}

      {/* Custom SAF Tab controls */}
      {activeTab.startsWith('custom-') && (
        <div className="jp-elevated flex flex-wrap items-center justify-between gap-2 rounded-xl px-3 py-2 text-[11px]">
          <span className="jp-mono truncate" style={{ color: 'var(--jp-text-secondary)' }}>
            {customTabs.find((c) => c.id === activeTab)?.uriPath}
          </span>
          <div className="flex items-center gap-1">
            {(() => {
              const idx = customTabs.findIndex((c) => c.id === activeTab);
              return (
                <>
                  <button
                    type="button"
                    onClick={() => moveCustomTab(idx, -1)}
                    className="jp-surface rounded-lg p-1.5 cursor-pointer"
                    title={ar ? 'تقديم التبويب' : 'Move earlier'}
                  >
                    <ArrowUp className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => moveCustomTab(idx, 1)}
                    className="jp-surface rounded-lg p-1.5 cursor-pointer"
                    title={ar ? 'تأخير التبويب' : 'Move later'}
                  >
                    <ArrowDown className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCustomTabs((prev) => prev.filter((c) => c.id !== activeTab));
                      setActiveTab('photos');
                    }}
                    className="rounded-lg p-1.5 cursor-pointer"
                    style={{ backgroundColor: 'var(--jp-status-danger-soft)', color: 'var(--jp-status-danger)' }}
                    title={ar ? 'حذف التبويب' : 'Remove tab'}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* Select All & Drag Hint */}
      <div className="flex items-center justify-between px-1 text-[11.5px]">
        <span style={{ color: 'var(--jp-text-muted)' }}>
          {ar ? 'اسحب فوق العناصر للتحديد المتعدد السريع' : 'Drag across items for fast multi-select'}
        </span>
        <button
          type="button"
          onClick={handleSelectAllInTab}
          className="inline-flex items-center gap-1 font-semibold cursor-pointer"
          style={{ color: 'var(--jp-accent-primary)' }}
        >
          <CheckSquare className="h-3.5 w-3.5" />
          <span>{ar ? 'تحديد الكل' : 'Select All'}</span>
        </button>
      </div>

      {/* Files Grid / List */}
      <div
        className={
          viewMode === 'grid' && (activeTab === 'photos' || activeTab === 'videos' || activeTab === 'music')
            ? 'grid grid-cols-2 gap-2.5'
            : 'space-y-2'
        }
      >
        {items.map((item) => {
          const selected = selectedFileIds.includes(item.id);
          const isVisual = activeTab === 'photos' || activeTab === 'videos' || activeTab === 'music';
          const artKind = activeTab === 'videos' ? 'video' : activeTab === 'music' ? 'music' : 'photo';

          if (viewMode === 'grid' && isVisual) {
            return (
              <div
                key={item.id}
                onMouseDown={() => {
                  setIsDraggingSelect(true);
                  onToggleFile(item.id);
                }}
                onMouseEnter={() => {
                  if (isDraggingSelect && !selected) onToggleFile(item.id);
                }}
                className="jp-surface jp-transition group relative overflow-hidden rounded-2xl select-none cursor-pointer"
                style={{
                  borderColor: selected ? 'var(--jp-accent-primary)' : 'var(--jp-border-subtle)',
                  transform: selected ? 'scale(0.985)' : 'scale(1)',
                }}
              >
                <div className="relative h-28 w-full overflow-hidden">
                  <GenerativeArtThumb kind={artKind} palette={item.palette} seed={item.seed} />
                  {item.duration && (
                    <span className="jp-mono absolute start-2 bottom-2 rounded-md bg-black/70 px-1.5 py-0.5 text-[10px] font-semibold text-white">
                      {item.duration}
                    </span>
                  )}
                  {activeTab === 'photos' && (
                    <button
                      type="button"
                      onMouseDown={(e) => e.stopPropagation()}
                      onClick={(e) => {
                        e.stopPropagation();
                        setHeroItem(item);
                      }}
                      className="absolute start-2 top-2 rounded-lg bg-black/55 px-2 py-0.5 text-[10px] font-semibold text-white cursor-pointer"
                    >
                      Hero ⤢
                    </button>
                  )}
                  {activeTab === 'videos' && (
                    <button
                      type="button"
                      onMouseDown={(e) => e.stopPropagation()}
                      onClick={(e) => {
                        e.stopPropagation();
                        onNavigate('watch');
                      }}
                      className="absolute start-2 top-2 rounded-lg px-2 py-0.5 text-[10px] font-bold text-white cursor-pointer"
                      style={{ backgroundColor: 'var(--jp-accent-signal)' }}
                    >
                      {ar ? 'مشاهدة معًا' : 'Watch Live'}
                    </button>
                  )}
                  <span
                    className="absolute end-2 top-2 flex h-6 w-6 items-center justify-center rounded-full border text-white"
                    style={{
                      backgroundColor: selected ? 'var(--jp-accent-primary)' : 'rgba(0,0,0,0.45)',
                      borderColor: selected ? 'var(--jp-accent-primary)' : 'rgba(255,255,255,0.6)',
                    }}
                  >
                    {selected && <Check className="h-3.5 w-3.5" />}
                  </span>
                </div>
                <div className="p-2.5">
                  <div className="truncate text-[12px] font-semibold">{item.name}</div>
                  <div
                    className="mt-0.5 flex items-center justify-between text-[10.5px]"
                    style={{ color: 'var(--jp-text-secondary)' }}
                  >
                    <span className="truncate">{item.albumAr ? (ar ? item.albumAr : item.albumEn) : ''}</span>
                    <span className="jp-num font-semibold">{formatBytes(item.sizeBytes)}</span>
                  </div>
                </div>
              </div>
            );
          }

          return (
            <div
              key={item.id}
              onMouseDown={() => {
                setIsDraggingSelect(true);
                onToggleFile(item.id);
              }}
              onMouseEnter={() => {
                if (isDraggingSelect && !selected) onToggleFile(item.id);
              }}
              className="jp-surface jp-transition flex min-h-[60px] items-center justify-between gap-2.5 rounded-2xl p-2.5 select-none cursor-pointer"
              style={{
                borderColor: selected ? 'var(--jp-accent-primary)' : 'var(--jp-border-subtle)',
                backgroundColor: selected ? 'var(--jp-accent-primary-soft)' : 'var(--jp-bg-surface)',
              }}
            >
              <div className="flex min-w-0 items-center gap-2.5">
                <div className="h-11 w-11 shrink-0 overflow-hidden rounded-xl">
                  <GenerativeArtThumb kind={isVisual ? artKind : 'app'} palette={item.palette} seed={item.seed} glyph={item.name.slice(0, 1)} />
                </div>
                <div className="min-w-0">
                  <div className="truncate text-[12.5px] font-semibold">{item.name}</div>
                  <div className="truncate text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                    {ar ? item.subtitleAr : item.subtitleEn}
                  </div>
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className="jp-num text-[11px] font-semibold" style={{ color: 'var(--jp-text-secondary)' }}>
                  {formatBytes(item.sizeBytes)}
                </span>
                <span
                  className="flex h-6 w-6 items-center justify-center rounded-lg border text-white"
                  style={{
                    borderColor: selected ? 'var(--jp-accent-primary)' : 'var(--jp-border-strong)',
                    backgroundColor: selected ? 'var(--jp-accent-primary)' : 'transparent',
                  }}
                >
                  {selected && <Check className="h-3.5 w-3.5" />}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating Selection Counter Dock */}
      {selectedFileIds.length > 0 && (
        <div
          className="sticky bottom-2 z-20 flex items-center justify-between gap-2 rounded-2xl p-3 text-white"
          style={{
            backgroundColor: 'var(--jp-accent-primary)',
            boxShadow: 'var(--jp-shadow-floating)',
          }}
        >
          <div className="text-[12px]">
            <div className="font-bold">
              {ar ? `${selectedFileIds.length} عناصر محددة` : `${selectedFileIds.length} selected`}
            </div>
            <div className="jp-num text-[11px] text-white/85">
              {formatBytes(selectedBytes)} · {ar ? 'تدفق مباشر بلا نسخ' : 'Zero-copy stream'}
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('readiness')}
            className="flex min-h-[40px] items-center gap-1.5 rounded-xl bg-white px-3.5 text-[12px] font-bold text-[#0D1421] cursor-pointer"
          >
            <Send className="h-3.5 w-3.5" />
            <span>{ar ? 'صفحة النقل' : 'Transfer'}</span>
          </button>
        </div>
      )}

      {/* Hero Transition Lightbox */}
      {heroItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'var(--jp-bg-overlay)' }}
          onClick={() => setHeroItem(null)}
        >
          <div
            className="jp-hero-enter jp-surface w-full max-w-md overflow-hidden rounded-3xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative h-60 w-full">
              <GenerativeArtThumb kind="photo" palette={heroItem.palette} seed={heroItem.seed} />
              <button
                type="button"
                onClick={() => setHeroItem(null)}
                className="absolute end-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-black/60 text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-4">
              <div className="text-[14px] font-bold">{heroItem.name}</div>
              <div className="mt-1 text-[12px]" style={{ color: 'var(--jp-text-secondary)' }}>
                {ar ? heroItem.subtitleAr : heroItem.subtitleEn} ·{' '}
                <span className="jp-num font-semibold">{formatBytes(heroItem.sizeBytes)}</span>
              </div>
              <div className="mt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (!selectedFileIds.includes(heroItem.id)) onToggleFile(heroItem.id);
                    setHeroItem(null);
                  }}
                  className="rounded-xl px-4 py-2 text-[12px] font-bold text-white cursor-pointer"
                  style={{ backgroundColor: 'var(--jp-accent-primary)' }}
                >
                  {ar ? 'تحديد للإرسال' : 'Select for Send'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Custom SAF Tab Sheet */}
      {showAddTab && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'var(--jp-bg-overlay)' }}
          onClick={() => setShowAddTab(false)}
        >
          <div
            className="jp-hero-enter jp-surface w-full max-w-sm rounded-3xl p-4 space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-[15px] font-bold">
                {ar ? 'إضافة تبويب مجلد مخصص (SAF)' : 'Add Custom SAF Folder Tab'}
              </h3>
              <button type="button" onClick={() => setShowAddTab(false)} className="cursor-pointer">
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="text-[12px]" style={{ color: 'var(--jp-text-secondary)' }}>
              {ar
                ? 'يحفظ التطبيق صلاحية URI دائمة (takePersistableUriPermission) بدون الحاجة لـ MANAGE_EXTERNAL_STORAGE.'
                : 'Uses takePersistableUriPermission via SAF — no MANAGE_EXTERNAL_STORAGE required.'}
            </p>
            <input
              type="text"
              value={newTabName}
              onChange={(e) => setNewTabName(e.target.value)}
              placeholder={ar ? 'مثال: تصوير الدرون أو كتب PDF' : 'e.g. Drone RAW or Books'}
              className="jp-elevated w-full rounded-xl px-3 py-2.5 text-[13px] outline-none"
            />
            <div className="flex gap-2">
              {(['folder', 'camera', 'code', 'film'] as const).map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setNewTabIcon(ic)}
                  className="flex-1 rounded-xl py-2 text-[11px] font-semibold cursor-pointer"
                  style={{
                    backgroundColor: newTabIcon === ic ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                    color: newTabIcon === ic ? '#FFF' : 'var(--jp-text-secondary)',
                  }}
                >
                  {ic}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={addCustomTab}
              className="w-full min-h-[44px] rounded-xl text-[13px] font-bold text-white cursor-pointer"
              style={{ backgroundColor: 'var(--jp-accent-primary)' }}
            >
              {ar ? 'اختيار المجلد وحفظ التبويب' : 'Grant SAF Folder & Pin Tab'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
 * 3. APPS & 3-TIER XAPK / SPLIT APK HANDLER (Sections 11 & 18.5)
 * ============================================================================ */
export const AppsAndXapkScreen: React.FC<{
  locale: Locale;
  onNavigate: (s: ScreenId) => void;
  onToast: (msg: string) => void;
}> = ({ locale, onNavigate, onToast }) => {
  const ar = locale === 'ar';
  const [subTab, setSubTab] = useState<'installed' | 'archives'>('installed');
  const [showSystem, setShowSystem] = useState(false);
  const [activeApp, setActiveApp] = useState<SampleAppItem | null>(SAMPLE_APPS[0]);
  const [chosenTier, setChosenTier] = useState<'tier1' | 'tier2' | 'tier3'>('tier1');

  const list = SAMPLE_APPS.filter((a) =>
    subTab === 'installed' ? a.installed && (showSystem || !a.isSystem) : !a.installed
  );

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      {/* Sub-tabs: Installed vs Uninstalled APK/XAPK/APKS/APKM */}
      <div className="jp-elevated grid grid-cols-2 gap-1 rounded-2xl p-1">
        <button
          type="button"
          onClick={() => setSubTab('installed')}
          className="min-h-[40px] rounded-xl text-[12.5px] font-bold cursor-pointer"
          style={{
            backgroundColor: subTab === 'installed' ? 'var(--jp-bg-surface)' : 'transparent',
            color: subTab === 'installed' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          {ar ? 'مثبتة على الجهاز' : 'Installed Apps'}
        </button>
        <button
          type="button"
          onClick={() => setSubTab('archives')}
          className="min-h-[40px] rounded-xl text-[12.5px] font-bold cursor-pointer"
          style={{
            backgroundColor: subTab === 'archives' ? 'var(--jp-bg-surface)' : 'transparent',
            color: subTab === 'archives' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          {ar ? 'غير مثبتة (XAPK/APKS)' : 'Uninstalled (XAPK/APKS)'}
        </button>
      </div>

      {subTab === 'installed' && (
        <label className="flex items-center justify-between px-1 text-[12px] cursor-pointer">
          <span style={{ color: 'var(--jp-text-secondary)' }}>
            {ar ? 'إظهار تطبيقات النظام' : 'Include system packages'}
          </span>
          <input
            type="checkbox"
            checked={showSystem}
            onChange={(e) => setShowSystem(e.target.checked)}
            className="h-4 w-4 accent-[#2F7CF6]"
          />
        </label>
      )}

      {/* App List */}
      <div className="space-y-2">
        {list.map((app) => (
          <div
            key={app.id}
            onClick={() => {
              setActiveApp(app);
              setChosenTier(app.hasObb ? 'tier3' : 'tier1');
            }}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && setActiveApp(app)}
            className="jp-surface jp-transition flex items-center justify-between gap-2.5 rounded-2xl p-3 cursor-pointer"
            style={{
              borderColor: activeApp?.id === app.id ? 'var(--jp-accent-primary)' : 'var(--jp-border-subtle)',
            }}
          >
            <div className="flex min-w-0 items-center gap-3">
              <div className="h-11 w-11 shrink-0 overflow-hidden rounded-2xl">
                <GenerativeArtThumb kind="app" palette={app.palette} seed={app.seed} glyph={app.glyph} />
              </div>
              <div className="min-w-0">
                <div className="truncate text-[13px] font-bold">{app.name}</div>
                <div className="jp-mono truncate text-[10.5px]" style={{ color: 'var(--jp-text-muted)' }}>
                  {app.packageName} · v{app.version}
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[10px]">
                  <span
                    className="rounded px-1.5 py-0.5 font-bold"
                    style={{
                      backgroundColor: app.hasObb ? 'var(--jp-status-danger-soft)' : 'var(--jp-accent-primary-soft)',
                      color: app.hasObb ? 'var(--jp-status-danger)' : 'var(--jp-accent-primary)',
                    }}
                  >
                    {app.format} {app.hasObb ? `+ OBB (${app.obbSizeMb} MB)` : ''}
                  </span>
                  <span className="jp-num" style={{ color: 'var(--jp-text-secondary)' }}>
                    {app.baseSizeMb} MB →{' '}
                    <strong style={{ color: 'var(--jp-status-success)' }}>{app.filteredSplitMb} MB</strong>
                  </span>
                </div>
              </div>
            </div>
            <Layers className="h-4 w-4 shrink-0" style={{ color: 'var(--jp-accent-primary)' }} />
          </div>
        ))}
      </div>

      {/* Section 11 & 18.5 Interactive 3-Tier Split / XAPK Ladder Panel */}
      {activeApp && (
        <div className="jp-surface rounded-3xl p-3.5 space-y-2.5" style={{ borderColor: 'var(--jp-accent-primary)' }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" style={{ color: 'var(--jp-accent-primary)' }} />
              <h4 className="text-[13px] font-bold">
                {ar ? `سلّم معالجة: ${activeApp.name}` : `Split Ladder: ${activeApp.name}`}
              </h4>
            </div>
          </div>

          {activeApp.hasObb ? (
            <div
              className="rounded-2xl p-3 text-[11.5px] space-y-1.5"
              style={{
                backgroundColor: 'var(--jp-status-warning-soft)',
                border: '1px solid var(--jp-status-warning)',
              }}
            >
              <div className="flex items-center gap-1.5 font-bold" style={{ color: 'var(--jp-status-warning)' }}>
                <ShieldAlert className="h-4 w-4 shrink-0" />
                <span>
                  {ar
                    ? 'يحتوي ملفات OBB إضافية (1.84 GB) — يُمنع إرسال APK ناقص'
                    : 'Contains 1.84 GB OBB data — incomplete APK merge blocked'}
                </span>
              </div>
              <p style={{ color: 'var(--jp-text-secondary)' }}>
                {ar
                  ? 'لا يمكن دمج OBB في APK واحد دون تعطل اللعبة. الخيار المتاح: إرسال الحزمة كاملة مع التحقق من وضع Android/obb عند الاستقبال، أو الإلغاء.'
                  : 'OBB cannot be merged into a single APK safely. Send complete XAPK+OBB bundle with post-install Android/obb verification, or cancel.'}
              </p>
            </div>
          ) : (
            <div className="space-y-2 text-[11.5px]">
              {/* Tier 1 */}
              <button
                type="button"
                onClick={() => setChosenTier('tier1')}
                className="w-full rounded-2xl p-2.5 text-start cursor-pointer"
                style={{
                  backgroundColor: chosenTier === 'tier1' ? 'var(--jp-status-success-soft)' : 'var(--jp-bg-elevated)',
                  border: `1px solid ${chosenTier === 'tier1' ? 'var(--jp-status-success)' : 'transparent'}`,
                }}
              >
                <div className="flex items-center justify-between font-bold">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="h-4 w-4" style={{ color: 'var(--jp-status-success)' }} />
                    {ar ? '1. Splits أصلية مفلترة (موصى به)' : '1. Filtered Original Splits (Best)'}
                  </span>
                  <span className="jp-num" style={{ color: 'var(--jp-status-success)' }}>
                    {activeApp.filteredSplitMb} MB
                  </span>
                </div>
                <p className="mt-1 text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                  {ar
                    ? 'يُرسل فقط (arm64 + DPI + ar) حسب قدرات المستقبل ويُثبّت عبر PackageInstaller.Session مع الحفاظ التام على التوقيع الأصلي والتحديثات.'
                    : 'Filters splits by receiver ABI/DPI/locale & installs via PackageInstaller.Session — preserves original signature.'}
                </p>
              </button>

              {/* Tier 2 */}
              <button
                type="button"
                onClick={() => setChosenTier('tier2')}
                className="w-full rounded-2xl p-2.5 text-start cursor-pointer"
                style={{
                  backgroundColor: chosenTier === 'tier2' ? 'var(--jp-accent-signal-soft)' : 'var(--jp-bg-elevated)',
                  border: `1px solid ${chosenTier === 'tier2' ? 'var(--jp-accent-signal)' : 'transparent'}`,
                }}
              >
                <div className="flex items-center justify-between font-bold">
                  <span>{ar ? '2. دمج في APK واحد (للمتصفح/خارج التطبيق)' : '2. Merge to Single APK (Web/External)'}</span>
                  <span className="jp-num">{activeApp.mergedSizeMb} MB</span>
                </div>
                <p className="mt-1 text-[11px]" style={{ color: 'var(--jp-accent-signal)' }}>
                  {ar
                    ? 'تنبيه صريح: يُوقَّع بمفتاح محلي (apksig v1+v2+v3)؛ تغيُّر التوقيع قد يمنع التحديث فوق نسخة مثبتة سابقًا أو تطبيقات تفحص التوقيع.'
                    : 'Explicit notice: Re-signed locally (apksig v1-v3); changed signature prevents updating over Play-signed installs.'}
                </p>
              </button>
            </div>
          )}

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                onToast(
                  ar
                    ? `تم تجهيز ${activeApp.name} للنقل (${activeApp.hasObb ? 'حزمة XAPK + OBB كاملة' : chosenTier === 'tier1' ? 'Splits بالتوقيع الأصلي' : 'APK واحد مدمج'})`
                    : `Queued ${activeApp.name} for transfer`
                );
                onNavigate('readiness');
              }}
              className="flex-1 min-h-[44px] rounded-xl text-[12.5px] font-bold text-white cursor-pointer"
              style={{ backgroundColor: 'var(--jp-accent-primary)' }}
            >
              {activeApp.hasObb
                ? ar
                  ? 'إرسال الحزمة الكاملة مع OBB'
                  : 'Send Full Bundle + OBB'
                : ar
                  ? 'متابعة لصفحة النقل'
                  : 'Continue to Transfer'}
            </button>
            {activeApp.hasObb && (
              <button
                type="button"
                onClick={() => setActiveApp(null)}
                className="jp-elevated min-h-[44px] rounded-xl px-3.5 text-[12px] font-semibold cursor-pointer"
              >
                {ar ? 'إلغاء' : 'Cancel'}
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
