import React, { useState } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Captions,
  CheckCircle2,
  Clock,
  ExternalLink,
  FolderOpen,
  Globe,
  Lock,
  Package,
  Pause,
  PictureInPicture2,
  Play,
  RefreshCw,
  ShieldBan,
  ShieldCheck,
  Users,
  Volume2,
} from 'lucide-react';
import { DeviceFrame, Locale, PeerDevice } from '../data/previewData';
import { DeviceAvatar, GenerativeArtThumb, RealQrCode } from './QrAndArtwork';

/* ============================================================================
 * 8. REAL WEB SHARE SERVER CONTROL (Sections 13 & 18.6)
 * ============================================================================ */
export const WebShareScreen: React.FC<{
  locale: Locale;
  webServerOn: boolean;
  onToggleWebServer: () => void;
  onSwitchFrame: (f: DeviceFrame) => void;
  onToast: (msg: string) => void;
}> = ({ locale, webServerOn, onToggleWebServer, onSwitchFrame, onToast }) => {
  const ar = locale === 'ar';
  const [proto, setProto] = useState<'http' | 'https'>('http');
  const [scope, setScope] = useState<'selected' | 'read' | 'readwrite'>('selected');
  const [showCaGuide, setShowCaGuide] = useState(false);

  const webUrl = `${proto}://192.168.1.42:53317`;

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      <div className="jp-surface rounded-3xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe
              className="h-5 w-5"
              style={{ color: webServerOn ? 'var(--jp-status-success)' : 'var(--jp-text-muted)' }}
            />
            <div>
              <div className="text-[13.5px] font-bold">
                {ar ? 'خادم الويب المدمج (بدون إنترنت)' : 'Embedded Offline Web Server'}
              </div>
              <div className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                {ar ? 'مضغوط مسبقًا brotli/gzip · صفر CDN' : 'Pre-compressed brotli/gzip · Zero CDN'}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onToggleWebServer}
            className="min-h-[40px] rounded-full px-3.5 text-[12px] font-bold text-white cursor-pointer"
            style={{
              backgroundColor: webServerOn ? 'var(--jp-status-success)' : 'var(--jp-text-muted)',
            }}
          >
            {webServerOn ? (ar ? 'يعمل' : 'Running') : ar ? 'متوقف' : 'Stopped'}
          </button>
        </div>

        <div className="flex flex-col items-center gap-2 py-1">
          <RealQrCode value={webUrl} size={142} label="Local Web Share URL QR" />
          <div className="jp-mono rounded-xl px-3 py-1.5 text-[12.5px] font-bold" style={{ backgroundColor: 'var(--jp-bg-elevated)', color: 'var(--jp-accent-primary)' }}>
            {webUrl}
          </div>
          <div className="text-[10.5px]" style={{ color: 'var(--jp-text-muted)' }}>
            {ar ? 'اسم mDNS الإضافي:' : 'mDNS alias:'} <span className="jp-mono">{proto}://jopro.local:53317</span> ·{' '}
            <span className="jp-mono font-bold">PIN: 9042</span>
          </div>
        </div>

        {/* HTTP (WASM fallbacks) vs HTTPS (Local Root CA) */}
        <div className="jp-elevated grid grid-cols-2 gap-1 rounded-xl p-1 text-[11.5px] font-bold">
          <button
            type="button"
            onClick={() => setProto('http')}
            className="min-h-[36px] rounded-lg cursor-pointer"
            style={{
              backgroundColor: proto === 'http' ? 'var(--jp-bg-surface)' : 'transparent',
              color: proto === 'http' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
            }}
          >
            HTTP (BLAKE3 WASM)
          </button>
          <button
            type="button"
            onClick={() => setProto('https')}
            className="min-h-[36px] rounded-lg cursor-pointer"
            style={{
              backgroundColor: proto === 'https' ? 'var(--jp-bg-surface)' : 'transparent',
              color: proto === 'https' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
            }}
          >
            HTTPS (Local CA)
          </button>
        </div>

        {proto === 'http' ? (
          <p className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
            {ar
              ? 'يعمل بالكامل على أي متصفح وتلفاز بدون سياق آمن: BLAKE3 عبر WASM محلي، وتنزيل ZIP64 تدفقي بلا ملف مؤقت، ورفع مقطّع مستأنف (Blob.slice).'
              : 'Works on every browser & TV without Secure Context: offline BLAKE3 WASM, zero-temp streaming ZIP64, and resumable Blob.slice uploads.'}
          </p>
        ) : (
          <div className="rounded-xl p-2.5 text-[11px] space-y-1.5" style={{ backgroundColor: 'var(--jp-accent-primary-soft)' }}>
            <div className="flex items-center justify-between font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
              <span className="flex items-center gap-1">
                <Lock className="h-3.5 w-3.5" />
                {ar ? 'شهادة CA محلية بعنوان IP SAN' : 'Device CA with IP SAN'}
              </span>
              <button
                type="button"
                onClick={() => setShowCaGuide((v) => !v)}
                className="underline cursor-pointer"
              >
                {ar ? 'خطوات التثبيت' : 'Install Guide'}
              </button>
            </div>
            {showCaGuide && (
              <div style={{ color: 'var(--jp-text-secondary)' }}>
                {ar
                  ? 'حمّل /jopro-ca.crt لفتح الحافظة وServiceWorker: Windows (الشهادات الموثوقة) · macOS (Keychain) · Android (شهادة CA) · iOS (ملف التعريف + الثقة)، أو اقبل التحذير مرة واحدة.'
                  : 'Download /jopro-ca.crt for Windows/macOS/Android/iOS trust store, or accept warning once.'}
              </div>
            )}
          </div>
        )}

        <button
          type="button"
          onClick={() => onSwitchFrame('web')}
          className="flex w-full min-h-[44px] items-center justify-center gap-2 rounded-xl text-[12.5px] font-bold text-white cursor-pointer"
          style={{ backgroundColor: 'var(--jp-accent-primary)' }}
        >
          <ExternalLink className="h-4 w-4" />
          <span>{ar ? 'فتح واجهة عميل الويب في المتصفح' : 'Preview Browser Web Client'}</span>
        </button>
      </div>

      {/* Host Scope & Browser Session Approval */}
      <div className="jp-surface rounded-2xl p-3.5 space-y-2.5 text-[11.5px]">
        <div className="font-bold">{ar ? 'صلاحية ما يُعرض للمتصفح:' : 'Web Exposure Scope:'}</div>
        <div className="grid grid-cols-3 gap-1.5">
          {[
            { id: 'selected' as const, label: ar ? 'ملفات محددة' : 'Selected Only' },
            { id: 'read' as const, label: ar ? 'تصفح (قراءة)' : 'Browse (Read)' },
            { id: 'readwrite' as const, label: ar ? 'قراءة + رفع' : 'Read + Upload' },
          ].map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setScope(s.id)}
              className="min-h-[38px] rounded-xl px-2 text-[11px] font-semibold cursor-pointer"
              style={{
                backgroundColor: scope === s.id ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                color: scope === s.id ? '#FFF' : 'var(--jp-text-secondary)',
              }}
            >
              {s.label}
            </button>
          ))}
        </div>

        <div className="jp-elevated flex items-center justify-between rounded-xl p-2.5">
          <div>
            <div className="font-bold">Firefox · Windows 11 (192.168.1.60)</div>
            <div className="text-[10.5px]" style={{ color: 'var(--jp-text-muted)' }}>
              {ar ? 'ينتظر موافقة الهاتف · تنتهي الجلسة بعد 30د' : 'Awaiting phone approval · 30m TTL'}
            </div>
          </div>
          <button
            type="button"
            onClick={() => onToast(ar ? 'تم منح توكن جلسة مؤقت لمتصفح Firefox' : 'Granted session token to Firefox')}
            className="rounded-lg px-3 py-1.5 text-[11px] font-bold text-white cursor-pointer"
            style={{ backgroundColor: 'var(--jp-status-success)' }}
          >
            {ar ? 'موافقة' : 'Approve'}
          </button>
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
 * 9. LIVE WATCH TOGETHER — ZERO-DOWNLOAD HTTP RANGE & NTP SYNC (Sections 12 & 18.7)
 * ============================================================================ */
export const WatchTogetherScreen: React.FC<{
  locale: Locale;
  isLowEnd: boolean;
  onToast: (msg: string) => void;
}> = ({ locale, isLowEnd, onToast }) => {
  const ar = locale === 'ar';
  const [playing, setPlaying] = useState(true);
  const [posPct, setPosPct] = useState(38);
  const [hostOnly, setHostOnly] = useState(true);
  const [subTrack, setSubTrack] = useState<'ar-ass' | 'en-srt' | 'off'>('ar-ass');
  const [browserTier, setBrowserTier] = useState<1 | 2 | 3 | 4 | 5>(3);

  const codecTiers = [
    { t: 1 as const, label: ar ? '1. بث Range مباشر' : '1. Direct Range', desc: ar ? 'الحاوية والترميز مدعومان أصليًا (صفر CPU)' : 'Native MP4/WebM range stream (0% extra CPU)' },
    { t: 2 as const, label: ar ? '2. إعادة تغليف fMP4' : '2. Rust fMP4 Remux', desc: ar ? 'تحويل MKV إلى fMP4 لـ MSE فوريًا بدون إعادة ترميز' : 'Instant MKV→fMP4 container remux in Rust for MSE' },
    { t: 3 as const, label: ar ? '3. تحويل الصوت AAC' : '3. Audio→AAC Only', desc: ar ? 'نسخ فيديو HEVC كما هو + تحويل DTS/AC3 لـ AAC بتكلفة CPU منخفضة' : 'Copy video untouched + lightweight DTS/AC3→AAC' },
    { t: 4 as const, label: ar ? '4. MediaCodec (اختياري)' : '4. HW Transcode', desc: isLowEnd ? (ar ? 'معطّل تلقائيًا على Galaxy A20 لحماية الحرارة والبطارية — افتحه بالتطبيق' : 'Disabled on A20 to protect battery/thermals') : (ar ? 'اختياري بتحذير صريح للحرارة والبطارية — لا يُفعَّل تلقائيًا' : 'Opt-in only with explicit thermal & battery warning') },
    { t: 5 as const, label: ar ? '5. فتح بالتطبيق' : '5. Open in App', desc: ar ? 'يشغّل media_kit/ExoPlayer كل صيغ MKV/HEVC/DTS/ASS بجودتها الكاملة' : 'Native media_kit plays MKV/HEVC/DTS/ASS at 100% quality' },
  ];

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      {/* Cinema Video Frame */}
      <div className="jp-surface overflow-hidden rounded-3xl">
        <div className="relative h-48 w-full bg-[#06080E]">
          <GenerativeArtThumb kind="video" palette={['#1E3A8A', '#B45309', '#090D16']} seed={11} />
          <div className="absolute inset-x-3 top-2.5 flex items-center justify-between text-[10.5px] text-white">
            <span className="rounded-full bg-black/65 px-2.5 py-0.5 font-semibold">
              4K HDR10 · HTTP Range ({ar ? 'صفر تخزين على القرص' : '0 Disk Save'})
            </span>
            <span className="jp-mono rounded-full bg-emerald-600/85 px-2 py-0.5 font-bold">
              NTP Δ +4ms
            </span>
          </div>

          {subTrack !== 'off' && (
            <div className="absolute inset-x-4 bottom-10 text-center">
              <span className="rounded-lg bg-black/75 px-3 py-1 text-[12px] font-semibold text-white">
                {subTrack === 'ar-ass'
                  ? '«الرياح تهدأ قبل الفجر فوق وادي رم» (ASS)'
                  : '"The desert wind stills before dawn." (SRT)'}
              </span>
            </div>
          )}

          {/* Scrub bar + Shared Read Ring Buffer */}
          <div className="absolute inset-x-3 bottom-3 space-y-1">
            <div
              className="relative h-2 w-full rounded-full bg-white/20 cursor-pointer"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                setPosPct(Math.round((ar ? 1 - ratio : ratio) * 100));
              }}
            >
              {/* Shared Ring Buffer Ahead */}
              <div
                className="absolute top-0 h-full rounded-full bg-white/40"
                style={{ insetInlineStart: 0, width: `${Math.min(100, posPct + 14)}%` }}
              />
              <div
                className="absolute top-0 h-full rounded-full bg-[#F59E0B]"
                style={{ insetInlineStart: 0, width: `${posPct}%` }}
              />
            </div>
          </div>
        </div>

        {/* Transport & Track Controls */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-3 text-[11.5px]">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setPlaying((p) => !p)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-white cursor-pointer"
              style={{ backgroundColor: 'var(--jp-accent-primary)' }}
            >
              {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
            <span className="jp-mono text-[11px]">00:51:12 / 02:14:38</span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() =>
                setSubTrack((s) => (s === 'ar-ass' ? 'en-srt' : s === 'en-srt' ? 'off' : 'ar-ass'))
              }
              className="jp-elevated flex h-9 items-center gap-1 rounded-xl px-2.5 text-[11px] font-semibold cursor-pointer"
            >
              <Captions className="h-3.5 w-3.5" />
              <span>{subTrack.toUpperCase()}</span>
            </button>
            <button
              type="button"
              onClick={() => onToast(ar ? 'تبديل المسار الصوتي: DTS-HD 5.1 / Arabic AAC' : 'Switched audio track')}
              className="jp-elevated flex h-9 items-center justify-center rounded-xl px-2.5 cursor-pointer"
              aria-label="Audio tracks"
            >
              <Volume2 className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onToast(ar ? 'فُعِّل وضع صورة-داخل-صورة (PiP) مع منع انطفاء الشاشة' : 'Entered PiP mode')}
              className="jp-elevated flex h-9 items-center justify-center rounded-xl px-2.5 cursor-pointer"
              aria-label="Picture in Picture"
            >
              <PictureInPicture2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Synced Viewers + Shared Ring Buffer */}
      <div className="jp-surface rounded-2xl p-3 space-y-2 text-[11.5px]">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-bold">
            <Users className="h-4 w-4" style={{ color: 'var(--jp-accent-primary)' }} />
            {ar ? 'غرفة المشاهدة (3 مشاهدين · كاش حلقي 16MB)' : 'Watch Room (3 Viewers · 16MB Shared Ring)'}
          </span>
          <button
            type="button"
            onClick={() => setHostOnly((h) => !h)}
            className="jp-elevated rounded-lg px-2 py-1 text-[10.5px] font-semibold cursor-pointer"
          >
            {hostOnly ? (ar ? 'تحكم: المضيف فقط' : 'Control: Host') : ar ? 'تحكم: الجميع' : 'Control: All'}
          </button>
        </div>

        {[
          { name: ar ? 'هاتف طارق · S24 (التطبيق)' : 'Tariq S24 (App)', st: ar ? 'متزامن (+4ms · كاش مشترك)' : 'Synced (+4ms · Shared Ring)', ok: true },
          { name: ar ? 'جالكسي A20 · سلمى (التطبيق)' : 'Salma A20 (App)', st: ar ? 'متزامن (+11ms · كاش مشترك)' : 'Synced (+11ms · Shared Ring)', ok: true },
          { name: ar ? 'متصفح التلفاز (MSE)' : 'Living Room TV (Web)', st: ar ? 'تصحيح معدل 1.04x (+120ms)' : 'Nudging 1.04x (+120ms)', ok: false },
        ].map((v, idx) => (
          <div key={idx} className="jp-elevated flex items-center justify-between rounded-xl px-3 py-2">
            <span className="font-semibold">{v.name}</span>
            <span
              className="text-[10.5px] font-bold"
              style={{ color: v.ok ? 'var(--jp-status-success)' : 'var(--jp-accent-signal)' }}
            >
              {v.st}
            </span>
          </div>
        ))}
      </div>

      {/* Browser Codec Ladder (Section 18.7) */}
      <div className="jp-surface rounded-2xl p-3 space-y-2 text-[11px]">
        <div className="font-bold text-[12px]">
          {ar ? 'سلّم تشغيل المتصفح (فحص MediaSource مسبقًا)' : 'Browser Codec Capability Ladder'}
        </div>
        <div className="flex flex-wrap gap-1">
          {codecTiers.map((c) => (
            <button
              key={c.t}
              type="button"
              onClick={() => setBrowserTier(c.t)}
              className="rounded-lg px-2 py-1 text-[10.5px] font-semibold cursor-pointer"
              style={{
                backgroundColor: browserTier === c.t ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                color: browserTier === c.t ? '#FFF' : 'var(--jp-text-secondary)',
              }}
            >
              {c.label}
            </button>
          ))}
        </div>
        <p style={{ color: 'var(--jp-text-secondary)' }}>
          {codecTiers.find((c) => c.t === browserTier)?.desc}
        </p>
      </div>
    </div>
  );
};

/* ============================================================================
 * 10. TRANSFER HISTORY IN Download/JOPRO (Sections 3.5 & 4.4)
 * ============================================================================ */
export const HistoryScreen: React.FC<{
  locale: Locale;
  onToast: (msg: string) => void;
}> = ({ locale, onToast }) => {
  const ar = locale === 'ar';
  const [filter, setFilter] = useState<'all' | 'in' | 'out' | 'resume'>('all');

  const entries = [
    {
      id: 'h1',
      dir: 'in' as const,
      name: 'OsmAnd_Splits_Bundle (4 APKs)',
      path: 'Download/JOPRO/Apps/',
      peer: ar ? 'هاتف طارق · S24' : 'Tariq · S24',
      size: '92.0 MB',
      status: 'done',
      isApk: true,
      blake3: '9F2A..81C4',
    },
    {
      id: 'h2',
      dir: 'out' as const,
      name: 'Wadi_Rum_Album (48 RAW)',
      path: ar ? 'مُرسل عبر 5GHz (66.4 MB/s)' : 'Sent over 5GHz (66.4 MB/s)',
      peer: ar ? 'تابلت الاستوديو' : 'Studio Pad Pro',
      size: '1.34 GB',
      status: 'done',
      isApk: false,
      blake3: '3C10..E72B',
    },
    {
      id: 'h3',
      dir: 'in' as const,
      name: 'Camera_Backup_2026_02.zip',
      path: 'Download/JOPRO/Archives/ (74% محفوظ)',
      peer: ar ? 'جالكسي A20 · سلمى' : 'Salma · Galaxy A20',
      size: '4.96 GB',
      status: 'resume',
      isApk: false,
      blake3: '231/310 chunks',
    },
  ].filter((e) =>
    filter === 'all' ? true : filter === 'resume' ? e.status === 'resume' : e.dir === filter
  );

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      <div className="flex gap-1.5">
        {[
          { id: 'all' as const, l: ar ? 'الكل' : 'All' },
          { id: 'in' as const, l: ar ? 'مستلم' : 'Received' },
          { id: 'out' as const, l: ar ? 'مرسل' : 'Sent' },
          { id: 'resume' as const, l: ar ? 'قابل للاستئناف' : 'Resumable' },
        ].map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setFilter(f.id)}
            className="min-h-[36px] rounded-full px-3 text-[11.5px] font-semibold cursor-pointer"
            style={{
              backgroundColor: filter === f.id ? 'var(--jp-accent-primary)' : 'var(--jp-bg-surface)',
              color: filter === f.id ? '#FFF' : 'var(--jp-text-secondary)',
            }}
          >
            {f.l}
          </button>
        ))}
      </div>

      {entries.map((e) => (
        <div key={e.id} className="jp-surface rounded-2xl p-3 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex min-w-0 items-center gap-2.5">
              <span
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                style={{
                  backgroundColor: e.dir === 'in' ? 'var(--jp-status-success-soft)' : 'var(--jp-accent-primary-soft)',
                  color: e.dir === 'in' ? 'var(--jp-status-success)' : 'var(--jp-accent-primary)',
                }}
              >
                {e.dir === 'in' ? <ArrowDownLeft className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}
              </span>
              <div className="min-w-0">
                <div className="truncate text-[12.5px] font-bold">{e.name}</div>
                <div className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                  {e.peer} · <span className="jp-num font-semibold">{e.size}</span>
                </div>
                <div className="jp-mono text-[10px]" style={{ color: 'var(--jp-text-muted)' }}>
                  {e.path} · BLAKE3 {e.blake3}
                </div>
              </div>
            </div>
            {e.status === 'done' ? (
              <CheckCircle2 className="h-4 w-4 shrink-0" style={{ color: 'var(--jp-status-success)' }} />
            ) : (
              <Clock className="h-4 w-4 shrink-0" style={{ color: 'var(--jp-accent-signal)' }} />
            )}
          </div>

          <div className="flex gap-2 pt-0.5 text-[11px]">
            {e.status === 'resume' ? (
              <button
                type="button"
                onClick={() => onToast(ar ? 'استؤنف النقل من المقطع #232 بعد فحص BLAKE3' : 'Resumed from chunk #232')}
                className="flex items-center gap-1 rounded-xl px-3 py-1.5 font-bold text-white cursor-pointer"
                style={{ backgroundColor: 'var(--jp-accent-primary)' }}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>{ar ? 'استئناف المقاطع المتبقية' : 'Resume Missing Chunks'}</span>
              </button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => onToast(ar ? `فُتح المجلد ${e.path}` : `Opened ${e.path}`)}
                  className="jp-elevated flex items-center gap-1 rounded-xl px-3 py-1.5 font-semibold cursor-pointer"
                >
                  <FolderOpen className="h-3.5 w-3.5" />
                  <span>{ar ? 'إظهار في المجلد' : 'Show in Folder'}</span>
                </button>
                {e.isApk && (
                  <button
                    type="button"
                    onClick={() => onToast(ar ? 'بدأت جلسة PackageInstaller.Session بالتوقيع الأصلي' : 'Started PackageInstaller.Session')}
                    className="flex items-center gap-1 rounded-xl px-3 py-1.5 font-bold text-white cursor-pointer"
                    style={{ backgroundColor: 'var(--jp-status-success)' }}
                  >
                    <Package className="h-3.5 w-3.5" />
                    <span>{ar ? 'تثبيت مباشر' : 'Install'}</span>
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

/* ============================================================================
 * 11. TRUSTED PEERS (TOFU) & FINGERPRINT BLOCKLIST (Section 9)
 * ============================================================================ */
export const TrustBlocklistScreen: React.FC<{
  locale: Locale;
  peers: PeerDevice[];
  onToggleAutoAccept: (id: string) => void;
  onToggleBlock: (id: string) => void;
}> = ({ locale, peers, onToggleAutoAccept, onToggleBlock }) => {
  const ar = locale === 'ar';
  const trusted = peers.filter((p) => p.trusted && !p.blocked);
  const blocked = peers.filter((p) => p.blocked);

  return (
    <div className="jp-screen-enter space-y-3.5 p-3.5">
      <div className="space-y-2">
        <h3 className="flex items-center gap-1.5 px-1 text-[12.5px] font-bold">
          <ShieldCheck className="h-4 w-4" style={{ color: 'var(--jp-status-success)' }} />
          <span>{ar ? 'الأجهزة الموثوقة (تثبيت بصمة TOFU + Direct Share)' : 'Trusted Pinned Peers (TOFU)'}</span>
        </h3>
        {trusted.map((p) => (
          <div key={p.id} className="jp-surface rounded-2xl p-3 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <DeviceAvatar seed={p.seed} initials={p.initials} accent={p.accent} size={38} trusted />
                <div>
                  <div className="text-[12.5px] font-bold">{ar ? p.aliasAr : p.aliasEn}</div>
                  <div className="jp-mono text-[10px]" style={{ color: 'var(--jp-accent-primary)' }}>
                    {p.fingerprint}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onToggleBlock(p.id)}
                className="rounded-lg px-2.5 py-1 text-[10.5px] font-bold cursor-pointer"
                style={{ backgroundColor: 'var(--jp-status-danger-soft)', color: 'var(--jp-status-danger)' }}
              >
                {ar ? 'حظر' : 'Block'}
              </button>
            </div>
            <label className="jp-elevated flex items-center justify-between rounded-xl px-3 py-2 text-[11px] cursor-pointer">
              <span>{ar ? 'قبول تلقائي واقتراح في Direct Share' : 'Auto-accept & show in Direct Share'}</span>
              <input
                type="checkbox"
                checked={p.autoAccept}
                onChange={() => onToggleAutoAccept(p.id)}
                className="h-4 w-4 accent-[#10B981]"
              />
            </label>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <h3 className="flex items-center gap-1.5 px-1 text-[12.5px] font-bold">
          <ShieldBan className="h-4 w-4" style={{ color: 'var(--jp-status-danger)' }} />
          <span>
            {ar
              ? `قائمة الحظر بالبصمة (${blocked.length}) — لا ترى حتى الاكتشاف`
              : `Fingerprint Blocklist (${blocked.length}) — Invisible to Discovery`}
          </span>
        </h3>
        {blocked.map((p) => (
          <div key={p.id} className="jp-surface flex items-center justify-between gap-2 rounded-2xl p-3">
            <div className="min-w-0">
              <div className="truncate text-[12.5px] font-bold">{ar ? p.aliasAr : p.aliasEn}</div>
              <div className="jp-mono text-[10px]" style={{ color: 'var(--jp-status-danger)' }}>
                {p.fingerprint}
              </div>
              <div className="text-[10.5px]" style={{ color: 'var(--jp-text-muted)' }}>
                {ar ? 'محظور بالبصمة حتى لو غيّر اسمه أو عنوان IP' : 'Blocked by cert fingerprint across name/IP changes'}
              </div>
            </div>
            <button
              type="button"
              onClick={() => onToggleBlock(p.id)}
              className="jp-elevated min-h-[38px] shrink-0 rounded-xl px-3 text-[11px] font-bold cursor-pointer"
            >
              {ar ? 'إلغاء الحظر' : 'Unblock'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
