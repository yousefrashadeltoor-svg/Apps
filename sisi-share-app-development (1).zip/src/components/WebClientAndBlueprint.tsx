import React, { useState } from 'react';
import {
  Archive,
  CheckCircle2,
  Code2,
  Copy,
  Download,
  FileCode,
  FolderTree,
  Gauge,
  Globe,
  Lock,
  Play,
  ShieldCheck,
  UploadCloud,
} from 'lucide-react';
import { formatBytes, Locale, SAMPLE_FILES, ScreenId } from '../data/previewData';
import { BrandMark, GenerativeArtThumb } from './QrAndArtwork';

/* ============================================================================
 * DESKTOP BROWSER FRAME: EMBEDDED WEB CLIENT (Section 13 & 18.6)
 * ============================================================================ */
export const EmbeddedWebClientView: React.FC<{
  locale: Locale;
  deviceAlias: string;
  onJumpWatch: () => void;
  onToast: (msg: string) => void;
}> = ({ locale, deviceAlias, onJumpWatch, onToast }) => {
  const ar = locale === 'ar';
  const [httpsOn, setHttpsOn] = useState(false);
  const [picked, setPicked] = useState<string[]>(['img-1', 'vid-2', 'doc-1']);
  const [uploadPct, setUploadPct] = useState<number | null>(null);

  const shared = SAMPLE_FILES.slice(0, 8);
  const toggle = (id: string) =>
    setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  const startSampleUpload = () => {
    setUploadPct(34);
    onToast(
      ar
        ? 'رفع مقطّع (Blob.slice 4MB) مع BLAKE3 WASM — ينتظر موافقة الهاتف (معاينة)'
        : 'Chunked Blob.slice upload with BLAKE3 WASM (preview)'
    );
    window.setTimeout(() => setUploadPct(78), 700);
    window.setTimeout(() => setUploadPct(100), 1400);
  };

  return (
    <div className="jp-surface mx-auto w-full max-w-[1040px] overflow-hidden rounded-3xl">
      {/* Desktop Browser Address Chrome */}
      <div
        className="flex flex-wrap items-center justify-between gap-2 border-b px-4 py-2.5 text-[11.5px]"
        style={{ backgroundColor: 'var(--jp-bg-elevated)', borderColor: 'var(--jp-border-subtle)' }}
      >
        <div className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-full bg-red-500/80" />
          <span className="h-3 w-3 rounded-full bg-amber-500/80" />
          <span className="h-3 w-3 rounded-full bg-emerald-500/80" />
        </div>

        <div className="jp-surface flex flex-1 max-w-lg items-center justify-between gap-2 rounded-xl px-3 py-1.5">
          <span className="jp-mono flex items-center gap-1.5 text-[11.5px]">
            {httpsOn ? (
              <Lock className="h-3.5 w-3.5" style={{ color: 'var(--jp-status-success)' }} />
            ) : (
              <Globe className="h-3.5 w-3.5" style={{ color: 'var(--jp-accent-signal)' }} />
            )}
            {httpsOn ? 'https://192.168.1.42:53317' : 'http://192.168.1.42:53317'}{' '}
            <span style={{ color: 'var(--jp-text-muted)' }}>(jopro.local)</span>
          </span>
          <button
            type="button"
            onClick={() => setHttpsOn((v) => !v)}
            className="rounded-md px-2 py-0.5 text-[10px] font-bold cursor-pointer"
            style={{ backgroundColor: 'var(--jp-accent-primary-soft)', color: 'var(--jp-accent-primary)' }}
          >
            {httpsOn ? 'HTTPS CA ✓' : 'HTTP WASM'}
          </button>
        </div>

        <span className="text-[11px] font-semibold" style={{ color: 'var(--jp-status-success)' }}>
          {ar ? 'جلسة موثّقة من الهاتف · PIN ✓' : 'Phone-Approved Session · PIN ✓'}
        </span>
      </div>

      {/* Web Client App Header (Exact Same Design Tokens) */}
      <div className="p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <BrandMark size={38} />
            <div>
              <h2 className="text-[16px] font-bold">
                SISI Share Web · <span style={{ color: 'var(--jp-accent-primary)' }}>{deviceAlias}</span>
              </h2>
              <p className="text-[11.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
                {httpsOn
                  ? ar
                    ? 'سياق آمن بشهادة CA المحلية (IP SAN) · صفر إنترنت · صفر CDN'
                    : 'Local CA Secure Context (IP SAN) · 100% Offline · Zero CDN'
                  : ar
                    ? 'يعمل بالكامل على HTTP بدون سياق آمن: BLAKE3 WASM + تنزيل Content-Disposition مباشر'
                    : 'Full HTTP operation without Secure Context: BLAKE3 WASM + direct streaming download'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onJumpWatch}
              className="jp-elevated flex min-h-[42px] items-center gap-1.5 rounded-xl px-3.5 text-[12px] font-bold cursor-pointer"
            >
              <Play className="h-3.5 w-3.5" style={{ color: 'var(--jp-accent-signal)' }} />
              <span>{ar ? 'غرفة المشاهدة الحية (1)' : 'Watch Together (1)'}</span>
            </button>
            <button
              type="button"
              onClick={() =>
                onToast(
                  ar
                    ? `بدء تنزيل ZIP64 تدفقي (${picked.length} ملفات) بدون ملف مؤقت وبدون إعادة ضغط`
                    : `Streaming zero-temp ZIP64 (${picked.length} files)`
                )
              }
              className="flex min-h-[42px] items-center gap-1.5 rounded-xl px-4 text-[12px] font-bold text-white cursor-pointer"
              style={{ backgroundColor: 'var(--jp-accent-primary)' }}
            >
              <Archive className="h-4 w-4" />
              <span>
                {ar ? `تنزيل ZIP64 تدفقي (${picked.length})` : `Stream ZIP64 (${picked.length})`}
              </span>
            </button>
          </div>
        </div>

        {/* Shared Files Grid + Chunked Resumable Upload Zone */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4 lg:col-span-9">
            {shared.map((f) => {
              const sel = picked.includes(f.id);
              const kind = f.category === 'videos' ? 'video' : f.category === 'music' ? 'music' : f.category === 'photos' ? 'photo' : 'app';
              return (
                <div
                  key={f.id}
                  onClick={() => toggle(f.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && toggle(f.id)}
                  className="jp-elevated jp-transition overflow-hidden rounded-2xl cursor-pointer"
                  style={{
                    borderColor: sel ? 'var(--jp-accent-primary)' : 'var(--jp-border-subtle)',
                  }}
                >
                  <div className="relative h-24 w-full">
                    <GenerativeArtThumb kind={kind} palette={f.palette} seed={f.seed} glyph={f.name[0]} />
                    {sel && (
                      <span
                        className="absolute end-2 top-2 rounded-full px-2 py-0.5 text-[10px] font-bold text-white"
                        style={{ backgroundColor: 'var(--jp-accent-primary)' }}
                      >
                        ✓
                      </span>
                    )}
                  </div>
                  <div className="p-2.5">
                    <div className="truncate text-[11.5px] font-bold">{f.name}</div>
                    <div className="mt-1 flex items-center justify-between text-[10.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
                      <span className="jp-num">{formatBytes(f.sizeBytes)}</span>
                      <Download className="h-3.5 w-3.5" style={{ color: 'var(--jp-accent-primary)' }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Resumable Upload to Phone Download/JOPRO */}
          <div className="jp-elevated flex flex-col justify-between rounded-2xl p-4 lg:col-span-3 space-y-3">
            <div className="space-y-2">
              <UploadCloud className="h-7 w-7" style={{ color: 'var(--jp-accent-primary)' }} />
              <h3 className="text-[13px] font-bold">
                {ar ? 'رفع مقطّع مستأنف إلى الهاتف' : 'Chunked Resumable Upload'}
              </h3>
              <p className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                {ar
                  ? 'يُقطَّع عبر Blob.slice ويُفحص مساره ضد Path Traversal ويُكتب ذريًا داخل Download/JOPRO بعد موافقة الهاتف.'
                  : 'Parallel Blob.slice upload verified against path traversal into Download/JOPRO.'}
              </p>
            </div>

            {uploadPct !== null && (
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between font-bold">
                  <span>Slides_Final.pdf</span>
                  <span className="jp-num">{uploadPct}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full" style={{ backgroundColor: 'var(--jp-bg-surface)' }}>
                  <div
                    className="jp-transition h-full rounded-full"
                    style={{ width: `${uploadPct}%`, backgroundColor: 'var(--jp-status-success)' }}
                  />
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={startSampleUpload}
              className="w-full min-h-[42px] rounded-xl text-[12px] font-bold text-white cursor-pointer"
              style={{ backgroundColor: 'var(--jp-accent-primary)' }}
            >
              {ar ? 'تجربة رفع ملف (معاينة)' : 'Simulate Upload'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
 * 16. JOPRO REPOSITORY, ARCHITECTURE, BENCHMARK & STAGES 0-8 INSPECTOR
 * ============================================================================ */
export const JoproBlueprintView: React.FC<{
  locale: Locale;
  onNavigate: (s: ScreenId) => void;
  onToast: (msg: string) => void;
}> = ({ locale, onToast }) => {
  const ar = locale === 'ar';
  const [selectedDoc, setSelectedDoc] = useState<'stages' | 'tree' | 'bench' | 'code'>('stages');

  const stages = [
    {
      n: '0',
      t: ar ? 'نظام التصميم الموحد وتطبيق المعاينة' : 'Design Tokens & Standalone Preview',
      f: 'JOPRO/design/tokens.json · design-spec.md · scripts/generate_tokens.mjs · JOPRO/index.html',
      ok: ar ? 'مولَّد فعليًا لـ CSS + Dart + Android XML (نهار/ليل)' : 'Compiled to CSS, Dart & Android XML',
    },
    {
      n: '1',
      t: ar ? 'المعمارية ونواة Rust + جسر FFI بلا نسخ' : 'Architecture, Rust Core & Zero-Copy FFI',
      f: 'JOPRO/core/src/{security,transfer,protocol,watch,lib}.rs · bridge/src/api.rs',
      ok: ar ? 'LocalSend v2.1 + Nova v1 + RawFd + fallocate/pwrite + BLAKE3 MAC + 16KB ELF' : 'LS v2.1 + Nova v1 + RawFd + 16KB ELF',
    },
    {
      n: '2-3',
      t: ar ? 'طبقة Android الأصلية (play/full) وواجهة Flutter' : 'Native Android (play/full) & Flutter UI',
      f: 'build.gradle.kts · AndroidManifest.xml · JoproForegroundService.kt · StorageAndFdManager.kt',
      ok: ar ? 'Download/JOPRO الذري + UIDT/connectedDevice + onTimeout + Share Target + XAPK Sessions' : 'Atomic Download/JOPRO + UIDT + Split Sessions',
    },
    {
      n: '4-5',
      t: ar ? 'الإشعارات والويدجتس الخمسة وسلّم الشبكات وQR' : 'Notifications, 5 Widgets, Network Ladder & QR',
      f: 'NotificationController.kt · NetworkLadderManager.kt · ML Kit Bundled · Real QR',
      ok: ar ? '1Hz EMA + ProgressStyle + بدون trampolines + Wi-Fi Direct 5GHz + كشف AP Isolation' : '1Hz EMA + Zero trampolines + AP Isolation probe',
    },
    {
      n: '6-8',
      t: ar ? 'خادم الويب (CA/WASM) والمشاهدة المشتركة وShizuku والـ Benchmark' : 'Web Share, Watch Together, Shizuku & Benchmark',
      f: 'watch.rs · ShizukuPrivilegedHelper.kt · scripts/build_{apk,web}.sh · docs/{LIMITATIONS,BENCHMARK}.md',
      ok: ar ? 'ZIP64 تدفقي + مزامنة NTP + سلّم الترميز + قائمة Shizuku البيضاء + فحص 16KB' : 'Streaming ZIP64 + NTP sync + 16KB readelf check',
    },
  ];

  const buildCmd = `node JOPRO/scripts/generate_tokens.mjs && (cd JOPRO/core && cargo test --release) && bash JOPRO/scripts/build_apk.sh both release`;

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      <div className="jp-elevated grid grid-cols-4 gap-1 rounded-2xl p-1 text-[11px] font-bold">
        {[
          { id: 'stages' as const, l: ar ? 'المراحل' : 'Stages', ic: <ShieldCheck className="h-3.5 w-3.5" /> },
          { id: 'tree' as const, l: ar ? 'الهيكل' : 'Tree', ic: <FolderTree className="h-3.5 w-3.5" /> },
          { id: 'bench' as const, l: 'Benchmark', ic: <Gauge className="h-3.5 w-3.5" /> },
          { id: 'code' as const, l: ar ? 'البناء' : 'Build', ic: <Code2 className="h-3.5 w-3.5" /> },
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setSelectedDoc(t.id)}
            className="flex min-h-[38px] items-center justify-center gap-1 rounded-xl cursor-pointer"
            style={{
              backgroundColor: selectedDoc === t.id ? 'var(--jp-bg-surface)' : 'transparent',
              color: selectedDoc === t.id ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
            }}
          >
            {t.ic}
            <span>{t.l}</span>
          </button>
        ))}
      </div>

      {selectedDoc === 'stages' && (
        <div className="space-y-2">
          {stages.map((st) => (
            <div key={st.n} className="jp-surface rounded-2xl p-3 space-y-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[12px] font-bold">
                  {ar ? `المرحلة ${st.n}:` : `Stage ${st.n}:`} {st.t}
                </span>
                <CheckCircle2 className="h-4 w-4 shrink-0" style={{ color: 'var(--jp-status-success)' }} />
              </div>
              <div className="jp-mono text-[10px]" style={{ color: 'var(--jp-accent-primary)' }}>
                {st.f}
              </div>
              <div className="text-[10.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
                {st.ok}
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedDoc === 'tree' && (
        <pre className="jp-surface jp-mono overflow-x-auto rounded-2xl p-3.5 text-[10.5px] leading-relaxed">
{`JOPRO/
├─ index.html                # Vanilla file:// offline design preview
├─ css/tokens.css            # Auto-generated from design/tokens.json
├─ design/
│  ├─ tokens.json            # Single source of truth
│  └─ design-spec.md         # Shared visual & motion contract
├─ core/                     # Rust engine (16KB page aligned)
│  ├─ .cargo/config.toml     # -Wl,-z,max-page-size=16384
│  └─ src/{lib,protocol,security,transfer,watch}.rs
├─ bridge/src/api.rs         # Zero-copy RawFd flutter_rust_bridge
├─ app/
│  ├─ lib/theme/jopro_tokens.g.dart
│  └─ android/app/           # play & full flavors, minSdk 24, targetSdk 35
│     ├─ src/main/AndroidManifest.xml
│     ├─ src/full/.../ShizukuPrivilegedHelper.kt
│     └─ src/main/.../{JoproForegroundService,StorageAndFdManager,
│        NetworkLadderManager,ApkAndXapkManager,NotificationController}.kt
├─ scripts/{generate_tokens.mjs,build_apk.sh,build_web.sh,compare_screenshots.mjs}
└─ docs/{ARCHITECTURE.md,LIMITATIONS.md,BENCHMARK.md}`}
        </pre>
      )}

      {selectedDoc === 'bench' && (
        <div className="space-y-2.5 text-[11.5px]">
          {[
            { dev: 'Galaxy A20 (Wi-Fi 4 · 2.4GHz 72Mbps)', ceil: 5.8, legacy: 3.4, jopro: 5.5, note: 'CPU 19% · RAM 42MB · 2 Streams' },
            { dev: 'Mid-Range (Wi-Fi 5 · 5GHz 433Mbps)', ceil: 34.6, legacy: 18.5, jopro: 32.8, note: 'AES-GCM HW · 4 Streams · RawFd' },
            { dev: 'Flagship (Wi-Fi 5/6 · 5GHz 866Mbps)', ceil: 69.2, legacy: 36.0, jopro: 66.8, note: 'AES-GCM HW · 6 Streams · pwrite' },
          ].map((b, i) => (
            <div key={i} className="jp-surface rounded-2xl p-3 space-y-1.5">
              <div className="flex justify-between font-bold text-[12px]">
                <span>{b.dev}</span>
                <span className="jp-num" style={{ color: 'var(--jp-status-success)' }}>
                  {b.jopro} / {b.ceil} MB/s
                </span>
              </div>
              <div className="h-2 overflow-hidden rounded-full" style={{ backgroundColor: 'var(--jp-bg-elevated)' }}>
                <div
                  className="h-full rounded-full"
                  style={{ width: `${Math.round((b.jopro / b.ceil) * 100)}%`, backgroundColor: 'var(--jp-accent-primary)' }}
                />
              </div>
              <div className="flex justify-between text-[10.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
                <span>{ar ? `SAF تقليدي: ${b.legacy} MB/s` : `Legacy SAF: ${b.legacy} MB/s`}</span>
                <span className="jp-mono">{b.note}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedDoc === 'code' && (
        <div className="jp-surface rounded-2xl p-3.5 space-y-2.5 text-[11.5px]">
          <div className="flex items-center gap-1.5 font-bold">
            <FileCode className="h-4 w-4" style={{ color: 'var(--jp-accent-primary)' }} />
            <span>{ar ? 'أمر البناء والتحقق من 16KB وAPK (play + full)' : 'Unified 16KB & APK Build Command'}</span>
          </div>
          <pre className="jp-elevated jp-mono overflow-x-auto rounded-xl p-2.5 text-[10.5px]">
            {buildCmd}
          </pre>
          <button
            type="button"
            onClick={() => {
              navigator.clipboard?.writeText(buildCmd).catch(() => {});
              onToast(ar ? 'نُسخ أمر البناء الكامل إلى الحافظة' : 'Copied build command');
            }}
            className="flex min-h-[40px] items-center gap-1.5 rounded-xl px-3.5 text-[11.5px] font-bold text-white cursor-pointer"
            style={{ backgroundColor: 'var(--jp-accent-primary)' }}
          >
            <Copy className="h-3.5 w-3.5" />
            <span>{ar ? 'نسخ أمر البناء' : 'Copy Command'}</span>
          </button>
          <p className="text-[10.5px]" style={{ color: 'var(--jp-text-muted)' }}>
            {ar
              ? 'شفافية البيئة: جميع ملفات JOPRO/ أُنشئت بالكامل داخل المشروع، وتم تشغيل generate_tokens.mjs فعليًا. يتطلب تجميع APK تشغيل build_apk.sh على مضيف يحتوي Android SDK 35 / NDK r27 وFlutter وcargo-ndk.'
              : 'All JOPRO/ source files are generated in this workspace; run build_apk.sh on a host with Android SDK 35 / NDK r27, Flutter & cargo-ndk.'}
          </p>
        </div>
      )}
    </div>
  );
};
