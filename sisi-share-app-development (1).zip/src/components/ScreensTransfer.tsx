import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  BatteryCharging,
  Bell,
  CameraOff,
  CheckCircle2,
  Flashlight,
  FolderCheck,
  Image as ImageIcon,
  Lock,
  Nfc,
  Pause,
  Play,
  QrCode,
  Radio,
  RefreshCw,
  ScanLine,
  Shield,
  ShieldBan,
  ShieldCheck,
  Wifi,
  XCircle,
  Zap,
} from 'lucide-react';
import {
  formatBytes,
  Locale,
  PeerDevice,
  SAMPLE_FILES,
  ScreenId,
} from '../data/previewData';
import { DeviceAvatar, RealQrCode } from './QrAndArtwork';

/* ============================================================================
 * 4. SMART TRANSFER & LIVE READINESS CHECKLIST (Sections 8 & 18.2)
 * ============================================================================ */
export const ReadinessTransferScreen: React.FC<{
  locale: Locale;
  isLowEnd: boolean;
  selectedFileIds: string[];
  peers: PeerDevice[];
  selectedPeerIds: string[];
  onTogglePeer: (id: string) => void;
  onNavigate: (s: ScreenId) => void;
  onToast: (msg: string) => void;
}> = ({
  locale,
  isLowEnd,
  selectedFileIds,
  peers,
  selectedPeerIds,
  onTogglePeer,
  onNavigate,
  onToast,
}) => {
  const ar = locale === 'ar';
  const [apIsolated, setApIsolated] = useState(false);
  const [batteryReady, setBatteryReady] = useState(false);
  const [nearbyReady, setNearbyReady] = useState(true);
  const [networkTier, setNetworkTier] = useState<'lan' | 'direct' | 'lohs' | 'manual' | 'shizuku'>('lan');

  const totalBytes = SAMPLE_FILES.filter((f) => selectedFileIds.includes(f.id)).reduce(
    (s, f) => s + f.sizeBytes,
    0
  );
  const visiblePeers = peers.filter((p) => !p.blocked);

  const checklist = [
    {
      id: 'wifi',
      ready: !apIsolated,
      icon: <Wifi className="h-4 w-4" />,
      title: apIsolated
        ? ar
          ? 'تم رصد عزل الأجهزة في الراوتر (AP Isolation)'
          : 'Router AP Isolation Detected'
        : networkTier === 'direct'
          ? ar
            ? 'يعمل عبر Wi-Fi Direct (192.168.49.1)'
            : 'Active via Wi-Fi Direct (192.168.49.1)'
          : ar
            ? `متصل بشبكة Wi-Fi (${isLowEnd ? '2.4GHz · 72Mbps' : '5GHz · 866Mbps'}) + مقابس مربوطة`
            : `Wi-Fi bound (${isLowEnd ? '2.4GHz · 72Mbps' : '5GHz · 866Mbps'}) · bindProcessToNetwork`,
      detail: apIsolated
        ? ar
          ? 'سُمع إعلان الجهاز عبر Multicast لكن فشل اتصال TCP. حوّل فورًا لـ Wi-Fi Direct.'
          : 'Peer announce heard, TCP blocked by router. Switch to Wi-Fi Direct.'
        : isLowEnd
          ? ar
            ? 'السقف المتوقع على A20: ~5.2 MB/s (نطاق 2.4GHz فقط — صدق السرعة)'
            : 'Honest A20 ceiling: ~5.2 MB/s (2.4GHz hardware)'
          : ar
            ? 'السقف المتوقع: ~68 MB/s · لا يوجد عزل بين الأجهزة'
            : 'Expected ceiling: ~68 MB/s · Zero AP isolation',
      actionLabel: apIsolated ? (ar ? 'تحويل Wi-Fi Direct' : 'Use Direct') : null,
      onFix: () => {
        setApIsolated(false);
        setNetworkTier('direct');
        onToast(ar ? 'تم إنشاء مجموعة DIRECT-JP-SISI وتجاوز عزل الراوتر' : 'Switched to DIRECT-JP-SISI');
      },
    },
    {
      id: 'nearby',
      ready: nearbyReady,
      icon: <Radio className="h-4 w-4" />,
      title: ar ? 'صلاحية الأجهزة القريبة (neverForLocation)' : 'Nearby Wi-Fi Devices (neverForLocation)',
      detail: nearbyReady
        ? ar
          ? 'جاهزة لـ Wi-Fi Direct والنقطة المحلية دون اشتقاق الموقع'
          : 'Ready for Wi-Fi Direct & LocalOnlyHotspot without GPS location'
        : ar
          ? 'مطلوبة فقط عند إنشاء شبكة مباشرة بدون راوتر'
          : 'Needed only for routerless Wi-Fi Direct',
      actionLabel: !nearbyReady ? (ar ? 'تفعيل' : 'Enable') : null,
      onFix: () => setNearbyReady(true),
    },
    {
      id: 'storage',
      ready: true,
      icon: <FolderCheck className="h-4 w-4" />,
      title: ar ? 'التخزين ومجلد Download/JOPRO' : 'Storage & Download/JOPRO',
      detail: ar
        ? '48.6 GB متاحة · f2fs يدعم ملفات >4GB · تمرير RawFd مباشر'
        : '48.6 GB free · >4GB files supported · Direct RawFd active',
      actionLabel: null,
      onFix: () => {},
    },
    {
      id: 'battery',
      ready: batteryReady,
      icon: <BatteryCharging className="h-4 w-4" />,
      title: ar ? 'تحسين البطارية للنقل الضخم' : 'Unrestricted Battery for Large Transfers',
      detail: batteryReady
        ? ar
          ? 'مستثنى + مهمة UIDT مفعّلة (بدون حد 6 ساعات على Android 14+)'
          : 'Unrestricted + Android 14+ UIDT job active'
        : ar
          ? 'موصى به عند إرسال ملفات أكبر من 4GB والشاشة مطفأة'
          : 'Recommended for >4GB background transfers',
      actionLabel: !batteryReady ? (ar ? 'لوحة الإعدادات' : 'Settings Panel') : null,
      onFix: () => {
        setBatteryReady(true);
        onToast(ar ? 'فُتحت شاشة استثناء البطارية وتحدّثت الحالة تلقائيًا' : 'Battery setting updated live');
      },
    },
    {
      id: 'notif',
      ready: true,
      icon: <Bell className="h-4 w-4" />,
      title: ar ? 'إشعارات التقدم اللحظي (1Hz EMA)' : 'Live Progress Notification (1Hz EMA)',
      detail: ar ? 'مفعّلة مع أزرار إيقاف/استئناف/إلغاء في الخلفية' : 'Active with background Pause/Cancel',
      actionLabel: null,
      onFix: () => {},
    },
  ];

  const ladderOptions = [
    {
      id: 'lan' as const,
      label: ar ? 'الراوتر الحالي' : 'Same Router',
      note: ar ? 'Multicast + mDNS + ربط مقابس Wi-Fi بدون إنترنت' : 'Multicast + mDNS + pinned LAN sockets',
    },
    {
      id: 'direct' as const,
      label: 'Wi-Fi Direct AP',
      note: ar
        ? 'المستوى 2: DIRECT-JP-SISI (5GHz) وعنوان ثابت 192.168.49.1 — يتصل به الكمبيوتر والهاتف مباشرة'
        : 'Tier 2: DIRECT-JP-SISI (5GHz) fixed IP 192.168.49.1 — joins like normal Wi-Fi',
    },
    {
      id: 'lohs' as const,
      label: 'LocalOnlyHotspot',
      note: ar
        ? 'المستوى 3 (قيد النظام): الاسم وكلمة المرور يولّدهما Android ولا يمكن تعديلهما برمجيًا — يُعرضان مع QR'
        : 'Tier 3 (OS limit): System-generated SSID/password displayed with instant join QR',
    },
    {
      id: 'manual' as const,
      label: ar ? 'هوتسبوت يدوي' : 'System Hotspot',
      note: ar
        ? 'المستوى 4: يفتح إعدادات نقطة الاتصال مباشرة ويكتشف التفعيل تلقائيًا'
        : 'Tier 4: Opens system Tethering settings and auto-detects activation',
    },
  ];

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      {/* Payload Summary */}
      <div className="jp-surface flex items-center justify-between rounded-2xl p-3">
        <div>
          <div className="text-[13px] font-bold">
            {ar
              ? `جاهز لإرسال ${selectedFileIds.length || 2} ملفات`
              : `Ready to send ${selectedFileIds.length || 2} files`}
          </div>
          <div className="jp-num text-[11.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
            {formatBytes(totalBytes || 14_848_400_000)} ·{' '}
            {selectedPeerIds.length > 1
              ? ar
                ? `إرسال متعدد (${selectedPeerIds.length} أجهزة · قراءة واحدة)`
                : `Multi-Send (${selectedPeerIds.length} peers · single read)`
              : ar
                ? 'مستلم واحد'
                : 'Single recipient'}
          </div>
        </div>
        <button
          type="button"
          onClick={() => setApIsolated((v) => !v)}
          className="rounded-xl px-2.5 py-1.5 text-[10.5px] font-semibold cursor-pointer"
          style={{
            backgroundColor: 'var(--jp-accent-signal-soft)',
            color: 'var(--jp-accent-signal)',
          }}
        >
          {ar ? 'محاكاة عزل AP' : 'Test AP Isolation'}
        </button>
      </div>

      {/* Live Readiness Checklist */}
      <div className="space-y-2">
        <h3 className="px-1 text-[12.5px] font-bold">
          {ar ? 'قائمة الجاهزية الحية (تتحدث تلقائيًا)' : 'Live Readiness Checklist'}
        </h3>
        {checklist.map((item) => (
          <div
            key={item.id}
            className="jp-surface flex items-center justify-between gap-2.5 rounded-2xl p-3"
            style={{
              borderColor: item.ready ? 'var(--jp-border-subtle)' : 'var(--jp-status-warning)',
            }}
          >
            <div className="flex min-w-0 items-start gap-2.5">
              <span
                className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-xl"
                style={{
                  backgroundColor: item.ready ? 'var(--jp-status-success-soft)' : 'var(--jp-status-warning-soft)',
                  color: item.ready ? 'var(--jp-status-success)' : 'var(--jp-status-warning)',
                }}
              >
                {item.ready ? <CheckCircle2 className="h-4 w-4" /> : item.icon}
              </span>
              <div className="min-w-0">
                <div className="text-[12px] font-bold">{item.title}</div>
                <div className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                  {item.detail}
                </div>
              </div>
            </div>
            {item.actionLabel && (
              <button
                type="button"
                onClick={item.onFix}
                className="min-h-[38px] shrink-0 rounded-xl px-3 text-[11px] font-bold text-white cursor-pointer"
                style={{ backgroundColor: 'var(--jp-accent-primary)' }}
              >
                {item.actionLabel}
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Routerless Network Creation Ladder (Section 18.2) */}
      <div className="jp-surface rounded-2xl p-3 space-y-2">
        <div className="text-[12px] font-bold">
          {ar ? 'سلّم إنشاء الشبكة بدون راوتر (بدون نزول صامت)' : 'Routerless Network Ladder'}
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {ladderOptions.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setNetworkTier(opt.id)}
              className="rounded-xl px-2.5 py-2 text-[11px] font-semibold cursor-pointer"
              style={{
                backgroundColor: networkTier === opt.id ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                color: networkTier === opt.id ? '#FFFFFF' : 'var(--jp-text-secondary)',
              }}
            >
              {opt.label}
            </button>
          ))}
        </div>
        <p className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
          {ladderOptions.find((o) => o.id === networkTier)?.note}
        </p>
      </div>

      {/* Multi-send Recipient Chips */}
      <div className="jp-surface rounded-2xl p-3 space-y-2">
        <div className="text-[12px] font-bold">
          {ar ? 'المستلمون المحددون (يدعم Multi-Send)' : 'Recipients (Multi-Send Enabled)'}
        </div>
        <div className="flex flex-wrap gap-1.5">
          {visiblePeers.map((p) => {
            const on = selectedPeerIds.includes(p.id);
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => onTogglePeer(p.id)}
                className="flex min-h-[38px] items-center gap-1.5 rounded-full px-3 text-[11.5px] font-semibold cursor-pointer"
                style={{
                  backgroundColor: on ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                  color: on ? '#FFFFFF' : 'var(--jp-text-secondary)',
                }}
              >
                <span>{(ar ? p.aliasAr : p.aliasEn).split('·')[0]}</span>
                {on && <span>✓</span>}
              </button>
            );
          })}
        </div>
      </div>

      <button
        type="button"
        onClick={() => onNavigate('progress')}
        className="w-full min-h-[48px] rounded-2xl text-[13.5px] font-bold text-white cursor-pointer"
        style={{ backgroundColor: 'var(--jp-accent-primary)' }}
      >
        {ar ? 'بدء النقل عالي الأداء (معاينة)' : 'Start High-Speed Transfer (Preview)'}
      </button>
    </div>
  );
};

/* ============================================================================
 * 5. LIVE PROGRESS — SINGLE & MULTI-SEND + PARALLEL RANGES + BLAKE3 RESUME
 * ============================================================================ */
export const LiveProgressScreen: React.FC<{
  locale: Locale;
  isLowEnd: boolean;
  reduceMotion: boolean;
  onToast: (msg: string) => void;
}> = ({ locale, isLowEnd, reduceMotion, onToast }) => {
  const ar = locale === 'ar';
  const [mode, setMode] = useState<'single' | 'multi'>('single');
  const [paused, setPaused] = useState(false);
  const [cipher, setCipher] = useState<'aes' | 'chacha' | 'maxperf'>(isLowEnd ? 'chacha' : 'aes');
  const [pct, setPct] = useState(64);
  const [peer2Failed, setPeer2Failed] = useState(false);
  const [peerPcts, setPeerPcts] = useState([78, 46, 91]);

  useEffect(() => {
    if (paused || reduceMotion) return;
    const id = window.setInterval(() => {
      setPct((p) => (p >= 100 ? 22 : +(p + 0.8).toFixed(1)));
      setPeerPcts(([a, b, c]) => [
        a >= 100 ? 100 : Math.min(100, +(a + 0.9).toFixed(1)),
        peer2Failed ? b : b >= 100 ? 100 : Math.min(100, +(b + 0.35).toFixed(1)),
        c >= 100 ? 100 : Math.min(100, +(c + 1.1).toFixed(1)),
      ]);
    }, 550);
    return () => window.clearInterval(id);
  }, [paused, reduceMotion, peer2Failed]);

  const speedMbs = isLowEnd ? 5.4 : cipher === 'maxperf' ? 74.2 : 66.8;
  const streams = isLowEnd ? 2 : 6;
  const remainingSecs = Math.max(1, Math.round(((100 - pct) / 100) * (isLowEnd ? 185 : 32)));

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      {/* Mode Switch */}
      <div className="jp-elevated grid grid-cols-2 gap-1 rounded-2xl p-1">
        <button
          type="button"
          onClick={() => setMode('single')}
          className="min-h-[40px] rounded-xl text-[12px] font-bold cursor-pointer"
          style={{
            backgroundColor: mode === 'single' ? 'var(--jp-bg-surface)' : 'transparent',
            color: mode === 'single' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          {ar ? 'نقل فردي (مقاطع متوازية)' : 'Single (Parallel Ranges)'}
        </button>
        <button
          type="button"
          onClick={() => setMode('multi')}
          className="min-h-[40px] rounded-xl text-[12px] font-bold cursor-pointer"
          style={{
            backgroundColor: mode === 'multi' ? 'var(--jp-bg-surface)' : 'transparent',
            color: mode === 'multi' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          {ar ? 'متعدد المستلمين (3 أجهزة)' : 'Multi-Send (3 Peers)'}
        </button>
      </div>

      {mode === 'single' ? (
        <div className="jp-surface rounded-3xl p-4 space-y-3.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <DeviceAvatar seed={3} initials="ط" accent="#2F7CF6" size={42} trusted />
              <div>
                <div className="text-[13.5px] font-bold">
                  {ar ? 'هاتف طارق · S24' : 'Tariq · Galaxy S24'}
                </div>
                <div className="jp-mono text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                  Desert_Odyssey_4K_HDR10.mkv · 14.82 GB
                </div>
              </div>
            </div>
            <span className="jp-num text-[20px] font-extrabold" style={{ color: 'var(--jp-accent-primary)' }}>
              {Math.round(pct)}%
            </span>
          </div>

          {/* Main Smooth Determinate Bar */}
          <div className="h-3 w-full overflow-hidden rounded-full" style={{ backgroundColor: 'var(--jp-bg-elevated)' }}>
            <div
              className="jp-transition h-full rounded-full"
              style={{
                width: `${pct}%`,
                backgroundColor: paused ? 'var(--jp-accent-signal)' : 'var(--jp-accent-primary)',
              }}
            />
          </div>

          {/* EMA Speed & ETA Metrics */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="jp-elevated rounded-xl p-2">
              <div className="text-[10px]" style={{ color: 'var(--jp-text-muted)' }}>
                {ar ? 'السرعة (EMA)' : 'Speed (EMA)'}
              </div>
              <div className="jp-num text-[13.5px] font-bold" style={{ color: 'var(--jp-status-success)' }}>
                {paused ? '0.0' : speedMbs} MB/s
              </div>
            </div>
            <div className="jp-elevated rounded-xl p-2">
              <div className="text-[10px]" style={{ color: 'var(--jp-text-muted)' }}>
                {ar ? 'الوقت المتبقي' : 'ETA'}
              </div>
              <div className="jp-num text-[13.5px] font-bold">
                {paused ? '—' : `00:${String(remainingSecs).padStart(2, '0')}`}
              </div>
            </div>
            <div className="jp-elevated rounded-xl p-2">
              <div className="text-[10px]" style={{ color: 'var(--jp-text-muted)' }}>
                {ar ? 'اتصالات متوازية' : 'Range Streams'}
              </div>
              <div className="jp-num text-[13.5px] font-bold">
                {streams} · {isLowEnd ? '128KB' : '1MB'}
              </div>
            </div>
          </div>

          {/* Parallel Range Segments */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
              <span>{ar ? 'خريطة المقاطع (pwrite + فحص BLAKE3)' : 'Range Bitmap (pwrite + BLAKE3)'}</span>
              <span className="jp-mono text-[10px]" style={{ color: 'var(--jp-status-success)' }}>
                BLAKE3 ✓
              </span>
            </div>
            <div className="grid grid-cols-6 gap-1">
              {Array.from({ length: streams }).map((_, idx) => {
                const segPct = Math.min(100, Math.max(15, Math.round(pct + (idx % 2 === 0 ? 12 : -8))));
                return (
                  <div
                    key={idx}
                    className="h-2 overflow-hidden rounded-full"
                    style={{ backgroundColor: 'var(--jp-bg-elevated)' }}
                  >
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${segPct}%`, backgroundColor: 'var(--jp-status-success)' }}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setPaused((p) => !p)}
              className="flex flex-1 min-h-[44px] items-center justify-center gap-1.5 rounded-xl text-[12.5px] font-bold text-white cursor-pointer"
              style={{ backgroundColor: 'var(--jp-accent-primary)' }}
            >
              {paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
              <span>{paused ? (ar ? 'استئناف المقطع' : 'Resume Range') : ar ? 'إيقاف مؤقت' : 'Pause'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setPaused(true);
                onToast(ar ? 'أُلغيت الجلسة وحُررت أقفال WakeLock/WifiLock فورًا' : 'Canceled & released locks');
              }}
              className="flex min-h-[44px] items-center gap-1 rounded-xl px-3.5 text-[12px] font-bold cursor-pointer"
              style={{ backgroundColor: 'var(--jp-status-danger-soft)', color: 'var(--jp-status-danger)' }}
            >
              <XCircle className="h-4 w-4" />
              <span>{ar ? 'إلغاء' : 'Cancel'}</span>
            </button>
          </div>
        </div>
      ) : (
        /* Multi-send: Read file ONCE, independent progress, fault isolation */
        <div className="space-y-2.5">
          <div className="jp-elevated flex items-center justify-between rounded-2xl px-3 py-2 text-[11.5px]">
            <span>
              {ar
                ? 'قراءة الملف مرة واحدة (Shared pread) · فشل جهاز لا يوقف الباقين'
                : 'Single storage read · Peer failure never halts others'}
            </span>
            <button
              type="button"
              onClick={() => setPeer2Failed((v) => !v)}
              className="shrink-0 rounded-lg px-2 py-1 text-[10.5px] font-bold cursor-pointer"
              style={{ backgroundColor: 'var(--jp-status-warning-soft)', color: 'var(--jp-status-warning)' }}
            >
              {peer2Failed ? (ar ? 'استئناف #2' : 'Resume #2') : ar ? 'قطع #2' : 'Drop #2'}
            </button>
          </div>

          {[
            { name: ar ? 'هاتف طارق · S24 (5GHz)' : 'Tariq · S24 (5GHz)', p: peerPcts[0], spd: '54.2 MB/s', failed: false },
            { name: ar ? 'جالكسي A20 · سلمى (2.4GHz)' : 'Salma · Galaxy A20 (2.4GHz)', p: peerPcts[1], spd: '5.3 MB/s', failed: peer2Failed },
            { name: ar ? 'تابلت الاستوديو (Direct)' : 'Studio Pad (Direct)', p: peerPcts[2], spd: '32.8 MB/s', failed: false },
          ].map((rec, i) => (
            <div key={i} className="jp-surface rounded-2xl p-3 space-y-2">
              <div className="flex items-center justify-between text-[12px]">
                <span className="font-bold">{rec.name}</span>
                <span
                  className="jp-num font-bold"
                  style={{
                    color: rec.failed
                      ? 'var(--jp-status-danger)'
                      : rec.p >= 100
                        ? 'var(--jp-status-success)'
                        : 'var(--jp-accent-primary)',
                  }}
                >
                  {rec.failed
                    ? ar
                      ? `انقطع عند ${Math.round(rec.p)}% (محفوظ للاستئناف)`
                      : `Interrupted at ${Math.round(rec.p)}% (resumable)`
                    : rec.p >= 100
                      ? ar
                        ? 'مكتمل ✓'
                        : 'Done ✓'
                      : `${Math.round(rec.p)}% · ${rec.spd}`}
                </span>
              </div>
              <div className="h-2 overflow-hidden rounded-full" style={{ backgroundColor: 'var(--jp-bg-elevated)' }}>
                <div
                  className="jp-transition h-full rounded-full"
                  style={{
                    width: `${rec.p}%`,
                    backgroundColor: rec.failed
                      ? 'var(--jp-status-danger)'
                      : rec.p >= 100
                        ? 'var(--jp-status-success)'
                        : 'var(--jp-accent-primary)',
                  }}
                />
              </div>
              {rec.failed && (
                <button
                  type="button"
                  onClick={() => setPeer2Failed(false)}
                  className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-bold text-white cursor-pointer"
                  style={{ backgroundColor: 'var(--jp-accent-primary)' }}
                >
                  <RefreshCw className="h-3 w-3" />
                  <span>{ar ? 'استئناف من المقطع #19' : 'Resume from Chunk #19'}</span>
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Adaptive Cipher Profile Selector (Sections 6 & 18.8) */}
      <div className="jp-surface rounded-2xl p-3 space-y-2">
        <div className="flex items-center gap-1.5 text-[12px] font-bold">
          <Lock className="h-3.5 w-3.5" style={{ color: 'var(--jp-accent-primary)' }} />
          <span>{ar ? 'وضع التشفير المتكيّف حسب العتاد' : 'Hardware-Adaptive Cipher Profile'}</span>
        </div>
        <div className="grid grid-cols-3 gap-1.5 text-[10.5px]">
          {[
            { id: 'aes' as const, label: 'AES-GCM HW' },
            { id: 'chacha' as const, label: 'ChaCha20' },
            { id: 'maxperf' as const, label: ar ? 'أداء أقصى MAC' : 'Max-Perf MAC' },
          ].map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setCipher(c.id)}
              className="min-h-[36px] rounded-xl px-2 font-semibold cursor-pointer"
              style={{
                backgroundColor: cipher === c.id ? 'var(--jp-accent-primary)' : 'var(--jp-bg-elevated)',
                color: cipher === c.id ? '#FFF' : 'var(--jp-text-secondary)',
              }}
            >
              {c.label}
            </button>
          ))}
        </div>
        {cipher === 'maxperf' && (
          <div
            className="flex items-start gap-1.5 rounded-xl p-2 text-[11px]"
            style={{ backgroundColor: 'var(--jp-status-warning-soft)', color: 'var(--jp-status-warning)' }}
          >
            <Zap className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <span>
              {ar
                ? 'تحذير صريح: المحتوى غير مشفر لتسريع sendfile على الشبكة الموثوقة، لكن كل مقطع مصادَق بـ BLAKE3-MAC لمنع حقن البيانات.'
                : 'Explicit warning: Unencrypted payload for max sendfile speed; every chunk is BLAKE3-MAC authenticated against injection.'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

/* ============================================================================
 * 6. RECEIVE MODE & MANDATORY PRE-CONNECTION APPROVAL (Sections 3.5 & 9)
 * ============================================================================ */
export const ReceiveApprovalScreen: React.FC<{
  locale: Locale;
  receiveOn: boolean;
  onToggleReceive: () => void;
  onDecision: (action: 'once' | 'trust' | 'reject' | 'block') => void;
}> = ({ locale, receiveOn, onToggleReceive, onDecision }) => {
  const ar = locale === 'ar';
  const [secondsLeft, setSecondsLeft] = useState(54);
  const [autoSubfolders, setAutoSubfolders] = useState(true);
  const [pinRequired, setPinRequired] = useState(false);

  useEffect(() => {
    const id = window.setInterval(() => {
      setSecondsLeft((s) => (s <= 1 ? 60 : s - 1));
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      {/* Mandatory Pre-Connection Approval Card */}
      <div
        className="jp-surface rounded-3xl p-4 space-y-3"
        style={{ border: '1.5px solid var(--jp-accent-primary)' }}
      >
        <div className="flex items-center justify-between">
          <span
            className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold"
            style={{ backgroundColor: 'var(--jp-accent-primary-soft)', color: 'var(--jp-accent-primary)' }}
          >
            <Shield className="h-3.5 w-3.5" />
            {ar ? 'طلب اتصال قبل كشف أي ملفات' : 'Pre-Connection Approval Gate'}
          </span>
          <span className="jp-mono text-[11px] font-bold" style={{ color: 'var(--jp-accent-signal)' }}>
            {secondsLeft}s
          </span>
        </div>

        <div className="flex items-center gap-3">
          <DeviceAvatar seed={11} initials="ت" accent="#F59E0B" size={48} />
          <div className="min-w-0">
            <div className="text-[14.5px] font-bold">
              {ar ? 'تابلت الاستوديو (Xiaomi Pad 6)' : 'Studio Pad Pro (Xiaomi Pad 6)'}
            </div>
            <div className="text-[11.5px]" style={{ color: 'var(--jp-text-secondary)' }}>
              <span className="jp-mono">192.168.49.4</span> · {ar ? '4 ملفات (1.18 GB) · مساحة كافية ✓' : '4 files (1.18 GB) · Space OK ✓'}
            </div>
          </div>
        </div>

        <div className="jp-elevated rounded-xl p-2.5 text-[11px]">
          <div style={{ color: 'var(--jp-text-muted)' }}>
            {ar ? 'بصمة شهادة TLS 1.3 (تُثبَّت بعد أول قبول):' : 'TLS 1.3 Certificate Fingerprint (TOFU):'}
          </div>
          <div className="jp-mono mt-0.5 font-bold" style={{ color: 'var(--jp-accent-primary)' }}>
            C712:88B4:3F09:A15D:92E4:77C0
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => onDecision('once')}
            className="min-h-[44px] rounded-xl text-[12px] font-bold text-white cursor-pointer"
            style={{ backgroundColor: 'var(--jp-accent-primary)' }}
          >
            {ar ? 'قبول هذه المرة' : 'Accept Once'}
          </button>
          <button
            type="button"
            onClick={() => onDecision('trust')}
            className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl text-[12px] font-bold cursor-pointer"
            style={{ backgroundColor: 'var(--jp-status-success-soft)', color: 'var(--jp-status-success)' }}
          >
            <ShieldCheck className="h-4 w-4" />
            <span>{ar ? 'قبول دائم (موثوق)' : 'Always Trust'}</span>
          </button>
          <button
            type="button"
            onClick={() => onDecision('reject')}
            className="jp-elevated min-h-[44px] rounded-xl text-[12px] font-semibold cursor-pointer"
          >
            {ar ? 'رفض' : 'Reject'}
          </button>
          <button
            type="button"
            onClick={() => onDecision('block')}
            className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl text-[12px] font-bold cursor-pointer"
            style={{ backgroundColor: 'var(--jp-status-danger-soft)', color: 'var(--jp-status-danger)' }}
          >
            <ShieldBan className="h-4 w-4" />
            <span>{ar ? 'حظر بالبصمة' : 'Block Fingerprint'}</span>
          </button>
        </div>
      </div>

      {/* Atomic Download/JOPRO Folder Card (Section 3.5) */}
      <div className="jp-surface rounded-2xl p-3.5 space-y-2.5 text-[12px]">
        <div className="flex items-center justify-between">
          <span className="font-bold">{ar ? 'وضع الاستقبال (خدمة أمامية خفيفة)' : 'Receive Foreground Service'}</span>
          <input
            type="checkbox"
            checked={receiveOn}
            onChange={onToggleReceive}
            className="h-4 w-4 accent-[#2F7CF6] cursor-pointer"
          />
        </div>
        <div className="jp-elevated rounded-xl p-2.5 space-y-1 text-[11px]">
          <div className="flex items-center justify-between">
            <span style={{ color: 'var(--jp-text-secondary)' }}>
              {ar ? 'مجلد الاستقبال الافتراضي:' : 'Default Receive Folder:'}
            </span>
            <span className="jp-mono font-bold" style={{ color: 'var(--jp-status-success)' }}>
              Download/JOPRO/
            </span>
          </div>
          <p style={{ color: 'var(--jp-text-muted)' }}>
            {ar
              ? 'كتابة ذرية IS_PENDING=1 + حجز fallocate بدون أي صلاحية على Android 10+ وإشعار MediaScanner الفوري.'
              : 'Atomic IS_PENDING=1 + upfront fallocate (zero permission on API 29+) + instant MediaScanner.'}
          </p>
        </div>
        <label className="flex items-center justify-between cursor-pointer">
          <span style={{ color: 'var(--jp-text-secondary)' }}>
            {ar ? 'فرز تلقائي (Images / Videos / Apps / Contacts)' : 'Auto-subfolders by media type'}
          </span>
          <input
            type="checkbox"
            checked={autoSubfolders}
            onChange={(e) => setAutoSubfolders(e.target.checked)}
            className="h-4 w-4 accent-[#2F7CF6]"
          />
        </label>
        <label className="flex items-center justify-between cursor-pointer">
          <span style={{ color: 'var(--jp-text-secondary)' }}>
            {ar ? 'طلب رمز PIN (4821) مع حماية التخمين' : 'Require session PIN (4821) + rate limit'}
          </span>
          <input
            type="checkbox"
            checked={pinRequired}
            onChange={(e) => setPinRequired(e.target.checked)}
            className="h-4 w-4 accent-[#2F7CF6]"
          />
        </label>
      </div>
    </div>
  );
};

/* ============================================================================
 * 7. REAL QR DISPLAY, WI-FI JOIN QR & OFFLINE BUNDLED SCANNER (Section 7)
 * ============================================================================ */
export const QrAndScannerScreen: React.FC<{
  locale: Locale;
  onToast: (msg: string) => void;
}> = ({ locale, onToast }) => {
  const ar = locale === 'ar';
  const [tab, setTab] = useState<'session' | 'wifi' | 'scan'>('session');
  const [torch, setTorch] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [cameraDenied, setCameraDenied] = useState(false);
  const [manualHost, setManualHost] = useState('192.168.1.18:53317');
  const [ssidSuffix, setSsidSuffix] = useState('SISI');

  const sessionPayload = 'sisishare://192.168.1.42:53317?fp=7B3EA9F4&tk=Q8M2&pin=4821';
  const wifiPayload = `WIFI:T:WPA;S:DIRECT-JP-${ssidSuffix || 'SISI'};P:k9Xm42Qp;;`;

  return (
    <div className="jp-screen-enter space-y-3 p-3.5">
      <div className="jp-elevated grid grid-cols-3 gap-1 rounded-2xl p-1 text-[11.5px] font-bold">
        <button
          type="button"
          onClick={() => setTab('session')}
          className="flex min-h-[40px] items-center justify-center gap-1 rounded-xl cursor-pointer"
          style={{
            backgroundColor: tab === 'session' ? 'var(--jp-bg-surface)' : 'transparent',
            color: tab === 'session' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          <QrCode className="h-3.5 w-3.5" />
          <span>{ar ? 'رمز الاتصال' : 'Session QR'}</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('wifi')}
          className="flex min-h-[40px] items-center justify-center gap-1 rounded-xl cursor-pointer"
          style={{
            backgroundColor: tab === 'wifi' ? 'var(--jp-bg-surface)' : 'transparent',
            color: tab === 'wifi' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          <Wifi className="h-3.5 w-3.5" />
          <span>{ar ? 'انضمام Wi-Fi' : 'Wi-Fi QR'}</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('scan')}
          className="flex min-h-[40px] items-center justify-center gap-1 rounded-xl cursor-pointer"
          style={{
            backgroundColor: tab === 'scan' ? 'var(--jp-bg-surface)' : 'transparent',
            color: tab === 'scan' ? 'var(--jp-text-primary)' : 'var(--jp-text-secondary)',
          }}
        >
          <ScanLine className="h-3.5 w-3.5" />
          <span>{ar ? 'مسح / يدوي' : 'Scan / IP'}</span>
        </button>
      </div>

      {tab === 'session' && (
        <div className="jp-surface flex flex-col items-center rounded-3xl p-4 text-center space-y-3">
          <RealQrCode value={sessionPayload} size={172} label="SISI Share Session QR" />
          <div>
            <div className="text-[13.5px] font-bold">
              {ar ? 'QR حقيقي مولَّد محليًا (ISO 18004)' : 'Real Locally-Encoded QR (ISO 18004)'}
            </div>
            <p className="mt-0.5 text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
              {ar
                ? 'يحمل IP + المنفذ + بصمة الشهادة + التوكن + PIN اختياري'
                : 'Encodes IP, Port, TLS Fingerprint, Session Token & optional PIN'}
            </p>
          </div>
          <div className="jp-elevated jp-mono w-full break-all rounded-xl p-2 text-[10.5px]">
            {sessionPayload}
          </div>
          <div
            className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-[11px]"
            style={{ backgroundColor: 'var(--jp-accent-primary-soft)', color: 'var(--jp-accent-primary)' }}
          >
            <span className="flex items-center gap-1.5 font-semibold">
              <Nfc className="h-4 w-4" />
              {ar ? 'NFC HCE جاهز: قرّب الهاتفين للاتصال بلمسة' : 'NFC HCE ready: tap phones to pair'}
            </span>
            <span className="jp-mono font-bold">PIN: 4821</span>
          </div>
        </div>
      )}

      {tab === 'wifi' && (
        <div className="jp-surface flex flex-col items-center rounded-3xl p-4 text-center space-y-3">
          <RealQrCode value={wifiPayload} size={168} label="Wi-Fi Direct WPA2 QR" />
          <div className="w-full space-y-2 text-start text-[11.5px]">
            <div className="flex items-center justify-between">
              <span style={{ color: 'var(--jp-text-secondary)' }}>SSID (Android 10+):</span>
              <span className="jp-mono font-bold">DIRECT-JP-{ssidSuffix || 'SISI'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span style={{ color: 'var(--jp-text-secondary)' }}>{ar ? 'كلمة المرور:' : 'Passphrase:'}</span>
              <span className="jp-mono font-bold">k9Xm42Qp</span>
            </div>
            <input
              type="text"
              maxLength={12}
              value={ssidSuffix}
              onChange={(e) => setSsidSuffix(e.target.value.replace(/[^A-Za-z0-9-]/g, ''))}
              placeholder="SISI"
              className="jp-elevated jp-mono w-full rounded-xl px-3 py-2 text-[12px] outline-none"
            />
            <p className="text-[10.5px]" style={{ color: 'var(--jp-text-muted)' }}>
              {ar
                ? 'قيد Android الصريح: بادئة DIRECT-xx- إلزامية في Wi-Fi Direct؛ رمز QR يتحدث لحظيًا مع التعديل.'
                : 'Explicit Android limit: DIRECT-xx- prefix is mandatory on WifiP2pConfig; QR updates live.'}
            </p>
          </div>
        </div>
      )}

      {tab === 'scan' && (
        <div className="space-y-3">
          <div className="jp-surface rounded-3xl p-3.5 space-y-3">
            {!cameraDenied ? (
              <>
                <div className="relative mx-auto h-44 w-full overflow-hidden rounded-2xl bg-[#070A10]">
                  <div className="pointer-events-none absolute inset-5 rounded-2xl border-2 border-dashed border-[#2F7CF6]/80" />
                  <div className="jp-scan-beam absolute inset-x-7 top-4 h-0.5 bg-[#F59E0B]" />
                  <div className="absolute start-3 bottom-2.5 jp-mono rounded-md bg-black/65 px-2 py-0.5 text-[10.5px] text-white">
                    ML Kit Bundled (Offline) · {zoom.toFixed(1)}x
                  </div>
                  {torch && (
                    <div className="absolute end-3 top-2.5 rounded-md bg-amber-500/90 px-2 py-0.5 text-[10px] font-bold text-black">
                      TORCH ON
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setTorch((t) => !t)}
                    className="jp-elevated flex min-h-[42px] items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-semibold cursor-pointer"
                    style={{ color: torch ? 'var(--jp-accent-signal)' : 'var(--jp-text-primary)' }}
                  >
                    <Flashlight className="h-4 w-4" />
                    <span>{ar ? 'مصباح' : 'Torch'}</span>
                  </button>
                  <input
                    type="range"
                    min={1}
                    max={4}
                    step={0.5}
                    value={zoom}
                    onChange={(e) => setZoom(Number(e.target.value))}
                    className="flex-1 accent-[#2F7CF6]"
                    aria-label="Scanner zoom"
                  />
                  <button
                    type="button"
                    onClick={() => onToast(ar ? 'فُتح منتقي الصور لقراءة QR من المعرض محليًا' : 'Reading QR from gallery')}
                    className="jp-elevated flex min-h-[42px] items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-semibold cursor-pointer"
                  >
                    <ImageIcon className="h-4 w-4" />
                    <span>{ar ? 'المعرض' : 'Gallery'}</span>
                  </button>
                </div>
              </>
            ) : (
              /* Graceful Degradation on Camera Permission Refusal (Section 3.2) */
              <div className="jp-elevated flex flex-col items-center rounded-2xl p-4 text-center space-y-2">
                <CameraOff className="h-7 w-7" style={{ color: 'var(--jp-accent-signal)' }} />
                <div className="text-[12.5px] font-bold">
                  {ar ? 'الكاميرا غير مفعّلة — التدهور اللطيف نشط' : 'Camera Denied — Graceful Fallback'}
                </div>
                <p className="text-[11px]" style={{ color: 'var(--jp-text-secondary)' }}>
                  {ar
                    ? 'يمكنك قراءة صورة QR من المعرض أو الاتصال بالإدخال اليدوي بالأسفل دون إجبارك على منح الكاميرا.'
                    : 'Scan a saved QR image from Gallery or connect via IP:Port below.'}
                </p>
              </div>
            )}

            <button
              type="button"
              onClick={() => setCameraDenied((c) => !c)}
              className="flex items-center gap-1 text-[11px] font-semibold cursor-pointer"
              style={{ color: 'var(--jp-text-muted)' }}
            >
              <AlertTriangle className="h-3.5 w-3.5" />
              <span>{cameraDenied ? (ar ? 'إعادة تفعيل الكاميرا' : 'Restore camera') : ar ? 'تجربة رفض صلاحية الكاميرا' : 'Simulate camera refusal'}</span>
            </button>
          </div>

          {/* Manual IP:Port / Short Code */}
          <div className="jp-surface rounded-2xl p-3 space-y-2">
            <div className="text-[12px] font-bold">
              {ar ? 'اتصال يدوي (IP:Port أو كود قصير)' : 'Manual Connect (IP:Port or Code)'}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={manualHost}
                onChange={(e) => setManualHost(e.target.value)}
                className="jp-elevated jp-mono flex-1 rounded-xl px-3 py-2 text-[12px] outline-none"
              />
              <button
                type="button"
                onClick={() => onToast(ar ? `جارٍ طلب مصافحة ${manualHost} (معاينة)` : `Handshaking ${manualHost}`)}
                className="min-h-[42px] rounded-xl px-4 text-[12px] font-bold text-white cursor-pointer"
                style={{ backgroundColor: 'var(--jp-accent-primary)' }}
              >
                {ar ? 'اتصال' : 'Connect'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
