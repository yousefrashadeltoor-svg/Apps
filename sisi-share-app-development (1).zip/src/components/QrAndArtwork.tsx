import React, { useMemo } from 'react';
import { encodeQr } from '../utils/qrEncoder';

export const BrandMark: React.FC<{ size?: number; monochrome?: boolean }> = ({
  size = 32,
  monochrome = false,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 40 40"
    fill="none"
    aria-hidden="true"
    className="shrink-0"
  >
    <rect
      x="1"
      y="1"
      width="38"
      height="38"
      rx="12"
      fill={monochrome ? 'currentColor' : 'var(--jp-accent-primary)'}
      fillOpacity={monochrome ? 0.14 : 1}
    />
    <path
      d="M11.5 22.5C11.5 16.425 16.425 11.5 22.5 11.5H28.5"
      stroke={monochrome ? 'currentColor' : '#FFFFFF'}
      strokeWidth="3"
      strokeLinecap="round"
    />
    <path
      d="M28.5 17.5C28.5 23.575 23.575 28.5 17.5 28.5H11.5"
      stroke={monochrome ? 'currentColor' : '#FFFFFF'}
      strokeOpacity={monochrome ? 0.85 : 0.88}
      strokeWidth="3"
      strokeLinecap="round"
    />
    <path
      d="M25 8.5L29 11.5L25 14.5"
      stroke={monochrome ? 'currentColor' : '#FFFFFF'}
      strokeWidth="2.6"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle
      cx="20"
      cy="20"
      r="3.4"
      fill={monochrome ? 'currentColor' : '#FBBF24'}
    />
  </svg>
);

export const RealQrCode: React.FC<{
  value: string;
  size?: number;
  className?: string;
  label?: string;
}> = ({ value, size = 168, className = '', label = 'QR Code' }) => {
  const { pathData, viewSize, version } = useMemo(() => {
    const qr = encodeQr(value);
    const quiet = 3;
    const total = qr.size + quiet * 2;
    const parts: string[] = [];
    for (let y = 0; y < qr.size; y++) {
      for (let x = 0; x < qr.size; x++) {
        if (qr.modules[y][x]) {
          parts.push(`M${x + quiet},${y + quiet}h1v1h-1z`);
        }
      }
    }
    return { pathData: parts.join(''), viewSize: total, version: qr.version };
  }, [value]);

  return (
    <div
      className={`inline-flex flex-col items-center justify-center rounded-2xl bg-white p-2.5 shadow-sm ${className}`}
      title={`${label} (QR v${version})`}
    >
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${viewSize} ${viewSize}`}
        shapeRendering="crispEdges"
        role="img"
        aria-label={label}
      >
        <rect width={viewSize} height={viewSize} fill="#FFFFFF" />
        <path d={pathData} fill="#0B0E14" />
      </svg>
    </div>
  );
};

export const DeviceAvatar: React.FC<{
  seed: number;
  initials: string;
  accent: string;
  size?: number;
  trusted?: boolean;
}> = ({ seed, initials, accent, size = 44, trusted = false }) => {
  const angle = (seed * 53) % 360;
  return (
    <div
      className="relative inline-flex shrink-0 items-center justify-center rounded-2xl font-bold text-white select-none"
      style={{
        width: size,
        height: size,
        background: `linear-gradient(${angle}deg, ${accent}, color-mix(in srgb, ${accent} 62%, #0B0E14))`,
        fontSize: Math.max(11, Math.round(size * 0.34)),
      }}
    >
      <svg
        className="pointer-events-none absolute inset-0 opacity-25"
        viewBox="0 0 44 44"
        fill="none"
        aria-hidden="true"
      >
        <circle cx={10 + (seed % 20)} cy={10 + ((seed * 7) % 18)} r="12" stroke="#FFF" strokeWidth="1.5" />
        <circle cx="34" cy="34" r="10" fill="#FFF" fillOpacity="0.2" />
      </svg>
      <span className="relative z-10 tracking-tight">{initials}</span>
      {trusted && (
        <span
          className="absolute -end-1 -bottom-1 flex h-4 w-4 items-center justify-center rounded-full border-2 text-[9px] text-white"
          style={{
            backgroundColor: 'var(--jp-status-success)',
            borderColor: 'var(--jp-bg-surface)',
          }}
          title="Trusted TOFU Peer"
        >
          ✓
        </span>
      )}
    </div>
  );
};

export const GenerativeArtThumb: React.FC<{
  kind: 'photo' | 'video' | 'music' | 'app';
  palette: [string, string, string];
  seed: number;
  glyph?: string;
  className?: string;
}> = ({ kind, palette, seed, glyph, className = '' }) => {
  const [c1, c2, c3] = palette;
  const sunX = 24 + ((seed * 19) % 52);
  const sunY = 20 + ((seed * 11) % 24);
  return (
    <svg
      viewBox="0 0 120 90"
      className={`h-full w-full object-cover select-none ${className}`}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`g-${kind}-${seed}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={c1} />
          <stop offset="60%" stopColor={c2} />
          <stop offset="100%" stopColor={c3} />
        </linearGradient>
      </defs>
      <rect width="120" height="90" fill={`url(#g-${kind}-${seed})`} />
      {kind === 'photo' && (
        <>
          <circle cx={sunX} cy={sunY} r="13" fill="#FFF" fillOpacity="0.82" />
          <path
            d={`M0 68 Q ${30 + (seed % 20)} 42, 66 62 T 120 54 L 120 90 L 0 90 Z`}
            fill={c3}
            fillOpacity="0.72"
          />
          <path
            d="M0 76 Q 48 58, 92 74 T 120 70 L 120 90 L 0 90 Z"
            fill="#0B0E14"
            fillOpacity="0.34"
          />
        </>
      )}
      {kind === 'video' && (
        <>
          <circle cx="88" cy="24" r="28" fill={c3} fillOpacity="0.45" />
          <path d="M0 64 L42 38 L78 58 L104 42 L120 52 L120 90 L0 90 Z" fill="#0B0E14" fillOpacity="0.42" />
          <circle cx="60" cy="45" r="14" fill="#0B0E14" fillOpacity="0.58" />
          <path d="M56 38 L68 45 L56 52 Z" fill="#FFFFFF" />
        </>
      )}
      {kind === 'music' && (
        <>
          <circle cx="60" cy="45" r="28" fill="#0B0E14" fillOpacity="0.35" />
          <circle cx="60" cy="45" r="19" stroke="#FFFFFF" strokeOpacity="0.35" strokeWidth="1.5" fill="none" />
          <circle cx="60" cy="45" r="7" fill={c3} />
          <circle cx="60" cy="45" r="2.5" fill="#FFFFFF" />
        </>
      )}
      {kind === 'app' && (
        <>
          <circle cx="96" cy="18" r="24" fill="#FFFFFF" fillOpacity="0.16" />
          {glyph && (
            <text
              x="60"
              y="55"
              textAnchor="middle"
              fill="#FFFFFF"
              fontSize="28"
              fontWeight="700"
              fontFamily="system-ui, sans-serif"
            >
              {glyph}
            </text>
          )}
        </>
      )}
    </svg>
  );
};
