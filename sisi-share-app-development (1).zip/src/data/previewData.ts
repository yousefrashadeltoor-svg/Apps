export type Locale = 'ar' | 'en';
export type ThemeMode = 'dark' | 'light';
export type DeviceFrame = 'phone' | 'tablet' | 'web';

export type ScreenId =
  | 'radar'
  | 'files'
  | 'apps'
  | 'readiness'
  | 'progress'
  | 'receive'
  | 'qr'
  | 'web'
  | 'watch'
  | 'history'
  | 'trust'
  | 'permissions'
  | 'settings'
  | 'system'
  | 'states'
  | 'blueprint';

export interface PeerDevice {
  id: string;
  aliasAr: string;
  aliasEn: string;
  model: string;
  ip: string;
  port: number;
  fingerprint: string;
  protocol: 'Nova v1 + LS v2.1' | 'LocalSend v2.1';
  band: '5 GHz' | '2.4 GHz' | 'Wi-Fi Direct';
  linkMbps: number;
  ceilingMbs: number;
  trusted: boolean;
  autoAccept: boolean;
  blocked: boolean;
  supportsSplitSession: boolean;
  accent: string;
  initials: string;
  seed: number;
  orbitAngle: number;
  orbitRadius: number; // 0.34 .. 0.82
  abi: string;
  dpi: string;
}

export type FileCategory =
  | 'photos'
  | 'videos'
  | 'music'
  | 'docs'
  | 'archives'
  | 'contacts'
  | 'downloads';

export interface SampleFileItem {
  id: string;
  category: FileCategory | string;
  name: string;
  subtitleAr: string;
  subtitleEn: string;
  sizeBytes: number;
  duration?: string;
  albumAr?: string;
  albumEn?: string;
  palette: [string, string, string];
  seed: number;
  codecInfo?: string;
}

export interface SampleAppItem {
  id: string;
  name: string;
  packageName: string;
  version: string;
  installed: boolean;
  isSystem: boolean;
  format: 'APK' | 'Split APK' | 'XAPK' | 'APKS' | 'APKM';
  baseSizeMb: number;
  filteredSplitMb: number;
  mergedSizeMb: number;
  hasObb: boolean;
  obbSizeMb?: number;
  signatureWarning?: boolean;
  splits: string[];
  palette: [string, string, string];
  glyph: string;
  seed: number;
}

export interface CustomFolderTab {
  id: string;
  labelAr: string;
  labelEn: string;
  uriPath: string;
  mode: 'SAF Persistable' | 'MANAGE_EXTERNAL_STORAGE';
  icon: 'folder' | 'camera' | 'code' | 'film';
}

export type PermState = 'granted' | 'partial' | 'not_requested' | 'denied' | 'permanently_denied';

export interface PermissionEntry {
  id: string;
  manifestName: string;
  apiScope: string;
  titleAr: string;
  titleEn: string;
  whyAr: string;
  whyEn: string;
  ifDeniedAr: string;
  ifDeniedEn: string;
  triggerAr: string;
  triggerEn: string;
  state: PermState;
  supportsPartial?: boolean;
  fullFlavorOnly?: boolean;
}

export const INITIAL_PEERS: PeerDevice[] = [
  {
    id: 'peer-s24',
    aliasAr: 'هاتف طارق · S24',
    aliasEn: 'Tariq · Galaxy S24',
    model: 'SM-S921B · Android 15',
    ip: '192.168.1.18',
    port: 53317,
    fingerprint: 'A9F4:C28E:71B0:9D3A:44E1:8C02',
    protocol: 'Nova v1 + LS v2.1',
    band: '5 GHz',
    linkMbps: 866,
    ceilingMbs: 68.4,
    trusted: true,
    autoAccept: true,
    blocked: false,
    supportsSplitSession: true,
    accent: '#2F7CF6',
    initials: 'ط',
    seed: 3,
    orbitAngle: -38,
    orbitRadius: 0.56,
    abi: 'arm64-v8a',
    dpi: 'xxhdpi (480)',
  },
  {
    id: 'peer-a20',
    aliasAr: 'جالكسي A20 · سلمى',
    aliasEn: 'Salma · Galaxy A20',
    model: 'SM-A205F · Android 11 (3GB)',
    ip: '192.168.1.27',
    port: 53317,
    fingerprint: '53D8:19FA:04C7:E821:6B90:31AF',
    protocol: 'Nova v1 + LS v2.1',
    band: '2.4 GHz',
    linkMbps: 72,
    ceilingMbs: 5.2,
    trusted: true,
    autoAccept: false,
    blocked: false,
    supportsSplitSession: true,
    accent: '#10B981',
    initials: 'س',
    seed: 7,
    orbitAngle: 42,
    orbitRadius: 0.66,
    abi: 'arm64-v8a',
    dpi: 'hdpi (280)',
  },
  {
    id: 'peer-tab',
    aliasAr: 'تابلت الاستوديو',
    aliasEn: 'Studio Pad Pro',
    model: 'Xiaomi Pad 6 · Android 14',
    ip: '192.168.49.4',
    port: 53317,
    fingerprint: 'C712:88B4:3F09:A15D:92E4:77C0',
    protocol: 'Nova v1 + LS v2.1',
    band: 'Wi-Fi Direct',
    linkMbps: 433,
    ceilingMbs: 34.2,
    trusted: false,
    autoAccept: false,
    blocked: false,
    supportsSplitSession: true,
    accent: '#F59E0B',
    initials: 'ت',
    seed: 11,
    orbitAngle: 148,
    orbitRadius: 0.62,
    abi: 'arm64-v8a',
    dpi: 'xhdpi (320)',
  },
  {
    id: 'peer-ls',
    aliasAr: 'لابتوب المكتب (LocalSend)',
    aliasEn: 'Desk ThinkPad (LocalSend)',
    model: 'Linux x86_64 · LocalSend 1.16',
    ip: '192.168.1.54',
    port: 53317,
    fingerprint: '8E20:4B11:DA65:09F3:1C78:5E4A',
    protocol: 'LocalSend v2.1',
    band: '5 GHz',
    linkMbps: 866,
    ceilingMbs: 52.0,
    trusted: false,
    autoAccept: false,
    blocked: false,
    supportsSplitSession: false,
    accent: '#6366F1',
    initials: 'LS',
    seed: 15,
    orbitAngle: 215,
    orbitRadius: 0.74,
    abi: 'x86_64',
    dpi: 'mdpi',
  },
  {
    id: 'peer-blocked',
    aliasAr: 'جهاز مجهول (قاعة عامة)',
    aliasEn: 'Unknown Device (Lobby)',
    model: 'Android 13',
    ip: '192.168.1.99',
    port: 53317,
    fingerprint: 'FF09:2D41:88AC:7E12:00B3:91DE',
    protocol: 'LocalSend v2.1',
    band: '2.4 GHz',
    linkMbps: 65,
    ceilingMbs: 4.5,
    trusted: false,
    autoAccept: false,
    blocked: true,
    supportsSplitSession: false,
    accent: '#EF4444',
    initials: '؟',
    seed: 19,
    orbitAngle: 90,
    orbitRadius: 0.8,
    abi: 'arm64-v8a',
    dpi: 'xhdpi',
  },
];

export const SAMPLE_FILES: SampleFileItem[] = [
  // Photos
  {
    id: 'img-1',
    category: 'photos',
    name: 'Wadi_Rum_GoldenHour_RAW.dng',
    subtitleAr: 'ألبوم الكاميرا · 4032×3024',
    subtitleEn: 'Camera · 4032×3024',
    sizeBytes: 28_400_000,
    albumAr: 'الكاميرا',
    albumEn: 'Camera',
    palette: ['#D97706', '#92400E', '#1E293B'],
    seed: 1,
  },
  {
    id: 'img-2',
    category: 'photos',
    name: 'RedSea_Coral_Dawn.jpg',
    subtitleAr: 'رحلة العقبة · 3840×2160',
    subtitleEn: 'Aqaba Trip · 3840×2160',
    sizeBytes: 6_800_000,
    albumAr: 'رحلة العقبة',
    albumEn: 'Aqaba Trip',
    palette: ['#0284C7', '#1D4ED8', '#0F172A'],
    seed: 2,
  },
  {
    id: 'img-3',
    category: 'photos',
    name: 'Amman_Citadel_Dusk.heic',
    subtitleAr: 'الكاميرا · HDR 10-bit',
    subtitleEn: 'Camera · HDR 10-bit',
    sizeBytes: 4_900_000,
    albumAr: 'الكاميرا',
    albumEn: 'Camera',
    palette: ['#4F46E5', '#7C3AED', '#1E1B4B'],
    seed: 3,
  },
  {
    id: 'img-4',
    category: 'photos',
    name: 'Olive_Grove_Morning.jpg',
    subtitleAr: 'الطبيعة · 4000×3000',
    subtitleEn: 'Nature · 4000×3000',
    sizeBytes: 5_300_000,
    albumAr: 'الطبيعة',
    albumEn: 'Nature',
    palette: ['#059669', '#0F766E', '#064E3B'],
    seed: 4,
  },
  // Videos
  {
    id: 'vid-1',
    category: 'videos',
    name: 'Desert_Odyssey_4K_HDR10.mkv',
    subtitleAr: '4K HEVC · صوت DTS-HD + ترجمة ASS عربية',
    subtitleEn: '4K HEVC · DTS-HD + Arabic ASS Subs',
    sizeBytes: 14_820_000_000,
    duration: '02:14:38',
    codecInfo: 'MKV · HEVC 10-bit · AC3/DTS · SRT+ASS',
    palette: ['#1E3A8A', '#B45309', '#090D16'],
    seed: 11,
  },
  {
    id: 'vid-2',
    category: 'videos',
    name: 'Drone_Coastline_60fps.mp4',
    subtitleAr: '1080p H.264 · AAC (مدعوم مباشرة بالمتصفح)',
    subtitleEn: '1080p H.264 · AAC (Direct Browser Range)',
    sizeBytes: 842_000_000,
    duration: '12:47',
    codecInfo: 'MP4 · H.264 · AAC-LC',
    palette: ['#0369A1', '#0E7490', '#0C1424'],
    seed: 12,
  },
  {
    id: 'vid-3',
    category: 'videos',
    name: 'Studio_Session_Cut.mkv',
    subtitleAr: '1440p H.264 · AC3 5.1',
    subtitleEn: '1440p H.264 · AC3 5.1',
    sizeBytes: 2_350_000_000,
    duration: '38:15',
    codecInfo: 'MKV · H.264 · AC3',
    palette: ['#6D28D9', '#1E40AF', '#0B0E14'],
    seed: 13,
  },
  // Music
  {
    id: 'mus-1',
    category: 'music',
    name: 'Oud_Nocturne_Live.flac',
    subtitleAr: 'ثلاثي المشرق · 24-bit / 96kHz',
    subtitleEn: 'Levant Trio · 24-bit / 96kHz',
    sizeBytes: 64_200_000,
    duration: '06:42',
    palette: ['#B45309', '#78350F', '#F59E0B'],
    seed: 21,
  },
  {
    id: 'mus-2',
    category: 'music',
    name: 'Midnight_Caravan.m4a',
    subtitleAr: 'ليالي البتراء · ألبوم صوتي',
    subtitleEn: 'Petra Nights · Acoustic',
    sizeBytes: 12_800_000,
    duration: '04:19',
    palette: ['#1D4ED8', '#1E3A8A', '#38BDF8'],
    seed: 22,
  },
  // Documents
  {
    id: 'doc-1',
    category: 'docs',
    name: 'Engineering_Architecture_v3.pdf',
    subtitleAr: 'مستند PDF · 84 صفحة',
    subtitleEn: 'PDF Document · 84 pages',
    sizeBytes: 18_400_000,
    palette: ['#DC2626', '#991B1B', '#450A0A'],
    seed: 31,
  },
  {
    id: 'doc-2',
    category: 'docs',
    name: 'Q3_Field_Survey_Dataset.xlsx',
    subtitleAr: 'جدول بيانات · محدّث اليوم',
    subtitleEn: 'Spreadsheet · Updated today',
    sizeBytes: 4_250_000,
    palette: ['#059669', '#065F46', '#022C22'],
    seed: 32,
  },
  // Archives
  {
    id: 'arc-1',
    category: 'archives',
    name: 'Camera_Backup_2026_02.zip',
    subtitleAr: 'أرشيف ZIP64 · 1,420 صورة (بدون إعادة ضغط)',
    subtitleEn: 'ZIP64 Archive · 1,420 photos (zero re-compress)',
    sizeBytes: 4_960_000_000,
    palette: ['#D97706', '#78350F', '#1C1917'],
    seed: 41,
  },
  {
    id: 'arc-2',
    category: 'archives',
    name: 'Offline_OSM_Maps_MENA.7z',
    subtitleAr: 'خرائط بدون إنترنت · 7-Zip',
    subtitleEn: 'Offline Maps · 7-Zip',
    sizeBytes: 1_280_000_000,
    palette: ['#475569', '#1E293B', '#0F172A'],
    seed: 42,
  },
  // Contacts
  {
    id: 'cnt-1',
    category: 'contacts',
    name: 'م. كريم النجار (vCard + صورة)',
    subtitleEn: 'Eng. Kareem Najjar (vCard + Photo)',
    subtitleAr: '+962 79 ••• 4810 · تصدير .vcf مع الصورة',
    sizeBytes: 48_000,
    palette: ['#2563EB', '#1E40AF', '#172554'],
    seed: 51,
  },
  {
    id: 'cnt-2',
    category: 'contacts',
    name: 'د. رنا الحسن (vCard + صورة)',
    subtitleAr: '+966 50 ••• 9120 · تصدير .vcf مع الصورة',
    subtitleEn: 'Dr. Rana Al-Hassan (vCard + Photo)',
    sizeBytes: 52_000,
    palette: ['#0D9488', '#115E59', '#042F2E'],
    seed: 52,
  },
  // Downloads (JOPRO default folder)
  {
    id: 'dl-1',
    category: 'downloads',
    name: 'Download/JOPRO/Videos/Lecture_04.mp4',
    subtitleAr: 'مستلم من هاتف طارق · BLAKE3 موثّق',
    subtitleEn: 'From Tariq S24 · BLAKE3 verified',
    sizeBytes: 312_000_000,
    palette: ['#2F7CF6', '#1D4ED8', '#0F172A'],
    seed: 61,
  },
  {
    id: 'dl-2',
    category: 'downloads',
    name: 'Download/JOPRO/Contacts/Team_24.vcf',
    subtitleAr: '24 جهة اتصال · جاهز للاستيراد بموافقتك',
    subtitleEn: '24 contacts · Ready to import on approval',
    sizeBytes: 410_000,
    palette: ['#10B981', '#047857', '#064E3B'],
    seed: 62,
  },
  // Custom SAF tab sample
  {
    id: 'saf-1',
    category: 'custom-raw',
    name: 'Project_Blueprints_CAD.dwg',
    subtitleAr: 'مجلد SAF دائم · قراءة عبر RawFd',
    subtitleEn: 'Persistable SAF · Zero-copy RawFd',
    sizeBytes: 94_500_000,
    palette: ['#0284C7', '#0369A1', '#082F49'],
    seed: 71,
  },
];

export const SAMPLE_APPS: SampleAppItem[] = [
  {
    id: 'app-1',
    name: 'OsmAnd~ Maps Offline',
    packageName: 'net.osmand.plus',
    version: '4.9.3',
    installed: true,
    isSystem: false,
    format: 'Split APK',
    baseSizeMb: 198,
    filteredSplitMb: 92,
    mergedSizeMb: 114,
    hasObb: false,
    signatureWarning: true,
    splits: ['base.apk', 'split_config.arm64_v8a.apk', 'split_config.xxhdpi.apk', 'split_config.ar.apk', 'split_config.en.apk'],
    palette: ['#F59E0B', '#D97706', '#78350F'],
    glyph: 'O',
    seed: 1,
  },
  {
    id: 'app-2',
    name: 'Krita Paint Studio',
    packageName: 'org.krita',
    version: '5.2.6',
    installed: true,
    isSystem: false,
    format: 'Split APK',
    baseSizeMb: 264,
    filteredSplitMb: 138,
    mergedSizeMb: 152,
    hasObb: false,
    signatureWarning: true,
    splits: ['base.apk', 'split_config.arm64_v8a.apk', 'split_config.hdpi.apk', 'split_config.ar.apk'],
    palette: ['#2563EB', '#7C3AED', '#1E1B4B'],
    glyph: 'K',
    seed: 2,
  },
  {
    id: 'app-3',
    name: 'AntennaPod Podcasts',
    packageName: 'de.danoeh.antennapod',
    version: '3.6.1',
    installed: true,
    isSystem: false,
    format: 'APK',
    baseSizeMb: 14.2,
    filteredSplitMb: 14.2,
    mergedSizeMb: 14.2,
    hasObb: false,
    splits: ['base.apk'],
    palette: ['#0284C7', '#0369A1', '#0C4A6E'],
    glyph: 'A',
    seed: 3,
  },
  {
    id: 'app-sys',
    name: 'حاسبة النظام (System)',
    packageName: 'com.android.calculator2',
    version: '15.0',
    installed: true,
    isSystem: true,
    format: 'APK',
    baseSizeMb: 4.8,
    filteredSplitMb: 4.8,
    mergedSizeMb: 4.8,
    hasObb: false,
    splits: ['base.apk'],
    palette: ['#475569', '#334155', '#0F172A'],
    glyph: '=',
    seed: 4,
  },
  {
    id: 'app-xapk-obb',
    name: 'Desert_Rally_Sim_2.4.xapk',
    packageName: 'dev.sim.desertrally',
    version: '2.4.0',
    installed: false,
    isSystem: false,
    format: 'XAPK',
    baseSizeMb: 168,
    filteredSplitMb: 112,
    mergedSizeMb: 118,
    hasObb: true,
    obbSizeMb: 1840,
    signatureWarning: true,
    splits: ['base.apk', 'split_config.arm64_v8a.apk', 'main.240.dev.sim.desertrally.obb'],
    palette: ['#DC2626', '#B45309', '#450A0A'],
    glyph: 'R',
    seed: 5,
  },
  {
    id: 'app-apks',
    name: 'LibreOffice_Viewer_24.8.apks',
    packageName: 'org.documentfoundation.libreoffice',
    version: '24.8.2',
    installed: false,
    isSystem: false,
    format: 'APKS',
    baseSizeMb: 142,
    filteredSplitMb: 78,
    mergedSizeMb: 84,
    hasObb: false,
    signatureWarning: true,
    splits: ['base.apk', 'split_config.arm64_v8a.apk', 'split_config.ar.apk'],
    palette: ['#059669', '#047857', '#064E3B'],
    glyph: 'L',
    seed: 6,
  },
];

export const INITIAL_PERMISSIONS: PermissionEntry[] = [
  {
    id: 'media',
    manifestName: 'READ_MEDIA_IMAGES / VIDEO / VISUAL_USER_SELECTED',
    apiScope: 'API 33+ (Partial API 34+)',
    titleAr: 'الصور والفيديو (دعم الوصول الجزئي)',
    titleEn: 'Photos & Videos (Partial Access Ready)',
    whyAr: 'لفهرسة ألبوماتك ومقاطع الفيديو داخل مدير الملفات المحلي دون نسخها.',
    whyEn: 'To index local albums and videos inside the File Manager without copying them.',
    ifDeniedAr: 'يبقى الاستقبال واختيار الملفات عبر منتقي النظام (SAF) وShare Target يعمل بالكامل.',
    ifDeniedEn: 'Receiving files, system SAF picker, and Share Target continue working normally.',
    triggerAr: 'عند فتح تبويب الصور أو الفيديو',
    triggerEn: 'When opening Photos or Videos tab',
    state: 'partial',
    supportsPartial: true,
  },
  {
    id: 'nearby',
    manifestName: 'NEARBY_WIFI_DEVICES (neverForLocation)',
    apiScope: 'API 33+ / FINE_LOCATION ≤32',
    titleAr: 'الأجهزة القريبة وWi-Fi Direct',
    titleEn: 'Nearby Wi-Fi Devices & Direct AP',
    whyAr: 'لإنشاء شبكة Wi-Fi Direct سريعة بدون راوتر أو تشغيل النقطة المحلية (لا نشتق موقعك الجغرافي أبدًا).',
    whyEn: 'To create a fast routerless Wi-Fi Direct group or LocalOnlyHotspot (never used for location).',
    ifDeniedAr: 'يستمر النقل والاكتشاف عبر الراوتر المحلي ورمز QR بشكل طبيعي.',
    ifDeniedEn: 'Same-router LAN transfer and QR connection continue normally.',
    triggerAr: 'عند تشغيل Wi-Fi Direct أو الهوتسبوت',
    triggerEn: 'When starting Wi-Fi Direct or Hotspot',
    state: 'granted',
  },
  {
    id: 'notif',
    manifestName: 'POST_NOTIFICATIONS',
    apiScope: 'API 33+',
    titleAr: 'إشعارات التقدم وطلبات الاستقبال',
    titleEn: 'Progress & Incoming Approval Alerts',
    whyAr: 'لعرض شريط التقدم الحقيقي وأزرار القبول/الرفض/الحظر الفورية في الخلفية.',
    whyEn: 'To show live progress bars and instant Accept/Reject/Block buttons in the background.',
    ifDeniedAr: 'يستمر النقل فعليًا مع شريط تنبيه وموافقة داخل شاشة التطبيق.',
    ifDeniedEn: 'Transfers continue working with in-app approval and progress banners.',
    triggerAr: 'عند بدء أول جلسة نقل (لا عند فتح التطبيق)',
    triggerEn: 'On first transfer (never on first app launch)',
    state: 'granted',
  },
  {
    id: 'camera',
    manifestName: 'CAMERA',
    apiScope: 'API 24+',
    titleAr: 'الكاميرا (قارئ QR بدون إنترنت)',
    titleEn: 'Camera (Offline QR Scanner)',
    whyAr: 'لمسح رمز اتصال الجهاز الآخر أو رمز شبكة Wi-Fi محليًا.',
    whyEn: 'To scan peer connection QR or Wi-Fi join QR completely offline.',
    ifDeniedAr: 'تبقى قراءة صورة QR من المعرض والإدخال اليدوي (IP:Port أو الكود) متاحة فورًا.',
    ifDeniedEn: 'Scan from gallery image and manual IP:Port / short code remain fully available.',
    triggerAr: 'عند الضغط على "مسح QR" فقط',
    triggerEn: 'Only when tapping "Scan QR"',
    state: 'not_requested',
  },
  {
    id: 'contacts_r',
    manifestName: 'READ_CONTACTS / WRITE_CONTACTS (منفصلتان)',
    apiScope: 'API 24+',
    titleAr: 'جهات الاتصال (قراءة للتصدير · كتابة للاستيراد)',
    titleEn: 'Contacts (Separate Read & Write)',
    whyAr: 'لتصدير الأسماء المحددة كملف .vcf مع الصور، أو استيراد ملف .vcf مستلم بموافقتك.',
    whyEn: 'To export selected contacts as .vcf with photos, or import received .vcf on confirmation.',
    ifDeniedAr: 'يعرض تبويب جهات الاتصال حالة فارغة هادئة مع زر تفعيل ولا يؤثر على بقية المدير.',
    ifDeniedEn: 'Contacts tab shows a clear empty state with an Enable action; rest of app unaffected.',
    triggerAr: 'عند فتح تبويب جهات الاتصال أو الضغط على استيراد .vcf',
    triggerEn: 'When opening Contacts tab or tapping Import .vcf',
    state: 'denied',
  },
  {
    id: 'install',
    manifestName: 'REQUEST_INSTALL_PACKAGES',
    apiScope: 'API 26+',
    titleAr: 'تثبيت التطبيقات وSplits المستلمة',
    titleEn: 'Install Received APKs & Splits',
    whyAr: 'لتشغيل PackageInstaller.Session وتثبيت حزم التطبيقات المستلمة مباشرة.',
    whyEn: 'To run PackageInstaller.Session for received APKs and multi-split bundles.',
    ifDeniedAr: 'تُحفَظ الحزم بأمان في Download/JOPRO/Apps ويمكن فتحها من مدير الملفات.',
    ifDeniedEn: 'Packages remain saved in Download/JOPRO/Apps for manual opening.',
    triggerAr: 'عند النقر على زر "تثبيت" لتطبيق مستلم',
    triggerEn: 'When tapping "Install" on a received app',
    state: 'not_requested',
  },
  {
    id: 'battery',
    manifestName: 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
    apiScope: 'API 24+ (اختياري)',
    titleAr: 'استثناء تحسين البطارية (اختياري)',
    titleEn: 'Unrestricted Background Battery (Optional)',
    whyAr: 'لمنع النظام من إيقاف نقل الملفات الضخمة (+20GB) عند إطفاء الشاشة لفترات طويلة.',
    whyEn: 'Prevents Doze from throttling massive (20GB+) transfers while the screen is off.',
    ifDeniedAr: 'تستمر الخدمة الأمامية ومهمة UIDT بالعمل مع استئناف المقاطع تلقائيًا.',
    ifDeniedEn: 'UIDT job and Foreground Service run normally with chunk-level auto-resume.',
    triggerAr: 'باختيار المستخدم من قائمة الجاهزية أو الإعدادات',
    triggerEn: 'Opt-in from Readiness Checklist or Settings',
    state: 'permanently_denied',
  },
  {
    id: 'all_files',
    manifestName: 'MANAGE_EXTERNAL_STORAGE',
    apiScope: 'نسخة full فقط · اختياري',
    titleAr: 'الوصول لكل الملفات (نسخة full فقط)',
    titleEn: 'All Files Access (`full` flavor only)',
    whyAr: 'مطلوبة فقط إذا أردت الحفظ في جذر /sdcard/JOPRO أو تصفح المدير الكامل عبر الويب.',
    whyEn: 'Only needed if you opt into root /sdcard/JOPRO or full Web Manager browsing.',
    ifDeniedAr: 'يعمل التطبيق بكامل قوته عبر Download/JOPRO (MediaStore) ومجلدات SAF الدائمة (متوافق مع Play).',
    ifDeniedEn: 'App works 100% via MediaStore Download/JOPRO and persistable SAF (Google Play compliant).',
    triggerAr: 'معطّلة افتراضيًا؛ لا توجد أصلًا في نكهة play',
    triggerEn: 'Disabled by default; completely omitted from `play` flavor',
    state: 'not_requested',
    fullFlavorOnly: true,
  },
];

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
