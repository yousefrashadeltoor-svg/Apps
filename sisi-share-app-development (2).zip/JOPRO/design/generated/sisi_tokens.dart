// Generated from design/tokens.json. Design reference only; not a native transfer implementation.
import 'dart:ui';
abstract final class SisiTokens {
  static const Color forest = Color(0xFF173E37);
  static const Color forestDeep = Color(0xFF10342E);
  static const Color primary = Color(0xFF25755C);
  static const Color mint = Color(0xFFD9EFDF);
  static const Color mintLight = Color(0xFFEEF7EF);
  static const Color coral = Color(0xFFEF896B);
  static const Color blue = Color(0xFF568CB8);
  static const Color sky = Color(0xFFE5EEF8);
  static const Color amber = Color(0xFFDBAD56);
  static const Color sand = Color(0xFFF5EBD7);
  static const Color canvas = Color(0xFFF6F8F7);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color ink = Color(0xFF203B33);
  static const Color muted = Color(0xFF69796D);
  static const Color line = Color(0xFFE7ECE8);
  static const Color danger = Color(0xFFC95750);
  static const Color warning = Color(0xFFA97923);
  static const Color success = Color(0xFF28795C);
  static const Color info = Color(0xFF427EA9);
  static const String arabicFont = 'IBM Plex Sans Arabic';
  static const String latinFont = 'Space Grotesk';
  static const double radiusSmall = 8;
  static const double radiusControl = 10;
  static const double radiusCard = 16;
  static const double radiusHero = 20;
  static const double radiusPill = 999;
  static const Duration fast = Duration(milliseconds: 160);
  static const Duration normal = Duration(milliseconds: 260);
  static const Duration slow = Duration(milliseconds: 480);
  static const Duration radar = Duration(milliseconds: 4200);
}
