import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {build} from 'esbuild';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const workspace=path.resolve(project,'..');
const tokens=JSON.parse(await fs.readFile(path.join(project,'design/tokens.json'),'utf8'));
const kebab=s=>s.replace(/[A-Z]/g,m=>'-'+m.toLowerCase());
const variables=object=>Object.entries(object).map(([key,value])=>`--${kebab(key)}:${typeof value==='number'&&!['body','small','title','hero'].includes(key)?value+'px':value};`).join('');
let css=`:root{${variables(tokens.colors)}--font-arabic:'${tokens.typography.arabic}',Tahoma,sans-serif;--font-latin:'${tokens.typography.latin}',var(--font-arabic);--radius-small:${tokens.radius.small}px;--radius-control:${tokens.radius.control}px;--radius-card:${tokens.radius.card}px;--radius-hero:${tokens.radius.hero}px;--radius-pill:${tokens.radius.pill}px;--shadow-card:${tokens.shadow.card};--shadow-float:${tokens.shadow.float};--sidebar-width:${tokens.layout.sidebar}px;--motion-speed:1;}\n:root[data-theme="dark"]{${variables(tokens.dark)}}\n`;
await fs.mkdir(path.join(project,'css'),{recursive:true});
await fs.writeFile(path.join(project,'css/tokens.css'),css);
const dartColor=hex=>'0xFF'+hex.slice(1).toUpperCase();
const dart=`// Generated from design/tokens.json. Design reference only; not a native transfer implementation.\nimport 'dart:ui';\nabstract final class SisiTokens {\n${Object.entries(tokens.colors).map(([k,v])=>`  static const Color ${k} = Color(${dartColor(v)});`).join('\n')}\n  static const String arabicFont = '${tokens.typography.arabic}';\n  static const String latinFont = '${tokens.typography.latin}';\n${Object.entries(tokens.radius).map(([k,v])=>`  static const double radius${k[0].toUpperCase()+k.slice(1)} = ${v};`).join('\n')}\n${Object.entries(tokens.motion).filter(([,v])=>typeof v==='number').map(([k,v])=>`  static const Duration ${k} = Duration(milliseconds: ${v});`).join('\n')}\n}\n`;
const colorsXml=`<?xml version="1.0" encoding="utf-8"?>\n<resources>\n${Object.entries(tokens.colors).map(([k,v])=>`  <color name="sisi_${kebab(k).replaceAll('-','_')}">${v}</color>`).join('\n')}\n</resources>\n`;
const dimensXml=`<?xml version="1.0" encoding="utf-8"?>\n<resources>\n${Object.entries(tokens.radius).map(([k,v])=>`  <dimen name="sisi_radius_${kebab(k)}">${v}dp</dimen>`).join('\n')}  <dimen name="sisi_touch_target">${tokens.layout.touch}dp</dimen>\n</resources>\n`;
await fs.mkdir(path.join(project,'design/generated'),{recursive:true});
await Promise.all([
 fs.writeFile(path.join(project,'design/generated/sisi_tokens.dart'),dart),
 fs.writeFile(path.join(project,'design/generated/colors.xml'),colorsXml),
 fs.writeFile(path.join(project,'design/generated/dimens.xml'),dimensXml)
]);
const fontSpecs=[
 ...[400,500,600,700].map(weight=>({family:'IBM Plex Sans Arabic',pkg:'ibm-plex-sans-arabic',subset:'arabic',weight,range:'U+0600-06FF,U+0750-077F,U+0870-089F,U+08A0-08FF,U+200C-200E,U+2010-2011,U+204F,U+2E41,U+FB50-FDFF,U+FE70-FEFF'})),
 ...[400,600].map(weight=>({family:'IBM Plex Sans Arabic',pkg:'ibm-plex-sans-arabic',subset:'latin',weight,range:'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD'})),
 ...[400,500,600,700].map(weight=>({family:'Space Grotesk',pkg:'space-grotesk',subset:'latin',weight}))
];
await fs.mkdir(path.join(project,'assets/fonts'),{recursive:true});
await fs.mkdir(path.join(project,'assets/licenses'),{recursive:true});
let fonts='';
for(const spec of fontSpecs){const name=`${spec.pkg}-${spec.subset}-${spec.weight}-normal.woff2`,source=path.join(workspace,'node_modules/@fontsource',spec.pkg,'files',name),bytes=await fs.readFile(source);await fs.writeFile(path.join(project,'assets/fonts',name),bytes);fonts+=`@font-face{font-family:'${spec.family}';font-style:normal;font-weight:${spec.weight};font-display:swap;src:url(data:font/woff2;base64,${bytes.toString('base64')}) format('woff2');${spec.range?'unicode-range:'+spec.range+';':''}}\n`;}
for(const pkg of ['ibm-plex-sans-arabic','space-grotesk','qrcode-generator','jsqr','lucide-react']){for(const name of ['LICENSE','LICENSE.md','OFL.txt']){try{const license=await fs.readFile(path.join(workspace,'node_modules',pkg,name),'utf8');await fs.writeFile(path.join(project,'assets/licenses',pkg+'-'+name+'.txt'),license);break}catch{}}}
const result=await build({entryPoints:[path.join(project,'js/preview.js')],bundle:true,write:false,format:'iife',platform:'browser',target:'es2020',minify:true,legalComments:'inline',logLevel:'warning'});
const bundle=result.outputFiles[0].text;
const previewCss=(await fs.readFile(path.join(project,'css/preview.css'),'utf8')).replace(/^@import[^\n]+\n/,'');
const mark='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="12" fill="#c4edce"/><g fill="none" stroke="#1c5340" stroke-linecap="round" stroke-linejoin="round"><path d="M11 15h16l-5-5m7 15H13l5 5" stroke-width="3.8"/><path d="m14 21 12-4" stroke-width="3.4"/></g></svg>';
await fs.writeFile(path.join(project,'assets/sisi-mark.svg'),mark);
const html=`<!doctype html>\n<html lang="ar" dir="rtl" data-theme="light">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n<meta name="theme-color" content="#173e37">\n<meta name="description" content="SISI Share — معاينة تصميم محلية ببيانات عيّنة. لا تنقل ملفات فعليًا.">\n<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; font-src data:; img-src data: blob:; connect-src 'none'; form-action 'none'; base-uri 'none'">\n<link rel="icon" href="data:image/svg+xml,${encodeURIComponent(mark)}">\n<title>SISI Share — معاينة التصميم</title>\n<style>${css}\n${fonts}\n${previewCss}</style>\n</head>\n<body>\n<div id="app"></div>\n<noscript><main style="padding:40px;font-family:Tahoma;direction:rtl"><h1>SISI Share</h1><p>معاينة تصميم · بيانات عيّنة · لا تنقل ملفات فعليًا</p><p>فعّل JavaScript لعرض المعاينة التفاعلية. لا يلزم الإنترنت أو الخادم.</p></main></noscript>\n<script>window.__SISI_DESIGN_TOKENS__=${JSON.stringify(tokens)};</script>\n<script>${bundle.replace(/<\/script/gi,'<\\/script')}</script>\n</body>\n</html>\n`;
await fs.writeFile(path.join(project,'index.html'),html);
console.log(`Built standalone JOPRO/index.html (${(Buffer.byteLength(html)/1024).toFixed(0)} KB). Fonts, SVG, QR and JavaScript are embedded. No network requests.`);
