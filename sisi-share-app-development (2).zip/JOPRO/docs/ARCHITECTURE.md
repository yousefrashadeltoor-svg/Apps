# المعمارية المختصرة — SISI Share

## التسليم الحالي: المرحلة 0 فقط
النواة وFlutter/Kotlin ليست مبنية أو مختبرة في هذا التسليم. المتاح معاينة تصميم مستقلة قابلة للتشغيل، والتوثيق المعماري للمراحل التالية. الالتزام بترتيب المستخدم يقتضي اعتماد التصميم قبل بناء التطبيق الأصلي. لا توجد ملفات APK أو مكتبات أصلية مزعومة.

## حدود الثقة المخططة
1. presentation: Flutter للهاتف والويب الحقيقي؛ Kotlin لـMediaStore/SAF/PackageInstaller/Wi-Fi/خدمات Android والويدجتس. واجهة المعاينة منفصلة تمامًا ولا تدخل assets الخاصة بالتطبيق.
2. bridge: flutter_rust_bridge ينقل أوامر وأحداثًا ومعرّفات وfds، وليس مخازن ملفات كبيرة. streams للأحداث، cancellation tokens للعمليات.
3. Rust core: بروتوكول LocalSend v2 القياسي، TLS وبصمات، اكتشاف متعدد الوسائط، مخطط نقل مقاطع قابل للاستئناف، BLAKE3، خادم HTTP/Range/WebSocket، امتدادات nova v1 بتفاوض القدرات.
4. storage: جلسات ومعلمات وموثوق/حظر وسجل في SQLite/Room؛ مفاتيح حساسة في Keystore حيث أمكن؛ ملفات مستقبلة ذرية في MediaStore أو SAF.

## مسارات النقل المخططة
MediaStore/content URI → ParcelFileDescriptor → fd مملوك لنواة Rust → pread/sendfile أو TLS streaming → مقاطع ثابتة → pwrite إلى ملف pending → تحقق BLAKE3 → نشر ذري → تسجيل الجلسة. لا يُحمّل ملف كامل إلى الذاكرة. توافق LocalSend يبقى مستقلًا عن الامتدادات؛ لا يُعلن نجاح دمج APK قبل التحقق من التوقيع والحزمة.

## الأحداث
نواة واحدة تصدر DeviceFound/ConsentRequired/TransferProgress/TransferCompleted/NetworkChanged/CapabilityChanged. طبقة Android وحدها تبدأ الخدمة وتدير الأقفال وUIDT according to documented eligibility. حدود سرعة تحديث الإشعارات والويدجتس ثانية واحدة، والسجل يحفظ نقاط الاستئناف. لا تبدأ معاينة الويب أي من هذه العمليات.

## قرارات يجب إثباتها قبل اعتمادها
- نقل LocalSend القياسي أولًا؛ التوازي والاستئنافextensions لا تُنسب للبروتوكول القياسي.
- دمج APK ليس concatenation. يلزم دمج manifest وموارد ومكتبات وتوقيع؛ الحفاظ على توقيع المطور الأصلي مستحيل عند إعادة توقيع ناتج جديد. تفضيل جلسة splits الأصلية عند وجود التطبيق.
- UIDT ليس بديلًا صالحًا لكل خدمة أو شبكة؛ اختيار connectedDevice أو UIDT يخضع للشروط الفعلية والاختبار، ولا يُستخدم لتجاوز سياسة النظام.
- ABC/apk/OBB/NFC/BLE/Wi-Fi Aware/Shizuku قدرات اختيارية قابلة للغياب، وتظهر بالمستوى الفعلي مع سبب واضح.

## المستودع المستهدف لاحقًا
core/ (Rust)، bridge/، app/ (Flutter + Kotlin android)، web_client/ (Flutter Web محلي)، design/، docs/، scripts/، معاينة الجذر. لا ننشئ هياكل فارغة أو واجهات API مزعومة في المرحلة 0.

## مراجع تم الرجوع إليها أثناء التصميم
- https://developer.android.com/develop/background-work/services/fgs/timeout
- https://developer.android.com/about/versions/15/behavior-changes-15
- https://developer.android.com/reference/android/net/wifi/WifiManager.LocalOnlyHotspotReservation
- https://github.com/kazuhikoarase/qrcode-generator
- https://github.com/cozmo/jsQR

التحقق المرجعي لا يعادل اختبار جهاز. مصفوفة Android والاختبارات الفعلية موثقة كغير منفذة في LIMITATIONS.md.