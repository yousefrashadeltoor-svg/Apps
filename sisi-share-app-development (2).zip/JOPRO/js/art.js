export const paths = {
  radar:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 12 19 5"/><circle cx="12" cy="12" r="1"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  folder:'<path d="M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>',
  send:'<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
  receive:'<path d="M12 3v12m-5-5 5 5 5-5"/><path d="M5 15v4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-4"/>',
  history:'<path d="M3 11a9 9 0 1 1 2.6 6.4M3 4v7h7"/><path d="M12 7v5l3 2"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a17 17 0 0 1 0 18 17 17 0 0 1 0-18"/>',
  play:'<path d="m8 4 12 8-12 8Z"/>',
  pause:'<path d="M8 5v14M16 5v14"/>',
  widgets:'<rect x="3" y="3" width="18" height="12" rx="2"/><rect x="3" y="18" width="7" height="3" rx="1"/><rect x="14" y="18" width="7" height="3" rx="1"/>',
  settings:'<path d="m9 3-1 3-3 1-2 3 2 2-1 3 3 3 3-1 2 2 3-1 1-3 3-1 1-3-3-2V5l-3-2-3 1Z"/><circle cx="12" cy="11" r="3"/>',
  sliders:'<path d="M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3M1 14h6m2-6h6m2 8h6"/>',
  shield:'<path d="M12 3 3 7v5c0 5 9 10 9 10s9-5 9-10V7Z"/><path d="m8 12 3 3 5-6"/>',
  lock:'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
  wifi:'<path d="M2 8a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0m-11 4a6 6 0 0 1 8 0"/><circle cx="12" cy="20" r=".7"/>',
  wifiOff:'<path d="m2 2 20 20M2 8a16 16 0 0 1 5-3m5-1a16 16 0 0 1 10 4M5 12a11 11 0 0 1 5-2m5 1 4 1m-11 4a6 6 0 0 1 8 0"/><circle cx="12" cy="20" r=".7"/>',
  phone:'<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 5h4m-3 14h2"/>',
  laptop:'<path d="M5 4h14a1 1 0 0 1 1 1v12H4V5a1 1 0 0 1 1-1ZM2 17h20l-1 4H3Z"/>',
  tablet:'<rect x="3" y="2" width="18" height="20" rx="3"/><path d="M11 18h2"/>',
  monitor:'<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M12 17v4m-5 0h10"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',
  arrowUp:'<path d="M7 17 17 7M7 7h10v10"/>',
  arrowDown:'<path d="M7 7 17 17M7 17h10V7"/>',
  chevron:'<path d="m9 5 7 7-7 7"/>',
  down:'<path d="m6 9 6 6 6-6"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  checkCircle:'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  x:'<path d="m6 6 12 12M6 18 18 6"/>',
  search:'<circle cx="10.5" cy="10.5" r="7.5"/><path d="m16 16 5 5"/>',
  bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9m-11 12a3 3 0 0 0 6 0"/>',
  moon:'<path d="M20.8 13A9 9 0 0 1 11 3.2 9 9 0 1 0 20.8 13Z"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
  languages:'<path d="M3 5h12M9 3v2m4 0c0 7-5 10-9 12m1-8c2 4 5 6 8 7m1 6 5-12 5 12m-8-4h6"/>',
  image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m21 15-5-5L5 21"/>',
  video:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="m10 8 6 4-6 4Z"/>',
  music:'<path d="M9 18V5l12-3v13M9 9l12-3"/><ellipse cx="6" cy="18" rx="3" ry="3"/><ellipse cx="18" cy="15" rx="3" ry="3"/>',
  file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8m-8 4h5"/>',
  archive:'<rect x="3" y="3" width="18" height="5" rx="1"/><path d="M5 8v13h14V8m-9 5h4"/>',
  app:'<rect x="3" y="3" width="18" height="18" rx="5"/><path d="m8 16 4-9 4 9m-7-3h6"/>',
  contacts:'<circle cx="9" cy="8" r="4"/><path d="M2 21v-2a7 7 0 0 1 14 0v2m2-17a4 4 0 0 1 0 8m2 4a5 5 0 0 1 2 5"/>',
  more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  list:'<path d="M8 5h13M8 12h13M8 19h13M3 5h.01M3 12h.01M3 19h.01"/>',
  filter:'<path d="M4 7h16M7 12h10m-7 5h4"/>',
  refresh:'<path d="M20 7a9 9 0 0 0-15-2L2 8m0-6v6h6m-4 9a9 9 0 0 0 15 2l3-3m0 6v-6h-6"/>',
  qr:'<rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="3" width="6" height="6" rx="1"/><rect x="3" y="15" width="6" height="6" rx="1"/><path d="M15 15h3v3h3v3h-6v-3m6-6h.01M12 3v3m0 6H3m9 0v3"/>',
  scan:'<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m8 0h3a2 2 0 0 0 2-2v-3M3 12h18"/>',
  copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
  download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
  trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
  edit:'<path d="m15 4 5 5M3 21l5-1L21 7a2 2 0 0 0-5-5L3 15Z"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
  alert:'<path d="m12 3 10 18H2Z"/><path d="M12 9v5m0 3h.01"/>',
  leaf:'<path d="M20 3C8 1 2 8 5 15s17 4 15-12Z"/><path d="M3 21 15 9"/>',
  activity:'<path d="M2 12h4l3-8 6 16 3-8h4"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  block:'<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  camera:'<path d="M8 5 6 8H3v13h18V8h-3l-2-3Z"/><circle cx="12" cy="14" r="4"/>',
  battery:'<rect x="2" y="6" width="18" height="12" rx="2"/><path d="M22 10v4M6 10v4m4-4v4m4-4v4"/>',
  network:'<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="16" y="16" width="6" height="6" rx="1"/><path d="M12 8v4M5 16v-4h14v4"/>',
  external:'<path d="M15 3h6v6m0-6L10 14m0-11H3v18h18v-7"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
  heart:'<path d="M20 5a5 5 0 0 0-8 1 5 5 0 0 0-8-1c-5 5 2 11 8 16 6-5 13-11 8-16Z"/>',
  cloudOff:'<path d="m2 2 20 20M6 8a6 6 0 0 1 10-3 6 6 0 0 1 3 7m1 2a4 4 0 0 1-1 7H6a4 4 0 0 1-3-7"/>',
  sparkle:'<path d="m12 3 3 6 6 3-6 3-3 6-3-6-6-3 6-3ZM21 2v4m-2-2h4"/>',
  link:'<path d="m10 13 4-4m-6 6-2 2a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0m2 2 2-2a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0" transform="translate(1 1)"/>',
  volume:'<path d="m11 4-6 5H2v6h3l6 5ZM15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
  expand:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m8 0h5v-5"/>',
  subtitles:'<rect x="2" y="4" width="20" height="16" rx="3"/><path d="M6 12h3m3 0h6M6 16h7m3 0h2"/>',
  grip:'<path d="M8 5h.01M16 5h.01M8 12h.01M16 12h.01M8 19h.01M16 19h.01"/>',
  undo:'<path d="M3 10h11a7 7 0 0 1 0 14M3 10l6-6m-6 6 6 6" transform="translate(0 -3)"/>',
  mail:'<rect x="2" y="4" width="20" height="16" rx="3"/><path d="m2 5 10 8L22 5"/>',
  bolt:'<path d="m13 2-9 12h7l-1 8 10-13h-8Z"/>',
  eye:'<path d="M2 12s4-8 10-8 10 8 10 8-4 8-10 8S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>'
};
export function icon(name, size=20, cls='') { return `<svg class="icon ${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.file}</svg>`; }
export function logo(size=35) { return `<svg width="${size}" height="${size}" viewBox="0 0 40 40" fill="none" aria-hidden="true"><rect width="40" height="40" rx="12" fill="#c4edce"/><path d="M11 15h16l-5-5m7 15H13l5 5" stroke="#1c5340" stroke-width="3.8" stroke-linecap="round" stroke-linejoin="round"/><path d="m14 21 12-4" stroke="#1c5340" stroke-width="3.4" stroke-linecap="round"/></svg>`; }
const palettes=[['#bfdacb','#5d947d','#275c4c','#f6dda3'],['#d9e5ee','#85adc4','#416b87','#fff2c4'],['#efd9bd','#c39971','#7b8061','#fff4cc'],['#d9d6e8','#a5a1bc','#636985','#fae4ba'],['#badad8','#529795','#235d62','#f6e7b5'],['#edcebf','#c28e78','#796e5b','#fff0bd']];
export function landscape(index=0, wide=false) {
 const p=palettes[index%palettes.length], w=wide?800:400, h=wide?420:280;
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="sky${index}" x2="0" y2="1"><stop stop-color="${p[0]}"/><stop offset="1" stop-color="${p[3]}"/></linearGradient></defs><rect width="${w}" height="${h}" fill="url(#sky${index})"/><circle cx="${w*.72}" cy="${h*.27}" r="${h*.12}" fill="${p[3]}"/><path d="M0 ${h*.7}Q${w*.17} ${h*.18} ${w*.36} ${h*.57}T${w*.7} ${h*.47}T${w} ${h*.55}V${h}H0Z" fill="${p[1]}" opacity=".6"/><path d="M0 ${h*.77} ${w*.35} ${h*.39} ${w*.67} ${h*.88} ${w} ${h*.52}V${h}H0Z" fill="${p[1]}"/><path d="M0 ${h*.87}Q${w*.2} ${h*.62} ${w*.47} ${h*.86}T${w} ${h*.73}V${h}H0Z" fill="${p[2]}"/><path d="M${w*.43} ${h}Q${w*.7} ${h*.85} ${w*.54} ${h*.77}Q${w*.43} ${h*.71} ${w*.58} ${h*.66}" fill="none" stroke="${p[3]}" stroke-width="${h*.022}" opacity=".7"/>${index%3===1?`<path d="M${w*.08} ${h*.68}h${w*.15}v${h*.32}h-${w*.15}Z" fill="${p[2]}"/><path d="m${w*.06} ${h*.68} ${w*.095}-${h*.13} ${w*.095} ${h*.13}Z" fill="${p[3]}"/>`:''}<g fill="${p[2]}" opacity=".65"><path d="m${w*.22} ${h*.2} 5 2 5-2-5 1Zm30 12 4 2 4-2-4 1Z"/></g></svg>`;
}
export function thumbnail(file, large=false) {
 const index=file.art||0;
 if(file.category==='photos'||file.category==='videos') return `<div class="thumb-art">${landscape(index)}${file.category==='videos'?`<span class="video-play">${icon('play',large?30:18)}</span><span class="duration">${file.duration||'02:34'}</span>`:''}</div>`;
 if(file.category==='music') return `<div class="album-art album-${index%6}"><div class="album-orbit"></div><span class="album-name">${['أصوات<br>الطبيعة','بعد<br>منتصف الليل','أيام<br>هادئة','رحلة<br>الصوت','موج','ذكريات'][index%6]}</span><small>THE LOCAL COLLECTION</small></div>`;
 if(file.category==='apps') return `<div class="app-art" style="--app-color:${['#739b7b','#d99973','#779ebd','#ac9dbe','#d2b46d','#73a8a0'][index%6]}">${icon(['leaf','camera','music','edit','archive','bolt'][index%6],large?64:36)}</div>`;
 if(file.category==='contacts') return `<div class="contact-art">${icon('contacts',large?70:38)}<span>vCard</span></div>`;
 return `<div class="file-art file-${file.category}">${icon(file.category==='archives'?'archive':'file',large?64:35)}<span>${(file.name.split('.').pop()||'FILE').toUpperCase()}</span></div>`;
}
export function avatar(name='أحمد', color='mint', size='normal', photo=true) {return `<span class="avatar avatar-${color} avatar-${size}">${photo?`<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M7 48c0-15 34-15 34 0" fill="currentColor" opacity=".65"/><ellipse cx="24" cy="21" rx="10" ry="12" fill="#eac4a3"/><path d="M14 22c-6-19 22-22 21-3-5 0-9-7-9-7s-2 8-12 10" fill="#3e493b"/><path d="M21 26q3 3 6 0" stroke="#956b56" fill="none" stroke-linecap="round"/></svg>`:name.slice(0,1)}</span>`;}
export function heroArtwork(){return `<svg class="hero-artwork" viewBox="0 0 460 290" fill="none" aria-hidden="true"><defs><linearGradient id="phone-screen" x2="1" y2="1"><stop stop-color="#edf7e6"/><stop offset="1" stop-color="#c6e3c9"/></linearGradient><linearGradient id="card-sky" x2="0" y2="1"><stop stop-color="#efc4a2"/><stop offset="1" stop-color="#f7e4c0"/></linearGradient><filter id="phone-shadow" x="-60%" y="-30%" width="240%" height="200%"><feDropShadow dx="4" dy="14" stdDeviation="9" flood-color="#315b42" flood-opacity=".19"/></filter><filter id="paper-shadow" x="-50%" y="-50%" width="200%" height="220%"><feDropShadow dx="0" dy="6" stdDeviation="5" flood-color="#315b42" flood-opacity=".12"/></filter></defs><ellipse cx="236" cy="256" rx="153" ry="15" fill="#7caa87" opacity=".12"/><g stroke="#78a88a" opacity=".26"><ellipse cx="231" cy="151" rx="189" ry="91" transform="rotate(-16 231 151)" stroke-dasharray="3 7"/><ellipse cx="234" cy="155" rx="139" ry="118" transform="rotate(21 234 155)"/><path d="M70 211c-49-90 107-194 239-158" stroke-dasharray="4 6"/></g><circle cx="68" cy="206" r="5" fill="#73a785"/><circle cx="368" cy="87" r="4" fill="#dcac6d"/><circle cx="202" cy="34" r="3" fill="#89b59b"/><g class="float-a"><g transform="translate(115 54) rotate(-14 57 101)" filter="url(#phone-shadow)"><rect width="116" height="204" rx="23" fill="#255746"/><rect x="5" y="5" width="106" height="194" rx="19" fill="url(#phone-screen)"/><rect x="41" y="11" width="34" height="6" rx="3" fill="#255746"/><text x="58" y="43" fill="#345e48" text-anchor="middle" font-size="10" font-family="sans-serif" font-weight="700">SISI SHARE</text><rect x="15" y="57" width="86" height="83" rx="10" fill="#7ca58a"/><circle cx="78" cy="78" r="10" fill="#f2d49c"/><path d="m15 119 29-43 34 45 12-16 11 16v9a10 10 0 0 1-10 10H25a10 10 0 0 1-10-10Z" fill="#49785b"/><path d="m15 128 27-25 36 37H25a10 10 0 0 1-10-10Z" fill="#315f45"/><rect x="23" y="152" width="69" height="5" rx="2.5" fill="#85ac8d"/><rect x="33" y="163" width="50" height="4" rx="2" fill="#a3c3a2"/><rect x="33" y="180" width="50" height="8" rx="4" fill="#367153"/></g></g><g class="float-b"><g transform="translate(252 39) rotate(13 57 105)" filter="url(#phone-shadow)"><rect width="119" height="211" rx="24" fill="#fafdf8" stroke="#c6d7c8" stroke-width="1.5"/><rect x="6" y="6" width="107" height="199" rx="19" fill="#f1f7ec"/><rect x="43" y="12" width="33" height="5" rx="2.5" fill="#315b43"/><circle cx="60" cy="77" r="29" fill="#d6e9ce"/><circle cx="60" cy="77" r="20" stroke="#8ab594" stroke-dasharray="2 4"/><path d="M48 73h24l-7-7m7 18H48l7 7" stroke="#387554" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><text x="60" y="126" fill="#345a41" text-anchor="middle" font-size="9" font-family="sans-serif" font-weight="700">A little closer.</text><rect x="26" y="139" width="67" height="4" rx="2" fill="#b8cdb2"/><rect x="36" y="149" width="47" height="4" rx="2" fill="#d1deca"/><rect x="20" y="173" width="79" height="18" rx="9" fill="#347252"/><text x="60" y="185" fill="#f3faec" text-anchor="middle" font-size="7" font-family="sans-serif">Send something good</text></g></g><g class="float-c"><g transform="translate(193 14) rotate(8)" filter="url(#paper-shadow)"><rect width="81" height="83" rx="10" fill="#fffdf9"/><rect x="6" y="6" width="69" height="57" rx="6" fill="url(#card-sky)"/><circle cx="58" cy="22" r="8" fill="#fff1b9"/><path d="m6 48 24-30 27 35 10-14 8 12v6a6 6 0 0 1-6 6H12a6 6 0 0 1-6-6Z" fill="#b48f72"/><path d="m6 57 20-19 28 25H12a6 6 0 0 1-6-6Z" fill="#897e60"/><rect x="8" y="70" width="37" height="3" rx="1.5" fill="#b9c7b6"/><circle cx="68" cy="71" r="3" fill="#72a17c"/></g></g><g class="float-b"><g transform="translate(70 157) rotate(-12)" filter="url(#paper-shadow)"><rect width="67" height="67" rx="13" fill="#fffefa"/><rect x="12" y="12" width="43" height="43" rx="10" fill="#e7eff5"/><path d="M27 22h10l7 7v17H27Z" stroke="#6a91ae" stroke-width="2" stroke-linejoin="round"/><path d="M36 22v8h8m-12 6h7m-7 5h5" stroke="#6a91ae" stroke-width="2"/></g></g><g class="float-a"><g transform="translate(350 176) rotate(12)" filter="url(#paper-shadow)"><rect width="62" height="62" rx="13" fill="#fffdf5"/><rect x="10" y="10" width="42" height="42" rx="10" fill="#f4e4c9"/><path d="M27 38V23l13-3v15m-13-7 13-3" stroke="#b79150" stroke-width="2"/><ellipse cx="24" cy="38" rx="4" ry="3" fill="#b79150"/><ellipse cx="37" cy="35" rx="4" ry="3" fill="#b79150"/></g></g><path d="M173 166c24 16 47 15 74-3" stroke="#528766" stroke-width="2" stroke-dasharray="4 5"/><path d="m240 162 9-2-3 9" stroke="#528766" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><g transform="translate(207 233)"><rect width="77" height="25" rx="12.5" fill="#fafff7" stroke="#d9e7d6"/><circle cx="14" cy="12.5" r="3" fill="#589875"/><text x="25" y="16" font-family="sans-serif" font-size="8" fill="#578166">Just nearby.</text></g><path d="M402 102v10m-5-5h10M51 117v7m-3.5-3.5h7" stroke="#91b49a" stroke-width="1.5" stroke-linecap="round"/></svg>`;}
export function qrSvg(text,size=180){const qr=window.qrcode(0,'M');qr.addData(text);qr.make();return qr.createSvgTag({cellSize:4,margin:16,scalable:true}).replace('<svg ',`<svg role="img" aria-label="QR: ${String(text).replace(/[<>&\"]/g,'')}" width="${size}" height="${size}" style="background:white;color:#173e37;max-width:100%" `);}
