import previewDocument from '../JOPRO/index.html?raw';

export default App;

/** The preview itself is standalone Vanilla HTML/CSS/JS. React only hosts it here. */
export function App() {
  return (
    <main className="fixed inset-0 h-dvh w-full overflow-hidden bg-[#f6f8f7]">
      <iframe
        title="SISI Share — معاينة التصميم المحلية، بيانات عيّنة"
        srcDoc={previewDocument}
        className="block h-full w-full border-0"
        allow="clipboard-write; fullscreen"
        allowFullScreen
      />
    </main>
  );
}
