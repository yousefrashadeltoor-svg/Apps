import { test, expect } from "@playwright/test";
import { pathToFileURL } from "node:url";
const url = pathToFileURL(`${process.cwd()}/JOPRO/index.html`).href;

test("all screens fit a narrow 320px viewport without horizontal content overflow", async ({
  page,
}) => {
  await page.setViewportSize({ width: 320, height: 900 });
  for (const screen of [
    "home",
    "files",
    "transfers",
    "history",
    "receive",
    "web",
    "watch",
    "qr",
    "apps",
    "settings",
    "permissions",
    "security",
    "gallery",
    "states",
    "system",
  ]) {
    await page.goto(`${url}#${screen}`);
    await expect(page.locator(`[data-screen="${screen}"]`)).toBeVisible();
    const size = await page
      .locator(".workspace")
      .evaluate((el) => ({ width: el.clientWidth, scroll: el.scrollWidth }));
    expect(size.scroll, screen).toBeLessThanOrEqual(size.width + 2);
  }
});

test("drag selects a contiguous group of sample files", async ({ page }) => {
  await page.goto(`${url}#files`);
  const first = await page.locator("[data-file]").nth(0).boundingBox(),
    third = await page.locator("[data-file]").nth(2).boundingBox();
  await page.mouse.move(first.x + first.width / 2, first.y + first.height / 2);
  await page.mouse.down();
  await page.mouse.move(third.x + third.width / 2, third.y + third.height / 2, {
    steps: 20,
  });
  await page.mouse.up();
  expect(
    await page.locator(".file-tile.selected").count(),
  ).toBeGreaterThanOrEqual(3);
});

test("thumbnail hero preview opens original local artwork", async ({
  page,
}) => {
  await page.goto(`${url}#files`);
  await page.locator("[data-file]").first().dblclick();
  await expect(page.locator(".hero-preview-target")).toBeVisible();
  await expect(page.locator('[role="dialog"]')).toContainText(
    "ليس ملفًا من جهازك",
  );
});
