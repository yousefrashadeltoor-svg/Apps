import { test, expect } from "@playwright/test";
import { pathToFileURL } from "node:url";
import { PNG } from "pngjs";
import jsQR from "jsqr";

const url = pathToFileURL(`${process.cwd()}/JOPRO/index.html`).href;
const action = (page, name) => page.locator(`[data-action="${name}"]`);
async function open(page, screen = "home") {
  await page.goto(`${url}#${screen}`);
  await expect(page.locator(`[data-screen="${screen}"]`)).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
}

test("standalone file preview works offline and makes zero remote requests", async ({
  page,
  context,
}) => {
  const remote = [];
  page.on("request", (r) => {
    if (/^https?:/.test(r.url())) remote.push(r.url());
  });
  await context.setOffline(true);
  await open(page);
  await expect(page.locator(".brand-type")).toHaveText("SISI Share");
  await expect(page.locator(".preview-warning")).toContainText(
    "لا تنقل ملفات فعليًا",
  );
  await expect(page.locator(".radar-device")).toHaveCount(3);
  expect(await page.evaluate(() => window.SisiPreview.designOnly)).toBe(true);
  expect(
    await page
      .locator('meta[http-equiv="Content-Security-Policy"]')
      .getAttribute("content"),
  ).toContain("connect-src 'none'");
  expect(remote).toEqual([]);
});

test("all fifteen screens are accessible from the screen explorer with no runtime errors", async ({
  page,
}) => {
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await open(page);
  const screens = [
    "files",
    "transfers",
    "history",
    "receive",
    "web",
    "watch",
    "qr",
    "apps",
    "settings",
    "permissions",
    "security",
    "gallery",
    "states",
    "system",
    "home",
  ];
  for (const screen of screens) {
    await page.locator('.preview-bar [data-action="explorer"]').click();
    await expect(page.locator('[role="dialog"]')).toBeVisible();
    await page.locator(`.explorer-grid [data-page="${screen}"]`).click();
    await expect(page.locator(`[data-screen="${screen}"]`)).toBeVisible();
  }
  expect(errors).toEqual([]);
});

test("file selection, search, sorting, view changes and every category work", async ({
  page,
}) => {
  await open(page, "files");
  await expect(page.locator("[data-file]")).toHaveCount(8);
  await page.locator("[data-file]").nth(0).click();
  await page.locator("[data-file]").nth(1).click();
  await expect(page.locator(".file-tile.selected")).toHaveCount(2);
  await action(page, "select-all").click();
  await expect(page.locator(".file-tile.selected")).toHaveCount(8);
  await action(page, "clear-selection").click();
  await expect(page.locator(".file-tile.selected")).toHaveCount(0);
  await page.locator("#file-search").fill("هدوء");
  await expect(page.locator("[data-file]")).toHaveCount(1);
  await page.locator("#file-search").fill("");
  await page.locator("#file-sort").selectOption("name");
  await action(page, "file-layout").click();
  await expect(page.locator("#file-grid")).toHaveClass(/file-list/);
  for (const cat of [
    "videos",
    "music",
    "documents",
    "archives",
    "apps",
    "contacts",
    "downloads",
    "custom",
  ]) {
    await page.locator(`[data-action="category"][data-value="${cat}"]`).click();
    expect(await page.locator("[data-file]").count()).toBeGreaterThan(0);
  }
});

test("custom folder is a named sample tab and does not request storage", async ({
  page,
}) => {
  await open(page, "files");
  await action(page, "custom-folder").click();
  await page.locator("#custom-folder-name").fill("تصاميمي");
  await action(page, "save-folder").click();
  await expect(page.locator(".custom-folder h3")).toHaveText("تصاميمي");
  await expect(page.locator(".toast")).toContainText("لم تُمنح أي صلاحية");
});

test("manual address validates without opening a network connection", async ({
  page,
}) => {
  await open(page);
  await action(page, "manual").click();
  await page.locator("#manual-address").fill("999.2.2.2:10");
  await action(page, "validate-manual").click();
  await expect(page.locator("#manual-error")).not.toBeEmpty();
  await page.locator("#manual-address").fill("192.168.1.12:53317");
  await page.locator("#manual-address").press("Enter");
  await expect(page.locator('[role="dialog"]')).toContainText(
    "لم يُفحص الاتصال",
  );
  await action(page, "manual-next").click();
  await expect(page.locator('[data-screen="transfers"]')).toBeVisible();
});

test("permission rationale supports partial access, denial and permanent denial", async ({
  page,
}) => {
  await open(page, "permissions");
  for (const value of ["granted", "denied", "permanent", "partial"]) {
    await page.locator('[data-action="permission"][data-key="media"]').click();
    await expect(page.locator('[role="dialog"]')).toContainText(
      "لا يظهر طلب إذن حقيقي",
    );
    await page
      .locator(`[data-action="permission-choice"][data-value="${value}"]`)
      .click();
  }
  await expect(page.locator(".permission-status").first()).toContainText(
    "وصول جزئي",
  );
});

test("multiple recipient transfers pause and cancel independently", async ({
  page,
}) => {
  await open(page, "transfers");
  await page.locator('[data-action="recipient"][data-id="iphone"]').click();
  await action(page, "start-transfer").click();
  await action(page, "confirm-start").click();
  await expect(page.locator("[data-transfer]")).toHaveCount(2);
  await page.locator('[data-action="pause-transfer"][data-id="mac"]').click();
  await expect(page.locator('[data-transfer-label="mac"]')).toContainText(
    "متوقف",
  );
  await expect(page.locator('[data-transfer-label="iphone"]')).toContainText(
    "جارٍ",
  );
  await page.locator('[data-action="cancel-transfer"][data-id="mac"]').click();
  await action(page, "confirm-cancel").click();
  await expect(page.locator("[data-transfer]")).toHaveCount(1);
  await expect(page.locator('[data-transfer="iphone"]')).toBeVisible();
});

test("consent updates trusted and blocked sample lists", async ({ page }) => {
  await open(page, "receive");
  await action(page, "consent-trust").click();
  await page.evaluate(() => (location.hash = "security"));
  await expect(page.locator(".security-list")).toContainText("iPhone 15");
  await page.evaluate(() => (location.hash = "receive"));
  await action(page, "reset-consent").click();
  await action(page, "consent-block").click();
  await page.evaluate(() => (location.hash = "security"));
  await page
    .locator('[data-action="security-tab"][data-value="blocked"]')
    .click();
  await expect(page.locator(".security-list")).toContainText("iPhone 15");
  await page
    .locator('[data-action="remove-security"][data-id="iphone"]')
    .click();
  await action(page, "confirm-remove-security").click();
  await expect(page.locator(".security-list")).not.toContainText("iPhone 15");
});

test("history filters, searches and clears only sample records", async ({
  page,
}) => {
  await open(page, "history");
  await page
    .locator('[data-action="history-filter"][data-value="failed"]')
    .click();
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await page.locator("#history-search").fill("does-not-exist");
  await expect(page.locator("tbody")).toContainText("لا توجد عمليات");
  await action(page, "clear-history").click();
  await action(page, "confirm-clear-history").click();
  await expect(page.locator("tbody")).toContainText("لا توجد عمليات");
});

test("generated QR independently decodes to the sample address", async ({
  page,
}) => {
  await open(page, "receive");
  const png = PNG.sync.read(await page.locator(".qr-wrap").screenshot());
  const result = jsQR(new Uint8ClampedArray(png.data), png.width, png.height);
  expect(result?.data).toBe("http://192.168.1.8:53317/?preview=design");
});

test("web design controls expose HTTP, HTTPS and manager limitations", async ({
  page,
}) => {
  await open(page, "web");
  await page.locator('[data-key="web"]').click();
  await expect(page.locator('[data-key="web"]')).toHaveAttribute(
    "aria-pressed",
    "true",
  );
  await page.locator("#web-protocol").selectOption("https");
  await expect(page.locator('[role="dialog"]')).toContainText("لم تُولّد شهادة");
  await action(page, "close-modal").first().click();
  await page.locator("#web-scope").selectOption("manager");
  await expect(page.locator('[role="dialog"]')).toContainText("/sdcard/JOPRO");
});

test("watch design plays, seeks, ends and returns without playing media", async ({
  page,
}) => {
  await open(page, "watch");
  await action(page, "watch-play").click();
  await expect(action(page, "watch-play")).toHaveAttribute(
    "aria-label",
    "إيقاف المعاينة",
  );
  await page.locator("#watch-seek").fill("65");
  expect(await page.locator("#watch-seek").inputValue()).toBe("65");
  await action(page, "end-watch").click();
  await action(page, "confirm-end-watch").click();
  await expect(page.locator(".empty-state")).toBeVisible();
  await action(page, "restart-watch").click();
  await expect(page.locator(".video-design")).toBeVisible();
  await expect(page.locator("video,audio")).toHaveCount(0);
});

test("notification and all five widget designs expose complete gallery states", async ({
  page,
}) => {
  await open(page, "gallery");
  await expect(page.locator(".notification")).toHaveCount(5);
  await action(page, "gallery-pause").click();
  await expect(page.locator(".notification").first()).toContainText(
    "متوقف مؤقتًا",
  );
  await page
    .locator('[data-action="gallery-tab"][data-value="widgets"]')
    .click();
  await expect(page.locator(".widget")).toHaveCount(5);
  for (const value of ["loading", "empty", "error"]) {
    await page.locator("#gallery-state").selectOption(value);
    await expect(page.locator(".widget-state")).toHaveCount(5);
  }
  await action(page, "widget-theme").click();
  await expect(page.locator('[data-widget-theme="dark"]')).toHaveCount(5);
});

test("language, theme, frames and reduced motion controls are functional", async ({
  page,
}) => {
  await open(page);
  await page.locator('.preview-bar [data-action="language"]').click();
  await expect(page.locator("html")).toHaveAttribute("dir", "ltr");
  await page.locator('.preview-bar [data-action="theme"]').click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.locator('[data-action="frame"][data-value="phone"]').click();
  expect(
    (await page.locator(".app-shell").boundingBox()).width,
  ).toBeLessThanOrEqual(412);
  await page.locator('[data-action="frame"][data-value="tablet"]').click();
  expect(
    (await page.locator(".app-shell").boundingBox()).width,
  ).toBeLessThanOrEqual(1024);
  await expect(page.locator("html")).toHaveAttribute("data-reduced", "true");
  expect(
    await page
      .locator(".ring-wave")
      .first()
      .evaluate((el) => getComputedStyle(el).animationName),
  ).toBe("none");
});

test("mobile layout keeps navigation and preview disclosure visible", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await open(page);
  const nav = await page.locator(".mobile-nav").boundingBox();
  const stage = await page.locator(".stage").boundingBox();
  expect(nav.y + nav.height).toBeLessThanOrEqual(stage.height + 1);
  expect(nav.y).toBeGreaterThan(0);
  await expect(page.locator(".preview-warning")).toBeVisible();
  await page.locator('.mobile-nav [data-page="files"]').click();
  await expect(page.locator('[data-screen="files"]')).toBeVisible();
});

test("dialog Escape and Tab trap keep keyboard focus accessible", async ({
  page,
}) => {
  await open(page);
  const trigger = action(page, "manual");
  await trigger.click();
  await page.locator('[data-action="validate-manual"]').focus();
  await page.keyboard.press("Tab");
  expect(
    await page.evaluate(
      () => !!document.activeElement.closest('[role="dialog"]'),
    ),
  ).toBe(true);
  await page.keyboard.press("Escape");
  await expect(page.locator('[role="dialog"]')).toHaveCount(0);
  await expect(trigger).toBeFocused();
});

test("React development host embeds the complete independent preview", async ({
  page,
}) => {
  await page.goto("http://localhost:5173");
  const frame = page.frameLocator("iframe.design-preview");
  await expect(frame.locator('[data-screen="home"]')).toBeVisible();
  await frame.locator('[data-action="choose-files"]').click();
  await expect(frame.locator('[data-screen="files"]')).toBeVisible();
});
