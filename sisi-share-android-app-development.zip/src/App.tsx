export default function App() {
  return (
    <iframe
      className="design-preview"
      src="./JOPRO/index.html"
      title="SISI Share - interactive design preview"
      allow="fullscreen"
    />
  );
}
