import { cp, mkdir } from "node:fs/promises";
await mkdir("public/JOPRO", { recursive: true });
for (const item of ["index.html", "css", "js", "assets"]) {
  await cp(`JOPRO/${item}`, `public/JOPRO/${item}`, { recursive: true });
}
console.log(
  "Standalone JOPRO preview synchronized to the React development host.",
);
