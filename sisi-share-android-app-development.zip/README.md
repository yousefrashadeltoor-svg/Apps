# SISI Share

Arabic-first, offline design preview for the planned local-sharing Android application.

**Phase 0 only. Sample data. No real transfers. No APK is implemented or claimed.**

Open [`JOPRO/index.html`](JOPRO/index.html) directly. Everything inside that document is vanilla HTML/CSS/JavaScript with local assets, and it needs neither a build nor a server. The React application in `src/App.tsx` is just a development host for the same independent preview, not a second implementation.

## Run and Verify

```sh
node JOPRO/scripts/build-preview.mjs
npm run dev
npx playwright test
node JOPRO/scripts/compare-screenshots.mjs
```

Playwright browser setup, only needed for development tests:

```sh
npx playwright install --with-deps chromium
```

After editing preview source, run `node scripts/sync-preview.mjs` to refresh the development host. Edit `JOPRO/design/tokens.json`, not generated CSS/XML/Dart references. Generate tokens using `node JOPRO/scripts/generate-tokens.mjs`.

## References

- [Architecture](JOPRO/docs/ARCHITECTURE.md)
- [Visual specification](JOPRO/design/design-spec.md)
- [Acceptance checklist](JOPRO/docs/ACCEPTANCE.md)
- [Executed test report](JOPRO/docs/TEST-REPORT.md)
- [Limits and unverified production features](JOPRO/docs/LIMITATIONS.md)
- [Visual report](JOPRO/docs/VISUAL-REPORT.md)

Approval of the design is required before Rust, Flutter, Kotlin or APK work begins. Preview files are intentionally separate from the future production build graphs.