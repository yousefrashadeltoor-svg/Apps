# SISI Share / JOPRO

هذه نسخة المرحلة 0 فقط: معاينة تصميم تفاعلية، ببيانات عيّنة، ولا تنقل ملفات فعليًا. افتح `index.html` مباشرة بالنقر المزدوج دون إنترنت أو خادم. يدعم الشريط السفلي تبديل العربية والإنجليزية، والمظهر، وإطار الجهاز، واستعراض جميع الشاشات. توقّف التنفيذ عند بوابة الموافقة البصرية؛ لم يُبنَ APK بعد.

## Phase 0: Visual Approval Required

**Design preview. Sample data. Does not transfer files.**

Open `index.html` by double-clicking. No server, CDN, installation or internet connection is required. Arabic/RTL is the default. The bottom preview bar changes language, theme, device frame and motion settings. The screen explorer opens every design surface, including permissions, error/empty states, Android notification designs and widget designs.

Files and devices are generated samples. Approving a request, starting a server, scanning, watching and transfer progress only demonstrate interface states. No system permission or network connection is requested. The preview is not included in any APK or real web-client build.

## Development Host

From the repository root:

```sh
node JOPRO/scripts/generate-tokens.mjs
node scripts/sync-preview.mjs
npm run dev
```

```sh
node scripts/sync-preview.mjs
npm run build
```

Or generate tokens, synchronize the host and build in one step:

```sh
node JOPRO/scripts/build-preview.mjs
```

## Checks

```sh
node JOPRO/scripts/generate-tokens.mjs
npx playwright test
```

See `design/design-spec.md`, `docs/ARCHITECTURE.md`, `docs/ACCEPTANCE.md` and `docs/LIMITATIONS.md`. Flutter golden comparison and APK builds intentionally wait for later phases. An APK has not been built or tested in phase 0.

## Local Third-Party Assets

- IBM Plex Sans Arabic: SIL Open Font License, IBM.
- Inter: SIL Open Font License, Rasmus Andersson.
- qrcode-generator: MIT license, Kazuhiko Arase.

License texts are included in `assets/licenses/`. All sample artwork and interface icons are locally authored SVGs. No protected photos, application logos, analytics or remote assets are used.