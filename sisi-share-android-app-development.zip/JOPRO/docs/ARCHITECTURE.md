# SISI Share: Phase 0 Architecture

## Scope and boundary

This delivery implements only phase 0, the offline visual contract. It is not an Android app, a LocalSend implementation, or the real browser client. No APK, transfer, discovery, permission request, service, codec support, or performance claim is represented as verified.

`index.html`, `css/`, `js/`, and `assets/` form an independent vanilla JavaScript application. Open `index.html` directly using `file://`. All UI sample data is declared in `js/app.js`. Its only persistent data is optional preview appearance in localStorage. The document CSP blocks all network connections. QR codes encode a plainly identified sample address and are generated offline with the vendored MIT-licensed qrcode-generator.

The repository-level React/Vite application is a development host that embeds this independent document. `scripts/sync-preview.mjs` copies only its public files into the host. The host is not required to open the standalone preview.

## Design source

`design/tokens.json` is the source of semantic palettes, typography, corner radii, spacing, motion, elevation, and shell sizes. `scripts/generate-tokens.mjs` creates CSS and design-reference Dart/XML outputs. These generated reference files are not an implemented Flutter theme or Android app.

## Planned production separation, subject to approval

- `core/`: Rust protocol, discovery, TLS, resumable streaming and security.
- `bridge/`: typed flutter_rust_bridge interface; file descriptors and identifiers rather than file payloads.
- `app/`: Flutter UI with Kotlin system integration and play/full flavors.
- `web_client/`: real, consent-gated Flutter Web client, embedded as offline assets.
- Preview code, sample assets and data are excluded from both production build graphs.

These production directories are intentionally not populated with nonfunctional scaffolding. Work on them starts only after visual approval.