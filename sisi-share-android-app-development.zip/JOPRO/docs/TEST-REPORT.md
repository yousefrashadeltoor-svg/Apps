# Phase 0 Verification Report

## Executed Environment

Linux x64 sandbox, Node.js 20.20.2, Playwright Chromium **159.0.8154.6**. These are actual browser tests, not Android device or emulator tests. Browser dependencies were installed for development; the delivered preview has no runtime network dependency.

## Results

| Check | Actual result |
| --- | --- |
| `npm run build` via `scripts/build-preview.mjs` | PASS: Vite production build |
| `npx tsc --noEmit` | PASS |
| `npx playwright test` | PASS: 20 tests, 0 failures, approximately 8 seconds |
| Standalone `JOPRO/index.html` with browser offline | PASS, zero HTTP/HTTPS requests |
| Built `dist/index.html` opened over `file://`, browser offline | PASS, embedded preview and file navigation work, zero HTTP/HTTPS requests |
| Arabic layout at 320px | PASS: all 15 screens without horizontal workspace overflow |
| Additional English 320px audit | PASS: all 15 screens, selected-file footer and widget gallery, no workspace overflow or runtime errors |
| QR independent decoding | PASS: jsQR decoded `http://192.168.1.8:53317/?preview=design` |
| Preview screenshots | PASS: four captures in `docs/screenshots/` |
| Flutter golden comparison | NOT VERIFIED: Flutter does not exist in phase 0 |
| APK / native Android tests | NOT RUN: waiting for visual approval |
| Device transfer benchmark / 60fps / battery / CPU | NOT RUN: not inferable from the preview |

## Automated Cases

1. Standalone preview works offline, with a visible warning and no remote requests.
2. All fifteen screens are reachable from the screen explorer without JavaScript errors.
3. File selection, all categories, search, sort and grid/list switching work.
4. Naming a custom sample folder adds a tab without requesting storage access.
5. Manual address validation handles invalid and valid input without a connection.
6. Permission rationale supports granted, denied, permanent and partial sample states.
7. Multiple recipient progress, pause and cancellation remain independent.
8. Consent updates trusted and blocked sample lists.
9. History search, filters and clearing affect sample records only.
10. The locally generated QR is independently decodable.
11. HTTP/HTTPS and file-manager web designs explain their real limitations.
12. Watching design controls play/pause, seek, end and reopen without media playback.
13. Five notifications and five widgets show normal, loading, empty and error states.
14. Language, theme, phone/tablet frames and reduced motion controls work.
15. Mobile navigation and the preview warning remain visible.
16. Dialog Tab trapping, Escape and focus restoration work.
17. React development host embeds the full standalone application.
18. All screens fit a narrow 320px Arabic viewport.
19. Pointer dragging selects a contiguous group of sample files.
20. Double-clicking a thumbnail opens the local illustration preview.

Raw machine-readable test output is available at repository-level `artifacts/test-results.json` after running the suite. Re-run tests after changes. The visual report intentionally refuses to invent Flutter matching results. No Android API behavior or native integration is certified by these tests.