# Limits and Verification Boundary

| Area | Delivered in phase 0 | Not claimed |
| --- | --- | --- |
| Preview | Offline vanilla HTML/CSS/JS, Arabic/English, responsive frames | Native Android UI |
| Devices and progress | Explicit sample data and UI animation | Discovery, actual throughput, transfers |
| Permissions | Explanations and preview-only UI states | Camera, contacts, storage or notifications access |
| QR | Locally encoded real QR of a sample address | A server listening at that address |
| Web and watching | Interactive screen designs | HTTP server, playback, codecs, synchronization |
| Widgets and notifications | Design gallery and states | Installed Android widgets or notifications |
| Tokens | CSS and Dart/XML design-reference generation | Tested Flutter or Android integration |
| Visual comparisons | Browser screenshots and test harness | Flutter goldens before Flutter exists |
| Android/APK/benchmarks | Not in phase-0 scope | APK assembly, device testing or MB/s claims |

`connect-src 'none'`, `media-src 'none'` and `form-action 'none'` prevent the preview from connecting, streaming or submitting. It does not request browser device permissions. The scan view is explicitly a design, never a camera feed. A preview switch changes only local in-memory state.

File URLs and localStorage availability vary by browser. All essential interactions work if localStorage is unavailable. Motion can be reduced using either OS preferences or preview settings. Clipboard availability is not assumed; sample links can always be selected manually.

All Android API requirements, capability ladders, flavors, publishing policy, Android version matrices and hardware benchmarks remain unverified until their implementation phases. No simulated Android result will be substituted for a real test. Galaxy A20 Wi-Fi capabilities must be verified for the exact device variant, not inferred from the preview.