# Visual Comparison Report

Preview captures are real browser output. Flutter comparison is only possible with real Flutter goldens.

Browser: 159.0.8154.6

| Capture | Preview | Flutter comparison |
| --- | --- | --- |
| desktop-home | Captured | NOT VERIFIED: Flutter is not implemented in phase 0 |
| phone-home | Captured | NOT VERIFIED: Flutter is not implemented in phase 0 |
| desktop-files | Captured | NOT VERIFIED: Flutter is not implemented in phase 0 |
| desktop-gallery | Captured | NOT VERIFIED: Flutter is not implemented in phase 0 |

No Android screenshot, native test, benchmark or APK result is implied.
