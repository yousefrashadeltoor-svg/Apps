# Phase 0 Acceptance

## Delivered

- [x] Independent `JOPRO/index.html`, vanilla JavaScript and CSS, opens over `file://`.
- [x] Permanent design/sample/no-transfer notice, including small screens.
- [x] Arabic RTL and English LTR, light/dark, desktop/tablet/phone frames.
- [x] Fifteen navigable design screens and the screen explorer.
- [x] Nine file categories, installed/package apps, custom-folder naming, search, sort, list/grid and multiple selection.
- [x] Sample readiness, multiple recipients, independent pause/cancel, consent and fingerprint-list design states.
- [x] Permission explanations and allowed/denied/permanent/partial UI states; no real permission request.
- [x] Real local QR generation, independently decoded by jsQR in tests.
- [x] Five Android-inspired notifications and five widget designs, including loading/empty/error and both widget themes.
- [x] Network/storage/background/helper/browser limitations visible in the design, not hidden fallbacks.
- [x] Locally bundled fonts, SVG artwork, icons, QR encoder and license texts. No runtime CDN.
- [x] Network and media connections blocked by the preview CSP.
- [x] Reduced motion, low-power controls, animation speed, radar/progress/page/dialog motion and thumbnail expansion.
- [x] Keyboard focus visibility, dialog focus trap, Escape and focus restoration.
- [x] Tokens generate CSS and Dart/XML design references.
- [x] Browser screenshot capture and a real optional pixel-comparison script.

## Test Boundary

The executed automated test result is recorded in `TEST-REPORT.md`. Browser tests are not native Android tests. Simulated frames are CSS layouts, not Android emulators. No 60fps, device thermal, battery, transfer-throughput or TalkBack claim is made from browser automation.

The 48px app-action target is reflected in the web styles; the compact desktop preview toolbar is an authoring tool, not the future Android interface. Native dp sizing, scaling, accessibility and dynamic system colors require later device testing.

## Approval Gate

- [ ] Owner approval of the visual design.
- [ ] Flutter/Android implementation and golden screenshots.
- [ ] Actual APK release assembly and signing.
- [ ] Native permissions, notifications, services, widgets and sharing integration.
- [ ] LocalSend compatibility, security and transfer integration tests.
- [ ] Real-device performance, storage stress and multi-recipient benchmarks.

## Android Matrix

| Android | API | Phase 0 result |
| --- | --- | --- |
| 7 | 24 | NOT TESTED: native app not implemented |
| 10 | 29 | NOT TESTED: native app not implemented |
| 12 | 31 | NOT TESTED: native app not implemented |
| 13 | 33 | NOT TESTED: native app not implemented |
| 14 | 34 | NOT TESTED: native app not implemented |
| 15 | 35 | NOT TESTED: native app not implemented |

This matrix is intentionally not filled with invented successes. Implementation stops at phase 0 until visual approval.