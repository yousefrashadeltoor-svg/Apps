/* This document is a design preview. All devices, files and progress are samples. */
(() => {
  "use strict";

  const root = document.getElementById("preview-root");
  const safe = (value) =>
    String(value).replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
  let saved = {};
  try {
    saved = JSON.parse(localStorage.getItem("sisi-preview-appearance") || "{}");
  } catch {
    /* Storage is optional under file://. */
  }
  const state = {
    page: "home",
    lang: saved.lang === "en" ? "en" : "ar",
    theme: saved.theme === "dark" ? "dark" : "light",
    frame: "desktop",
    reduced: matchMedia("(prefers-reduced-motion: reduce)").matches,
    low: false,
    speed: 1,
    scanning: true,
    visible: true,
    fileCategory: "images",
    selected: new Set(),
    textSize: 0,
    search: "",
    fileLayout: "grid",
    sort: "newest",
    appTab: "installed",
    customName: "",
    recipients: new Set(["mac"]),
    transferDevices: ["mac"],
    paused: new Set(),
    cancelled: new Set(),
    progress: 64,
    transferTab: "active",
    historyFilter: "all",
    historySearch: "",
    historyRemoved: false,
    web: false,
    webProtocol: "http",
    webScope: "selected",
    webUpload: false,
    pin: false,
    watchPlaying: false,
    watchEnded: false,
    watchPosition: 36,
    watchControl: "host",
    qrTab: "scan",
    torch: false,
    gallery: "notifications",
    galleryState: "normal",
    galleryTheme: "light",
    securityTab: "trusted",
    trusted: new Set(["mac", "tab"]),
    blocked: new Set(["unknown"]),
    errorState: "devices",
    name: "أحمد محمد",
    deviceName: "Galaxy S24",
    permissions: {
      media: "partial",
      notifications: "denied",
      nearby: "granted",
      camera: "denied",
      contacts: "denied",
      storage: "denied",
      battery: "denied",
    },
    settings: {
      encryption: true,
      integrity: true,
      organize: true,
      autoAccept: false,
      widgetNames: false,
      lockPrivacy: true,
      helper: false,
      idle: true,
    },
  };
  const t = (ar, en) => (state.lang === "ar" ? ar : en);
  const paths = {
    home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    folder:
      '<path d="M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/><path d="M3 9h18"/>',
    transfer: '<path d="M4 7h15m-4-4 4 4-4 4M20 17H5m4 4-4-4 4-4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    download: '<path d="M12 3v12m-4-4 4 4 4-4M4 16v4h16v-4"/>',
    upload: '<path d="M12 16V4m-4 4 4-4 4 4M4 16v4h16v-4"/>',
    globe:
      '<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
    play: '<path d="m9 5 11 7-11 7z"/>',
    pause: '<path d="M9 5v14M15 5v14"/>',
    video:
      '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m10 9 5 3-5 3z"/>',
    settings:
      '<path d="m9 3-1 3-3 1-1 4 2 2-1 3 3 3 3-1 2 2 4-1 1-3 3-1v-4l-3-1-1-3-4-1-2 2-3-1Z"/><circle cx="12" cy="12" r="3"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 8.5a2.6 2.6 0 1 1 4 2.2c-1 .6-1.5 1-1.5 2.3M12 17h.01"/>',
    shield:
      '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6z"/><path d="m8 12 3 3 5-6"/>',
    lock: '<rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
    laptop:
      '<rect x="5" y="4" width="14" height="12" rx="1.5"/><path d="m5 16-3 4h20l-3-4M10 18h4"/>',
    phone:
      '<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 5h4M11 19h2"/>',
    tablet:
      '<rect x="4" y="2" width="16" height="20" rx="3"/><path d="M11 18h2"/>',
    monitor:
      '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M12 17v4m-4 0h8"/>',
    bell: '<path d="M6 9a6 6 0 0 1 12 0c0 7 3 7 3 8H3c0-1 3-1 3-8m4 12h4"/>',
    chevron: '<path d="m9 5 7 7-7 7"/>',
    down: '<path d="m6 9 6 6 6-6"/>',
    left: '<path d="M19 12H5m6 6-6-6 6-6"/>',
    arrow: '<path d="M7 17 17 7M7 7h10v10"/>',
    qr: '<rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="3" width="6" height="6" rx="1"/><rect x="3" y="15" width="6" height="6" rx="1"/><path d="M15 15h3v3h3m-6 3h3m3-9v3M12 3v3m0 6h3M3 12h4m5 3v6"/>',
    wifi: '<path d="M2 8a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0m-11 4a6 6 0 0 1 8 0m-4 4h.01"/>',
    refresh: '<path d="M20 7V3l-3 3a8 8 0 1 0 3 9M20 3h-5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    text: '<path d="M4 5h16M12 5v15M8 20h8"/>',
    link: '<path d="m10 13 4-4M8 15l-1 1a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0m0 4 1-1a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0" transform="translate(2 1)"/>',
    file: '<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9l-7-7Zm0 0v7h7M8 14h8m-8 4h5"/>',
    image:
      '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m3 16 5-5 4 4 4-6 5 7"/>',
    music:
      '<path d="M9 18V5l11-2v13M9 8l11-2"/><ellipse cx="6" cy="18" rx="3" ry="3"/><ellipse cx="17" cy="16" rx="3" ry="3"/>',
    archive:
      '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M10 3v3h3v3h-3v3h3v3m-3 0h3v4h-3z"/>',
    apps: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    contacts:
      '<rect x="4" y="3" width="16" height="18" rx="3"/><circle cx="12" cy="9" r="2.5"/><path d="M8 17c0-4 8-4 8 0M2 7h3m-3 5h3m-3 5h3"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    checkCircle: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    close: '<path d="m6 6 12 12M6 18 18 6"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1"/>',
    moon: '<path d="M20 15A9 9 0 0 1 9 4 9 9 0 1 0 20 15Z"/>',
    sliders:
      '<path d="M4 4v4m0 6v6m8-16v10m0 6v-2m8-14v2m0 6v8M1 8h6m2 10h6m2-12h6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
    warning: '<path d="m12 3 10 18H2L12 3Z"/><path d="M12 9v5m0 3h.01"/>',
    power: '<path d="M12 2v10M7 5a9 9 0 1 0 10 0"/>',
    copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
    users:
      '<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3m1-16a3 3 0 0 1 0 6m3 3a5 5 0 0 1 3 5v2"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    trash: '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
    block: '<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>',
    camera:
      '<path d="M3 7h4l2-3h6l2 3h4v14H3Z"/><circle cx="12" cy="13" r="4"/>',
    flash: '<path d="m13 2-9 12h7l-1 8L21 9h-8z"/>',
    battery:
      '<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M23 10v4M6 10v4m4-4v4m4-4v4"/>',
    storage:
      '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 4 16 4 16 0V5M4 12c0 4 16 4 16 0"/>',
    volume:
      '<path d="m11 4-6 5H2v6h3l6 5V4Zm5 4a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
    expand: '<path d="M8 3H3v5m13-5h5v5M3 16v5h5m8 0h5v-5"/>',
    fingerprint:
      '<path d="M4 10a8 8 0 0 1 16 0m-12 9c1-2 0-5 0-8a4 4 0 1 1 8 0c0 4 0 7 2 9M4 14v3m8-6c0 5 1 9 2 11m-2-5-1 5m9-8v3"/>',
    send: '<path d="m22 2-7 20-4-9-9-4L22 2ZM11 13 22 2"/>',
    exit: '<path d="M9 4H3v16h6m7-13 5 5-5 5M8 12h13"/>',
    sort: '<path d="M4 6h16M4 12h11M4 18h6"/>',
    edit: '<path d="m15 4 5 5M3 21l5-1L21 7l-5-5L3 15v6Z"/>',
  };
  const icon = (name, cls = "") =>
    `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.file}</svg>`;
  const mark = () =>
    '<svg viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M8 16h19l-6-6m11 14H13l6 6" stroke="currentColor" stroke-width="3.3" stroke-linecap="round" stroke-linejoin="round"/><path d="m8 16 6 6m18 2-6-6" stroke="currentColor" stroke-width="3.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const brand = () => `<span class="brand-symbol">${mark()}</span>`;
  const btn = (action, label, kind = "secondary", symbol = "", extra = "") =>
    `<button class="btn ${kind}" data-action="${action}" ${extra}>${symbol ? icon(symbol) : ""}<span>${label}</span></button>`;
  const switcher = (key, on, label, extra = "") =>
    `<button class="switch ${on ? "on" : ""}" data-action="toggle" data-key="${key}" aria-label="${safe(label)}" aria-pressed="${on}" ${extra}></button>`;
  const qrSvg = () => {
    const code = window.qrcode(0, "M");
    code.addData("http://192.168.1.8:53317/?preview=design");
    code.make();
    return code.createSvgTag({
      cellSize: 4,
      margin: 8,
      scalable: true,
      alt: "Sample local address QR",
    });
  };
  const devices = [
    {
      id: "mac",
      name: "MacBook Pro",
      owner: ["ماك بوك أحمد", "Ahmed’s MacBook"],
      type: "laptop",
      color: "",
      os: "macOS",
      ip: "192.168.1.12",
    },
    {
      id: "iphone",
      name: "iPhone 15",
      owner: ["آيفون سارة", "Sara’s iPhone"],
      type: "phone",
      color: "purple",
      os: "iOS",
      ip: "192.168.1.14",
    },
    {
      id: "tab",
      name: "Galaxy Tab S9",
      owner: ["تابلت العائلة", "Family tablet"],
      type: "tablet",
      color: "green",
      os: "Android",
      ip: "192.168.1.16",
    },
  ];
  const device = (id) => devices.find((d) => d.id === id) || devices[0];
  const availableDevices = () =>
    devices.filter((d) => !state.blocked.has(d.id));
  const owner = (d) => t(...d.owner);
  const screens = () => [
    ["home", "home", t("الرئيسية", "Overview")],
    ["files", "folder", t("ملفاتي", "My files")],
    ["transfers", "transfer", t("عمليات النقل", "Transfers")],
    ["history", "clock", t("السجل", "History")],
    ["receive", "download", t("الاستقبال", "Receive")],
    ["web", "globe", t("مشاركة الويب", "Web sharing")],
    ["watch", "video", t("المشاهدة المشتركة", "Watch together")],
    ["qr", "qr", t("رمز QR", "QR connection")],
    ["apps", "apps", t("التطبيقات", "Applications")],
    ["settings", "settings", t("الإعدادات", "Settings")],
    ["permissions", "shield", t("الأذونات", "Permissions")],
    ["security", "fingerprint", t("الموثوقون والحظر", "Trusted & blocked")],
    ["gallery", "grid", t("الإشعارات والويدجتس", "Notifications & widgets")],
    ["states", "warning", t("الحالات والأخطاء", "Empty & error states")],
    ["system", "sliders", t("حالة النظام", "System capabilities")],
  ];
  const currentScreen = () =>
    screens().find((s) => s[0] === state.page) || screens()[0];
  const intro = (title, subtitle, actions = "", cls = "") =>
    `<div class="page-intro ${cls}"><div><h1 id="page-title">${title}</h1><p>${subtitle}</p></div>${actions ? `<div class="intro-actions">${actions}</div>` : ""}</div>`;
  const footer = () =>
    `<p class="workspace-foot">${icon("lock")}${t("بين أجهزتك فقط. لا سحابة، لا حدود.", "Only between your devices. No cloud, no detours.")}</p>`;
  function navigation() {
    const navItem = ([id, symbol, label]) =>
      `<button class="nav-item ${state.page === id ? "active" : ""}" data-page="${id}" ${state.page === id ? 'aria-current="page"' : ""}>${icon(symbol)}<span>${label}</span>${id === "transfers" && state.transferDevices.some((id) => !state.cancelled.has(id)) ? '<span class="nav-badge">1</span>' : ""}</button>`;
    const nav = screens();
    return `<aside class="sidebar"><button class="brand" data-page="home" aria-label="SISI Share"><span class="brand-type">SISI <span>Share</span></span>${brand()}</button><p class="brand-caption">${t("قريب منك. أسرع لك.", "A little closer. A lot faster.")}</p><nav aria-label="${t("القائمة الرئيسية", "Main navigation")}"><div class="nav-group">${nav.slice(0, 4).map(navItem).join("")}</div><p class="nav-label">${t("مساحة المشاركة", "YOUR SHARED SPACE")}</p><div class="nav-group">${nav.slice(4, 7).map(navItem).join("")}</div></nav><div class="sidebar-bottom"><div class="nav-group">${navItem(nav.find((n) => n[0] === "settings"))}<button class="nav-item" data-action="explorer">${icon("grid")}<span>${t("استعراض الشاشات", "Screen explorer")}</span></button></div><div class="privacy-note">${icon("shield")}<div><strong>${t("محلي تمامًا. خاص دائمًا.", "Always local. Always yours.")}</strong><p>${t("لا حسابات. لا إعلانات. لا تتبّع.", "No accounts. No ads. No tracking.")}</p></div></div><button class="my-device" data-action="profile"><span class="avatar blue">${icon("phone")}</span><div><b class="latin">${safe(state.deviceName)}</b><p><span class="dot"></span> ${t("هذا الجهاز", "This device")} <bdi>192.168.1.8</bdi></p></div>${icon("more")}</button></div></aside>`;
  }
  function topbar() {
    const screen = currentScreen();
    return `<header class="topbar"><div class="breadcrumb">${icon(screen[1])}<span>${screen[2]}</span><small>/ &nbsp; ${t("مساحتك القريبة", "Your local space")}</small></div><div class="header-actions"><button class="network-status" data-page="system">${icon("wifi")}<span>${t("متصل بشبكتك المحلية", "On your local network")}</span><span class="dot"></span></button><span class="header-divider"></span><button class="icon-btn notification-btn" data-action="notifications" aria-label="${t("الإشعارات", "Notifications")}">${icon("bell")}</button><button class="profile-button" data-action="profile"><span class="avatar">${t("أ", "A")}</span><strong>${safe(state.lang === "ar" ? state.name : "Ahmed Mohamed")}</strong>${icon("down")}</button></div></header>`;
  }
  function previewbar() {
    return `<div class="preview-bar"><div class="preview-warning">${icon("info")}<span class="preview-label">${t("معاينة تصميم", "Design preview")}</span><span>·</span><span>${t("بيانات عيّنة · لا تنقل ملفات فعليًا", "Sample data · No actual file transfers")}</span></div><div class="preview-controls"><button class="explorer-button" data-action="explorer">${icon("grid")}<span>${t("استعراض الشاشات", "Explore screens")}</span></button><span class="control-divider"></span><div class="device-control" aria-label="${t("إطار الجهاز", "Device frame")}">${[
      ["phone", "phone"],
      ["tablet", "tablet"],
      ["desktop", "monitor"],
    ]
      .map(
        ([id, i]) =>
          `<button class="${state.frame === id ? "active" : ""}" data-action="frame" data-value="${id}" aria-label="${id}" aria-pressed="${state.frame === id}">${icon(i)}</button>`,
      )
      .join(
        "",
      )}</div><span class="control-divider"></span><button class="language-control" data-action="language">${icon("globe")}<span>${t("العربية", "English")}</span></button><button class="icon-btn" data-action="theme" aria-label="${t("تبديل المظهر", "Toggle theme")}">${icon(state.theme === "light" ? "moon" : "sun")}</button><button class="icon-btn motion-settings ${state.reduced || state.low ? "active" : ""}" data-action="motion" aria-label="${t("إعدادات الحركة", "Motion settings")}">${icon("sliders")}</button></div></div>`;
  }
  function render() {
    const scroll = document.querySelector(".workspace")?.scrollTop || 0;
    document.documentElement.lang = state.lang;
    document.documentElement.dir = state.lang === "ar" ? "rtl" : "ltr";
    document.documentElement.dataset.theme = state.theme;
    document.documentElement.dataset.reduced = String(state.reduced);
    document.documentElement.dataset.low = String(state.low);
    document.body.className = `frame-${state.frame}`;
    root.innerHTML = `<div class="stage"><div class="app-shell"><div class="app-layout">${navigation()}<div class="app-main">${topbar()}<main class="workspace" id="main-content" aria-labelledby="page-title"><div class="page" data-screen="${state.page}">${pageContent()}</div></main></div></div><nav class="mobile-nav" aria-label="${t("التنقل السريع", "Quick navigation")}">${screens()
      .filter((s) =>
        ["home", "files", "transfers", "receive", "settings"].includes(s[0]),
      )
      .map(
        ([id, symbol, label]) =>
          `<button data-page="${id}" class="${state.page === id ? "active" : ""}">${icon(symbol)}<span>${label}</span></button>`,
      )
      .join(
        "",
      )}</nav></div></div>${previewbar()}<div id="modal-root"></div><div id="toast-root" aria-live="polite" aria-atomic="true"></div>`;
    if (document.querySelector(".workspace"))
      document.querySelector(".workspace").scrollTop = scroll;
    try {
      localStorage.setItem(
        "sisi-preview-appearance",
        JSON.stringify({ lang: state.lang, theme: state.theme }),
      );
    } catch {
      /* Preview remains usable without persistence. */
    }
  }
  function pageContent() {
    const pages = {
      home: homePage,
      files: filesPage,
      apps: filesPage,
      transfers: transfersPage,
      history: historyPage,
      receive: receivePage,
      web: webPage,
      watch: watchPage,
      qr: qrPage,
      settings: settingsPage,
      permissions: permissionsPage,
      security: securityPage,
      gallery: galleryPage,
      states: statesPage,
      system: systemPage,
    };
    return (pages[state.page] || homePage)();
  }
  function shareArt() {
    return '<svg class="share-art" viewBox="0 0 140 100" fill="none" aria-hidden="true"><ellipse cx="71" cy="90" rx="49" ry="5" fill="#dcebe0" opacity=".5"/><rect x="33" y="16" width="57" height="65" rx="8" transform="rotate(-13 33 16)" fill="#f0f3ec" stroke="#dce5da"/><rect x="51" y="8" width="54" height="70" rx="7" transform="rotate(12 51 8)" fill="#f7eccc" stroke="#eee2bb"/><path d="m72 29 14 3m-17 6 21 4m-23 5 17 3" stroke="#c9b887" stroke-width="2" stroke-linecap="round"/><rect x="30" y="30" width="65" height="55" rx="8" fill="#e5f0e6" stroke="#cee0d0"/><rect x="38" y="39" width="49" height="35" rx="4" fill="#b2cdb8"/><circle cx="74" cy="48" r="4" fill="#e7eed7"/><path d="m38 66 15-15 12 12 8-8 14 15v4H38z" fill="#749b7d"/><circle cx="102" cy="73" r="17" fill="#157b62" stroke="white" stroke-width="4"/><path d="M102 80V66m-5 5 5-5 5 5" stroke="white" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  }
  function homePage() {
    return `${intro(t("كل أجهزتك، على بُعد لمسة.", "All your devices. One touch away."), t("شارك ما تحب، مع من حولك. بدون إنترنت، وبدون تعقيد.", "Share what matters with those around you. No internet. No complications."), btn("manual", t("اتصال يدوي", "Connect manually"), "secondary", "plus") + `<button class="btn secondary" data-page="qr" aria-label="${t("مسح رمز QR", "Scan QR code")}">${icon("qr")}</button>`, "home-intro")}<div class="home-grid"><section><div class="section-title"><h2>${t("الأجهزة القريبة", "Nearby devices")} <span class="counter">${availableDevices().length}</span></h2><button class="text-btn" data-action="scan">${icon("refresh")} ${state.scanning ? t("تحديث الأجهزة", "Refresh devices") : t("بدء البحث", "Start discovery")}</button></div><div class="radar-panel ${!state.scanning || !state.visible ? "radar-sleep" : ""}"><div class="radar-status"><span class="dot live"></span>${state.scanning && state.visible ? t("جارٍ البحث عن أجهزة قريبة", "Looking for nearby devices") : t("البحث متوقف مؤقتًا", "Discovery paused")}</div><button class="radar-privacy icon-btn" data-action="visibility-info" aria-label="${t("خصوصية الاكتشاف", "Discovery privacy")}">${icon("shield")}</button><div class="radar-rings"><span class="ring"></span><span class="ring"></span><span class="ring"></span><span class="ring-wave"></span><span class="ring-wave"></span><span class="ring-axis"></span></div><div class="radar-center">${brand()}</div><div class="self-label"><strong>${safe(state.deviceName)}</strong><p>${state.visible ? t("جهازك · مرئي للأجهزة القريبة", "Your device · Visible nearby") : t("جهازك · غير مرئي حاليًا", "Your device · Not visible")}</p></div>${availableDevices()
      .map(
        (d) =>
          `<button class="radar-device" data-action="device" data-id="${d.id}" aria-label="${t("الاتصال بـ", "Connect to")} ${d.name}"><span class="node-icon ${d.color}">${icon(d.type)}</span><span class="device-name">${d.name}</span><span class="device-owner">${owner(d)}</span></button>`,
      )
      .join(
        "",
      )}<div class="radar-footer">${icon("wifi")}${t("على شبكة Wi-Fi نفسها", "On the same Wi-Fi network")}</div></div></section><section><div class="section-title"><h2>${t("إرسال سريع", "Quick send")}</h2><small>${t("كل أنواع الملفات", "Every kind of file")}</small></div><div class="upload-panel" data-dropzone="true">${shareArt()}<h3>${t("ماذا تريد أن تشارك؟", "What would you like to share?")}</h3><p>${t("اسحب ملفاتك هنا، أو اخترها من جهازك", "Drop your files here, or pick from your device")}</p>${btn("choose-files", t("اختيار ملفات", "Choose files"), "primary", "plus")}<span class="upload-caption">${t("صور، فيديو، مستندات، وأي شيء آخر", "Photos, videos, documents, and everything else")}</span><div class="upload-tools"><button data-action="text-share">${icon("text")}${t("نص أو رابط", "Text or link")}</button><button data-action="folder-share">${icon("folder")}${t("مشاركة مجلد", "Share a folder")}</button></div></div></section></div><section class="home-transfers"><div class="section-title"><div class="segmented-title"><button data-action="transfer-tab" data-value="active" class="${state.transferTab === "active" ? "active" : ""}">${t("النقل الجاري", "In progress")} <span class="counter">${state.transferDevices.filter((id) => !state.cancelled.has(id)).length}</span></button><button data-action="transfer-tab" data-value="done" class="${state.transferTab === "done" ? "active" : ""}">${t("المكتمل", "Completed")}</button></div><button class="text-btn" data-page="transfers">${t("كل العمليات", "All transfers")}${icon("left")}</button></div>${state.transferTab === "active" ? activeTransfers() : `<div class="panel">${icon("checkCircle")} ${t("اكتملت مشاركة 12 صورة مع Galaxy Tab S9. بيانات عيّنة.", "12 photos shared with Galaxy Tab S9. Sample data.")}</div>`}</section><section class="recent-section"><div class="section-title"><h2>${t("آخر المشاركات", "Recently shared")}</h2><button class="text-btn" data-page="history">${t("عرض السجل", "View history")}${icon("left")}</button></div>${historyTable(true)}</section>${footer()}`;
  }
  function transferRow(id) {
    const d = device(id),
      paused = state.paused.has(id);
    return `<div class="transfer-item" data-transfer="${id}"><img class="transfer-art" src="assets/art/trip.svg" alt="${t("رسم توضيحي لصور رحلة", "Original travel illustration")}"><div class="transfer-content"><div class="transfer-heading"><h3>${t("ذكريات الرحلة", "Weekend memories")} <span class="subtle small">${t("· 24 ملفًا", "· 24 files")}</span></h3><span class="sample-state"><span class="dot"></span><span data-transfer-label="${id}">${paused ? t("متوقف مؤقتًا", "Paused") : t("جارٍ الإرسال", "Sending")}</span></span></div><p class="transfer-to">${icon("arrow")}${t("إلى", "To")} <bdi>${d.name}</bdi></p><div class="progress-track" role="progressbar" aria-label="${t("تقدم توضيحي", "Sample progress")} ${d.name}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.floor(state.progress)}"><div class="progress-fill" style="transform:scaleX(${state.progress / 100})"></div></div><div class="transfer-bottom"><span><bdi data-sent-size>${(state.progress * 0.02).toFixed(2)}</bdi> ${t("من", "of")} <bdi>2 GB</bdi></span><span class="transfer-speed"><b><bdi>${paused ? "0" : "38.4"} MB/s</bdi></b><span>${paused ? t("بانتظار الاستئناف", "Waiting to resume") : t("متبقٍ 18 ثانية", "18 sec remaining")}</span></span></div></div><span class="transfer-percent" data-percent>${Math.floor(state.progress)}%</span><div class="transfer-controls"><button class="icon-btn" data-action="pause-transfer" data-id="${id}" aria-label="${paused ? t("استئناف", "Resume") : t("إيقاف مؤقت", "Pause")}">${icon(paused ? "play" : "pause")}</button><button class="icon-btn" data-action="cancel-transfer" data-id="${id}" aria-label="${t("إلغاء النقل", "Cancel transfer")}">${icon("close")}</button></div></div>`;
  }
  function activeTransfers() {
    const active = state.transferDevices.filter(
      (id) => !state.cancelled.has(id),
    );
    return active.length
      ? `<div class="stack">${active.map(transferRow).join("")}</div>`
      : `<div class="panel between"><p class="muted small">${t("لا توجد عمليات نقل جارية. ماذا ستشارك اليوم؟", "Nothing transferring. What will you share today?")}</p>${btn("choose-files", t("اختيار ملفات", "Choose files"), "soft", "plus")}</div>`;
  }
  const categories = () => [
    ["images", "image", t("الصور", "Photos")],
    ["videos", "video", t("الفيديو", "Videos")],
    ["music", "music", t("الموسيقى", "Music")],
    ["documents", "file", t("المستندات", "Documents")],
    ["archives", "archive", t("المضغوطات", "Archives")],
    ["apps", "apps", t("التطبيقات", "Apps")],
    ["contacts", "contacts", t("جهات الاتصال", "Contacts")],
    ["downloads", "download", t("التنزيلات", "Downloads")],
    ["custom", "folder", state.customName || t("مجلد مخصص", "Custom folder")],
  ];
  function sampleFiles() {
    const cat = state.page === "apps" ? "apps" : state.fileCategory;
    const names = {
      images: [
        "لحظة هدوء",
        "عند البحيرة",
        "طريق الشمال",
        "صباح أخضر",
        "آخر ضوء",
        "بيت بين التلال",
        "على الشاطئ",
        "أفق بعيد",
      ],
      videos: [
        "رحلة الشمال",
        "يوم في الطبيعة",
        "لحظات عائلية",
        "صوت البحر",
        "على الطريق",
        "غروب هادئ",
      ],
      music: [
        "Quiet mornings",
        "Northern lights",
        "A little closer",
        "Sunday afternoon",
        "Ocean sounds",
        "Golden hour",
      ],
      documents: [
        "خطة الرحلة",
        "دليل المشروع",
        "ملاحظات الاجتماع",
        "أفكار جديدة",
        "قائمة القراءة",
        "الميزانية",
      ],
      archives: ["صور الرحلة", "نسخة المستندات", "مشاريع قديمة", "ملفات العمل"],
      apps: [
        "Orbit",
        "Paper Notes",
        "Flow Music",
        "Trail Maps",
        "Little Lens",
        "Calm Weather",
      ],
      contacts: [
        "سارة أحمد",
        "محمد علي",
        "نور حسن",
        "عمر خالد",
        "ريم إبراهيم",
        "يوسف محمود",
      ],
      downloads: [
        "دليل الاستخدام",
        "خلفيات الطبيعة",
        "قائمة المهام",
        "الرحلة القادمة",
      ],
      custom: ["مشروعي الأول", "المراجع", "ملاحظات", "ملفات مشتركة"],
    };
    const english = {
      images: [
        "A quiet moment",
        "By the lake",
        "The northern road",
        "Green morning",
        "Last light",
        "A hillside cabin",
        "By the sea",
        "Distant horizons",
      ],
      videos: [
        "Northern trip",
        "Into the wild",
        "Family moments",
        "Ocean sounds",
        "On the road",
        "Quiet sunset",
      ],
      documents: [
        "Trip itinerary",
        "Project guide",
        "Meeting notes",
        "New ideas",
        "Reading list",
        "Budget",
      ],
      archives: [
        "Trip photos",
        "Document backup",
        "Old projects",
        "Work files",
      ],
      contacts: [
        "Sara Ahmed",
        "Mohamed Ali",
        "Nour Hassan",
        "Omar Khaled",
        "Reem Ibrahim",
        "Youssef Mahmoud",
      ],
      downloads: [
        "User guide",
        "Nature wallpapers",
        "Task list",
        "Our next trip",
      ],
      custom: ["My first project", "References", "Notes", "Shared files"],
    };
    const exts = {
      images: "jpg",
      videos: "mp4",
      music: "mp3",
      documents: "pdf",
      archives: "zip",
      apps: state.appTab === "installed" ? "" : "apk",
      contacts: "vcf",
      downloads: "pdf",
      custom: "pdf",
    };
    return (names[cat] || names.images).map((name, index) => ({
      id: `${cat}-${index}`,
      name: state.lang === "en" ? english[cat]?.[index] || name : name,
      index,
      cat,
      ext: exts[cat],
      size:
        cat === "contacts"
          ? "2 KB"
          : cat === "videos"
            ? `${128 + index * 31} MB`
            : cat === "apps"
              ? `${24 + index * 12} MB`
              : `${(2.4 + index * 0.7).toFixed(1)} MB`,
    }));
  }
  function fileTile(f) {
    const symbols = {
      music: "music",
      documents: "file",
      archives: "archive",
      downloads: "download",
      custom: "file",
    };
    const media = ["images", "videos"].includes(f.cat);
    const artwork = media
      ? `<img src="assets/art/landscape-${(f.index % 8) + 1}.svg" alt="${safe(f.name)}" loading="lazy">`
      : f.cat === "apps"
        ? `<span class="app-icon" style="background:${["#5b8f9b", "#bc9d71", "#8e86ac", "#759877", "#ad8279", "#809cac"][f.index]}">${f.name.slice(0, 1)}</span>`
        : f.cat === "contacts"
          ? `<span class="avatar ${f.index % 2 ? "blue" : "purple"}" style="width:58px;height:58px;font-size:24px">${safe(f.name.slice(0, 1))}</span>`
          : icon(symbols[f.cat] || "file");
    return `<button class="file-tile ${state.selected.has(f.id) ? "selected" : ""}" data-file="${f.id}" aria-pressed="${state.selected.has(f.id)}" aria-label="${safe(f.name)}"><span class="file-check">${icon("check")}</span><div class="file-thumb">${artwork}${f.cat === "videos" ? `<span class="duration">0${f.index + 1}:24</span>` : ""}</div><div class="file-info"><b>${safe(f.name)}${f.ext ? `<span class="latin">.${f.ext}</span>` : ""}</b><span class="latin">${f.size}${f.cat === "apps" ? " · v2.1.0" : ""}</span></div></button>`;
  }
  function filteredFiles() {
    let list = sampleFiles().filter((f) =>
      f.name.toLowerCase().includes(state.search.toLowerCase()),
    );
    if (state.sort === "name")
      list.sort((a, b) => a.name.localeCompare(b.name, state.lang));
    if (state.sort === "oldest") list.reverse();
    return list;
  }
  function selectedSize() {
    const megabytes = [...state.selected].reduce((total, id) => {
      if (id === "text-sample") return total + state.textSize / 1048576;
      const [category, rawIndex] = id.split("-");
      const index = Number(rawIndex);
      return (
        total +
        (category === "contacts"
          ? 2 / 1024
          : category === "videos"
            ? 128 + index * 31
            : category === "apps"
              ? 24 + index * 12
              : 2.4 + index * 0.7)
      );
    }, 0);
    return megabytes >= 1024
      ? `${(megabytes / 1024).toFixed(2)} GB`
      : megabytes < 0.1
        ? `${(megabytes * 1024).toFixed(1)} KB`
        : `${megabytes.toFixed(1)} MB`;
  }
  function selectionbar() {
    return state.selected.size
      ? `<div class="selection-bar"><div><strong>${state.selected.size} ${t("ملفات محددة", "files selected")} · <bdi>${selectedSize()}</bdi></strong><br><small>${t("تحديد تجريبي · لم تُقرأ أي ملفات من جهازك", "Sample selection · No device files accessed")}</small></div><div class="flex"><button class="icon-btn" style="color:white" data-action="clear-selection" aria-label="${t("إلغاء التحديد", "Clear selection")}">${icon("close")}</button>${btn("review-transfer", t("إرسال الملفات", "Send files"), "", "send")}</div></div>`
      : "";
  }
  function filesPage() {
    const apps = state.page === "apps" || state.fileCategory === "apps";
    return `${intro(apps ? t("تطبيقاتك، أقرب.", "Your apps, together.") : t("كل ما تحب مشاركته.", "Everything worth sharing."), t("اختر الملفات، واترك المسافة علينا. هذه ملفات عيّنة للتصميم.", "Pick your files. We will bridge the distance. These are design samples."), btn("custom-folder", t("إضافة مجلد", "Add folder"), "secondary", "plus"))}<div class="category-tabs" role="tablist">${categories()
      .map(
        ([id, symbol, label]) =>
          `<button class="category-tab ${(state.page === "apps" ? "apps" : state.fileCategory) === id ? "active" : ""}" role="tab" aria-selected="${(state.page === "apps" ? "apps" : state.fileCategory) === id}" data-action="category" data-value="${id}">${icon(symbol)}${safe(label)}</button>`,
      )
      .join(
        "",
      )}</div>${apps ? `<div class="gallery-tabs">${["installed", "packages"].map((id) => btn("app-tab", id === "installed" ? t("المثبتة", "Installed") : t("حزم التثبيت", "Install packages"), state.appTab === id ? "soft" : "secondary", "", `data-value="${id}"`)).join("")}</div>` : ""}${state.fileCategory === "custom" ? `<div class="custom-folder"><div><h3>${safe(state.customName || t("مجلدك الخاص", "Your custom folder"))}</h3><p>${t("في التطبيق الحقيقي ستختار المجلد باستخدام منتقي Android الآمن.", "In the Android app, choose this folder with the system’s secure folder picker.")}</p></div><button class="icon-btn" data-action="custom-folder" aria-label="${t("تعديل المجلد", "Edit folder")}">${icon("edit")}</button></div>` : ""}${state.fileCategory === "contacts" ? `<div class="info-banner" style="margin:0 0 22px">${icon("info")}<div>${t("جهات اتصال عيّنة فقط. لا تقرأ المعاينة دفتر عناوينك.", "Sample contacts only. The preview never reads your address book.")}<p>${t("في التطبيق الحقيقي يُطلب إذن القراءة عند أول تصدير فقط.", "The real app requests read access only when first exporting.")}</p></div></div>` : ""}<div class="toolbar-row"><div class="searchbar">${icon("search")}<input id="file-search" type="search" placeholder="${t("ابحث في ملفاتك...", "Search your files...")}" value="${safe(state.search)}" aria-label="${t("البحث في الملفات", "Search files")}"></div><button class="text-btn" data-action="select-all">${t("تحديد الكل", "Select all")}</button><span class="spacer"></span><select id="file-sort" aria-label="${t("ترتيب الملفات", "Sort files")}">${[
      ["newest", t("الأحدث أولًا", "Newest first")],
      ["oldest", t("الأقدم أولًا", "Oldest first")],
      ["name", t("حسب الاسم", "By name")],
    ]
      .map(
        ([v, l]) =>
          `<option value="${v}" ${state.sort === v ? "selected" : ""}>${l}</option>`,
      )
      .join(
        "",
      )}</select><button class="icon-btn" data-action="file-layout" aria-label="${t("تبديل طريقة العرض", "Change file layout")}">${icon(state.fileLayout === "grid" ? "list" : "grid")}</button></div><div id="file-grid" class="files-grid ${state.fileLayout === "list" ? "file-list" : ""}">${filteredFiles().map(fileTile).join("")}</div><div id="selection-slot">${selectionbar()}</div>${footer()}`;
  }
  function transfersPage() {
    const checks = [
      [
        "wifi",
        t("Wi-Fi متصل وجاهز", "Wi-Fi connected and ready"),
        t("شبكة محلية · 192.168.1.8", "Local network · 192.168.1.8"),
        true,
      ],
      [
        "storage",
        t("مساحة كافية لاستقبال الملفات", "Enough space for your files"),
        t(
          "18.6 GB متاحة · Download/JOPRO",
          "18.6 GB available · Download/JOPRO",
        ),
        true,
      ],
      [
        "shield",
        t("اتصال خاص ومشفّر", "Private, encrypted connection"),
        t(
          "TLS 1.3 · التحقق من هوية الجهاز",
          "TLS 1.3 · Device identity verification",
        ),
        true,
      ],
      [
        "bell",
        t("إشعارات تقدم النقل", "Transfer notifications"),
        t(
          "لتبقى على اطلاع عند مغادرة التطبيق",
          "Stay informed when you leave the app",
        ),
        state.permissions.notifications === "granted",
      ],
    ];
    return `${intro(t("لنجهّز لحظة المشاركة.", "Ready for a little sharing?"), t("اختر جهازًا أو أكثر، وتأكد أن كل شيء جاهز قبل الإرسال.", "Choose one or more devices and check that you are ready to go."), btn("choose-files", t("تعديل الملفات", "Edit files"), "secondary", "folder"))}<div class="two-col"><section class="panel"><h2>${t("الملفات وجاهزية النقل", "Files & transfer readiness")}</h2><div class="bundle"><span class="file-icon">${icon("image")}</span><div><strong>${state.selected.size || 24} ${t("ملفًا جاهزًا للمشاركة", "files ready to share")}</strong><p><bdi>${state.selected.size ? selectedSize() : "2 GB"}</bdi> · ${t("بيانات عيّنة", "Sample data")}</p></div><button class="icon-btn" style="margin-inline-start:auto" data-page="files" aria-label="${t("تعديل الملفات", "Edit files")}">${icon("edit")}</button></div><div class="readiness-list">${checks.map(([symbol, title, sub, ready]) => `<div class="check-row"><span class="check-icon ${ready ? "" : "warning"}">${icon(ready ? "check" : symbol)}</span><div class="check-text"><strong>${title}</strong><p>${sub}</p></div>${ready ? icon("checkCircle", "sm green") : `<button class="text-btn" data-action="permission" data-key="notifications">${t("تفعيل", "Enable")}</button>`}</div>`).join("")}</div><div class="info-banner">${icon("shield")}<div>${t("الموافقة أولًا، دائمًا.", "Consent always comes first.")}<p>${t("لن يبدأ النقل حتى يوافق الجهاز الآخر. القيم هنا توضيحية فقط.", "A transfer starts only after the recipient agrees. All values here are illustrative.")}</p></div></div></section><section class="panel"><div class="section-title"><h2>${t("إلى من نرسل؟", "Who are we sharing with?")}</h2><span class="counter">${state.recipients.size}</span></div><p class="muted small">${t("على شبكتك المحلية الآن", "On your local network now")}</p><div class="device-list">${availableDevices()
      .map(
        (d) =>
          `<button class="device-choice ${state.recipients.has(d.id) ? "chosen" : ""}" data-action="recipient" data-id="${d.id}" aria-pressed="${state.recipients.has(d.id)}"><span class="node-icon ${d.color}">${icon(d.type)}</span><div><strong>${d.name}</strong><p>${owner(d)} · ${state.trusted.has(d.id) ? t("موثوق", "Trusted") : t("جهاز جديد", "New device")}</p></div><span class="choice-check">${icon(state.recipients.has(d.id) ? "checkCircle" : "plus")}</span></button>`,
      )
      .join(
        "",
      )}</div><div class="mt">${btn("start-transfer", t("بدء الإرسال التجريبي", "Preview sending"), "primary", "send", `style="width:100%" ${state.recipients.size ? "" : "disabled"}`)}</div><p class="small subtle" style="text-align:center;margin-top:10px">${t("لا يتم نقل أي ملف في المعاينة", "No files are transferred in this preview")}</p></section></div><section class="section-gap"><div class="section-title"><h2>${t("عملياتك الجارية", "Your ongoing transfers")}</h2><span class="small subtle">${t("تقدم توضيحي", "Illustrative progress")}</span></div>${activeTransfers()}</section>${footer()}`;
  }
  const historyRecords = () => [
    {
      id: "h1",
      name: t("خطة المشروع.pdf", "Project plan.pdf"),
      size: "4.2 MB",
      type: "file",
      color: "orange",
      device: "MacBook Pro",
      time: t("اليوم، 10:42 ص", "Today, 10:42 AM"),
      status: "done",
      direction: "send",
    },
    {
      id: "h2",
      name: t("صور عطلة نهاية الأسبوع", "Weekend photos"),
      size: "128 MB · 12 " + t("صورة", "photos"),
      type: "image",
      color: "blue",
      device: "Galaxy Tab S9",
      time: t("اليوم، 09:18 ص", "Today, 09:18 AM"),
      status: "done",
      direction: "receive",
    },
    {
      id: "h3",
      name: "Northern lights.mp4",
      size: "842 MB",
      type: "video",
      color: "purple",
      device: "iPhone 15",
      time: t("أمس، 08:30 م", "Yesterday, 08:30 PM"),
      status: "failed",
      direction: "send",
    },
    {
      id: "h4",
      name: t("ملاحظات الرحلة.zip", "Trip notes.zip"),
      size: "32 MB",
      type: "archive",
      color: "orange",
      device: "MacBook Pro",
      time: t("أمس، 04:12 م", "Yesterday, 04:12 PM"),
      status: "done",
      direction: "receive",
    },
  ];
  function historyTable(compact = false) {
    let records = state.historyRemoved ? [] : historyRecords();
    if (compact) records = records.slice(0, 2);
    else
      records = records.filter(
        (r) =>
          (state.historyFilter === "all" ||
            r.direction === state.historyFilter ||
            r.status === state.historyFilter) &&
          r.name.toLowerCase().includes(state.historySearch.toLowerCase()),
      );
    return `<table class="recent-table"><thead><tr><th>${t("الملف", "File")}</th><th>${t("الجهاز", "Device")}</th><th>${t("الوقت", "Time")}</th><th>${t("الحالة", "Status")}</th><th aria-label="${t("إجراءات", "Actions")}"></th></tr></thead><tbody>${records.map((r) => `<tr><td><div class="file-mini"><span class="file-icon ${r.color}">${icon(r.type)}</span><div><strong>${safe(r.name)}</strong><small class="latin">${r.size}</small></div></div></td><td><bdi>${r.device}</bdi></td><td>${r.time}</td><td><span class="status-label ${r.status === "failed" ? "failed" : ""}">${icon(r.status === "failed" ? "warning" : "checkCircle")}${r.status === "failed" ? t("لم يكتمل", "Interrupted") : t("مكتمل", "Completed")}</span></td><td><button class="icon-btn" data-action="history-detail" data-id="${r.id}" aria-label="${t("تفاصيل العملية", "Transfer details")}">${icon("more")}</button></td></tr>`).join("")}${records.length ? "" : `<tr><td colspan="5" style="text-align:center;padding:35px">${t("لا توجد عمليات لعرضها. ابدأ بمشاركة شيء تحبه.", "No transfers to show. Start with something worth sharing.")}</td></tr>`}</tbody></table>`;
  }
  function historyPage() {
    return `${intro(t("لكل مشاركة، حكاية.", "A story in every share."), t("كل ما أرسلت واستقبلت، في مكان واحد. بيانات عيّنة.", "Everything sent and received, in one place. Sample data."), btn("clear-history", t("مسح السجل", "Clear history"), "secondary", "trash"))}<div class="toolbar-row history-tools"><div class="searchbar">${icon("search")}<input id="history-search" type="search" placeholder="${t("ابحث في السجل...", "Search history...")}" value="${safe(state.historySearch)}" aria-label="${t("البحث في السجل", "Search history")}"></div><div class="category-tabs" style="margin:0;padding:0;border:0">${[
      ["all", t("الكل", "All")],
      ["send", t("المرسلة", "Sent")],
      ["receive", t("المستلمة", "Received")],
      ["failed", t("غير المكتملة", "Interrupted")],
    ]
      .map(
        ([id, label]) =>
          `<button class="category-tab ${state.historyFilter === id ? "active" : ""}" data-action="history-filter" data-value="${id}">${label}</button>`,
      )
      .join(
        "",
      )}</div></div><div id="history-table">${historyTable()}</div>${footer()}`;
  }

  function receivePage() {
    return `${intro(t("دع المشاركة تأتي إليك.", "Let good things come to you."), t("كن مرئيًا لمن حولك، وابقَ متحكمًا في كل اتصال.", "Be visible nearby, and stay in control of every connection."))}<div class="equal-col"><section class="panel qr-panel"><div class="between"><span class="small muted">${t("الظهور للأجهزة القريبة", "Nearby visibility")}</span>${switcher("visible", state.visible, t("وضع الاستقبال", "Receive mode"))}</div><div class="receive-state">${brand()}<h2>${state.visible ? t("أنت جاهز للاستقبال", "You are ready to receive") : t("خذ وقتك. أنت غير مرئي الآن.", "Take your time. You are invisible.")}</h2><p>${t("اسم جهازك", "Your device")} <bdi>${safe(state.deviceName)}</bdi></p></div><div class="qr-wrap large">${qrSvg()}</div><p class="qr-label">${t("QR حقيقي لعنوان عيّنة، وليس لخادم يعمل.", "A real QR of a sample URL, not a running server.")}</p><code class="sample-url">192.168.1.8:53317</code><button class="text-btn" data-action="profile">${icon("edit")}${t("تعديل اسم الجهاز وصورته", "Edit device name & avatar")}</button></section><section><div class="section-title"><h2>${t("طلبات الاتصال", "Connection requests")}</h2><span class="small subtle">${t("حالة توضيحية", "Design state")}</span></div>${consentContent()}<div class="info-banner">${icon("shield")}<div>${t("قرار المشاركة لك وحدك.", "Sharing is always your decision.")}<p>${t("لن يرى الجهاز الآخر ملفاتك أو يبدأ أي نقل قبل موافقتك. يمكنك حظره ببصمته في أي وقت.", "Another device cannot browse your files or transfer anything without consent. Block its fingerprint at any time.")}</p></div></div><div class="panel mt"><div class="setting-row"><span class="setting-copy"><strong>${t("تنبيه عند وصول طلب جديد", "A heads-up for new requests")}</strong><p>${t("يُطلب إذن الإشعارات عند الحاجة، وليس عند أول تشغيل.", "Notification access is requested when needed, not at first launch.")}</p></span><button class="text-btn" data-action="permission" data-key="notifications">${t("معاينة الإذن", "Preview permission")}</button></div></div></section></div>${footer()}`;
  }
  function consentContent() {
    if (state.receiveDecision)
      return `<div class="panel"><div class="empty-state" style="min-height:270px;padding:25px 10px"><span class="empty-icon">${icon(state.receiveDecision === "block" ? "block" : "checkCircle")}</span><h2 style="font-size:18px">${t("تم تحديث حالة المعاينة", "Preview state updated")}</h2><p>${t("لم يتم إنشاء اتصال حقيقي أو قبول ملفات.", "No real connection was established or files accepted.")}</p>${btn("reset-consent", t("عرض الطلب مجددًا", "Show request again"), "soft", "refresh")}</div></div>`;
    return `<div class="consent-card"><div class="flex"><span class="node-icon purple">${icon("phone")}</span><div><h3 class="latin">iPhone 15</h3><p class="muted small">${t("سارة تريد مشاركة ملفات معك", "Sara would like to share with you")}</p></div><span class="counter" style="margin-inline-start:auto">${t("جديد", "New")}</span></div><div class="bundle"><span class="file-icon blue">${icon("image")}</span><div><strong>${t("12 صورة من عطلة الأسبوع", "12 photos from the weekend")}</strong><p><bdi>128 MB</bdi> · ${t("سيتم الحفظ في", "Save to")} <bdi>Download/JOPRO</bdi></p></div></div><p class="small muted">${t("بصمة الجهاز · تحقق منها عند أول اتصال", "Device fingerprint · Verify on first connection")}</p><div class="fingerprint">8F:3A:62:BD:01:7C:9E:A4:55:2B:7F:31:C8:DA:09:42</div><div class="consent-actions">${btn("consent-once", t("قبول مرة واحدة", "Accept once"), "primary", "check")}${btn("consent-trust", t("قبول ووثوق دائم", "Accept & trust"), "soft", "shield")}${btn("consent-reject", t("رفض الطلب", "Decline"), "secondary", "close")}${btn("consent-block", t("حظر الجهاز", "Block device"), "danger-btn", "block")}</div><p class="small subtle" style="margin-top:13px;text-align:center">${t("ينتهي الطلب بعد 60 ثانية في التطبيق الحقيقي.", "In the real app, a request expires after 60 seconds.")}</p></div>`;
  }
  function qrPage() {
    return `${intro(t("قرّب المسافات برمز.", "One code. A closer connection."), t("امسح رمز الجهاز الآخر أو اعرض رمز جهازك. واجهة توضيحية فقط.", "Scan another device or show your own code. Interface design only."))}<div class="gallery-tabs">${btn("qr-tab", t("مسح رمز", "Scan a code"), state.qrTab === "scan" ? "soft" : "secondary", "camera", 'data-value="scan"')}${btn("qr-tab", t("رمز جهازي", "My device code"), state.qrTab === "show" ? "soft" : "secondary", "qr", 'data-value="show"')}</div><div class="two-col"><section class="panel">${state.qrTab === "scan" ? `<div class="scan-box"><div class="scan-target">${icon("qr")}<span class="scan-line"></span></div><small>${t("معاينة الماسح · الكاميرا غير مستخدمة", "Scanner preview · Camera is not being used")}</small></div><div class="scan-actions"><button class="icon-btn ${state.torch ? "green" : ""}" data-action="torch" aria-label="${t("المصباح", "Flashlight")}" aria-pressed="${state.torch}">${icon("flash")}</button><button class="btn secondary" data-action="sample-gallery">${icon("image")}${t("من المعرض", "From gallery")}</button><button class="icon-btn" data-action="zoom" aria-label="${t("التقريب", "Zoom")}"><bdi>${state.zoom || "1"}×</bdi></button></div>` : `<div class="qr-panel"><h2>${safe(state.deviceName)}</h2><div class="qr-wrap large">${qrSvg()}</div><p class="qr-label">${t("عنوان اتصال عيّنة فقط", "Sample connection address only")}</p><code class="sample-url">http://192.168.1.8:53317/?preview=design</code></div>`}</section><section class="panel"><h2>${t("اتصال بسيط، وآمن.", "Simple. Private. Connected.")}</h2><div class="helper-steps"><p class="helper-step">${t("تأكد أن الجهازين على شبكة Wi-Fi نفسها.", "Make sure both devices are on the same Wi-Fi network.")}</p><p class="helper-step">${t("افتح SISI Share على الجهاز الآخر واعرض رمز QR.", "Open SISI Share on the other device and display its QR code.")}</p><p class="helper-step">${t("تحقق من بصمة الجهاز قبل الموافقة على الاتصال.", "Verify the device fingerprint before accepting the connection.")}</p></div><div class="info-banner">${icon("camera")}<div>${t("إذن الكاميرا، فقط عندما تحتاجه.", "Camera access, only when you need it.")}<p>${t("هذه المعاينة لا تطلب أي إذن. يمكنك مراجعة شاشة الشرح دون تشغيل كاميرا.", "This preview never requests access. Review the rationale without opening a camera.")}</p></div></div><div class="mt">${btn("permission", t("معاينة شرح الإذن", "Preview permission rationale"), "secondary", "camera", 'data-key="camera"')}</div><button class="text-btn" data-action="manual">${t("أفضّل إدخال العنوان يدويًا", "I would rather enter an address")}${icon("left")}</button></section></div>`;
  }
  function webPage() {
    return `${intro(t("من هاتفك، إلى أي متصفح.", "From your phone. To any browser."), t("مساحة مشاركة محلية، لا تحتاج إلى تثبيت على الجهاز الآخر.", "A local shared space. Nothing to install on the other device."))}<div class="two-col"><section class="panel"><div class="between"><div class="flex"><span class="file-icon">${icon("globe")}</span><div><h2>${t("مشاركة الويب", "Web sharing")}</h2><p class="small muted">${state.web ? t("حالة تصميم: قيد التشغيل", "Design state: running") : t("حالة تصميم: متوقفة", "Design state: stopped")}</p></div></div>${switcher("web", state.web, t("تشغيل مشاركة الويب في المعاينة", "Preview web sharing"))}</div><div class="info-banner warning">${icon("info")}<div>${t("هذه ليست واجهة الويب الحقيقية.", "This is not the real web client.")}<p>${t("لن يُشغَّل خادم. الرابط والاتصالات أدناه أمثلة لعرض التصميم.", "No server is started. The URL and sessions below are design samples.")}</p></div></div><div class="setting-row"><span class="setting-copy"><strong>${t("نوع الاتصال", "Connection type")}</strong><p>${t("HTTP يعمل محليًا، وHTTPS يتطلب الثقة بالشهادة.", "HTTP works locally. HTTPS requires trusting a local certificate.")}</p></span><select id="web-protocol" aria-label="${t("نوع اتصال الويب", "Web connection type")}"><option value="http" ${state.webProtocol === "http" ? "selected" : ""}>HTTP</option><option value="https" ${state.webProtocol === "https" ? "selected" : ""}>HTTPS</option></select></div><div class="setting-row"><span class="setting-copy"><strong>${t("ما الذي تريد مشاركته؟", "What would you like to share?")}</strong><p>${t("لا يُعرض شيء خارج النطاق الذي تختاره.", "Nothing outside your chosen scope is ever exposed.")}</p></span><select id="web-scope" aria-label="${t("نطاق المشاركة", "Sharing scope")}"><option value="selected" ${state.webScope === "selected" ? "selected" : ""}>${t("ملفات محددة", "Selected files")}</option><option value="folder" ${state.webScope === "folder" ? "selected" : ""}>${t("مجلد مختار", "Chosen folder")}</option><option value="manager" ${state.webScope === "manager" ? "selected" : ""}>${t("تصفح المدير", "File manager")}</option></select></div><div class="setting-row"><span class="setting-copy"><strong>${t("السماح برفع الملفات", "Allow uploads")}</strong><p>${t("بموافقة جديدة من الهاتف لكل طلب.", "Each request still needs approval from your phone.")}</p></span>${switcher("webUpload", state.webUpload, t("السماح بالرفع", "Allow uploads"))}</div><div class="setting-row"><span class="setting-copy"><strong>${t("رمز PIN للجلسة", "Session PIN")}</strong><p>${t("طبقة إضافية فوق موافقة الاتصال.", "An extra layer, in addition to connection consent.")}</p></span>${switcher("pin", state.pin, t("رمز PIN", "Session PIN"))}</div><div class="mt">${btn("web-choose", t("اختيار ما أشاركه", "Choose what to share"), "primary", "folder")}${state.webProtocol === "https" ? `<button class="text-btn" style="margin-inline-start:16px" data-action="https-info">${t("حول الشهادة المحلية", "About local certificates")}</button>` : ""}</div></section><section class="panel qr-panel"><h2>${t("افتح الرابط، وابدأ بالقرب.", "Open a link. Bring things closer.")}</h2><p class="small muted" style="margin-top:7px">${t("على الجهاز الآخر، ضمن شبكة Wi-Fi نفسها.", "On another device, on the same Wi-Fi network.")}</p><div class="qr-wrap large">${qrSvg()}</div><p class="qr-label">${t("QR يشفّر عنوان HTTP توضيحيًا فقط", "QR encodes an illustrative HTTP address only")}</p><code class="sample-url">${state.webProtocol}://192.168.1.8:53317</code><button class="text-btn" data-action="copy-url">${icon("copy")}${t("تحديد الرابط للنسخ", "Select sample link")}</button><p class="small muted">${t("المتصفحات المتصلة: 0 في هذه المعاينة", "Connected browsers: 0 in this preview")}</p></section></div>${footer()}`;
  }
  function watchPage() {
    if (state.watchEnded)
      return `${intro(t("المشاهدة المشتركة", "Watch together"), t("فيلم واحد، ولحظة نعيشها معًا.", "One film. A moment shared."))}<div class="panel empty-state"><span class="empty-icon">${icon("video")}</span><h2>${t("انتهت جلسة العرض التوضيحية", "The design session has ended")}</h2><p>${t("لم يتم تشغيل فيديو أو إنشاء غرفة حقيقية.", "No video was played or real room created.")}</p>${btn("restart-watch", t("معاينة الغرفة مجددًا", "Preview the room again"), "primary", "play")}</div>`;
    return `${intro(t("نفس اللحظة. معًا.", "The same moment. Together."), t("شاهدوا من جهاز واحد، وكأنكم في الغرفة نفسها. معاينة واجهة فقط.", "Watch from one device, like you are in the same room. Interface preview only."), btn("end-watch", t("إنهاء الغرفة", "End room"), "secondary", "exit"))}<div class="watch-layout"><section><div class="video-design"><img src="assets/art/poster.svg" alt="${t("رسم أصلي لوادٍ أخضر بين الجبال", "Original illustration of a green mountain valley")}"><span class="video-tag">${t("مشهد توضيحي · لا يوجد فيديو فعلي", "Illustration · No actual video")}</span><button class="video-play" data-action="watch-play" aria-label="${state.watchPlaying ? t("إيقاف المعاينة", "Pause preview") : t("تشغيل المعاينة", "Play preview")}">${icon(state.watchPlaying ? "pause" : "play")}</button><div class="video-controls"><input id="watch-seek" type="range" min="0" max="100" value="${state.watchPosition}" aria-label="${t("تقدم العرض التوضيحي", "Design playback position")}"><div class="between"><span><span id="watch-time">${Math.floor((state.watchPosition / 100) * 94)}:24</span> / 1:34:00</span><div class="flex"><button data-action="watch-volume" aria-label="${t("الصوت", "Volume")}">${icon("volume")}</button><button data-action="watch-options" aria-label="${t("المسارات والترجمات", "Tracks and subtitles")}">${icon("settings")}</button><button data-action="watch-fullscreen" aria-label="${t("ملء الشاشة", "Full screen")}">${icon("expand")}</button></div></div></div></div><div class="media-meta"><div><h2>${t("إلى حيث تأخذنا الطبيعة", "Where nature takes us")}</h2><p><bdi>4K · MKV · HEVC</bdi> · ${t("ملف فيديو عيّنة", "Sample video file")}</p></div><span class="status-label">${icon("users")} ${t("3 مشاهدين", "3 viewers")}</span></div><div class="info-banner warning">${icon("info")}<div>${t("الصيغ تختلف باختلاف المتصفح.", "Codec support varies by browser.")}<p>${t("في التطبيق الحقيقي: تشغيل مباشر، ثم إعادة تغليف إن أمكن، وإلا فتح بالتطبيق. لا تَعِد هذه المعاينة بتشغيل أي صيغة.", "Real client: direct playback, then remux where possible, otherwise open in the app. This preview makes no codec-support claims.")}</p></div></div></section><section class="panel"><div class="section-title"><h2>${t("في الغرفة", "In the room")}</h2><span class="counter">3</span></div>${[
      [
        t("أنت (المضيف)", "You (host)"),
        t("Galaxy S24 · مصدر العرض", "Galaxy S24 · Hosting"),
        "أ",
        true,
      ],
      [t("سارة", "Sara"), "iPhone 15", "س", true],
      [t("محمد", "Mohamed"), "MacBook Pro", "م", false],
    ]
      .map(
        ([name, sub, initial, sync], i) =>
          `<div class="viewer"><span class="avatar ${i === 1 ? "purple" : "blue"}">${state.lang === "ar" ? initial : String(name).slice(0, 1)}</span><div><strong>${name}</strong><p>${sub}</p></div><span class="status-label" style="color:${sync ? "var(--primary)" : "var(--warning)"}">${sync ? t("متزامن", "In sync") : t("متأخر 0.4ث", "0.4s behind")}</span></div>`,
      )
      .join(
        "",
      )}<div class="setting-row"><span class="setting-copy"><strong>${t("من يتحكم بالتشغيل؟", "Who can control playback?")}</strong><p>${t("حالة إعداد توضيحية", "Illustrative setting")}</p></span><select id="watch-control" aria-label="${t("التحكم بالتشغيل", "Playback control")}"><option value="host">${t("المضيف فقط", "Host only")}</option><option value="everyone" ${state.watchControl === "everyone" ? "selected" : ""}>${t("الجميع", "Everyone")}</option></select></div>${btn("invite-watch", t("دعوة للمشاهدة", "Invite to watch"), "soft", "qr", 'style="width:100%;margin-top:17px"')}</section></div>${footer()}`;
  }
  const permissionInfo = () => ({
    media: [
      "image",
      t("الصور والفيديو والصوت", "Photos, video & audio"),
      t(
        "لعرض وسائطك عند اختيار ما تشاركه. يمكنك السماح بصور محددة فقط.",
        "Browse media when choosing what to share. You can allow selected photos only.",
      ),
    ],
    notifications: [
      "bell",
      t("الإشعارات", "Notifications"),
      t(
        "لمتابعة تقدم النقل والرد على طلبات الاستقبال خارج التطبيق. الرفض لا يمنع النقل.",
        "Track transfers and respond outside the app. Denial does not prevent transferring.",
      ),
    ],
    nearby: [
      "wifi",
      t("الأجهزة القريبة", "Nearby devices"),
      t(
        "لإنشاء اتصال Wi-Fi Direct أو نقطة اتصال محلية عند اختيارك ذلك.",
        "Create a Wi-Fi Direct connection or local hotspot when you choose to.",
      ),
    ],
    camera: [
      "camera",
      t("الكاميرا", "Camera"),
      t(
        "لقراءة رمز QR فقط. الإدخال اليدوي يبقى متاحًا عند الرفض.",
        "Only to scan a QR code. Manual entry remains available if you decline.",
      ),
    ],
    contacts: [
      "contacts",
      t("قراءة جهات الاتصال", "Read contacts"),
      t(
        "لتصدير الجهات التي تحددها بصيغة vCard. إذن الاستيراد يُطلب بشكل منفصل.",
        "Export selected contacts as vCards. Import requires a separate permission.",
      ),
    ],
    storage: [
      "folder",
      t("الوصول لكل الملفات (اختياري)", "All files access (optional)"),
      t(
        "لوضع المدير المتقدم فقط. التطبيق يعمل بدونه عبر منتقي المجلدات الآمن SAF.",
        "Only for advanced manager mode. The app works without it via the safe system picker.",
      ),
    ],
    battery: [
      "battery",
      t(
        "استثناء تحسين البطارية (اختياري)",
        "Battery optimization exemption (optional)",
      ),
      t(
        "قد يساعد مع النقل الطويل على بعض الأجهزة، لكنه لا يضمن بقاء التطبيق حيًا.",
        "May help long transfers on some devices, but never guarantees background survival.",
      ),
    ],
  });
  function permissionsPage() {
    return `${intro(t("صلاحيات بقدر حاجتك.", "Only the access you need."), t("كل إذن له سبب. كل قرار يبقى لك.", "Every permission has a purpose. Every decision stays yours."))}<div class="info-banner warning" style="margin:0 0 24px">${icon("info")}<div>${t("هذه حالات واجهة، وليست أذونات فعلية.", "These are UI states, not real permissions.")}<p>${t("لا تفحص المعاينة صلاحيات Android ولا تطلب الوصول إلى أي شيء في جهازك.", "The preview does not inspect Android permissions or request access to anything on your device.")}</p></div></div><section class="panel">${Object.entries(
      permissionInfo(),
    )
      .map(
        ([key, [symbol, title, why]]) =>
          `<div class="setting-row">${icon(symbol)}<div class="setting-copy"><strong>${title}</strong><p>${why}</p></div><span class="permission-status ${state.permissions[key] === "granted" ? "granted" : ""}">${state.permissions[key] === "granted" ? t("مسموح (عيّنة)", "Allowed (sample)") : state.permissions[key] === "partial" ? t("وصول جزئي (عيّنة)", "Partial (sample)") : state.permissions[key] === "permanent" ? t("مرفوض دائمًا (عيّنة)", "Blocked (sample)") : t("غير مفعّل (عيّنة)", "Not allowed (sample)")}</span><button class="icon-btn" data-action="permission" data-key="${key}" aria-label="${t("معاينة إذن", "Preview permission:")} ${title}">${icon("chevron")}</button></div>`,
      )
      .join(
        "",
      )}</section><div class="info-banner">${icon("shield")}<div>${t("لا إذن دون خطوة منك.", "No permission without your action.")}<p>${t("في التطبيق الحقيقي يظهر الشرح عند أول استخدام للميزة، مع بديل واضح عند الرفض.", "The real app explains access just in time, with a clear alternative if you decline.")}</p></div></div>${footer()}`;
  }
  function settingsPage() {
    const row = (symbol, title, sub, control) =>
      `<div class="setting-row">${icon(symbol)}<div class="setting-copy"><strong>${title}</strong><p>${sub}</p></div>${control}</div>`;
    const settingSwitch = (key, label) =>
      switcher(`setting:${key}`, state.settings[key], label);
    return `${intro(t("على طريقتك.", "Make yourself at home."), t("تفاصيل صغيرة، تجعل المشاركة أقرب إليك. جميع التغييرات للتصميم فقط.", "Small details that make sharing yours. All changes affect this design preview only."))}<div class="settings-layout"><section class="panel"><h2>${icon("phone")}${t("جهازك ومساحتك", "Your device & space")}</h2>${row("phone", safe(state.deviceName), t("اسم الجهاز والصورة واللون", "Device name, avatar and color"), `<button class="icon-btn" data-action="profile" aria-label="${t("تعديل الملف", "Edit profile")}">${icon("edit")}</button>`)}${row("folder", t("مجلد الاستقبال", "Receive folder"), "<bdi>Download/JOPRO</bdi>", `<button class="text-btn" data-action="storage-info">${t("تغيير", "Change")}</button>`)}${row("grid", t("تنظيم الملفات تلقائيًا", "Organize automatically"), t("مجلدات حسب نوع الملف", "Subfolders by file type"), settingSwitch("organize", t("تنظيم الملفات", "Organize files")))}${row("shield", t("الأذونات", "Permissions"), t("شاهد حالة كل إذن، وما الذي يحتاجه", "Review every permission and its purpose"), `<button class="icon-btn" data-page="permissions" aria-label="${t("فتح الأذونات", "Open permissions")}">${icon("chevron")}</button>`)}</section><section class="panel"><h2>${icon("transfer")}${t("النقل والأداء", "Transfers & performance")}</h2>${row("lock", t("تشفير النقل", "Transfer encryption"), t("TLS 1.3 · موصى به دائمًا", "TLS 1.3 · Always recommended"), settingSwitch("encryption", t("التشفير", "Encryption")))}${row("fingerprint", t("التحقق من سلامة الملفات", "File integrity checks"), t("BLAKE3 · افتراضي للملفات الكبيرة", "BLAKE3 · Default for large files"), settingSwitch("integrity", t("فحص السلامة", "Integrity checks")))}${row("sliders", t("الاتصالات المتوازية", "Parallel connections"), t("يُقاس الأنسب حسب الشبكة والجهاز", "Measured for the network and device"), `<select id="parallel-connections" aria-label="${t("عدد الاتصالات", "Connection count")}"><option>${t("تلقائي (موصى به)", "Auto (recommended)")}</option><option>2</option><option>4</option><option>8</option></select>`)}${row("wifi", t("خيارات الشبكة", "Network options"), t("Wi-Fi Direct · هوتسبوت · اتصال يدوي", "Wi-Fi Direct · Hotspot · Manual connection"), `<button class="icon-btn" data-action="network-options" aria-label="${t("خيارات الشبكة", "Network options")}">${icon("chevron")}</button>`)}</section><section class="panel"><h2>${icon("sun")}${t("الشكل واللغة", "Appearance & language")}</h2>${row(state.theme === "light" ? "sun" : "moon", t("المظهر", "Theme"), state.theme === "light" ? t("فاتح، مثل بداية جديدة", "Light, like a fresh start") : t("داكن ومريح للعين", "Dark and easy on the eyes"), btn("theme", state.theme === "light" ? t("فاتح", "Light") : t("داكن", "Dark"), "secondary"))}${row("globe", t("اللغة", "Language"), t("عربي كامل من اليمين لليسار", "Full English, left to right"), btn("language", t("العربية", "English"), "secondary"))}${row("sliders", t("تقليل الحركة", "Reduce motion"), t("تجربة هادئة، بنفس التفاصيل", "A calmer experience, with the same details"), switcher("reduced", state.reduced, t("تقليل الحركة", "Reduce motion")))}${row("battery", t("وضع الجهاز الضعيف", "Low-power device mode"), t("يخفف التأثيرات دون تغيير التصميم", "Fewer effects, same overall design"), switcher("low", state.low, t("وضع الجهاز الضعيف", "Low-power mode")))}</section><section class="panel"><h2>${icon("shield")}${t("الثقة والخصوصية", "Trust & privacy")}</h2>${row("users", t("الموثوقون والمحظورون", "Trusted & blocked devices"), t("تُحفظ هوية الجهاز ببصمته، لا باسمه", "Identity is tied to fingerprint, not device name"), `<button class="icon-btn" data-page="security" aria-label="${t("إدارة الأجهزة", "Manage devices")}">${icon("chevron")}</button>`)}${row("checkCircle", t("قبول تلقائي للموثوقين", "Auto-accept trusted devices"), t("معطّل افتراضيًا، والقرار لك", "Off by default. Always your choice."), settingSwitch("autoAccept", t("القبول التلقائي", "Auto acceptance")))}${row("lock", t("إخفاء الملفات على شاشة القفل", "Hide file names on lock screen"), t("تظهر معلومات النقل فقط", "Only transfer information is shown"), settingSwitch("lockPrivacy", t("خصوصية شاشة القفل", "Lock-screen privacy")))}${row("grid", t("أسماء الملفات في الويدجت", "File names in widgets"), t("معطّلة افتراضيًا لحماية خصوصيتك", "Hidden by default for your privacy"), settingSwitch("widgetNames", t("أسماء الملفات", "File names")))}</section><section class="panel"><h2>${icon("bell")}${t("الإشعارات والخلفية", "Notifications & background")}</h2>${row("bell", t("قنوات الإشعارات", "Notification channels"), t("النقل · طلبات الاتصال · الاكتمال · الغرف", "Transfers · Requests · Completion · Rooms"), `<button class="text-btn" data-action="notification-settings">${t("إدارة", "Manage")}</button>`)}${row("clock", t("إيقاف الاستقبال عند الخمول", "Stop receiving when idle"), t("بعد 30 دقيقة، مع تنبيه مسبق", "After 30 minutes, with advance notice"), settingSwitch("idle", t("الإيقاف عند الخمول", "Idle timeout")))}${row("battery", t("سلوك الخلفية", "Background behavior"), t("قيود Android والنصائح الاختيارية", "Android restrictions and optional advice"), `<button class="icon-btn" data-action="background-info" aria-label="${t("سلوك الخلفية", "Background behavior")}">${icon("chevron")}</button>`)}</section><section class="panel"><h2>${icon("sliders")}${t("خيارات متقدمة", "Advanced options")}</h2>${row("globe", t("منفذ الشبكة", "Network port"), t("تغيير تصميمي؛ لا يوجد خادم يعمل", "Design setting; no server is running"), '<input id="network-port" type="number" value="53317" min="1024" max="65535" aria-label="Port" style="width:100px;min-height:36px;font-size:11px;direction:ltr">')}${row("shield", t("مساعد الصلاحيات الاختياري", "Optional privileged helper"), t("Shizuku / Root · غير مفعّل", "Shizuku / Root · Not enabled"), `<button class="text-btn" data-action="helper-info">${t("اعرف أكثر", "Learn more")}</button>`)}${row("sliders", t("حالة النظام", "System capabilities"), t("سلّم القدرات والقيود لكل ميزة", "Capability levels and limits for every feature"), `<button class="icon-btn" data-page="system" aria-label="${t("حالة النظام", "System capabilities")}">${icon("chevron")}</button>`)}${row("help", t("حول SISI Share", "About SISI Share"), t("المرحلة 0 · بانتظار الموافقة البصرية", "Phase 0 · Awaiting visual approval"), '<span class="counter">0.1.0</span>')}</section></div>${footer()}`;
  }
  function securityPage() {
    const list =
      state.securityTab === "trusted"
        ? devices.filter((d) => state.trusted.has(d.id))
        : [
            ...devices.filter((d) => state.blocked.has(d.id)),
            ...(state.blocked.has("unknown")
              ? [
                  {
                    id: "unknown",
                    name: "Android device",
                    owner: ["جهاز محظور", "Blocked device"],
                    type: "phone",
                    color: "purple",
                  },
                ]
              : []),
          ];
    return `${intro(t("ثقة تُبنى. وخصوصية تُحترم.", "Trust, on your terms."), t("قوائم مبنية على بصمة الجهاز، لا على الاسم أو عنوان الشبكة. بيانات عيّنة.", "Device fingerprints, not names or IP addresses. Sample data."))}<div class="gallery-tabs">${btn("security-tab", t("الأجهزة الموثوقة", "Trusted devices"), state.securityTab === "trusted" ? "soft" : "secondary", "shield", 'data-value="trusted"')}${btn("security-tab", t("الأجهزة المحظورة", "Blocked devices"), state.securityTab === "blocked" ? "soft" : "secondary", "block", 'data-value="blocked"')}</div><section class="panel security-list">${list.length ? list.map((d, i) => `<div class="device-choice"><span class="node-icon ${d.color}">${icon(d.type)}</span><div><strong>${d.name}</strong><p>${owner(d)}</p><p class="fingerprint">${i ? "4B:19:AD:67:CC:01:8F:09" : "8F:3A:62:BD:01:7C:9E:A4"}…</p></div><button class="text-btn ${state.securityTab === "trusted" ? "danger" : ""}" data-action="remove-security" data-id="${d.id}">${state.securityTab === "trusted" ? t("إلغاء الوثوق", "Revoke trust") : t("إلغاء الحظر", "Unblock")}</button></div>`).join("") : `<div class="empty-state" style="min-height:260px"><span class="empty-icon">${icon("shield")}</span><h2>${t("قائمة هادئة، حتى الآن.", "A quiet list. For now.")}</h2><p>${t("لا توجد أجهزة في هذه القائمة.", "There are no devices in this list.")}</p></div>`}</section><div class="info-banner">${icon("fingerprint")}<div>${t("تغيّر الاسم لا يغيّر الهوية.", "A new name is not a new identity.")}<p>${t("في التطبيق الحقيقي، يُحظر الجهاز بشهادته ولا يحصل على استجابات اكتشاف. لا توجد أجهزة حقيقية هنا.", "In the real app, blocking uses the certificate fingerprint and suppresses discovery replies. No real devices are present here.")}</p></div></div>`;
  }
  function notification(kind) {
    const head = `<div class="notification-head">${brand()}<bdi>SISI Share</bdi><span>· ${t("الآن", "now")}</span></div>`;
    if (kind === "progress" && state.galleryCancelled)
      return `<article class="notification">${head}<h3>${t("أُلغيت عملية العيّنة", "Sample transfer cancelled")}</h3><p>${t("لم يتم إلغاء أي نقل حقيقي.", "No real transfer was cancelled.")}</p><div class="notification-actions"><button data-action="gallery-cancel">${t("إعادة العرض", "Reset preview")}</button></div></article>`;
    if (kind === "request" && state.receiveDecision)
      return `<article class="notification">${head}<h3>${t("تم التعامل مع طلب العيّنة", "Sample request handled")}</h3><p>${t("لم يصل أو يُقبل أي ملف فعلي.", "No actual files were received or accepted.")}</p><div class="notification-actions"><button data-action="reset-consent">${t("عرض الطلب مجددًا", "Show request again")}</button></div></article>`;
    const notifications = {
      progress: `<h3>${state.galleryPaused ? t("النقل التجريبي متوقف مؤقتًا", "Sample transfer paused") : t("جارٍ الإرسال إلى MacBook Pro", "Sending to MacBook Pro")}</h3><p>${t("24 ملفًا · 64% · متبقٍ 18 ثانية", "24 files · 64% · 18 seconds remaining")}</p><div class="progress-track"><div class="progress-fill" style="transform:scaleX(.64)"></div></div><p style="margin-top:6px"><bdi>${state.galleryPaused ? "0" : "38.4"} MB/s</bdi></p><div class="notification-actions"><button data-action="gallery-pause">${state.galleryPaused ? t("استئناف", "Resume") : t("إيقاف مؤقت", "Pause")}</button><button data-action="gallery-cancel">${t("إلغاء", "Cancel")}</button></div>`,
      request: `<h3>${t("سارة تريد المشاركة معك", "Sara wants to share with you")}</h3><p><bdi>iPhone 15</bdi> · ${t("12 صورة", "12 photos")} · <bdi>128 MB</bdi></p><div class="notification-actions"><button data-action="notification-consent" data-value="once">${t("قبول", "Accept")}</button><button data-action="notification-consent" data-value="reject">${t("رفض", "Decline")}</button><button data-action="notification-consent" data-value="block">${t("حظر", "Block")}</button></div>`,
      complete: `<h3>${t("وصلت ملفاتك بأمان", "Your files arrived safely")}</h3><p>${t("12 صورة · تم الحفظ في Download/JOPRO", "12 photos · Saved to Download/JOPRO")}</p><div class="notification-actions"><button data-action="sample-open">${t("فتح", "Open")}</button><button data-action="show-folder">${t("إظهار في المجلد", "Show in folder")}</button><button data-action="sample-share">${t("مشاركة", "Share")}</button></div>`,
      failure: `<h3>${t("انقطع الاتصال، لا تقلق.", "Disconnected? We have your place.")}</h3><p>${t("تم حفظ موضع الاستئناف. اتصل بالشبكة للمتابعة.", "Your resume position is saved. Reconnect to continue.")}</p><div class="notification-actions"><button data-page="transfers">${t("استئناف النقل", "Resume transfer")}</button></div>`,
      group: `<h3>${t("مشاركة مع 3 أجهزة", "Sharing with 3 devices")}</h3><p>${t("جهازان قيد النقل · جهاز واحد مكتمل", "2 transferring · 1 complete")}</p><div class="notification-actions"><button data-action="gallery-multi">${t("عرض العمليات", "View transfers")}</button></div>`,
    };
    return `<article class="notification">${head}${notifications[kind]}</article>`;
  }
  function widgetBody(normal) {
    if (state.galleryState === "loading")
      return '<div class="widget-state"><span class="skeleton"></span><span class="skeleton short"></span></div>';
    if (state.galleryState === "empty")
      return `<div class="widget-state">${icon("folder")}<p>${t("لا توجد عمليات بعد", "No transfers yet")}</p><button class="text-btn" data-page="files">${t("شارك أول ملف", "Share your first file")}</button></div>`;
    if (state.galleryState === "error")
      return `<div class="widget-state">${icon("warning")}<p>${t("الخدمة متوقفة أو الإذن غير متاح", "Service stopped or permission missing")}</p><button class="text-btn" data-action="widget-retry">${t("مراجعة الحالة", "Review status")}</button></div>`;
    return normal;
  }
  function galleryPage() {
    const widget = (name, size, body, wide = false) =>
      `<article class="widget ${wide ? "widget-wide" : ""}" data-widget-theme="${state.galleryTheme}"><div class="between"><h3>${name}</h3>${brand()}</div>${widgetBody(body)}<p class="widget-name"><bdi>${size}</bdi> · ${t("تصميم ويدجت، غير مُثبّت", "Widget design, not installed")}</p></article>`;
    const widgets = () =>
      `<div class="widget-canvas">${widget(t("شارك شيئًا جميلًا", "Share something good"), "4 × 1", `<div class="widget-actions"><button data-page="files">${icon("upload")}${t("إرسال ملفات", "Send files")}</button><button data-page="qr">${icon("qr")}${t("مسح QR", "Scan QR")}</button><button data-page="receive">${icon("download")}${t("استقبال", "Receive")}</button></div>`, true)}${widget(t("قريب منك الآن", "Nearby right now"), "2 × 2", `<div class="widget-receive"><div><h3 class="latin">${safe(state.deviceName)}</h3><p>${state.visible ? t("مرئي للأجهزة القريبة", "Visible nearby") : t("غير مرئي حاليًا", "Not visible")}</p></div>${switcher("visible", state.visible, t("حالة الاستقبال", "Receive state"))}</div><p class="latin" style="margin-top:15px">192.168.1.8</p>`)}${widget(t("مشاركة الويب", "Web sharing"), "2 × 2", `<div class="widget-receive"><div><p>${state.web ? t("حالة تصميم: يعمل", "Design state: on") : t("حالة تصميم: متوقف", "Design state: off")}</p><p class="latin" style="font-size:8px">192.168.1.8:53317</p><button class="text-btn" data-action="widget-web">${state.web ? t("إيقاف", "Stop") : t("تشغيل", "Start")}</button></div><div class="qr-wrap">${qrSvg()}</div></div>`)}${widget(t("لحظاتك في الطريق", "Your moments are on their way"), "4 × 2", `<div class="between" style="margin-top:17px"><p><bdi>MacBook Pro</bdi> · <bdi>64%</bdi></p><p><bdi>38.4 MB/s</bdi></p></div><div class="progress-track"><div class="progress-fill" style="transform:scaleX(.64)"></div></div><div class="widget-actions"><button data-action="gallery-pause">${icon(state.galleryPaused ? "play" : "pause")}${state.galleryPaused ? t("استئناف", "Resume") : t("إيقاف مؤقت", "Pause")}</button><button data-action="gallery-cancel">${icon("close")}${t("إلغاء", "Cancel")}</button></div>`, true)}${widget(
        t("آخر مشاركاتك", "Your recent shares"),
        "4 × 3",
        `<div style="max-height:150px;overflow:auto;margin-top:10px">${historyRecords()
          .map(
            (r) =>
              `<div class="widget-history-row"><span class="flex">${icon(r.direction === "send" ? "upload" : "download")}${state.settings.widgetNames ? r.name : t("ملف تمت مشاركته", "Shared file")}</span><span>${r.status === "done" ? icon("check") : icon("warning")}</span></div>`,
          )
          .join("")}</div>`,
        true,
      )}</div>`;
    return `${intro(t("قريب، حتى خارج التطبيق.", "Close, even outside the app."), t("معرض تصاميم الإشعارات والويدجتس. لا يثبت أو يرسل أي شيء للنظام.", "Notification and widget design gallery. Nothing is installed or sent to your system."))}<div class="between" style="flex-wrap:wrap;margin-bottom:20px"><div class="gallery-tabs" style="margin:0">${btn("gallery-tab", t("الإشعارات", "Notifications"), state.gallery === "notifications" ? "soft" : "secondary", "bell", 'data-value="notifications"')}${btn("gallery-tab", t("الويدجتس", "Widgets"), state.gallery === "widgets" ? "soft" : "secondary", "grid", 'data-value="widgets"')}</div>${
      state.gallery === "widgets"
        ? `<div class="flex"><select id="gallery-state" aria-label="${t("حالة الويدجت", "Widget state")}">${[
            ["normal", t("عادي", "Normal")],
            ["loading", t("تحميل", "Loading")],
            ["empty", t("فارغ", "Empty")],
            ["error", t("خطأ / إذن ناقص", "Error / permission")],
          ]
            .map(
              ([v, l]) =>
                `<option value="${v}" ${state.galleryState === v ? "selected" : ""}>${l}</option>`,
            )
            .join(
              "",
            )}</select><button class="icon-btn" data-action="widget-theme" aria-label="${t("مظهر الويدجت", "Widget theme")}">${icon(state.galleryTheme === "light" ? "moon" : "sun")}</button></div>`
        : ""
    }</div>${state.gallery === "notifications" ? `<div class="android-shade"><div class="shade-head"><strong>10:42</strong><small>${t("الثلاثاء، 14 مايو", "Tuesday, May 14")}</small><span class="flex">${icon("wifi", "sm")}${icon("battery", "sm")}</span></div>${["progress", "request", "complete", "failure", "group"].map(notification).join("")}</div>` : widgets()}${footer()}`;
  }
  const emptyStates = () => ({
    devices: [
      "wifi",
      t("قريبون، لكن لم نلتقِ بعد.", "Nearby. Not yet connected."),
      t(
        "تأكد أن الجهاز الآخر على شبكة Wi-Fi نفسها وأن وضع الاستقبال مفعّل.",
        "Check that the other device is on the same Wi-Fi and receive mode is on.",
      ),
      "manual",
      t("اتصال يدوي", "Connect manually"),
    ],
    offline: [
      "wifi",
      t("انقطعت الشبكة للحظة.", "The network took a moment off."),
      t(
        "يمكن متابعة النقل من موضعه بعد عودة الاتصال. لم تفقد ما اكتمل.",
        "Resume where you left off when the network returns. Completed chunks stay safe.",
      ),
      "network-options",
      t("خيارات الاتصال", "Connection options"),
    ],
    storage: [
      "storage",
      t("نحتاج مساحة صغيرة للمتابعة.", "A little more room to continue."),
      t(
        "المساحة المتاحة لا تكفي. حرّر بعض المساحة أو اختر مجلد استقبال آخر.",
        "There is not enough free space. Free up space or choose another receive folder.",
      ),
      "storage-info",
      t("تغيير مجلد الاستقبال", "Change receive folder"),
    ],
    denied: [
      "shield",
      t("القرار لك، دائمًا.", "Your choice. Always."),
      t(
        "لم يُمنح الإذن المطلوب. يمكنك تفعيله لاحقًا أو اختيار الملفات عبر منتقي النظام.",
        "Access was not granted. Enable it later, or choose files with the system picker.",
      ),
      "open-permissions",
      t("مراجعة الأذونات", "Review permissions"),
    ],
    timeout: [
      "clock",
      t("توقفنا بأمان، لنكمل لاحقًا.", "Paused safely. Ready when you are."),
      t(
        "انتهت مدة الخدمة التي يسمح بها Android. حُفظت حالة الاستئناف؛ عد للتطبيق للمتابعة.",
        "Android’s background time limit was reached. Resume state is saved; return to continue.",
      ),
      "open-transfers",
      t("متابعة النقل", "Continue transfer"),
    ],
  });
  function statesPage() {
    const [symbol, title, copy, action, label] =
      emptyStates()[state.errorState];
    return `${intro(t("حتى التوقف، يستحق الوضوح.", "Even a pause deserves clarity."), t("حالات عيّنة توضّح ما حدث، وما يمكنك فعله بعد ذلك.", "Sample states that explain what happened, and what you can do next."))}<div class="state-pills">${Object.entries(
      {
        devices: t("لا أجهزة", "No devices"),
        offline: t("انقطاع الشبكة", "Disconnected"),
        storage: t("امتلاء التخزين", "Storage full"),
        denied: t("رفض الإذن", "Access denied"),
        timeout: t("مهلة الخلفية", "Background timeout"),
      },
    )
      .map(([id, label]) =>
        btn(
          "error-state",
          label,
          state.errorState === id ? "soft" : "secondary",
          "",
          `data-value="${id}"`,
        ),
      )
      .join(
        "",
      )}</div><section class="panel empty-state ${["storage", "offline"].includes(state.errorState) ? "error" : ""}"><span class="empty-icon">${icon(symbol)}</span><h2>${title}</h2><p>${copy}</p>${btn(action, label, "primary", symbol)}<span class="small subtle" style="margin-top:16px">${t("حالة تصميم توضيحية، وليست خطأً حقيقيًا على جهازك", "Illustrative design state, not an actual error on your device")}</span></section>`;
  }
  function systemPage() {
    const caps = [
      [
        t("إنشاء الشبكة", "Create a network"),
        "Helper → Wi-Fi Direct → LocalOnlyHotspot → Settings",
        t("لم يُفحص عتاد Android", "Android hardware not tested"),
      ],
      [
        t("اكتشاف الأجهزة", "Device discovery"),
        "Multicast → mDNS → Subnet → BLE → QR",
        t("عينات تصميم فقط", "Design samples only"),
      ],
      [
        t("النقل في الخلفية", "Background transfers"),
        "UIDT → connectedDevice → dataSync",
        t("لم تُنفذ خدمة أصلية", "Native service not implemented"),
      ],
      [
        t("الاستقبال والتخزين", "Receive storage"),
        "MediaStore → SAF → All files",
        t("لا وصول إلى التخزين", "No storage access"),
      ],
      [
        t("حزم التطبيقات", "Application packages"),
        "Original splits → Merge → Original package",
        t("لا تثبيت أو دمج هنا", "No installation or merging"),
      ],
      [
        t("تشغيل المتصفح", "Browser playback"),
        "Direct → Remux → Audio → Hardware → App",
        t("لا تشغيل في المعاينة", "No playback in preview"),
      ],
    ];
    return `${intro(t("نعرف ما يمكن. ونوضح ما لا يمكن.", "Know what works. Know the limits."), t("مرجع بصري لسلّم القدرات. لا يمثل فحصًا فعليًا للجهاز أو المتصفح.", "A visual reference for the capability ladder. Not a device or browser capability scan."))}<div class="panel" style="overflow:auto"><table class="system-table"><thead><tr><th>${t("الميزة", "Feature")}</th><th>${t("المستويات المخططة", "Planned levels")}</th><th>${t("الحالة الفعلية هنا", "Actual state here")}</th></tr></thead><tbody>${caps.map(([name, levels, status]) => `<tr><td><strong>${name}</strong></td><td><bdi>${levels}</bdi></td><td><span class="muted">${status}</span></td></tr>`).join("")}</tbody></table></div><div class="info-banner warning">${icon("info")}<div>${t("لا قياسات أو وعود غير مختبرة.", "No untested measurements or promises.")}<p>${t("توثيق APIs واختبارات Android 7–15 والأجهزة الحقيقية ومعدلات النقل تبدأ بعد اعتماد المرحلة 0.", "API verification, Android 7–15 testing, real hardware and transfer benchmarks begin after phase-0 approval.")}</p></div></div><div class="mt">${btn("network-options", t("راجع قيود الشبكة", "Review network limits"), "secondary", "wifi")}${btn("helper-info", t("حول المساعد الاختياري", "About the optional helper"), "secondary", "shield", 'style="margin-inline-start:8px"')}</div>`;
  }

  let lastFocus = null,
    activeModal = null,
    toastTimer = null;
  function showModal(title, body, actions = "", wide = false) {
    lastFocus = document.activeElement;
    const slot = document.getElementById("modal-root");
    slot.innerHTML = `<div class="overlay"><section class="dialog ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-labelledby="dialog-title" tabindex="-1"><div class="dialog-head"><h2 id="dialog-title">${title}</h2><button class="icon-btn" data-action="close-modal" aria-label="${t("إغلاق النافذة", "Close dialog")}">${icon("close")}</button></div>${body}${actions ? `<div class="dialog-actions">${actions}</div>` : ""}</section></div>`;
    const focusable = slot.querySelector(
      "input:not([type=range]),textarea,select",
    );
    (focusable || slot.querySelector(".dialog")).focus();
  }
  function closeModal() {
    document.getElementById("modal-root").innerHTML = "";
    activeModal = null;
    if (lastFocus?.isConnected) lastFocus.focus();
  }
  function toast(message) {
    clearTimeout(toastTimer);
    document.getElementById("toast-root").innerHTML =
      `<div class="toast" role="status">${icon("info")}<span>${safe(message)}</span></div>`;
    toastTimer = setTimeout(() => {
      const el = document.getElementById("toast-root");
      if (el) el.innerHTML = "";
    }, 4200);
  }
  function navigate(page) {
    if (!screens().some((s) => s[0] === page)) return;
    activeModal = null;
    state.page = page;
    if (page === "apps") state.fileCategory = "apps";
    if (location.hash !== `#${page}`)
      history.replaceState(null, "", `#${page}`);
    render();
    document.querySelector(".workspace").scrollTop = 0;
    document.querySelector("main").setAttribute("tabindex", "-1");
  }
  function permissionModal(key) {
    const info = permissionInfo()[key];
    if (!info) return;
    activeModal = { kind: "permission", key };
    showModal(
      t("قبل أن نطلب الإذن", "Before asking for access"),
      `<div class="dialog-icon">${icon(info[0])}</div><h3>${info[1]}</h3><p class="muted small" style="margin-top:9px">${info[2]}</p><div class="info-banner warning">${icon("info")}<div>${t("شرح تصميمي فقط. لا يظهر طلب إذن حقيقي.", "Design rationale only. No real permission prompt is shown.")}<p>${t("اختر حالة لمراجعة سلوك الواجهة عند السماح أو الرفض.", "Choose a state to review how the interface responds.")}</p></div></div><div class="permission-examples">${btn("permission-choice", t("سماح (عيّنة)", "Allow (sample)"), "primary", "check", `data-key="${key}" data-value="granted"`)}${key === "media" ? btn("permission-choice", t("صور محددة", "Selected photos"), "secondary", "image", `data-key="${key}" data-value="partial"`) : ""}${btn("permission-choice", t("رفض", "Deny"), "secondary", "close", `data-key="${key}" data-value="denied"`)}${btn("permission-choice", t("رفض دائم", "Deny permanently"), "danger-btn", "block", `data-key="${key}" data-value="permanent"`)}</div>${state.permissions[key] === "permanent" ? `<p class="small muted" style="margin-top:18px">${t("في Android الحقيقي يظهر زر فتح إعدادات التطبيق، وتُحدّث الحالة عند العودة.", "On Android, this shows an app-settings action and refreshes access when returning.")}</p>` : ""}`,
    );
  }
  function motionModal() {
    activeModal = { kind: "motion" };
    showModal(
      t("الحركة، بإيقاعك.", "Motion, at your pace."),
      `<p>${t("راجع التجربة بسرعة مختلفة أو خفّف التأثيرات.", "Review at a different speed, or simplify the effects.")}</p><div class="setting-row"><span class="setting-copy"><strong>${t("تقليل الحركة", "Reduce motion")}</strong><p>${t("إيقاف النبض والانتقالات المتحركة", "Stop pulsing and movement transitions")}</p></span>${switcher("reduced", state.reduced, t("تقليل الحركة", "Reduce motion"))}</div><div class="setting-row"><span class="setting-copy"><strong>${t("وضع جهاز ضعيف", "Low-power device mode")}</strong><p>${t("دوائر أقل، وبدون ظلال إضافية", "Fewer rings and no extra shadows")}</p></span>${switcher("low", state.low, t("وضع جهاز ضعيف", "Low-power mode"))}</div><label class="field">${t("سرعة الحركة", "Animation speed")}<select id="motion-speed">${[0.5, 1, 1.5, 2].map((v) => `<option value="${v}" ${state.speed === v ? "selected" : ""}>${v}× ${v === 1 ? t("(طبيعي)", "(normal)") : ""}</option>`).join("")}</select></label>`,
      btn(
        "close-modal",
        t("حفظ ومتابعة", "Save & continue"),
        "primary",
        "check",
      ),
    );
  }
  function manualModal() {
    activeModal = { kind: "manual" };
    showModal(
      t("مسافة عنوان واحد.", "Just one address away."),
      `<div class="dialog-icon">${icon("link")}</div><p>${t("أدخل عنوان IP والمنفذ الظاهرين على الجهاز الآخر. لن تُنشئ المعاينة أي اتصال.", "Enter the IP address and port shown on the other device. This preview will not connect.")}</p><label class="field" for="manual-address">${t("عنوان الجهاز", "Device address")}<input id="manual-address" inputmode="url" autocomplete="off" placeholder="192.168.1.12:53317" dir="ltr" aria-describedby="manual-error"></label><div id="manual-error" class="form-error" role="alert"></div><p class="small subtle">${t("أو أدخل كودًا قصيرًا من 6 أرقام لمراجعة حالة التصميم.", "Or enter a six-digit code to review the design state.")}</p>`,
      btn("close-modal", t("إلغاء", "Cancel"), "secondary") +
        btn(
          "validate-manual",
          t("متابعة المعاينة", "Continue preview"),
          "primary",
          "arrow",
        ),
    );
  }
  function validateManual() {
    const input = document.getElementById("manual-address");
    const value = input.value
      .trim()
      .replace(/^https?:\/\//, "")
      .replace(/\/$/, "");
    const parts = value.match(/^(\d{1,3}(?:\.\d{1,3}){3}):(\d{1,5})$/);
    const valid =
      /^\d{6}$/.test(value) ||
      (parts &&
        parts[1].split(".").every((n) => Number(n) <= 255) &&
        Number(parts[2]) > 0 &&
        Number(parts[2]) <= 65535);
    if (!valid) {
      input.setAttribute("aria-invalid", "true");
      document.getElementById("manual-error").textContent = t(
        "أدخل IP:Port صالحًا، مثل 192.168.1.12:53317.",
        "Enter a valid IP:Port, such as 192.168.1.12:53317.",
      );
      input.focus();
      return;
    }
    showModal(
      t("العنوان جاهز للمراجعة", "Address ready for review"),
      `<div class="dialog-icon">${icon("checkCircle")}</div><code class="sample-url">${safe(value)}</code><div class="info-banner warning">${icon("info")}<div>${t("الصيغة صحيحة فقط؛ لم يُفحص الاتصال أو يُرسل أي طلب.", "The format is valid; connectivity was not checked and no request was sent.")}</div></div>`,
      btn(
        "manual-next",
        t("عرض صفحة الجاهزية", "View readiness screen"),
        "primary",
        "left",
      ),
    );
  }
  function profileModal() {
    activeModal = { kind: "profile" };
    showModal(
      t("وجه مألوف لأجهزتك.", "A familiar face for your devices."),
      `<div class="flex" style="margin:12px 0 20px"><span class="avatar" style="width:64px;height:64px;font-size:26px">${safe(state.name.slice(0, 1))}</span><div><h3>${t("ملفك الشخصي", "Your profile")}</h3><p class="small muted">${t("صورة رمزية عيّنة · تبقى محليًا", "Sample avatar · Stays local")}</p></div></div><label class="field">${t("اسمك", "Your name")}<input id="profile-name" maxlength="40" value="${safe(state.name)}"></label><label class="field">${t("اسم الجهاز", "Device name")}<input id="device-name" maxlength="40" value="${safe(state.deviceName)}" dir="auto"></label><p class="small subtle" style="margin-top:15px">${t("تعديل بيانات المعاينة فقط. لا تُرسل هذه المعلومات إلى الشبكة.", "Edits preview data only. None of this is sent over a network.")}</p><p id="profile-error" class="form-error" role="alert"></p>`,
      btn("close-modal", t("إلغاء", "Cancel"), "secondary") +
        btn(
          "save-profile",
          t("حفظ التغييرات", "Save changes"),
          "primary",
          "check",
        ),
    );
  }
  function infoModal(kind) {
    const copy = {
      "storage-info": [
        t("مكان لملفاتك، باختيارك.", "A place for your files. Your choice."),
        "folder",
        t(
          "الافتراضي في التطبيق الحقيقي هو Download/JOPRO عبر MediaStore دون إذن على Android 10+. يمكن اختيار مجلد آخر باستخدام SAF.",
          "The real default is Download/JOPRO via MediaStore without permission on Android 10+. Another folder can be chosen through SAF.",
        ),
        t(
          "لا يمكن إنشاء /sdcard/JOPRO مباشرة على Android 11+ دون وصول خاص. لن تطلب المعاينة الوصول إلى ملفاتك.",
          "Creating /sdcard/JOPRO directly on Android 11+ requires special access. This preview never requests file access.",
        ),
      ],
      "https-info": [
        t("HTTPS محلي، بثقة واضحة.", "Local HTTPS. Clearly trusted."),
        "lock",
        t(
          "الشهادة المحلية تحتاج تثبيت جهة إصدار موثوقة أو قبول تحذير المتصفح. بعض الميزات الآمنة قد لا تصبح متاحة بمجرد تجاوز التحذير.",
          "A local certificate requires a trusted local CA or a browser warning. Bypassing a warning alone may not enable all secure-context features.",
        ),
        t(
          "يبقى HTTP المحلي هو الأساس بدون الاعتماد على الحافظة أو Service Workers. لم تُولّد شهادة في هذه المرحلة.",
          "Local HTTP remains fully usable without clipboard or Service Workers. No certificate is generated in this phase.",
        ),
      ],
      "background-info": [
        t(
          "في الخلفية، بحدود واضحة.",
          "Background work, with clear boundaries.",
        ),
        "battery",
        t(
          "Android يقيّد بدء الخدمات من الخلفية وقد ينهي عملها. المسار الحقيقي سيستخدم UIDT أو النوع الملائم من الخدمة، مع حفظ حالة الاستئناف.",
          "Android limits background starts and can stop services. Production will use UIDT or an appropriate service type, with durable resume state.",
        ),
        t(
          "استثناء البطارية اختياري، ولا يضمن بقاء التطبيق. لم تُختبر أي خدمة أصلية أو مسارات بدء على أجهزة في المرحلة 0.",
          "Battery exemption is optional and does not guarantee survival. No native service or start path has been tested in phase 0.",
        ),
      ],
      "helper-info": [
        t(
          "مساعد اختياري. وليس شرطًا.",
          "An optional helper. Never a requirement.",
        ),
        "shield",
        t(
          "Shizuku وRoot قد يتيحان صلاحيات متقدمة على أجهزة وإصدارات معينة، بعد موافقة صريحة، وبأوامر ضمن قائمة بيضاء ثابتة.",
          "Shizuku or root can enable advanced access on certain devices and versions, with explicit consent and a fixed command allowlist.",
        ),
        t(
          "هذه مرحلة مستقلة لاحقة، معطّلة وغير مُنفّذة هنا. تعمل المستويات الأساسية دونها، ولا يجري اكتشاف Root أو تشغيل أي أمر.",
          "This is a separate later phase, disabled and not implemented here. Base levels do not require it. No root scan or command is run.",
        ),
      ],
      "visibility-info": [
        t("ظاهر، لكن ملفاتك ليست كذلك.", "Visible. Your files are not."),
        "eye",
        t(
          "يسمح وضع الاستقبال باكتشاف اسم جهازك وصورته المصغرة. تبقى الملفات مخفية حتى تختار مشاركتها ويوافق الطرف الآخر.",
          "Receive mode advertises your device identity, not your files. Files remain private until deliberately shared with consent.",
        ),
        t(
          "الأجهزة الثلاثة في الرادار بيانات عيّنة، ولا يجري أي اكتشاف فعلي.",
          "The radar’s three devices are sample data. No real discovery is running.",
        ),
      ],
    };
    const [title, symbol, body, limit] = copy[kind];
    activeModal = { kind };
    showModal(
      title,
      `<div class="dialog-icon">${icon(symbol)}</div><p>${body}</p><div class="info-banner warning">${icon("info")}<div>${limit}</div></div>`,
      btn("close-modal", t("واضح، شكرًا", "Understood"), "primary", "check"),
    );
  }
  function networkModal() {
    activeModal = { kind: "network" };
    const levels = [
      [
        t("Wi-Fi Direct", "Wi-Fi Direct"),
        t(
          "اسم مخصص بالبادئة DIRECT-xx- حيث يسمح الإصدار والجهاز. لا نفترض IP ثابتًا.",
          "Custom DIRECT-xx- name where supported. Never assume a fixed IP.",
        ),
      ],
      [
        t("نقطة اتصال محلية", "Local-only hotspot"),
        t(
          "الاسم وكلمة المرور يختارهما النظام، وليس التطبيق.",
          "The system chooses the name and password, not the app.",
        ),
      ],
      [
        t("الهوتسبوت اليدوي", "Manual hotspot"),
        t(
          "يفتح التطبيق إعدادات Android، ويكشف التفعيل عند العودة.",
          "Open Android settings, then detect the enabled network on return.",
        ),
      ],
      [
        t("مساعد الصلاحيات", "Privileged helper"),
        t(
          "اختياري، في مرحلة لاحقة، مع تحقق مستقل لكل API.",
          "Optional later phase, with independent verification for each API.",
        ),
      ],
    ];
    showModal(
      t("بدون راوتر؟ نبقى قريبين.", "No router? Still close."),
      `<p>${t("سلّم تصميمي لطرق الاتصال. لا تنشئ هذه الأزرار شبكة أو تغيّر إعدادات جهازك.", "A design reference for connection options. These controls cannot create a network or change device settings.")}</p><div class="helper-steps">${levels.map(([name, body]) => `<div class="helper-step"><div><strong>${name}</strong><p class="small muted">${body}</p></div></div>`).join("")}</div><div class="info-banner warning">${icon("wifi")}<div>${t("لا يمكن الجزم بعزل الأجهزة من فشل TCP وحده. تُعرض رسالة احتمال مع بديل يدوي أو QR.", "TCP failure alone does not prove AP isolation. Show a possible-isolation warning with manual or QR alternatives.")}</div></div>`,
      btn(
        "network-manual",
        t("معاينة الاتصال اليدوي", "Preview manual connection"),
        "primary",
        "link",
      ),
    );
  }
  function confirmDialog(title, body, action, extra = "") {
    showModal(
      title,
      `<p>${body}</p>`,
      btn("close-modal", t("تراجع", "Go back"), "secondary") +
        btn(action, t("تأكيد", "Confirm"), "danger-btn", "check", extra),
    );
  }
  function updateFileGrid() {
    const grid = document.getElementById("file-grid");
    if (grid)
      grid.innerHTML =
        filteredFiles().map(fileTile).join("") ||
        `<p class="muted small">${t("لا توجد ملفات تطابق البحث.", "No files match your search.")}</p>`;
    const slot = document.getElementById("selection-slot");
    if (slot) slot.innerHTML = selectionbar();
  }
  function selectFile(id, value) {
    const selected = value === undefined ? !state.selected.has(id) : value;
    selected ? state.selected.add(id) : state.selected.delete(id);
    const element = root.querySelector(`[data-file="${id}"]`);
    element?.classList.toggle("selected", selected);
    element?.setAttribute("aria-pressed", String(selected));
    const slot = document.getElementById("selection-slot");
    if (slot) slot.innerHTML = selectionbar();
  }
  const baseMotion = Object.fromEntries(
    ["fast", "normal", "slow", "radar", "scanner", "skeleton"].map((key) => [
      key,
      parseFloat(
        getComputedStyle(document.documentElement).getPropertyValue(
          `--motion-${key}`,
        ),
      ),
    ]),
  );
  function applyMotion() {
    for (const [key, value] of Object.entries(baseMotion))
      document.documentElement.style.setProperty(
        `--motion-${key}`,
        `${value / state.speed}ms`,
      );
  }

  root.addEventListener("click", (event) => {
    if (event.target.classList.contains("overlay")) {
      closeModal();
      return;
    }
    const file = event.target.closest("[data-file]");
    if (file) {
      if (!suppressClick) selectFile(file.dataset.file);
      suppressClick = false;
      return;
    }
    const page = event.target.closest("[data-page]");
    if (page) {
      navigate(page.dataset.page);
      return;
    }
    const target = event.target.closest("[data-action]");
    if (!target) return;
    const { action, key, value, id } = target.dataset;
    switch (action) {
      case "close-modal":
        closeModal();
        break;
      case "explorer":
        showModal(
          t("كل زاوية من التجربة.", "Every corner of the experience."),
          `<p>${t("اختر شاشة لمراجعة تصميمها وحالاتها. كل المحتوى هنا تجريبي.", "Choose a screen to review its design and states. All content is illustrative.")}</p><div class="explorer-grid">${screens()
            .map(
              ([id, symbol, label]) =>
                `<button class="explorer-item ${state.page === id ? "active" : ""}" data-page="${id}">${icon(symbol)}${label}</button>`,
            )
            .join("")}</div>`,
          "",
          true,
        );
        break;
      case "theme":
        state.theme = state.theme === "light" ? "dark" : "light";
        render();
        break;
      case "language":
        state.lang = state.lang === "ar" ? "en" : "ar";
        render();
        break;
      case "frame":
        state.frame = value;
        render();
        break;
      case "motion":
        motionModal();
        break;
      case "manual":
      case "network-manual":
        manualModal();
        break;
      case "validate-manual":
        validateManual();
        break;
      case "manual-next":
        navigate("transfers");
        toast(
          t(
            "هذه صفحة جاهزية عيّنة. لم يتم الاتصال بالعنوان.",
            "Sample readiness screen. No connection was made.",
          ),
        );
        break;
      case "profile":
        profileModal();
        break;
      case "save-profile": {
        const name = document.getElementById("profile-name").value.trim(),
          deviceName = document.getElementById("device-name").value.trim();
        if (!name || !deviceName) {
          document.getElementById("profile-error").textContent = t(
            "اكتب اسمك واسم الجهاز للمتابعة.",
            "Enter a name and device name to continue.",
          );
          return;
        }
        state.name = name;
        state.deviceName = deviceName;
        render();
        toast(
          t("حُدّث ملفك في المعاينة فقط.", "Your preview profile was updated."),
        );
        break;
      }
      case "scan":
        state.scanning = !state.scanning;
        render();
        toast(
          t(
            "تغيّرت حالة الرادار التوضيحية. لا يجري فحص للشبكة.",
            "The illustrative radar state changed. No network scan is running.",
          ),
        );
        break;
      case "device": {
        const d = device(id);
        showModal(
          d.name,
          `<div class="flex" style="margin-bottom:17px"><span class="node-icon ${d.color}">${icon(d.type)}</span><div><h3>${owner(d)}</h3><p class="small muted"><bdi>${d.os} · ${d.ip}</bdi></p></div></div><p>${state.trusted.has(id) ? t("جهاز موثوق في بيانات العيّنة.", "A trusted device in the sample data.") : t("عند الاتصال لأول مرة، تحقق من البصمة ووافق من الجهازين.", "On first connection, verify the fingerprint and approve on both devices.")}</p><div class="fingerprint">8F:3A:62:BD:01:7C:9E:A4:55:2B:7F:31:C8:DA:09:42</div><p class="small subtle">${t("هذا الجهاز عيّنة، ولم يُكتشف عبر الشبكة.", "This is a sample device, not discovered over a network.")}</p>`,
          btn(
            "device-files",
            t("اختيار ملفات لإرسالها", "Choose files to send"),
            "primary",
            "folder",
            `data-id="${id}"`,
          ) +
            btn(
              "device-ready",
              t("معاينة الجاهزية", "Preview readiness"),
              "secondary",
              "check",
              `data-id="${id}"`,
            ),
        );
        break;
      }
      case "device-files":
        state.recipients = new Set([id]);
        navigate("files");
        break;
      case "device-ready":
        state.recipients = new Set([id]);
        navigate("transfers");
        break;
      case "choose-files":
        navigate("files");
        break;
      case "review-transfer":
        navigate("transfers");
        break;
      case "clear-selection":
        state.selected.clear();
        updateFileGrid();
        break;
      case "select-all": {
        const list = filteredFiles(),
          all = list.every((f) => state.selected.has(f.id));
        list.forEach((f) =>
          all ? state.selected.delete(f.id) : state.selected.add(f.id),
        );
        updateFileGrid();
        break;
      }
      case "category":
        state.fileCategory = value;
        state.search = "";
        if (state.page === "apps") state.page = "files";
        render();
        break;
      case "app-tab":
        state.appTab = value;
        render();
        break;
      case "file-layout":
        state.fileLayout = state.fileLayout === "grid" ? "list" : "grid";
        render();
        break;
      case "folder-share":
      case "custom-folder":
        showModal(
          t("مساحة باسمك.", "A space with your name."),
          `<p>${t("سمِّ مجلدك المخصص لمراجعة شكل التبويب. في التطبيق الحقيقي سيُفتح منتقي Android الآمن.", "Name a custom folder to preview its tab. The real app will open Android’s secure folder picker.")}</p><label class="field">${t("اسم المجلد", "Folder name")}<input id="custom-folder-name" value="${safe(state.customName)}" maxlength="25" placeholder="${t("مثل: مشاريعي", "e.g. My projects")}"></label>`,
          btn(
            "save-folder",
            t("إضافة تبويب تجريبي", "Add preview tab"),
            "primary",
            "plus",
          ),
        );
        break;
      case "save-folder": {
        const name = document.getElementById("custom-folder-name").value.trim();
        if (!name) {
          document.getElementById("custom-folder-name").focus();
          return;
        }
        state.customName = name;
        state.fileCategory = "custom";
        navigate("files");
        toast(
          t(
            "أُضيف تبويب عيّنة، ولم تُمنح أي صلاحية مجلد.",
            "A sample tab was added. No folder access was granted.",
          ),
        );
        break;
      }
      case "text-share":
        showModal(
          t("أحيانًا، تكفي كلمة.", "Sometimes a word is enough."),
          `<p>${t("اكتب نصًا أو رابطًا لمراجعة خطوات المشاركة. يبقى في هذه الصفحة فقط.", "Enter text or a link to review the sharing flow. It stays in this page.")}</p><label class="field">${t("النص أو الرابط", "Text or link")}<textarea id="shared-text" placeholder="${t("ما الذي يدور في بالك؟", "What is on your mind?")}" maxlength="4000"></textarea></label>`,
          btn(
            "send-text-preview",
            t("اختيار المستلم", "Choose recipient"),
            "primary",
            "send",
          ),
        );
        break;
      case "send-text-preview":
        if (!document.getElementById("shared-text").value.trim()) {
          document.getElementById("shared-text").focus();
          return;
        }
        state.textSize = new TextEncoder().encode(
          document.getElementById("shared-text").value,
        ).length;
        state.selected.add("text-sample");
        navigate("transfers");
        toast(
          t(
            "انتقلت إلى تصميم اختيار المستلم. لن يُرسل النص.",
            "Showing recipient selection. Your text will not be sent.",
          ),
        );
        break;
      case "recipient":
        state.recipients.has(id)
          ? state.recipients.delete(id)
          : state.recipients.add(id);
        render();
        break;
      case "start-transfer":
        showModal(
          t("كل شيء في مكانه.", "Everything in its place."),
          `<div class="dialog-icon">${icon("send")}</div><p>${t("ستُعرض حالة نقل متحركة للمستلمين الذين اخترتهم. لا يتم إرسال ملفات أو طلب اتصال.", "Animated progress will be shown for the recipients you selected. No files are sent or connections requested.")}</p>`,
          btn(
            "confirm-start",
            t("عرض التقدم التجريبي", "Show sample progress"),
            "primary",
            "play",
          ),
        );
        break;
      case "confirm-start":
        state.transferDevices = [...state.recipients];
        state.cancelled.clear();
        state.paused.clear();
        state.progress = 8;
        render();
        document.querySelector(".section-gap")?.scrollIntoView({
          behavior: state.reduced ? "instant" : "smooth",
          block: "start",
        });
        toast(
          t(
            "تقدم متحرك ببيانات عيّنة. لا يوجد نقل فعلي.",
            "Animated sample progress. No actual transfer.",
          ),
        );
        break;
      case "transfer-tab":
        state.transferTab = value;
        render();
        break;
      case "pause-transfer":
        state.paused.has(id) ? state.paused.delete(id) : state.paused.add(id);
        render();
        break;
      case "cancel-transfer":
        confirmDialog(
          t("إلغاء هذه العملية التجريبية؟", "Cancel this sample transfer?"),
          t(
            "يؤثر هذا على حالة العرض لهذا المستلم فقط، ولا يمس بقية المستلمين.",
            "This changes only this recipient’s design state, not the others.",
          ),
          "confirm-cancel",
          `data-id="${id}"`,
        );
        break;
      case "confirm-cancel":
        state.cancelled.add(id);
        render();
        toast(
          t("أُلغيت العملية في المعاينة.", "The sample transfer was cancelled."),
        );
        break;
      case "permission":
        permissionModal(key);
        break;
      case "permission-choice":
        state.permissions[key] = value;
        render();
        toast(
          t(
            "حُدّثت حالة الإذن التوضيحية فقط.",
            "Only the illustrative permission state was changed.",
          ),
        );
        break;
      case "toggle": {
        const modalKind = activeModal?.kind;
        if (key.startsWith("setting:")) {
          const setting = key.slice(8);
          if (setting === "encryption" && state.settings.encryption) {
            confirmDialog(
              t(
                "المحتوى سيكون غير مشفّر.",
                "Your content would be unencrypted.",
              ),
              t(
                "وضع الأداء الأقصى في التطبيق الحقيقي يُبقي مصادقة المقاطع، لكنه لا يخفي المحتوى. لا تستخدمه إلا على شبكة موثوقة. هذا تغيير تصميمي فقط.",
                "Production performance mode authenticates chunks but does not hide their contents. Use only on a trusted network. This is a design-only change.",
              ),
              "confirm-performance",
            );
            return;
          }
          state.settings[setting] = !state.settings[setting];
        } else state[key] = !state[key];
        render();
        if (modalKind === "motion") motionModal();
        break;
      }
      case "confirm-performance":
        state.settings.encryption = false;
        render();
        toast(
          t(
            "حالة تصميم: التشفير غير مفعّل. لا يوجد نقل فعلي.",
            "Design state: encryption off. No actual transfer.",
          ),
        );
        break;
      case "consent-once":
      case "consent-trust":
      case "consent-reject":
      case "consent-block": {
        state.receiveDecision = action.replace("consent-", "");
        if (action === "consent-trust") state.trusted.add("iphone");
        if (action === "consent-block") {
          state.blocked.add("iphone");
          state.trusted.delete("iphone");
          state.recipients.delete("iphone");
        }
        render();
        toast(
          t(
            "حُدّث طلب العيّنة. لم يتم قبول ملفات أو إنشاء اتصال.",
            "The sample request was updated. No files accepted or connection made.",
          ),
        );
        break;
      }
      case "reset-consent":
        state.receiveDecision = null;
        render();
        break;
      case "qr-tab":
        state.qrTab = value;
        render();
        break;
      case "torch":
        state.torch = !state.torch;
        render();
        toast(
          t(
            "تبديل المصباح توضيحي فقط. الكاميرا غير مستخدمة.",
            "Illustrative flashlight state only. Camera is not used.",
          ),
        );
        break;
      case "zoom":
        state.zoom = (Number(state.zoom || 1) % 3) + 1;
        render();
        break;
      case "sample-gallery":
        toast(
          t(
            "في التطبيق الحقيقي يفتح منتقي الصور لقراءة QR محليًا.",
            "The real app opens a photo picker to read a QR locally.",
          ),
        );
        break;
      case "history-filter":
        state.historyFilter = value;
        render();
        break;
      case "history-detail": {
        const r = historyRecords().find((r) => r.id === id);
        showModal(
          t("تفاصيل المشاركة", "Share details"),
          `<div class="bundle"><span class="file-icon ${r.color}">${icon(r.type)}</span><div><strong>${safe(r.name)}</strong><p class="latin">${r.size}</p></div></div><p><bdi>${r.device}</bdi> · ${r.time}</p><div class="info-banner ${r.status === "failed" ? "warning" : ""}">${icon(r.status === "failed" ? "warning" : "checkCircle")}<div>${r.status === "failed" ? t("عينة لانقطاع الاتصال. يمكن عرض تصميم الاستئناف.", "Sample connection loss. Review the resume design.") : t("عملية مكتملة في بيانات العيّنة، وليست ملفًا مستلمًا فعليًا.", "A completed sample record, not an actually received file.")}</div></div>`,
          btn(
            r.status === "failed" ? "open-transfers" : "show-folder",
            r.status === "failed"
              ? t("معاينة الاستئناف", "Preview resume")
              : t("عرض ملفات العيّنة", "View sample files"),
            "primary",
            r.type,
          ),
        );
        break;
      }
      case "clear-history":
        confirmDialog(
          t("نبدأ صفحة جديدة؟", "A fresh page?"),
          t(
            "سيُمسح سجل العيّنة في هذه الجلسة فقط. لا تُحذف أي ملفات.",
            "Clear sample history for this session only. No files are deleted.",
          ),
          "confirm-clear-history",
        );
        break;
      case "confirm-clear-history":
        state.historyRemoved = true;
        render();
        toast(t("مُسحت سجلات العيّنة فقط.", "Only sample records were cleared."));
        break;
      case "show-folder":
        state.fileCategory = "downloads";
        navigate("files");
        break;
      case "open-permissions":
        navigate("permissions");
        break;
      case "open-transfers":
        navigate("transfers");
        break;
      case "web-choose":
        navigate("files");
        toast(
          t(
            "اختر ملفات عيّنة لمراجعة نطاق المشاركة.",
            "Choose sample files to review the share scope.",
          ),
        );
        break;
      case "copy-url": {
        const range = document.createRange(),
          selection = window.getSelection();
        range.selectNodeContents(document.querySelector(".sample-url"));
        selection.removeAllRanges();
        selection.addRange(range);
        toast(
          t(
            "الرابط محدد. انسخه يدويًا؛ إنه عنوان عيّنة لا يخدم ملفات.",
            "Link selected. Copy manually; this sample address serves no files.",
          ),
        );
        break;
      }
      case "watch-play":
        state.watchPlaying = !state.watchPlaying;
        render();
        break;
      case "end-watch":
        confirmDialog(
          t("إنهاء جلسة التصميم؟", "End this design session?"),
          t(
            "ستظهر الحالة الفارغة لغرفة المشاهدة، دون إنهاء أي بث حقيقي.",
            "Show the room’s empty state. There is no real stream to end.",
          ),
          "confirm-end-watch",
        );
        break;
      case "confirm-end-watch":
        state.watchEnded = true;
        state.watchPlaying = false;
        render();
        break;
      case "restart-watch":
        state.watchEnded = false;
        render();
        break;
      case "invite-watch":
        showModal(
          t("لحظة أجمل، حين تُشارك.", "A better moment, shared."),
          `<div class="qr-wrap large">${qrSvg()}</div><p class="small muted">${t("رمز لعنوان عيّنة فقط. لا توجد غرفة بث حقيقية.", "A QR of a sample address only. No real streaming room exists.")}</p>`,
          btn("close-modal", t("تم", "Close"), "primary", "check"),
        );
        break;
      case "watch-options":
        showModal(
          t("الصوت والترجمات", "Audio & subtitles"),
          `<p>${t("خيارات واجهة عيّنة، لا يوجد فيديو مُشغّل.", "Sample interface options. No video is playing.")}</p><label class="field">${t("المسار الصوتي", "Audio track")}<select><option>${t("الأصلي · ستيريو", "Original · Stereo")}</option><option>${t("تعليق المخرج (عيّنة)", "Commentary (sample)")}</option></select></label><label class="field">${t("الترجمة", "Subtitles")}<select><option>${t("العربية · SRT", "Arabic · SRT")}</option><option>English · VTT</option><option>${t("إيقاف", "Off")}</option></select></label>`,
          btn("close-modal", t("حفظ", "Save"), "primary", "check"),
        );
        break;
      case "watch-volume":
        showModal(
          t("الصوت", "Volume"),
          `<p>${t("مستوى صوت توضيحي، لا يغير صوت النظام.", "Illustrative volume, does not change system volume.")}</p><input type="range" min="0" max="100" value="70" aria-label="${t("مستوى الصوت", "Volume level")}" style="width:100%;margin-top:20px">`,
          btn("close-modal", t("تم", "Close"), "primary"),
        );
        break;
      case "watch-fullscreen":
        if (document.fullscreenElement) document.exitFullscreen?.();
        else
          document
            .querySelector(".video-design")
            .requestFullscreen?.()
            .catch(() =>
              toast(
                t(
                  "ملء الشاشة غير متاح في هذا المتصفح.",
                  "Fullscreen is not available in this browser.",
                ),
              ),
            );
        break;
      case "security-tab":
        state.securityTab = value;
        render();
        break;
      case "remove-security":
        confirmDialog(
          state.securityTab === "trusted"
            ? t("إلغاء الوثوق بالجهاز؟", "Revoke this device’s trust?")
            : t("إلغاء حظر الجهاز؟", "Unblock this device?"),
          t(
            "يغيّر هذا قائمة العيّنة فقط. لا يؤثر على أجهزة حقيقية.",
            "Changes only the sample list. No real devices are affected.",
          ),
          "confirm-remove-security",
          `data-id="${id}"`,
        );
        break;
      case "confirm-remove-security":
        (state.securityTab === "trusted"
          ? state.trusted
          : state.blocked
        ).delete(id);
        render();
        break;
      case "notifications":
        state.gallery = "notifications";
        navigate("gallery");
        break;
      case "gallery-tab":
        state.gallery = value;
        render();
        break;
      case "widget-theme":
        state.galleryTheme = state.galleryTheme === "light" ? "dark" : "light";
        render();
        break;
      case "gallery-pause":
        state.galleryPaused = !state.galleryPaused;
        render();
        toast(
          t(
            "تغيّرت حالة الإيقاف في تصميم الإشعار والويدجت.",
            "The notification/widget pause design state changed.",
          ),
        );
        break;
      case "gallery-cancel":
        state.galleryCancelled = !state.galleryCancelled;
        render();
        toast(
          t(
            "تغيّرت حالة الإلغاء في بيانات العيّنة فقط.",
            "Cancellation state changed in sample data only.",
          ),
        );
        break;
      case "notification-consent":
        state.receiveDecision = value;
        if (value === "block") {
          state.blocked.add("iphone");
          state.trusted.delete("iphone");
          state.recipients.delete("iphone");
        }
        render();
        toast(
          t(
            "تم التعامل مع طلب عيّنة، وليس إشعار Android حقيقيًا.",
            "A sample request was handled, not a real Android notification.",
          ),
        );
        break;
      case "sample-open":
        showModal(
          t("عرض ملف عيّنة", "Sample file preview"),
          `<img src="assets/art/landscape-1.svg" alt="${t("رسم طبيعي أصلي", "Original landscape illustration")}" style="width:100%;border-radius:12px"><p class="small muted mt">${t("رسم SVG محلي، وليس ملفًا مستلمًا.", "Local SVG artwork, not a received file.")}</p>`,
        );
        break;
      case "sample-share":
        toast(
          t(
            "تصميم لزر المشاركة فقط. لم تُرسل أي ملفات.",
            "Share-button design only. No files were sent.",
          ),
        );
        break;
      case "gallery-multi":
        state.transferDevices = ["mac", "iphone", "tab"];
        state.cancelled.clear();
        navigate("transfers");
        break;
      case "widget-web":
        state.web = !state.web;
        render();
        break;
      case "widget-retry":
        navigate("permissions");
        break;
      case "error-state":
        state.errorState = value;
        render();
        break;
      case "network-options":
        networkModal();
        break;
      case "storage-info":
      case "https-info":
      case "background-info":
      case "helper-info":
      case "visibility-info":
        infoModal(action);
        break;
      case "notification-settings":
        showModal(
          t("كل تنبيه، في مكانه.", "Every notification in its place."),
          `<p>${t("قنوات Android المخططة، وليست إعدادات النظام الفعلية.", "Planned Android channels, not actual system settings.")}</p>${[
            [
              t("عمليات النقل", "Transfers"),
              t("منخفضة · بدون صوت", "Low · Silent"),
            ],
            [
              t("طلبات الاتصال", "Connection requests"),
              t("عالية · تنبيه عائم", "High · Heads-up"),
            ],
            [
              t("الاكتمال والفشل", "Completion & failure"),
              t("متوسطة", "Default importance"),
            ],
            [
              t("الويب وغرف المشاهدة", "Web & watch rooms"),
              t("منخفضة · بدون صوت", "Low · Silent"),
            ],
          ]
            .map(
              ([name, detail]) =>
                `<div class="setting-row"><div class="setting-copy"><strong>${name}</strong><p>${detail}</p></div>${icon("bell", "sm")}</div>`,
            )
            .join("")}`,
          btn(
            "show-notifications",
            t("عرض تصاميم الإشعارات", "View notification designs"),
            "primary",
            "bell",
          ),
        );
        break;
      case "show-notifications":
        state.gallery = "notifications";
        navigate("gallery");
        break;
      default:
        break;
    }
  });

  root.addEventListener("input", (event) => {
    const target = event.target;
    if (target.id === "file-search") {
      state.search = target.value;
      updateFileGrid();
    }
    if (target.id === "history-search") {
      state.historySearch = target.value;
      document.getElementById("history-table").innerHTML = historyTable();
    }
    if (target.id === "watch-seek") {
      state.watchPosition = Number(target.value);
      document.getElementById("watch-time").textContent =
        `${Math.floor((state.watchPosition / 100) * 94)}:24`;
    }
    if (target.id === "manual-address") target.removeAttribute("aria-invalid");
  });
  root.addEventListener("change", (event) => {
    const target = event.target;
    switch (target.id) {
      case "file-sort":
        state.sort = target.value;
        updateFileGrid();
        break;
      case "web-protocol":
        state.webProtocol = target.value;
        render();
        if (target.value === "https") infoModal("https-info");
        break;
      case "web-scope":
        state.webScope = target.value;
        render();
        if (target.value === "manager") infoModal("storage-info");
        break;
      case "watch-control":
        state.watchControl = target.value;
        toast(
          t(
            "حُفظ إعداد تحكم الغرفة في المعاينة.",
            "Room-control preference updated in the preview.",
          ),
        );
        break;
      case "gallery-state":
        state.galleryState = target.value;
        render();
        break;
      case "motion-speed":
        state.speed = Number(target.value);
        applyMotion();
        break;
      case "parallel-connections":
        toast(
          t(
            "إعداد عيّنة فقط. عدد الاتصالات الحقيقي سيُقاس عند التنفيذ.",
            "Sample setting only. Real concurrency will be measured during implementation.",
          ),
        );
        break;
      case "network-port":
        if (Number(target.value) < 1024 || Number(target.value) > 65535) {
          target.value = "53317";
          toast(
            t(
              "اختر منفذًا بين 1024 و65535.",
              "Choose a port between 1024 and 65535.",
            ),
          );
        }
        break;
      default:
        break;
    }
  });
  root.addEventListener("keydown", (event) => {
    const dialog = document.querySelector(".dialog");
    if (event.key === "Escape" && dialog) {
      event.preventDefault();
      closeModal();
      return;
    }
    if (event.key === "Enter" && event.target.id === "manual-address") {
      event.preventDefault();
      validateManual();
      return;
    }
    if (event.key === "Tab" && dialog) {
      const focusable = [
        ...dialog.querySelectorAll(
          'button:not(:disabled),input,textarea,select,[tabindex="0"]',
        ),
      ].filter((el) => el.getClientRects().length);
      const first = focusable[0],
        last = focusable[focusable.length - 1];
      if (
        event.shiftKey &&
        (document.activeElement === first || document.activeElement === dialog)
      ) {
        event.preventDefault();
        last?.focus();
      } else if (
        !event.shiftKey &&
        (document.activeElement === last || document.activeElement === dialog)
      ) {
        event.preventDefault();
        first?.focus();
      }
    }
  });

  // A single pointer gesture selects multiple samples without reading actual files.
  let dragStart = null,
    dragActive = false,
    dragValue = true,
    longPress = null,
    suppressClick = false;
  root.addEventListener("pointerdown", (event) => {
    const file = event.target.closest("[data-file]");
    if (!file) return;
    dragStart = file.dataset.file;
    dragValue = !state.selected.has(dragStart);
    dragActive = event.pointerType === "mouse";
    suppressClick = false;
    if (event.pointerType !== "mouse")
      longPress = setTimeout(() => {
        dragActive = true;
        suppressClick = true;
        selectFile(dragStart, dragValue);
      }, 380);
  });
  root.addEventListener("pointerover", (event) => {
    if (!dragActive || !dragStart) return;
    const file = event.target.closest("[data-file]");
    if (file && file.dataset.file !== dragStart) {
      suppressClick = true;
      selectFile(dragStart, dragValue);
      selectFile(file.dataset.file, dragValue);
    }
  });
  document.addEventListener("pointerup", () => {
    clearTimeout(longPress);
    dragActive = false;
    dragStart = null;
  });
  document.addEventListener("pointercancel", () => {
    clearTimeout(longPress);
    dragActive = false;
    dragStart = null;
  });
  root.addEventListener("contextmenu", (event) => {
    if (event.target.closest("[data-file]")) event.preventDefault();
  });
  root.addEventListener("dragstart", (event) => {
    if (event.target.closest("[data-file]")) event.preventDefault();
  });
  root.addEventListener("dragover", (event) => {
    event.preventDefault();
    event.target.closest("[data-dropzone]")?.classList.add("dragover");
  });
  root.addEventListener("dragleave", (event) => {
    event.target.closest("[data-dropzone]")?.classList.remove("dragover");
  });
  root.addEventListener("drop", (event) => {
    event.preventDefault();
    document.querySelector(".dragover")?.classList.remove("dragover");
    toast(
      t(
        "هذه معاينة تصميم. لم تُقرأ ملفاتك أو تُرفع.",
        "This is a design preview. Your files were not read or uploaded.",
      ),
    );
  });
  root.addEventListener("dblclick", (event) => {
    const file = event.target.closest("[data-file]");
    if (!file) return;
    const record = sampleFiles().find((f) => f.id === file.dataset.file);
    if (!record || !["images", "videos", "music"].includes(record.cat)) return;
    const source = file.querySelector("img"),
      sourceBox = source?.getBoundingClientRect();
    showModal(
      safe(record.name),
      `<img class="hero-preview-target" src="assets/art/landscape-${(record.index % 8) + 1}.svg" alt="${safe(record.name)}" style="width:100%;border-radius:14px"><p class="small muted mt">${t("رسم عيّنة أصلي مولّد محليًا، وليس ملفًا من جهازك.", "Original local sample artwork, not a file from your device.")}</p>`,
    );
    if (sourceBox && !state.reduced && !state.low) {
      const target = document.querySelector(".hero-preview-target");
      requestAnimationFrame(() => {
        const box = target.getBoundingClientRect(),
          clone = source.cloneNode();
        clone.className = "hero-image-clone";
        clone.style.cssText = `top:${box.top}px;left:${box.left}px;width:${box.width}px;height:${box.height}px;border-radius:14px`;
        document.body.appendChild(clone);
        target.style.opacity = "0";
        clone
          .animate(
            [
              {
                transform: `translate(${sourceBox.left - box.left}px,${sourceBox.top - box.top}px) scale(${sourceBox.width / box.width},${sourceBox.height / box.height})`,
                opacity: 0.9,
              },
              { transform: "translate(0,0) scale(1)", opacity: 1 },
            ],
            {
              duration: baseMotion.slow / state.speed,
              easing: "cubic-bezier(0.2,0.7,0.2,1)",
            },
          )
          .finished.then(() => {
            clone.remove();
            target.style.opacity = "1";
          });
      });
    }
  });
  window.addEventListener("hashchange", () => {
    const page = location.hash.slice(1);
    if (page !== state.page) navigate(page);
  });
  setInterval(() => {
    if (document.hidden) return;
    if (
      state.transferDevices.some(
        (id) => !state.paused.has(id) && !state.cancelled.has(id),
      )
    ) {
      state.progress = state.progress >= 97 ? 64 : state.progress + 0.13;
      document.querySelectorAll("[data-transfer]").forEach((row) => {
        if (state.paused.has(row.dataset.transfer)) return;
        row.querySelector(".progress-fill").style.transform =
          `scaleX(${state.progress / 100})`;
        row
          .querySelector("[role=progressbar]")
          .setAttribute("aria-valuenow", String(Math.floor(state.progress)));
        row.querySelector("[data-percent]").textContent =
          `${Math.floor(state.progress)}%`;
        row.querySelector("[data-sent-size]").textContent = (
          state.progress * 0.02
        ).toFixed(2);
      });
    }
    if (state.watchPlaying && state.page === "watch") {
      state.watchPosition = (state.watchPosition + 0.025) % 100;
      const seek = document.getElementById("watch-seek");
      if (seek) seek.value = String(state.watchPosition);
      const time = document.getElementById("watch-time");
      if (time)
        time.textContent = `${Math.floor((state.watchPosition / 100) * 94)}:24`;
    }
  }, 1000);
  const initial = location.hash.slice(1);
  if (screens().some((s) => s[0] === initial)) state.page = initial;
  render();
  window.SisiPreview = Object.freeze({ version: "0.1.0", designOnly: true });
})();
