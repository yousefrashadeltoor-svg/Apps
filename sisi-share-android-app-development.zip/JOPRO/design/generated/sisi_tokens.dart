// Generated design reference, not an implemented Android application.
abstract final class SisiTokens {
  static const background = 0xFFF7F9F8;
  static const surface = 0xFFFFFFFF;
  static const surfaceAlt = 0xFFF0F5F2;
  static const text = 0xFF20372F;
  static const textSecondary = 0xFF596E62;
  static const textMuted = 0xFF617568;
  static const primary = 0xFF157B62;
  static const primaryHover = 0xFF10644F;
  static const primarySoft = 0xFFE8F3ED;
  static const radar = 0xFFF0F7F2;
  static const ring = 0xFFD9E8DE;
  static const border = 0xFFE7ECE8;
  static const danger = 0xFFB14944;
  static const dangerSoft = 0xFFFCF0ED;
  static const warning = 0xFF906423;
  static const warningSoft = 0xFFFCF6E9;
  static const blue = 0xFF6C8DA9;
  static const radiusPanel = 22.0;
  static const motionNormalMs = 280;
}
