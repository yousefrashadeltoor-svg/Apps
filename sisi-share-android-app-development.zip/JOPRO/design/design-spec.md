# SISI Share: Visual Contract, Version 0.1

## Identity and Tokens

Original Arabic-first workspace, not a LocalSend reskin. Warm-white canvas, forest-green accents, generous negative space, fine dividers and a custom two-arrow S mark. Brand at the top of the navigation rail. `tokens.json` is the sole source of palette, radii, spacing, elevation and motion. Locally hosted IBM Plex Sans Arabic and Inter, weights 400/500/600/700. Body 14px/1.8, supporting 12px, page titles 29px/600. Addresses, file extensions and device names are LTR-isolated.

## Shell, Accessibility and Frames

- Desktop: 232px right sidebar, 85px topbar, 40px page gutters, 49px persistent preview toolbar.
- Tablet: narrower rail; phone: maximum 412px frame, single column, five-action bottom navigation, screen explorer for other destinations.
- Targets at least 48px, visible focus, labeled controls. Escape closes dialogs, Tab is trapped, focus returns to the trigger. Dialogs use aria-modal; progress has progressbar semantics.
- Light/dark and Arabic/English are independent. Optional appearance persistence. Preview warning always visible, including phone mode.

## Screen Specifications

| Screen | Composition | States and actions |
| --- | --- | --- |
| Home/radar | Intro; two-column radar and drop area; active transfer; recent operations | Search/stop, device selection, manual connect, QR, choose files, pause/cancel |
| File manager | Category tabs, search/sort, thumbnail grid, selection footer | Images, videos, music, docs, archives, installed/package apps, contacts, downloads, custom folder; select all, pointer-drag and touch long press |
| Transfer | Selected bundle, readiness checklist, receivers, summary | Single/multiple receivers; necessary checks; independent pause/cancel |
| Receive | Visibility, real QR of sample URL, connection request | Accept once/trust/reject/block; notification rationale |
| QR | Scanner design and QR display tabs | Gallery, torch/zoom design states; manual entry; never accesses camera |
| History | Search and direction/status-filtered table | Retry opens readiness; clear confirmation; empty state |
| Web sharing | Server switch, sample URL/QR, scope | HTTP/HTTPS design, read/upload scope, approval message; no server |
| Watch together | Original SVG poster and room panel | Play/pause, seek, sample synchronization, codec constraint, end room |
| Settings | Grouped sections without clutter | Profile, storage, concurrency, encryption, integrity, theme/language, networks, helper explanation, privacy |
| Permissions | Reason, consequence of denial, preview-only state | Just-in-time rationale, granted/denied/partial/settings states |
| Trusted/blocked | Fingerprint-based management design | Tabs, revoke/unblock, confirmation, empty |
| Notifications/widgets | Android-inspired shade and home-screen gallery | Five notifications, five widgets, dp-inspired sizes, loading/empty/error, both themes |
| States | One focused empty/error state | Offline, storage full, denied, no devices, service timeout, next action |

## Shared Components

Primary buttons solid green; secondary actions thin borders; danger muted red. Panels group interactions, not decoration. 18-22px panel corners, 12px buttons. No heavy blur. Radar concentric rings 130/220/310px with a 62px identity and three device nodes. Sample artwork is deterministic original SVG. Tables use separators. Toasts never claim an actual transfer or permission operation.

## Motion

- Shared-axis entrance: 280ms, 8px translate/opacity, token ease.
- Dialogs: 280ms, 12px translate/opacity; shade opacity only.
- Selection: 160ms transform/opacity, no layout animation.
- Radar: 4200ms staggered transform/opacity loops, stopped when scan or visibility is off.
- Progress: scaleX over 460ms, sample updates at most once/second without page redraw.
- Reduced motion removes loops/translations. Low-power removes extra rings. Speed control multiplies durations. OS reduced motion honored.

## Validation

Browser tests cover file://, no remote requests, navigation, dialogs, language/theme/frame, selection, readiness, consent, real QR and gallery states. Screenshot script captures the preview and reports Flutter comparison unavailable until a real matching golden is supplied. Future comparison threshold 0.2, maximum changed-pixel ratio 1%; document font-rasterization differences. Owner visual approval remains pending.