import { chromium } from "@playwright/test";
import { PNG } from "pngjs";
import pixelmatch from "pixelmatch";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { pathToFileURL, fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const output = path.join(root, "docs/screenshots");
const goldenArg = process.argv.find((a) => a.startsWith("--goldens="));
const goldenDir = goldenArg ? path.resolve(goldenArg.slice(10)) : null;
await mkdir(output, { recursive: true });
const browser = await chromium.launch();
const cases = [
  ["desktop-home", "home", 1440, 1000],
  ["phone-home", "home", 390, 844],
  ["desktop-files", "files", 1440, 1000],
  ["desktop-gallery", "gallery", 1440, 1000],
];
const report = [
  "# Visual Comparison Report",
  "",
  "Preview captures are real browser output. Flutter comparison is only possible with real Flutter goldens.",
  "",
  `Browser: ${browser.version()}`,
  "",
  "| Capture | Preview | Flutter comparison |",
  "| --- | --- | --- |",
];
let failed = false;
for (const [name, screen, width, height] of cases) {
  const page = await browser.newPage({
    viewport: { width, height },
    reducedMotion: "reduce",
  });
  await page.addInitScript(() => {
    window.setInterval = () => 0;
  });
  await page.goto(
    `${pathToFileURL(path.join(root, "index.html")).href}#${screen}`,
  );
  await page.evaluate(() => document.fonts.ready);
  const screenshot = await page.screenshot({
    path: path.join(output, `${name}.png`),
    animations: "disabled",
  });
  if (!goldenDir) {
    report.push(
      `| ${name} | Captured | NOT VERIFIED: Flutter is not implemented in phase 0 |`,
    );
  } else {
    try {
      const a = PNG.sync.read(screenshot),
        b = PNG.sync.read(await readFile(path.join(goldenDir, `${name}.png`)));
      if (a.width !== b.width || a.height !== b.height)
        throw new Error("Golden dimensions do not match");
      const diff = new PNG({ width: a.width, height: a.height });
      const changed = pixelmatch(a.data, b.data, diff.data, a.width, a.height, {
        threshold: 0.2,
        includeAA: false,
      });
      const ratio = changed / (a.width * a.height),
        pass = ratio <= 0.01;
      await writeFile(
        path.join(output, `${name}-diff.png`),
        PNG.sync.write(diff),
      );
      report.push(
        `| ${name} | Captured | ${pass ? "PASS" : "FAIL"}: ${(ratio * 100).toFixed(3)}% changed (limit 1%) |`,
      );
      if (!pass) failed = true;
    } catch (error) {
      report.push(`| ${name} | Captured | NOT VERIFIED: ${error.message} |`);
      failed = true;
    }
  }
  await page.close();
}
await browser.close();
report.push(
  "",
  "No Android screenshot, native test, benchmark or APK result is implied.",
);
await writeFile(
  path.join(root, "docs/VISUAL-REPORT.md"),
  report.join("\n") + "\n",
);
console.log(report.join("\n"));
if (failed) process.exitCode = 1;
