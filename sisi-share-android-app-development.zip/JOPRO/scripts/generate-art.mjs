import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const out = path.join(root, "assets/art");
await mkdir(out, { recursive: true });
const palettes = [
  ["#e5dfcc", "#f3efdd", "#b5b69c", "#7d9987", "#3b6958", "#bbcfb6"],
  ["#c4d8db", "#e6ece0", "#a8bdba", "#6d9993", "#365e62", "#b7d4cd"],
  ["#ead9c6", "#f4e8d4", "#c7ac89", "#9a9670", "#606e52", "#d7c9a1"],
  ["#d9e4ce", "#f5f1db", "#b7c498", "#8d9e6c", "#4e7050", "#c0d0a7"],
  ["#e5c6b8", "#f4deba", "#c99f94", "#ae8e7a", "#656f5a", "#d4c4a3"],
  ["#cdd4d0", "#eef0e5", "#abb8ac", "#7e9c8e", "#486c5e", "#b4c5b3"],
  ["#c6dbe0", "#e9e7d5", "#b8cabc", "#8ea9a2", "#416e6e", "#c5dcd0"],
  ["#ded5db", "#f1e4dc", "#bdacb7", "#9297a0", "#526b72", "#c3c4bc"],
];
function landscape(i, wide = false) {
  const [sky, sun, far, mid, front, water] = palettes[i];
  let trees = "";
  for (let j = 0; j < 17; j++) {
    const x = j * 83 - 35,
      y = 555 + Math.sin(j * 2.3 + i) * 40,
      h = 75 + ((j * 31) % 90);
    trees += `<path d="M${x} ${y - h}l-${h * 0.31} ${h * 0.65}h${h * 0.15}l-${h * 0.26} ${h * 0.45}h${h * 0.83}l-${h * 0.26}-${h * 0.45}h${h * 0.15}Z" fill="${front}" opacity="${j % 2 ? 0.8 : 0.55}"/>`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="${wide ? 720 : 800}" viewBox="0 0 1200 800"><defs><linearGradient id="sky" x2="0" y2="1"><stop stop-color="${sky}"/><stop offset="1" stop-color="${sun}"/></linearGradient><linearGradient id="lake" x2="0" y2="1"><stop stop-color="${water}"/><stop offset="1" stop-color="${mid}"/></linearGradient></defs><path fill="url(#sky)" d="M0 0h1200v800H0z"/><circle cx="${780 - i * 57}" cy="${175 + i * 7}" r="${46 + i * 3}" fill="${sun}"/><path d="m-80 480 235-227 130 130 170-215 230 267 172-199 230 274 163-190v320H-80Z" fill="${far}"/><path d="m180 383 105-130 58 72 112-157 72 84-75-43-49 113-36-17-65 91-62-55Z" fill="${sun}" opacity=".38"/><path d="M-50 410q180-92 360 76t410-23 530-89v426H-50Z" fill="${mid}"/><path d="M0 554q250-65 536 7t664-41v280H0Z" fill="url(#lake)"/><path d="M-30 480q190-26 390 110l-120 32-110 28-160 4Zm1260-29q-180 22-314 140l126 39 188-11Z" fill="${front}"/>${trees}<path d="M330 637q180-12 400 0M460 680h360m-460 45h220m-90 36h365" stroke="${sun}" opacity=".23" stroke-width="3" stroke-linecap="round"/><path d="M0 721q220-37 400 79H0Zm1200-27q-175 5-280 106h280Z" fill="${front}"/><path d="m619 609 22 7-10 6-22-7z" fill="${front}"/><path d="m629 611 5-28 3 30z" fill="${sun}"/></svg>`;
}
for (let i = 0; i < 8; i++)
  await writeFile(path.join(out, `landscape-${i + 1}.svg`), landscape(i));
await writeFile(path.join(out, "trip.svg"), landscape(0));
await writeFile(path.join(out, "poster.svg"), landscape(5, true));
await writeFile(
  path.join(root, "assets/brand.svg"),
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><rect width="48" height="48" rx="15" fill="#157b62"/><g transform="translate(4 4)" stroke="white" stroke-width="3.3" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M8 16h19l-6-6m11 14H13l6 6M8 16l6 6m18 2-6-6"/></g></svg>',
);
console.log(
  "Created ten original local SVG sample illustrations and brand mark.",
);
