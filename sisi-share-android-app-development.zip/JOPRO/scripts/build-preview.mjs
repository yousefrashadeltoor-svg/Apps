import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const repository = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "../..",
);
for (const script of [
  "JOPRO/scripts/generate-tokens.mjs",
  "scripts/sync-preview.mjs",
]) {
  execFileSync(process.execPath, [script], {
    cwd: repository,
    stdio: "inherit",
  });
}
execFileSync("npm", ["run", "build"], { cwd: repository, stdio: "inherit" });
console.log(
  "Built the preview host. This is not an Android APK or the production web client.",
);
