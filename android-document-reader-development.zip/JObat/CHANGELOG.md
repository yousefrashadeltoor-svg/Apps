# Changelog

## [1.0.0-phase1] — 2026
### Added
- Gradle Kotlin DSL multi-module structure with version catalog; R8 full mode, shrinkResources, ABI splits, AAB.
- Design tokens (`design-system/tokens/tokens.json`) + generator producing Compose `JoBatTokens.kt` and preview CSS.
- `:design-system`: JoBatTheme (Dark/Light/AMOLED/Sepia/Dynamic/System), typography with subset fonts, motion honouring Reduce Motion, glass bottom bar, logo, shimmer.
- `:domain`: DocumentFormat registry (30+ extensions, MIME fallback, engine routing) with unit tests; OpenResult.
- `:core-engine`: DocumentEngine API; MuPDF engine (render, text, search, outline, metadata, reflow, password); zero-copy content:// resolver.
- `:core-native`: C++17 JNI — auto-crop margins, contrast enhancement, adaptive threshold.
- `:app`: Splash Screen API with soft exit, Open-with/Share/SAF, password dialog, corrupt-file handling, settings via DataStore, licenses.
- Interactive web preview (`preview-web/`).
