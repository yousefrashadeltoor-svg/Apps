# MuPDF JNI calls back into these classes by name — never rename/strip them.
-keep class com.artifex.mupdf.fitz.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
