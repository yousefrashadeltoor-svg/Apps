package com.jobat.core.engine

import android.graphics.Bitmap
import android.graphics.RectF
import com.jobat.domain.model.OpenResult
import java.io.Closeable

data class PageSize(val width: Float, val height: Float)

data class OutlineItem(val title: String, val page: Int, val level: Int, val children: List<OutlineItem>)

data class SearchHit(val page: Int, val rects: List<RectF>)

data class DocumentMetadata(val title: String?, val author: String?, val subject: String?, val keywords: String?)

/** Reflowable layout settings (EPUB/FB2/MOBI/HTML) — units are points, font size is the "em". */
data class ReflowLayout(val pageWidth: Float, val pageHeight: Float, val fontSize: Float)

/**
 * Engine-agnostic document contract used by the Reader, Library (covers/metadata),
 * Search and indexing. Implementations MUST be safe to call from any coroutine:
 * they confine native access to their own single-thread dispatcher.
 */
interface OpenedDocument : Closeable {
    val pageCount: Int
    val isReflowable: Boolean
    suspend fun pageSize(index: Int): PageSize
    /** Renders [index] into [target] at [zoom] (1f = 72 dpi), offset by (-originX, -originY) for tiling. */
    suspend fun renderPage(index: Int, target: Bitmap, zoom: Float, originX: Int = 0, originY: Int = 0)
    suspend fun pageText(index: Int): String
    suspend fun search(query: String, fromPage: Int = 0, maxHits: Int = 500): List<SearchHit>
    suspend fun outline(): List<OutlineItem>
    suspend fun metadata(): DocumentMetadata
    suspend fun relayout(layout: ReflowLayout)
    /** Cancels any in-flight render (fast page flipping). */
    fun abortRendering()
}

interface DocumentEngine {
    fun canOpen(fileName: String, mimeType: String?): Boolean
    suspend fun open(path: String, password: String? = null): OpenResult<OpenedDocument>
}
