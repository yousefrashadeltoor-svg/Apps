package com.jobat.core.engine.mupdf

import android.graphics.Bitmap
import android.graphics.RectF
import com.artifex.mupdf.fitz.Cookie
import com.artifex.mupdf.fitz.Document
import com.artifex.mupdf.fitz.Matrix
import com.artifex.mupdf.fitz.Outline
import com.artifex.mupdf.fitz.Page
import com.artifex.mupdf.fitz.android.AndroidDrawDevice
import com.jobat.core.engine.DocumentEngine
import com.jobat.core.engine.DocumentMetadata
import com.jobat.core.engine.OpenedDocument
import com.jobat.core.engine.OutlineItem
import com.jobat.core.engine.PageSize
import com.jobat.core.engine.ReflowLayout
import com.jobat.core.engine.SearchHit
import com.jobat.domain.model.DocumentFormat
import com.jobat.domain.model.EngineKind
import com.jobat.domain.model.OpenResult
import kotlinx.coroutines.ExecutorCoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class MuPdfEngine : DocumentEngine {

    override fun canOpen(fileName: String, mimeType: String?): Boolean =
        DocumentFormat.detect(fileName, mimeType)?.engine == EngineKind.MUPDF

    override suspend fun open(path: String, password: String?): OpenResult<OpenedDocument> {
        val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "mupdf-doc").apply { priority = Thread.NORM_PRIORITY + 1 } }
            .asCoroutineDispatcher()
        return try {
            withContext(dispatcher) {
                val doc = Document.openDocument(path)
                if (doc.needsPassword()) {
                    if (password.isNullOrEmpty()) { doc.destroy(); dispatcher.close(); return@withContext OpenResult.PasswordRequired }
                    if (!doc.authenticatePassword(password)) { doc.destroy(); dispatcher.close(); return@withContext OpenResult.WrongPassword }
                }
                val count = doc.countPages()
                if (count <= 0) { doc.destroy(); dispatcher.close(); return@withContext OpenResult.Corrupted("Document has no pages") }
                OpenResult.Success(MuPdfDocument(doc, dispatcher))
            }
        } catch (e: RuntimeException) {
            dispatcher.close()
            OpenResult.Corrupted(e.message ?: "Unreadable document")
        }
    }
}

internal class MuPdfDocument(
    private val doc: Document,
    private val dispatcher: ExecutorCoroutineDispatcher,
) : OpenedDocument {

    private val currentCookie = AtomicReference<Cookie?>(null)
    @Volatile private var count: Int = doc.countPages()
    private val pageCache = object : android.util.LruCache<Int, Page>(4) {
        override fun entryRemoved(evicted: Boolean, key: Int, oldValue: Page, newValue: Page?) { oldValue.destroy() }
    }

    override val pageCount: Int get() = count
    override val isReflowable: Boolean = doc.isReflowable

    private fun page(index: Int): Page = pageCache.get(index) ?: doc.loadPage(index).also { pageCache.put(index, it) }

    override suspend fun pageSize(index: Int): PageSize = withContext(dispatcher) {
        val b = page(index).bounds
        PageSize(b.x1 - b.x0, b.y1 - b.y0)
    }

    override suspend fun renderPage(index: Int, target: Bitmap, zoom: Float, originX: Int, originY: Int) = withContext(dispatcher) {
        val cookie = Cookie()
        currentCookie.getAndSet(cookie)?.abort()
        val dev = AndroidDrawDevice(target, originX, originY)
        try {
            page(index).run(dev, Matrix.Scale(zoom), cookie)
        } finally {
            dev.close()
            dev.destroy()
            currentCookie.compareAndSet(cookie, null)
        }
    }

    override fun abortRendering() { currentCookie.get()?.abort() }

    override suspend fun pageText(index: Int): String = withContext(dispatcher) {
        val st = page(index).toStructuredText()
        val sb = StringBuilder()
        for (block in st.blocks) {
            for (line in block.lines) {
                for (ch in line.chars) sb.appendCodePoint(ch.c)
                sb.append('\n')
            }
            sb.append('\n')
        }
        st.destroy()
        sb.toString()
    }

    override suspend fun search(query: String, fromPage: Int, maxHits: Int): List<SearchHit> = withContext(dispatcher) {
        val hits = ArrayList<SearchHit>()
        if (query.isBlank()) return@withContext hits
        for (i in fromPage until count) {
            val results = page(i).search(query) ?: continue
            for (quads in results) {
                hits += SearchHit(i, quads.map { q ->
                    RectF(minOf(q.ul_x, q.ll_x), minOf(q.ul_y, q.ur_y), maxOf(q.ur_x, q.lr_x), maxOf(q.ll_y, q.lr_y))
                })
                if (hits.size >= maxHits) return@withContext hits
            }
        }
        hits
    }

    override suspend fun outline(): List<OutlineItem> = withContext(dispatcher) {
        fun map(items: Array<Outline>?, level: Int): List<OutlineItem> = items.orEmpty().map { o ->
            val pageNo = runCatching { o.uri?.let { doc.pageNumberFromLocation(doc.resolveLink(it)) } ?: -1 }.getOrDefault(-1)
            OutlineItem(o.title ?: "", pageNo, level, map(o.down, level + 1))
        }
        map(runCatching { doc.loadOutline() }.getOrNull(), 0)
    }

    override suspend fun metadata(): DocumentMetadata = withContext(dispatcher) {
        fun m(k: String) = runCatching { doc.getMetaData(k) }.getOrNull()?.takeIf { it.isNotBlank() }
        DocumentMetadata(m(Document.META_INFO_TITLE), m(Document.META_INFO_AUTHOR), m("info:Subject"), m("info:Keywords"))
    }

    override suspend fun relayout(layout: ReflowLayout) = withContext(dispatcher) {
        if (!doc.isReflowable) return@withContext
        pageCache.evictAll()
        doc.layout(layout.pageWidth, layout.pageHeight, layout.fontSize)
        count = doc.countPages()
    }

    override fun close() {
        abortRendering()
        dispatcher.executor.execute {
            pageCache.evictAll()
            doc.destroy()
        }
        dispatcher.close()
    }
}
