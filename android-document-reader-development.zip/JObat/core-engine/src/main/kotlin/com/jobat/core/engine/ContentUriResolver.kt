package com.jobat.core.engine

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.Closeable
import java.io.File

/**
 * Turns any SAF/content/file Uri into a filesystem path native engines can open,
 * WITHOUT copying when possible: "/proc/self/fd/N" for a detached-on-close descriptor.
 * Falls back to a private cache copy (cleared by [cleanup]) when the provider only
 * offers a pipe (e.g. some cloud providers).
 */
class ResolvedPath(val path: String, val displayName: String, private val onClose: () -> Unit) : Closeable {
    override fun close() = onClose()
}

object ContentUriResolver {
    private const val CACHE_DIR = "open-cache"

    fun displayName(context: Context, uri: Uri): String {
        if (uri.scheme == "file") return File(uri.path.orEmpty()).name
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { return it }
        }
        return uri.lastPathSegment ?: "document"
    }

    fun resolve(context: Context, uri: Uri): ResolvedPath {
        val name = displayName(context, uri)
        if (uri.scheme == "file") return ResolvedPath(uri.path!!, name) {}
        val pfd: ParcelFileDescriptor? = runCatching { context.contentResolver.openFileDescriptor(uri, "r") }.getOrNull()
        if (pfd != null && pfd.statSize >= 0) {
            return ResolvedPath("/proc/self/fd/${pfd.fd}", name) { pfd.close() }
        }
        pfd?.close()
        val dir = File(context.cacheDir, CACHE_DIR).apply { mkdirs() }
        val out = File(dir, "${System.nanoTime()}_$name")
        context.contentResolver.openInputStream(uri)!!.use { input -> out.outputStream().use { input.copyTo(it, 1 shl 16) } }
        return ResolvedPath(out.absolutePath, name) { out.delete() }
    }

    /** Called at app start and on low storage: removes stale fallback copies. */
    fun cleanup(context: Context) {
        File(context.cacheDir, CACHE_DIR).listFiles()?.forEach { it.delete() }
    }
}
