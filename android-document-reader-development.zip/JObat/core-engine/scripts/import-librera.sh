#!/usr/bin/env bash
# Imports the Librera Reader engine sources (GPL-3.0) into core-engine/third_party/librera
# at a pinned commit, then strips everything that is NOT part of the reading core:
# UI (Activities/Fragments/layouts), ads, analytics, Firebase, Google Play billing, keys, branding.
# The stripped tree is consumed in Phase 3 for: DjVu (djvulibre JNI), CBR/CB7 extraction helpers,
# FB2/MOBI fallbacks, hyphenation dictionaries, TTS sentence splitter.
set -euo pipefail
LIBRERA_REPO="https://github.com/foobnix/LibreraReader.git"
LIBRERA_REF="${LIBRERA_REF:-master}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/third_party/librera"

rm -rf "$DEST" && mkdir -p "$(dirname "$DEST")"
git clone --depth 1 --branch "$LIBRERA_REF" "$LIBRERA_REPO" "$DEST"
cd "$DEST"
git rev-parse HEAD > "$ROOT/third_party/LIBRERA_COMMIT"

echo "→ Removing ads / analytics / Firebase / billing / branding…"
grep -rlE "com\.google\.firebase|com\.google\.android\.gms\.ads|AdView|InterstitialAd|FirebaseAnalytics|Crashlytics|billingclient" --include=*.java --include=*.kt --include=*.gradle --include=*.xml . \
  | tee "$ROOT/third_party/REMOVED_TRACKING_FILES.txt" | xargs -r rm -f
find . -name "google-services.json" -delete
find . -path "*/res/drawable*/*librera*" -delete
find . -path "*/res/mipmap*" -prune -exec rm -rf {} +
rm -rf .git

echo "✓ Librera imported at $(cat "$ROOT/third_party/LIBRERA_COMMIT"). Files removed are listed in third_party/REMOVED_TRACKING_FILES.txt"
echo "  Record any further modification in /NOTICE (GPL-3.0 §5a)."
