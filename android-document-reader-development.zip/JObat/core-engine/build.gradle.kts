plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.jobat.core.engine"
    compileSdk = 35
    defaultConfig {
        minSdk = 24
        consumerProguardFiles("consumer-rules.pro")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    api(project(":domain"))
    api(project(":core-native"))
    // MuPDF (AGPL-3.0) — PDF, XPS, EPUB, MOBI, FB2, CBZ, SVG, images, DOCX/XLSX/PPTX (MuPDF ≥1.23 "office" handler).
    api(libs.mupdf.fitz)
    implementation(libs.androidx.core.ktx)
    implementation(libs.coroutines.android)
    testImplementation(libs.junit)
    testImplementation(libs.truth)
}
