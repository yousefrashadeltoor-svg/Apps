pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Official Artifex repository: prebuilt MuPDF "fitz" (AGPL-3.0) JNI library for all ABIs.
        maven("https://maven.ghostscript.com") {
            content { includeGroup("com.artifex.mupdf") }
        }
    }
}

rootProject.name = "JObat"

// ---- Phase 1 (this delivery) ----
include(":app")
include(":core-native")
include(":core-engine")
include(":design-system")
include(":domain")

// ---- Later phases: each module is added to this list in the phase that creates it ----
// Phase 2: ":data", ":feature-library"
// Phase 3: ":feature-reader"
// Phase 4: ":feature-editor-pdf", ":feature-editor-text", ":feature-editor-image"
// Phase 5: ":feature-scanner-ocr", ":feature-tools"
// Phase 6: ":feature-settings", ":feature-stats", ":widget"
// Phase 7: ":baselineprofile"
