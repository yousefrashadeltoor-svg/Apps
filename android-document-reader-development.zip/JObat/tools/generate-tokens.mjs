#!/usr/bin/env node
/**
 * JO bat — Design Token generator.
 * Single source of truth: design-system/tokens/tokens.json
 * Outputs:
 *   1) design-system/src/main/kotlin/com/jobat/design/theme/JoBatTokens.kt   (Jetpack Compose)
 *   2) preview-web/src/tokens.generated.css                                 (Web preview CSS variables)
 * Usage: node tools/generate-tokens.mjs
 * The Gradle task :design-system:generateTokens calls this script; CI fails if outputs drift.
 */
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const t = JSON.parse(readFileSync(resolve(root, "design-system/tokens/tokens.json"), "utf8"));

const HEADER = "AUTO-GENERATED from design-system/tokens/tokens.json — DO NOT EDIT.";

/** "#RRGGBB" or "#RRGGBBAA" -> 0xAARRGGBB */
function kColor(hex) {
  const h = hex.replace("#", "");
  const rgb = h.slice(0, 6).toUpperCase();
  const a = (h.length === 8 ? h.slice(6, 8) : "FF").toUpperCase();
  return `Color(0x${a}${rgb})`;
}
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const kebab = (s) => s.replace(/[A-Z]/g, (m) => "-" + m.toLowerCase());

// ---------- Kotlin ----------
let kt = `// ${HEADER}\npackage com.jobat.design.theme\n\n`;
kt += `import androidx.compose.animation.core.CubicBezierEasing\nimport androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.unit.dp\nimport androidx.compose.ui.unit.sp\n\n`;
kt += `data class JoBatPalette(\n${Object.keys(t.themes.dark).map((k) => `    val ${k}: Color`).join(",\n")}\n)\n\n`;
kt += `data class ReaderPalette(val page: Color, val text: Color, val accent: Color)\n\n`;
kt += `object JoBatTokens {\n`;
kt += `    object Brand {\n${Object.entries(t.brand).map(([k, v]) => `        val ${k} = ${kColor(v)}`).join("\n")}\n    }\n\n`;
for (const [name, pal] of Object.entries(t.themes)) {
  kt += `    val ${name}Palette = JoBatPalette(\n${Object.entries(pal).map(([k, v]) => `        ${k} = ${kColor(v)}`).join(",\n")}\n    )\n\n`;
}
kt += `    object Reader {\n${Object.entries(t.readerThemes).map(([k, v]) => `        val ${k} = ReaderPalette(${kColor(v.page)}, ${kColor(v.text)}, ${kColor(v.accent)})`).join("\n")}\n        val all = mapOf(${Object.keys(t.readerThemes).map((k) => `"${k}" to ${k}`).join(", ")})\n    }\n\n`;
kt += `    object Spacing {\n${Object.entries(t.spacing).map(([k, v]) => `        val ${k} = ${v}.dp`).join("\n")}\n    }\n\n`;
kt += `    object Radius {\n${Object.entries(t.radius).map(([k, v]) => `        val ${k} = ${v}.dp`).join("\n")}\n    }\n\n`;
kt += `    object Elevation {\n        val level1 = ${t.elevation.level1Dp}.dp\n        val level2 = ${t.elevation.level2Dp}.dp\n        val level3 = ${t.elevation.level3Dp}.dp\n    }\n\n`;
kt += `    object Type {\n${Object.entries(t.typography.scale).map(([k, v]) => `        val ${k}Size = ${v.size}.sp\n        val ${k}Line = ${v.line}.sp\n        const val ${k}Weight = ${v.weight}\n        val ${k}Tracking = ${v.tracking}.sp\n        const val ${k}Family = "${v.family}"`).join("\n")}\n    }\n\n`;
kt += `    object Motion {\n${Object.entries(t.motion.duration).map(([k, v]) => `        const val ${k} = ${v}`).join("\n")}\n${Object.entries(t.motion.easing).map(([k, v]) => `        val ${k} = CubicBezierEasing(${v.map((n) => n + "f").join(", ")})`).join("\n")}\n        const val springDamping = ${t.motion.spring.dampingRatio}f\n        const val springStiffness = ${t.motion.spring.stiffness}f\n    }\n}\n`;

const ktPath = resolve(root, "design-system/src/main/kotlin/com/jobat/design/theme/JoBatTokens.kt");
mkdirSync(dirname(ktPath), { recursive: true });
writeFileSync(ktPath, kt);

// ---------- CSS ----------
let css = `/* ${HEADER} */\n:root {\n`;
for (const [k, v] of Object.entries(t.brand)) css += `  --brand-${kebab(k)}: ${v};\n`;
for (const [k, v] of Object.entries(t.spacing)) css += `  --space-${k}: ${v}px;\n`;
for (const [k, v] of Object.entries(t.radius)) css += `  --radius-${k}: ${v}px;\n`;
for (const k of ["level0", "level1", "level2", "level3"]) css += `  --elev-${k.replace("level", "")}: ${t.elevation[k]};\n`;
for (const [k, v] of Object.entries(t.motion.duration)) css += `  --dur-${kebab(k)}: ${v}ms;\n`;
for (const [k, v] of Object.entries(t.motion.easing)) css += `  --ease-${kebab(k)}: cubic-bezier(${v.join(", ")});\n`;
const fam = t.typography.families;
css += `  --font-display: "${fam.display}", "Amiri", serif;\n  --font-ui: "${fam.ui}", "${fam.uiArabic}", system-ui, sans-serif;\n  --font-reading: "${fam.readingSerif}", "${fam.readingArabic}", serif;\n  --font-mono: "${fam.mono}", ui-monospace, monospace;\n`;
for (const [k, v] of Object.entries(t.typography.scale)) {
  css += `  --type-${kebab(k)}: ${v.weight} ${v.size}px/${v.line}px var(--font-${v.family === "display" ? "display" : "ui"});\n  --track-${kebab(k)}: ${v.tracking}px;\n`;
}
for (const [k, v] of Object.entries(t.readerThemes)) {
  css += `  --reader-${k}-page: ${v.page};\n  --reader-${k}-text: ${v.text};\n  --reader-${k}-accent: ${v.accent};\n`;
}
css += `}\n`;
for (const [name, pal] of Object.entries(t.themes)) {
  css += `[data-theme="${name}"] {\n${Object.entries(pal).map(([k, v]) => `  --c-${kebab(k)}: ${v};`).join("\n")}\n}\n`;
}
css += `[data-reduce-motion="true"] { --dur-short: 0ms; --dur-medium: 0ms; --dur-long: 0ms; --dur-extra-long: 0ms; }\n`;

const cssPath = resolve(root, "preview-web/src/tokens.generated.css");
mkdirSync(dirname(cssPath), { recursive: true });
writeFileSync(cssPath, css);

console.log("✓ Tokens generated:\n  " + ktPath + "\n  " + cssPath);
