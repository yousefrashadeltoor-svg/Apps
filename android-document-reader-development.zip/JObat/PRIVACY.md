# Privacy Policy — 𝒥𝒪 bat
*Last updated: 2026*

**Summary: JO bat collects nothing. Your files, notes and reading data never leave your device unless you export them.**

- **No accounts, ads, analytics, crash reporting or trackers.** The app ships without these SDKs, and you can check this in the source.
- **No network access in the base app.** The main app does not request the `INTERNET` permission, and cleartext traffic is blocked.
- **Optional OCR language packs (Phase 5).** These are downloaded only when you tap *Download*, from the URL shown in the app. That download is the only network request, and it carries no identifiers.
- **Files.** Documents are opened through Android's Storage Access Framework, so the app only sees files you pick or folders you grant. Temporary copies are kept in app-private cache and deleted automatically.
- **Vault (Phase 6).** Vault files are encrypted with AES-256-GCM using keys held in the Android Keystore and protected by biometrics or the device credential.
- **Backups.** Android cloud backup is turned off. In-app backup creates a single file at a location you choose.
- **Permissions:** Camera (scanner, only while it is in use) and Notifications (TTS playback controls). On Android 12L and older, Read storage is used only for optional library indexing.

Contact: open an issue in the project repository.
