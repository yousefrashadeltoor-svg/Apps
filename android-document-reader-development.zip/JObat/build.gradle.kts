// Root build file — JO bat (com.jobat.reader)
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.android.test) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.jvm) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
    alias(libs.plugins.baselineprofile) apply false
}

tasks.register<Exec>("generateTokens") {
    group = "jobat"
    description = "Regenerates Compose + CSS tokens from design-system/tokens/tokens.json"
    commandLine("node", "tools/generate-tokens.mjs")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
