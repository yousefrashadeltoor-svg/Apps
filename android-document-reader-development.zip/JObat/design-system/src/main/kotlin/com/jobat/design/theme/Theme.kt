package com.jobat.design.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext

/** App-level theme choices (Settings → Appearance). */
enum class AppTheme { System, Dark, Light, Amoled, Sepia, Dynamic }

@Immutable
data class JoBatExtras(
    val palette: JoBatPalette,
    val isDark: Boolean,
    val reduceMotion: Boolean,
)

val LocalJoBat = staticCompositionLocalOf {
    JoBatExtras(JoBatTokens.darkPalette, isDark = true, reduceMotion = false)
}

private fun JoBatPalette.toScheme(dark: Boolean): ColorScheme {
    val base = if (dark) darkColorScheme() else lightColorScheme()
    return base.copy(
        primary = primary,
        onPrimary = onPrimary,
        primaryContainer = primaryContainer,
        onPrimaryContainer = onPrimaryContainer,
        secondary = primaryDeep,
        onSecondary = onPrimary,
        background = background,
        onBackground = onBackground,
        surface = surface,
        onSurface = onSurface,
        surfaceVariant = surfaceHigh,
        onSurfaceVariant = onSurfaceVariant,
        surfaceContainerLowest = background,
        surfaceContainerLow = surface,
        surfaceContainer = surface,
        surfaceContainerHigh = surfaceHigh,
        surfaceContainerHighest = surfaceHighest,
        outline = outline,
        outlineVariant = outlineVariant,
        error = error,
        scrim = scrim,
    )
}

@Composable
fun JoBatTheme(
    theme: AppTheme = AppTheme.Dark,
    reduceMotion: Boolean = false,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val palette: JoBatPalette
    val dark: Boolean
    when (theme) {
        AppTheme.System -> { dark = systemDark; palette = if (dark) JoBatTokens.darkPalette else JoBatTokens.lightPalette }
        AppTheme.Dark, AppTheme.Dynamic -> { dark = if (theme == AppTheme.Dynamic) systemDark else true; palette = if (dark) JoBatTokens.darkPalette else JoBatTokens.lightPalette }
        AppTheme.Light -> { dark = false; palette = JoBatTokens.lightPalette }
        AppTheme.Amoled -> { dark = true; palette = JoBatTokens.amoledPalette }
        AppTheme.Sepia -> { dark = false; palette = JoBatTokens.sepiaPalette }
    }
    val scheme = if (theme == AppTheme.Dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val ctx = LocalContext.current
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        palette.toScheme(dark)
    }
    CompositionLocalProvider(LocalJoBat provides JoBatExtras(palette, dark, reduceMotion)) {
        MaterialTheme(
            colorScheme = scheme,
            typography = JoBatTypography,
            shapes = JoBatShapes,
            content = content,
        )
    }
}
