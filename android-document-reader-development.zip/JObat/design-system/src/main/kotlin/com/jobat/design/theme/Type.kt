package com.jobat.design.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.jobat.design.R

/**
 * Bundled, subsetted fonts (see docs/FONTS.md for the pyftsubset command used):
 *  - Cormorant Garamond SemiBold (Latin subset)  → display / logo
 *  - Inter Regular/Medium/SemiBold (Latin subset) → UI
 *  - IBM Plex Sans Arabic Regular/Medium/SemiBold (Arabic subset) → UI Arabic fallback
 * Android picks Arabic glyphs from the system font when a family lacks them; we
 * merge Inter + Plex Arabic in a single FontFamily so mixed text shapes correctly.
 */
val DisplayFamily = FontFamily(
    Font(R.font.cormorant_semibold, FontWeight.SemiBold),
)

val UiFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
)

val UiArabicFamily = FontFamily(
    Font(R.font.plex_arabic_regular, FontWeight.Normal),
    Font(R.font.plex_arabic_medium, FontWeight.Medium),
    Font(R.font.plex_arabic_semibold, FontWeight.SemiBold),
)

private fun style(family: FontFamily, size: Int, line: Int, weight: Int, tracking: Float) = TextStyle(
    fontFamily = family,
    fontSize = size.sp,
    lineHeight = line.sp,
    fontWeight = FontWeight(weight),
    letterSpacing = tracking.sp,
)

private fun fam(key: String) = if (key == "display") DisplayFamily else UiFamily

val JoBatTypography = with(JoBatTokens.Type) {
    Typography(
        displayLarge = style(fam(displayLargeFamily), displayLargeSize.value.toInt(), displayLargeLine.value.toInt(), displayLargeWeight, displayLargeTracking.value),
        displaySmall = style(fam(displaySmallFamily), displaySmallSize.value.toInt(), displaySmallLine.value.toInt(), displaySmallWeight, displaySmallTracking.value),
        headlineMedium = style(fam(headlineMediumFamily), headlineMediumSize.value.toInt(), headlineMediumLine.value.toInt(), headlineMediumWeight, headlineMediumTracking.value),
        titleLarge = style(fam(titleLargeFamily), titleLargeSize.value.toInt(), titleLargeLine.value.toInt(), titleLargeWeight, titleLargeTracking.value),
        titleMedium = style(fam(titleMediumFamily), titleMediumSize.value.toInt(), titleMediumLine.value.toInt(), titleMediumWeight, titleMediumTracking.value),
        bodyLarge = style(fam(bodyLargeFamily), bodyLargeSize.value.toInt(), bodyLargeLine.value.toInt(), bodyLargeWeight, bodyLargeTracking.value),
        bodyMedium = style(fam(bodyMediumFamily), bodyMediumSize.value.toInt(), bodyMediumLine.value.toInt(), bodyMediumWeight, bodyMediumTracking.value),
        labelLarge = style(fam(labelLargeFamily), labelLargeSize.value.toInt(), labelLargeLine.value.toInt(), labelLargeWeight, labelLargeTracking.value),
        labelSmall = style(fam(labelSmallFamily), labelSmallSize.value.toInt(), labelSmallLine.value.toInt(), labelSmallWeight, labelSmallTracking.value),
    )
}

val JoBatShapes = Shapes(
    extraSmall = RoundedCornerShape(JoBatTokens.Radius.sm),
    small = RoundedCornerShape(JoBatTokens.Radius.sm),
    medium = RoundedCornerShape(JoBatTokens.Radius.md),
    large = RoundedCornerShape(JoBatTokens.Radius.lg),
    extraLarge = RoundedCornerShape(JoBatTokens.Radius.xl),
)
