package com.jobat.design.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import com.jobat.design.theme.LocalJoBat

/** Skeleton shimmer; static when Reduce Motion is on. */
fun Modifier.shimmer(): Modifier = composed {
    val extras = LocalJoBat.current
    val base = extras.palette.surfaceHigh
    val hi = extras.palette.surfaceHighest
    if (extras.reduceMotion) return@composed background(base)
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(-600f, 1200f, infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart), label = "x")
    background(Brush.linearGradient(listOf(base, hi, base), start = Offset(x, 0f), end = Offset(x + 600f, 300f)))
}

@Composable
fun SkeletonPlaceholder(modifier: Modifier) {
    androidx.compose.foundation.layout.Box(modifier.shimmer())
}
