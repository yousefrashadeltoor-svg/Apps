// AUTO-GENERATED from design-system/tokens/tokens.json — DO NOT EDIT.
package com.jobat.design.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class JoBatPalette(
    val background: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val surfaceHighest: Color,
    val outline: Color,
    val outlineVariant: Color,
    val onBackground: Color,
    val onSurface: Color,
    val onSurfaceVariant: Color,
    val primary: Color,
    val primaryDeep: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val error: Color,
    val success: Color,
    val scrim: Color,
    val glass: Color
)

data class ReaderPalette(val page: Color, val text: Color, val accent: Color)

object JoBatTokens {
    object Brand {
        val obsidian = Color(0xFF0B0C10)
        val graphite = Color(0xFF15171C)
        val graphiteHigh = Color(0xFF1E2128)
        val champagne = Color(0xFFD4B26A)
        val champagneDeep = Color(0xFFB8914A)
        val ivory = Color(0xFFF6F1E7)
    }

    val darkPalette = JoBatPalette(
        background = Color(0xFF0B0C10),
        surface = Color(0xFF15171C),
        surfaceHigh = Color(0xFF1E2128),
        surfaceHighest = Color(0xFF272A33),
        outline = Color(0xFF2E323C),
        outlineVariant = Color(0xFF22252D),
        onBackground = Color(0xFFECE7DC),
        onSurface = Color(0xFFECE7DC),
        onSurfaceVariant = Color(0xFF9A9AA3),
        primary = Color(0xFFD4B26A),
        primaryDeep = Color(0xFFB8914A),
        onPrimary = Color(0xFF1A1408),
        primaryContainer = Color(0xFF3A2F18),
        onPrimaryContainer = Color(0xFFF1DDAE),
        error = Color(0xFFE5786D),
        success = Color(0xFF7FBF8E),
        scrim = Color(0xB3000000),
        glass = Color(0xCC15171C)
    )

    val lightPalette = JoBatPalette(
        background = Color(0xFFF6F1E7),
        surface = Color(0xFFFFFCF6),
        surfaceHigh = Color(0xFFEFE8DA),
        surfaceHighest = Color(0xFFE6DDCB),
        outline = Color(0xFFD6CCB8),
        outlineVariant = Color(0xFFE4DCCC),
        onBackground = Color(0xFF1B1A17),
        onSurface = Color(0xFF1B1A17),
        onSurfaceVariant = Color(0xFF6B655A),
        primary = Color(0xFF9C7A35),
        primaryDeep = Color(0xFF7E6026),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFF1E2BE),
        onPrimaryContainer = Color(0xFF3A2B0B),
        error = Color(0xFFB3402F),
        success = Color(0xFF3D7F4E),
        scrim = Color(0x80000000),
        glass = Color(0xCCFFFCF6)
    )

    val amoledPalette = JoBatPalette(
        background = Color(0xFF000000),
        surface = Color(0xFF0A0A0C),
        surfaceHigh = Color(0xFF131418),
        surfaceHighest = Color(0xFF1B1C21),
        outline = Color(0xFF24262C),
        outlineVariant = Color(0xFF17181C),
        onBackground = Color(0xFFE8E3D8),
        onSurface = Color(0xFFE8E3D8),
        onSurfaceVariant = Color(0xFF8C8C94),
        primary = Color(0xFFD4B26A),
        primaryDeep = Color(0xFFB8914A),
        onPrimary = Color(0xFF140F04),
        primaryContainer = Color(0xFF2C2412),
        onPrimaryContainer = Color(0xFFF1DDAE),
        error = Color(0xFFE5786D),
        success = Color(0xFF7FBF8E),
        scrim = Color(0xCC000000),
        glass = Color(0xD90A0A0C)
    )

    val sepiaPalette = JoBatPalette(
        background = Color(0xFFF1E6D0),
        surface = Color(0xFFF8EEDB),
        surfaceHigh = Color(0xFFE8DBC0),
        surfaceHighest = Color(0xFFDECFB0),
        outline = Color(0xFFCDBB97),
        outlineVariant = Color(0xFFDCCCAB),
        onBackground = Color(0xFF3B2F20),
        onSurface = Color(0xFF3B2F20),
        onSurfaceVariant = Color(0xFF7A6A52),
        primary = Color(0xFF8F6A2C),
        primaryDeep = Color(0xFF74551F),
        onPrimary = Color(0xFFFFF8EA),
        primaryContainer = Color(0xFFE9D3A5),
        onPrimaryContainer = Color(0xFF35260A),
        error = Color(0xFFA8432F),
        success = Color(0xFF4E7A43),
        scrim = Color(0x802B200F),
        glass = Color(0xCCF8EEDB)
    )

    object Reader {
        val paper = ReaderPalette(Color(0xFFFFFFFF), Color(0xFF1C1C1C), Color(0xFF9C7A35))
        val sepia = ReaderPalette(Color(0xFFF4E9D3), Color(0xFF4A3B28), Color(0xFF8F6A2C))
        val ivory = ReaderPalette(Color(0xFFF6F1E7), Color(0xFF26231E), Color(0xFF9C7A35))
        val graphite = ReaderPalette(Color(0xFF2A2C31), Color(0xFFD9D6CF), Color(0xFFD4B26A))
        val midnight = ReaderPalette(Color(0xFF121726), Color(0xFFC9CFDD), Color(0xFFD4B26A))
        val amoled = ReaderPalette(Color(0xFF000000), Color(0xFFBDBDBD), Color(0xFFD4B26A))
        val all = mapOf("paper" to paper, "sepia" to sepia, "ivory" to ivory, "graphite" to graphite, "midnight" to midnight, "amoled" to amoled)
    }

    object Spacing {
        val xxs = 2.dp
        val xs = 4.dp
        val sm = 8.dp
        val md = 12.dp
        val lg = 16.dp
        val xl = 24.dp
        val xxl = 32.dp
        val xxxl = 48.dp
    }

    object Radius {
        val sm = 8.dp
        val md = 12.dp
        val lg = 16.dp
        val xl = 24.dp
        val full = 999.dp
    }

    object Elevation {
        val level1 = 1.dp
        val level2 = 4.dp
        val level3 = 10.dp
    }

    object Type {
        val displayLargeSize = 44.sp
        val displayLargeLine = 50.sp
        const val displayLargeWeight = 600
        val displayLargeTracking = -0.5.sp
        const val displayLargeFamily = "display"
        val displaySmallSize = 32.sp
        val displaySmallLine = 38.sp
        const val displaySmallWeight = 600
        val displaySmallTracking = -0.25.sp
        const val displaySmallFamily = "display"
        val headlineMediumSize = 24.sp
        val headlineMediumLine = 30.sp
        const val headlineMediumWeight = 600
        val headlineMediumTracking = 0.sp
        const val headlineMediumFamily = "display"
        val titleLargeSize = 20.sp
        val titleLargeLine = 26.sp
        const val titleLargeWeight = 600
        val titleLargeTracking = 0.sp
        const val titleLargeFamily = "ui"
        val titleMediumSize = 16.sp
        val titleMediumLine = 22.sp
        const val titleMediumWeight = 600
        val titleMediumTracking = 0.1.sp
        const val titleMediumFamily = "ui"
        val bodyLargeSize = 16.sp
        val bodyLargeLine = 24.sp
        const val bodyLargeWeight = 400
        val bodyLargeTracking = 0.15.sp
        const val bodyLargeFamily = "ui"
        val bodyMediumSize = 14.sp
        val bodyMediumLine = 20.sp
        const val bodyMediumWeight = 400
        val bodyMediumTracking = 0.2.sp
        const val bodyMediumFamily = "ui"
        val labelLargeSize = 14.sp
        val labelLargeLine = 20.sp
        const val labelLargeWeight = 500
        val labelLargeTracking = 0.1.sp
        const val labelLargeFamily = "ui"
        val labelSmallSize = 11.sp
        val labelSmallLine = 16.sp
        const val labelSmallWeight = 500
        val labelSmallTracking = 0.5.sp
        const val labelSmallFamily = "ui"
    }

    object Motion {
        const val short = 150
        const val medium = 300
        const val long = 450
        const val extraLong = 600
        val standard = CubicBezierEasing(0.2f, 0f, 0f, 1f)
        val emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
        val emphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)
        val emphasizedAccelerate = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)
        const val springDamping = 0.8f
        const val springStiffness = 380f
    }
}
