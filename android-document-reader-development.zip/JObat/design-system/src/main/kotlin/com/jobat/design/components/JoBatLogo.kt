package com.jobat.design.components

import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.jobat.design.theme.DisplayFamily
import com.jobat.design.theme.JoBatTokens
import com.jobat.design.theme.LocalJoBat

/** The wordmark "𝒥𝒪 bat": script monogram in champagne gradient + serif "bat". */
@Composable
fun JoBatLogo(modifier: Modifier = Modifier, size: TextUnit = 40.sp) {
    val onBg = LocalJoBat.current.palette.onBackground
    val gold = Brush.linearGradient(listOf(JoBatTokens.Brand.champagne, JoBatTokens.Brand.champagneDeep))
    Row(modifier, verticalAlignment = Alignment.Bottom) {
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(brush = gold, fontStyle = FontStyle.Italic)) { append("\uD835\uDCA5\uD835\uDCAA") }
                withStyle(SpanStyle(color = onBg)) { append(" bat") }
            },
            style = TextStyle(fontFamily = DisplayFamily, fontSize = size),
        )
    }
}
