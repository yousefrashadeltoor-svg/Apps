package com.jobat.design.motion

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import com.jobat.design.theme.JoBatTokens
import com.jobat.design.theme.LocalJoBat

/**
 * Motion helpers that always respect "Reduce Motion":
 * system "Remove animations" (animator scale = 0) is honoured by Compose automatically,
 * and the in-app toggle is applied here by returning snap().
 */
object JoBatMotion {
    @Composable @ReadOnlyComposable
    fun <T> emphasized(duration: Int = JoBatTokens.Motion.medium): FiniteAnimationSpec<T> =
        if (LocalJoBat.current.reduceMotion) snap() else tween(duration, easing = JoBatTokens.Motion.emphasizedDecelerate)

    @Composable @ReadOnlyComposable
    fun <T> standard(duration: Int = JoBatTokens.Motion.short): FiniteAnimationSpec<T> =
        if (LocalJoBat.current.reduceMotion) snap() else tween(duration, easing = JoBatTokens.Motion.standard)

    @Composable @ReadOnlyComposable
    fun <T> exit(duration: Int = JoBatTokens.Motion.short): FiniteAnimationSpec<T> =
        if (LocalJoBat.current.reduceMotion) snap() else tween(duration, easing = JoBatTokens.Motion.emphasizedAccelerate)

    @Composable @ReadOnlyComposable
    fun <T> springy(): FiniteAnimationSpec<T> =
        if (LocalJoBat.current.reduceMotion) snap()
        else spring(dampingRatio = JoBatTokens.Motion.springDamping, stiffness = JoBatTokens.Motion.springStiffness)

    fun <T> gentleSpring(): FiniteAnimationSpec<T> = spring(Spring.DampingRatioNoBouncy, Spring.StiffnessMediumLow)
}
