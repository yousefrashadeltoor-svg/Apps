package com.jobat.design.components

import android.os.Build
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.jobat.design.motion.JoBatMotion
import com.jobat.design.theme.JoBatTokens
import com.jobat.design.theme.LocalJoBat

data class NavDestination(val route: String, val label: String, val icon: ImageVector)

/**
 * Floating glass bottom navigation with an animated champagne indicator.
 * Blur: Compose cannot blur content *behind* a composable on all API levels; we use a
 * translucent "glass" token colour + hairline border (identical to the web preview),
 * and on API 31+ the hosting Activity enables window background blur (see MainActivity).
 */
@Composable
fun GlassBottomBar(
    items: List<NavDestination>,
    selectedRoute: String,
    onSelect: (NavDestination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalJoBat.current.palette
    val haptics = LocalHapticFeedback.current
    val selectedIndex = items.indexOfFirst { it.route == selectedRoute }.coerceAtLeast(0)
    val shape = RoundedCornerShape(JoBatTokens.Radius.xl)

    Box(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = JoBatTokens.Spacing.lg, vertical = JoBatTokens.Spacing.md)
            .fillMaxWidth()
            .height(64.dp)
            .clip(shape)
            .background(palette.glass)
            .border(1.dp, palette.outline.copy(alpha = 0.6f), shape)
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth().fillMaxHeight()) {
            val slot = maxWidth / items.size
            val indicatorX by animateDpAsState(slot * selectedIndex, JoBatMotion.springy(), label = "nav-indicator")
            Box(
                Modifier
                    .offset(x = indicatorX + (slot - 28.dp) / 2, y = 6.dp)
                    .width(28.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Brush.horizontalGradient(listOf(JoBatTokens.Brand.champagne, JoBatTokens.Brand.champagneDeep)))
            )
            Row(Modifier.fillMaxWidth().fillMaxHeight(), horizontalArrangement = Arrangement.SpaceEvenly) {
                items.forEachIndexed { i, item ->
                    val selected = i == selectedIndex
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .semantics { this.selected = selected }
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(bounded = false, radius = 32.dp),
                                role = Role.Tab,
                            ) {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSelect(item)
                            },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Spacer(Modifier.height(4.dp))
                        Icon(
                            item.icon,
                            contentDescription = null,
                            tint = if (selected) palette.primary else palette.onSurfaceVariant,
                            modifier = Modifier.size(22.dp),
                        )
                        Text(
                            item.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (selected) palette.primary else palette.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}
