#!/usr/bin/env bash
# OPTIONAL: build MuPDF from source instead of using the official prebuilt
# com.artifex.mupdf:fitz AAR (e.g. to strip unused fonts and shrink ~3–4 MB per ABI).
# Produces core-native/third_party/mupdf-android-fitz/ which can replace libs.mupdf.fitz
# via:  api(project(":mupdf-fitz"))  after adding it to settings.gradle.kts.
set -euo pipefail
MUPDF_TAG="${MUPDF_TAG:-1.24.10}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/third_party"
mkdir -p "$DEST"
cd "$DEST"
if [ ! -d mupdf-android-fitz ]; then
  git clone --recursive --depth 1 --branch "$MUPDF_TAG" https://git.ghostscript.com/mupdf-android-fitz.git
fi
cd mupdf-android-fitz
# Size reduction: drop CJK & extra Noto fonts (users can still read CJK via system font fallback in reflow docs).
export XCFLAGS="-DTOFU_CJK -DTOFU_NOTO -DTOFU_SYMBOL -DTOFU_EMOJI -DTOFU_SIL"
make -C libmupdf generate
./gradlew assembleRelease
echo "✓ Built: $(pwd)/lib/build/outputs/aar/"
