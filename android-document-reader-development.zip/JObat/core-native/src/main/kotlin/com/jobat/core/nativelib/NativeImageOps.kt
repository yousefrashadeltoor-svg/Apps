package com.jobat.core.nativelib

import android.graphics.Bitmap
import android.graphics.Rect

/** Thin Kotlin facade over libjobat_native.so. All functions expect a mutable ARGB_8888 bitmap. */
object NativeImageOps {
    init { System.loadLibrary("jobat_native") }

    /** Auto-crop margins: returns the content rect of a rendered page. */
    fun detectContentBounds(bitmap: Bitmap, inkRatio: Float = 0.004f, threshold: Int = 200): Rect {
        require(bitmap.config == Bitmap.Config.ARGB_8888) { "ARGB_8888 required" }
        val r = nativeDetectContentBounds(bitmap, inkRatio, threshold) ?: return Rect(0, 0, bitmap.width, bitmap.height)
        return Rect(r[0], r[1], r[2], r[3])
    }

    /** "Enhance contrast" reader option and scanner auto-enhance. */
    fun enhanceContrast(bitmap: Bitmap, gamma: Float = 1.1f): Boolean {
        require(bitmap.isMutable) { "Mutable bitmap required" }
        return nativeEnhanceContrast(bitmap, gamma)
    }

    /** Scanner "B&W document" filter. */
    fun adaptiveThreshold(bitmap: Bitmap, block: Int = 31, c: Int = 12): Boolean {
        require(bitmap.isMutable) { "Mutable bitmap required" }
        return nativeAdaptiveThreshold(bitmap, block, c)
    }

    private external fun nativeDetectContentBounds(bitmap: Bitmap, inkRatio: Float, threshold: Int): IntArray?
    private external fun nativeEnhanceContrast(bitmap: Bitmap, gamma: Float): Boolean
    private external fun nativeAdaptiveThreshold(bitmap: Bitmap, block: Int, c: Int): Boolean
}
