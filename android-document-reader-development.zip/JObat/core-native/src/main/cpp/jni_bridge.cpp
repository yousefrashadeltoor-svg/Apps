#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include "jobat_image_ops.h"

#define LOG_TAG "JoBatNative"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
struct LockedBitmap {
    JNIEnv* env; jobject bmp; AndroidBitmapInfo info{}; void* pixels = nullptr; bool ok = false;
    LockedBitmap(JNIEnv* e, jobject b) : env(e), bmp(b) {
        if (AndroidBitmap_getInfo(env, bmp, &info) != ANDROID_BITMAP_RESULT_SUCCESS) { LOGE("getInfo failed"); return; }
        if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) { LOGE("Bitmap must be ARGB_8888"); return; }
        ok = AndroidBitmap_lockPixels(env, bmp, &pixels) == ANDROID_BITMAP_RESULT_SUCCESS;
    }
    ~LockedBitmap() { if (ok) AndroidBitmap_unlockPixels(env, bmp); }
};
}  // namespace

extern "C" JNIEXPORT jintArray JNICALL
Java_com_jobat_core_nativelib_NativeImageOps_nativeDetectContentBounds(JNIEnv* env, jobject, jobject bitmap, jfloat inkRatio, jint threshold) {
    LockedBitmap lb(env, bitmap);
    if (!lb.ok) return nullptr;
    auto r = jobat::detectContentBounds(static_cast<const uint32_t*>(lb.pixels), (int) lb.info.width, (int) lb.info.height,
                                        (int) lb.info.stride, inkRatio, threshold);
    jint out[4] = {r.left, r.top, r.right, r.bottom};
    jintArray arr = env->NewIntArray(4);
    env->SetIntArrayRegion(arr, 0, 4, out);
    return arr;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativelib_NativeImageOps_nativeEnhanceContrast(JNIEnv* env, jobject, jobject bitmap, jfloat gamma) {
    LockedBitmap lb(env, bitmap);
    if (!lb.ok) return JNI_FALSE;
    jobat::enhanceContrast(static_cast<uint32_t*>(lb.pixels), (int) lb.info.width, (int) lb.info.height, (int) lb.info.stride, gamma);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativelib_NativeImageOps_nativeAdaptiveThreshold(JNIEnv* env, jobject, jobject bitmap, jint block, jint c) {
    LockedBitmap lb(env, bitmap);
    if (!lb.ok) return JNI_FALSE;
    jobat::adaptiveThreshold(static_cast<uint32_t*>(lb.pixels), (int) lb.info.width, (int) lb.info.height, (int) lb.info.stride, block, c);
    return JNI_TRUE;
}
