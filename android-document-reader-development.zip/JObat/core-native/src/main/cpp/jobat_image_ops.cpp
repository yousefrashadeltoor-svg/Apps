#include "jobat_image_ops.h"
#include <algorithm>
#include <cmath>
#include <vector>

namespace jobat {

static inline int luma(uint32_t p) {
    // ANDROID_BITMAP_FORMAT_RGBA_8888 is stored as R,G,B,A bytes → little-endian uint32 = 0xAABBGGRR
    int r = p & 0xFF, g = (p >> 8) & 0xFF, b = (p >> 16) & 0xFF;
    return (r * 77 + g * 150 + b * 29) >> 8;
}

Rect detectContentBounds(const uint32_t* px, int w, int h, int stride, float inkRatio, int thr) {
    const int strideP = stride / 4;
    std::vector<int> rowInk(h, 0), colInk(w, 0);
    for (int y = 0; y < h; ++y) {
        const uint32_t* row = px + y * strideP;
        for (int x = 0; x < w; ++x) {
            if (luma(row[x]) < thr) { rowInk[y]++; colInk[x]++; }
        }
    }
    const int minRow = std::max(1, static_cast<int>(w * inkRatio));
    const int minCol = std::max(1, static_cast<int>(h * inkRatio));
    Rect r{0, 0, w, h};
    while (r.top < h && rowInk[r.top] < minRow) r.top++;
    while (r.bottom > r.top && rowInk[r.bottom - 1] < minRow) r.bottom--;
    while (r.left < w && colInk[r.left] < minCol) r.left++;
    while (r.right > r.left && colInk[r.right - 1] < minCol) r.right--;
    if (r.right - r.left < w / 10 || r.bottom - r.top < h / 10) return Rect{0, 0, w, h};
    // Keep a small breathing margin (1.5%) so glyphs are never clipped.
    const int mx = w * 15 / 1000, my = h * 15 / 1000;
    r.left = std::max(0, r.left - mx);
    r.top = std::max(0, r.top - my);
    r.right = std::min(w, r.right + mx);
    r.bottom = std::min(h, r.bottom + my);
    return r;
}

void enhanceContrast(uint32_t* px, int w, int h, int stride, float gamma) {
    const int strideP = stride / 4;
    int hist[256] = {0};
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) hist[luma(px[y * strideP + x])]++;
    const long total = static_cast<long>(w) * h;
    long acc = 0; int lo = 0, hi = 255;
    for (int i = 0; i < 256; ++i) { acc += hist[i]; if (acc > total / 100) { lo = i; break; } }
    acc = 0;
    for (int i = 255; i >= 0; --i) { acc += hist[i]; if (acc > total / 100) { hi = i; break; } }
    if (hi <= lo) return;
    uint8_t lut[256];
    const float inv = 1.0f / static_cast<float>(hi - lo);
    const float g = gamma > 0.f ? 1.0f / gamma : 1.0f;
    for (int i = 0; i < 256; ++i) {
        float v = std::clamp((i - lo) * inv, 0.f, 1.f);
        lut[i] = static_cast<uint8_t>(std::lround(std::pow(v, g) * 255.f));
    }
    for (int y = 0; y < h; ++y) {
        uint32_t* row = px + y * strideP;
        for (int x = 0; x < w; ++x) {
            uint32_t p = row[x];
            uint32_t r = lut[p & 0xFF], gg = lut[(p >> 8) & 0xFF], b = lut[(p >> 16) & 0xFF];
            row[x] = (p & 0xFF000000u) | (b << 16) | (gg << 8) | r;
        }
    }
}

void adaptiveThreshold(uint32_t* px, int w, int h, int stride, int block, int c) {
    const int strideP = stride / 4;
    // Integral image of luminance for O(1) block means.
    std::vector<uint64_t> integral(static_cast<size_t>(w + 1) * (h + 1), 0);
    for (int y = 0; y < h; ++y) {
        uint64_t rowSum = 0;
        for (int x = 0; x < w; ++x) {
            rowSum += luma(px[y * strideP + x]);
            integral[(y + 1) * (w + 1) + (x + 1)] = integral[y * (w + 1) + (x + 1)] + rowSum;
        }
    }
    const int half = std::max(1, block / 2);
    for (int y = 0; y < h; ++y) {
        const int y0 = std::max(0, y - half), y1 = std::min(h - 1, y + half);
        for (int x = 0; x < w; ++x) {
            const int x0 = std::max(0, x - half), x1 = std::min(w - 1, x + half);
            const uint64_t sum = integral[(y1 + 1) * (w + 1) + (x1 + 1)] - integral[y0 * (w + 1) + (x1 + 1)]
                               - integral[(y1 + 1) * (w + 1) + x0] + integral[y0 * (w + 1) + x0];
            const int count = (x1 - x0 + 1) * (y1 - y0 + 1);
            const int mean = static_cast<int>(sum / count);
            uint32_t& p = px[y * strideP + x];
            const uint32_t v = luma(p) < mean - c ? 0u : 255u;
            p = 0xFF000000u | (v << 16) | (v << 8) | v;
        }
    }
}

}  // namespace jobat
