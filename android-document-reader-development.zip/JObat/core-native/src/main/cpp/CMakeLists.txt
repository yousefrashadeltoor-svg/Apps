cmake_minimum_required(VERSION 3.22.1)
project(jobat_native CXX)

add_library(jobat_native SHARED
        jobat_image_ops.cpp
        jni_bridge.cpp)

target_link_libraries(jobat_native jnigraphics log)
target_link_options(jobat_native PRIVATE "-Wl,--gc-sections" "-Wl,-z,max-page-size=16384")
