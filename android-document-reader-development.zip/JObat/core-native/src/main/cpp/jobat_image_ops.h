#pragma once
#include <cstdint>

namespace jobat {

struct Rect { int left, top, right, bottom; };

/**
 * Detects content bounds of a page bitmap (RGBA_8888) by scanning luminance
 * variance per row/column. Rows/columns whose fraction of "ink" pixels is below
 * [inkRatio] are treated as margin. Returns the full rect if nothing is found.
 */
Rect detectContentBounds(const uint32_t* pixels, int width, int height, int stride,
                         float inkRatio, int luminanceThreshold);

/** In-place contrast enhancement: percentile stretch (1%..99%) + optional gamma. */
void enhanceContrast(uint32_t* pixels, int width, int height, int stride, float gamma);

/** Converts to grayscale and applies adaptive (mean-of-block) thresholding — scanner "B&W" mode. */
void adaptiveThreshold(uint32_t* pixels, int width, int height, int stride, int block, int c);

}  // namespace jobat
