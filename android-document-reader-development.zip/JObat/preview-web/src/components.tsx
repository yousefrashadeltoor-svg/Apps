import { useEffect, useState, type CSSProperties, type ReactNode } from "react";
import type { Book } from "./data";
import { Icon } from "./icons";
import { useApp, type Tab } from "./store";

export function Logo({ size = 40 }: { size?: number }) {
  return (
    <span className="logo" style={{ fontSize: size }}>
      <span className="mono">𝒥𝒪</span> bat
    </span>
  );
}

export function StatusBar({ light }: { light?: boolean }) {
  const [time, setTime] = useState(() => new Date());
  useEffect(() => { const i = setInterval(() => setTime(new Date()), 30000); return () => clearInterval(i); }, []);
  return (
    <div className="statusbar" style={light ? { color: "#fff" } : undefined} dir="ltr">
      <span>{time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })}</span>
      <span className="sb-icons">
        <svg width="16" height="11" viewBox="0 0 16 11" fill="currentColor"><rect x="0" y="7" width="3" height="4" rx="1" /><rect x="4.3" y="5" width="3" height="6" rx="1" /><rect x="8.6" y="2.5" width="3" height="8.5" rx="1" /><rect x="12.9" y="0" width="3" height="11" rx="1" /></svg>
        <span className="batt" />
      </span>
    </div>
  );
}

const ORN = [
  (c: string) => <svg className="c-orn" viewBox="0 0 100 150" preserveAspectRatio="none"><rect x="6" y="6" width="88" height="138" fill="none" stroke={c} strokeWidth=".6" opacity=".55" /><rect x="9" y="9" width="82" height="132" fill="none" stroke={c} strokeWidth=".3" opacity=".4" /></svg>,
  (c: string) => <svg className="c-orn" viewBox="0 0 100 150" preserveAspectRatio="none"><path d="M50 98 l10 10 -10 10 -10 -10z M50 103 l5 5 -5 5 -5 -5z" fill="none" stroke={c} strokeWidth=".7" opacity=".7" /><path d="M14 92 H86" stroke={c} strokeWidth=".4" opacity=".5" /></svg>,
  (c: string) => <svg className="c-orn" viewBox="0 0 100 150" preserveAspectRatio="none"><circle cx="50" cy="104" r="16" fill="none" stroke={c} strokeWidth=".6" opacity=".6" /><circle cx="50" cy="104" r="5" fill={c} opacity=".5" /></svg>,
  (_c: string) => <svg className="c-orn" viewBox="0 0 100 150" preserveAspectRatio="none"><rect x="12" y="62" width="76" height="2" fill="#9C7A35" opacity=".6" />{[72, 78, 84, 90, 96, 102, 108].map((y) => <rect key={y} x="12" y={y} width={y % 12 ? 70 : 52} height="1.6" fill="#7a7466" opacity=".35" />)}</svg>,
  (_c: string) => <svg className="c-orn" viewBox="0 0 100 150" preserveAspectRatio="none"><path d="M0 150 L100 40 L100 150Z" fill="#E94560" opacity=".55" /><circle cx="70" cy="40" r="18" fill="#F6E05E" opacity=".75" /></svg>,
  (c: string) => <svg className="c-orn" viewBox="0 0 100 150" preserveAspectRatio="none"><text x="12" y="120" fontFamily="JetBrains Mono" fontSize="22" fill={c} opacity=".5">#md</text></svg>,
  (_c: string) => <svg className="c-orn" viewBox="0 0 100 150" preserveAspectRatio="none"><path d="M0 110 L30 80 L50 100 L72 70 L100 104 V150 H0Z" fill="#000" opacity=".25" /><circle cx="74" cy="38" r="12" fill="#F4D58D" opacity=".8" /></svg>,
];

export function Cover({ book, width, style }: { book: Book; width: number; style?: CSSProperties }) {
  const [a, b, o] = book.cover;
  const paper = o === 3;
  const fs = Math.max(9, width / 7.2) * (book.title.length > 22 ? 0.82 : 1);
  return (
    <div className={`cover ${paper ? "paper" : ""}`} style={{ width, height: width * 1.5, background: `linear-gradient(160deg, ${a}, ${b})`, ...style }} dir={book.rtl ? "rtl" : "ltr"}>
      {ORN[o]("#D4B26A")}
      <div className="c-title" style={{ fontSize: fs }}>{book.title}</div>
      {width > 70 && <div className="c-author" style={{ fontSize: Math.max(6, width / 16) }}>{book.author}</div>}
      <span className="c-fmt">{book.format}</span>
      {book.locked && <span className="c-lock"><Icon name="lock" size={11} stroke={2} /></span>}
    </div>
  );
}

export function Ring({ value, size = 56, stroke = 4, label }: { value: number; size?: number; stroke?: number; label?: ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const [v, setV] = useState(0);
  useEffect(() => { const id = requestAnimationFrame(() => setV(value)); return () => cancelAnimationFrame(id); }, [value]);
  return (
    <div className="ring" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="var(--brand-champagne)" /><stop offset="1" stopColor="var(--brand-champagne-deep)" /></linearGradient></defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--c-surface-highest)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="url(#rg)" strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - v)} style={{ transition: "stroke-dashoffset var(--dur-extra-long) var(--ease-emphasized-decelerate)" }} />
      </svg>
      <span className="ring-lbl">{label ?? `${Math.round(value * 100)}%`}</span>
    </div>
  );
}

export function Sheet({ open, onClose, title, children, actions }: { open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode; actions?: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <div className="sheet" role="dialog" aria-modal="true">
        <div className="grab" />
        {title && <div className="sheet-title row between"><h3 className="title-l">{title}</h3>{actions}</div>}
        <div className="sheet-body">{children}</div>
      </div>
    </>
  );
}

export function Dialog({ open, onClose, children }: { open: boolean; onClose: () => void; children: ReactNode }) {
  if (!open) return null;
  return (<><div className="scrim" onClick={onClose} /><div className="dialog" role="alertdialog">{children}</div></>);
}

export function Toast() {
  const { toast, dismissToast } = useApp();
  if (!toast) return null;
  return (
    <div className="toast" key={toast.id} role="status">
      <span className="t-dot" />
      <span className="t-msg">{toast.msg}</span>
      {toast.action && <button onClick={() => { toast.action!.run(); dismissToast(); }}>{toast.action.label}</button>}
    </div>
  );
}

export function Switch({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  const { haptic } = useApp();
  return <button role="switch" aria-checked={on} aria-label={label} className={`switch ${on ? "on" : ""}`} onClick={(e) => { e.stopPropagation(); haptic(); onChange(!on); }} />;
}

export function IconBtn({ name, onClick, label, on, disabled, size = 22, className = "" }: { name: string; onClick?: () => void; label: string; on?: boolean; disabled?: boolean; size?: number; className?: string }) {
  return (
    <button className={`ib ${on ? "on" : ""} ${className}`} onClick={onClick} aria-label={label} title={label} disabled={disabled}>
      <Icon name={name} size={size} />
    </button>
  );
}

export function TopBar({ title, onBack, children, sub }: { title: ReactNode; onBack?: () => void; children?: ReactNode; sub?: ReactNode }) {
  const { t } = useApp();
  return (
    <div className="top">
      {onBack && <IconBtn name="back" onClick={onBack} label={t.cancel} className="flip-rtl" />}
      <div className="grow" style={{ paddingInlineStart: onBack ? 0 : 8 }}>
        <div className="title-l" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</div>
        {sub && <div className="label-s muted">{sub}</div>}
      </div>
      {children}
    </div>
  );
}

const TABS: { id: Tab; icon: string; key: "navLibrary" | "navTools" | "navScanner" | "navCollections" | "navSettings" }[] = [
  { id: "library", icon: "library", key: "navLibrary" },
  { id: "tools", icon: "tools", key: "navTools" },
  { id: "scanner", icon: "scan", key: "navScanner" },
  { id: "collections", icon: "collections", key: "navCollections" },
  { id: "settings", icon: "settings", key: "navSettings" },
];

export function BottomNav({ hidden }: { hidden?: boolean }) {
  const { tab, setTab, t, haptic } = useApp();
  const idx = TABS.findIndex((x) => x.id === tab);
  return (
    <nav className={`bnav ${hidden ? "hidden" : ""}`} aria-label="Main">
      <span className="ind" style={{ insetInlineStart: `calc(${(idx + 0.5) * 20}% - 14px)` }} />
      {TABS.map((x) => (
        <button key={x.id} className={tab === x.id ? "on" : ""} onClick={() => { haptic(); setTab(x.id); }} aria-current={tab === x.id ? "page" : undefined}>
          <Icon name={x.icon} size={22} />
          <span>{t[x.key]}</span>
        </button>
      ))}
    </nav>
  );
}

/** Drawn empty-state art (same vector as the Android EmptyState composable). */
export function EmptyArt({ size = 120 }: { size?: number }) {
  return (
    <svg className="art" width={size} height={size} viewBox="0 0 120 120" fill="none">
      <circle cx="60" cy="60" r="52" fill="var(--c-surface-high)" />
      <rect x="34" y="30" width="34" height="50" rx="3" fill="var(--c-surface-highest)" stroke="var(--c-outline)" transform="rotate(-8 51 55)" />
      <rect x="50" y="34" width="34" height="50" rx="3" fill="var(--c-surface)" stroke="var(--c-primary)" strokeWidth="1.4" />
      <path d="M57 46h20M57 52h20M57 58h13" stroke="var(--c-on-surface-variant)" strokeWidth="1.6" strokeLinecap="round" opacity=".6" />
      <circle cx="84" cy="80" r="11" fill="var(--c-background)" stroke="var(--c-primary)" strokeWidth="2" />
      <path d="M92 88l7 7" stroke="var(--c-primary)" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

export function useRipple() {
  return (e: React.PointerEvent<HTMLElement>) => {
    const el = e.currentTarget;
    const r = el.getBoundingClientRect();
    const s = document.createElement("span");
    const d = Math.max(r.width, r.height);
    s.className = "ripple";
    s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
    el.appendChild(s);
    setTimeout(() => s.remove(), 500);
  };
}
