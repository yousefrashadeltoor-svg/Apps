/**
 * Minimal, spec-compliant PDF 1.4 writer used by the web preview for "Images → PDF",
 * "Text → PDF" and scanner export (JPEG pages + optional invisible OCR text layer = searchable PDF).
 * The Android app uses MuPDF's PDFDocument/PDFWriter for the same operations.
 */
export interface PdfPage {
  widthPt: number;
  heightPt: number;
  jpeg?: { data: Uint8Array; w: number; h: number };
  text?: { lines: string[]; size?: number; invisible?: boolean; margin?: number };
}

const enc = (s: string) => { const b = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0xff; return b; };
const pdfStr = (s: string) => "(" + s.replace(/[^\x20-\x7E]/g, "?").replace(/([\\()])/g, "\\$1") + ")";

export function dataUrlToBytes(url: string): Uint8Array {
  const bin = atob(url.split(",")[1]); const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function wrapText(text: string, maxChars: number): string[] {
  const out: string[] = [];
  text.split("\n").forEach((para) => {
    if (!para.trim()) { out.push(""); return; }
    let line = "";
    para.split(/\s+/).forEach((w) => { if ((line + " " + w).trim().length > maxChars) { out.push(line); line = w; } else line = (line + " " + w).trim(); });
    if (line) out.push(line);
  });
  return out;
}

export function buildPdf(pages: PdfPage[], title = "JO bat"): Blob {
  const chunks: Uint8Array[] = [];
  const offsets: number[] = [];
  let pos = 0;
  const push = (b: Uint8Array) => { chunks.push(b); pos += b.length; };
  const obj = (n: number, body: (string | Uint8Array)[]) => { offsets[n] = pos; push(enc(`${n} 0 obj\n`)); body.forEach((p) => push(typeof p === "string" ? enc(p) : p)); push(enc("\nendobj\n")); };

  push(enc("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n"));
  const first = 5; // 1 catalog, 2 pages, 3 font, 4 info
  const kids: number[] = [];
  let n = first;
  const plan = pages.map((p) => { const page = n++, content = n++, img = p.jpeg ? n++ : 0; kids.push(page); return { p, page, content, img }; });

  obj(1, ["<< /Type /Catalog /Pages 2 0 R >>"]);
  obj(2, [`<< /Type /Pages /Count ${pages.length} /Kids [${kids.map((k) => `${k} 0 R`).join(" ")}] >>`]);
  obj(3, ["<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"]);
  obj(4, [`<< /Title ${pdfStr(title)} /Producer (JO bat preview) /CreationDate (D:${new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14)}) >>`]);

  for (const { p, page, content, img } of plan) {
    let cs = "";
    if (p.jpeg) cs += `q ${p.widthPt.toFixed(2)} 0 0 ${p.heightPt.toFixed(2)} 0 0 cm /Im0 Do Q\n`;
    if (p.text) {
      const size = p.text.size ?? 11, m = p.text.margin ?? 56, lead = size * 1.45;
      cs += `BT /F1 ${size} Tf ${p.text.invisible ? "3" : "0"} Tr ${lead.toFixed(2)} TL ${m} ${(p.heightPt - m - size).toFixed(2)} Td\n`;
      p.text.lines.forEach((l, i) => { cs += `${i ? "T* " : ""}${pdfStr(l)} Tj\n`; });
      cs += "ET\n";
    }
    const res = `<< /Font << /F1 3 0 R >>${img ? ` /XObject << /Im0 ${img} 0 R >>` : ""} >>`;
    obj(page, [`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${p.widthPt.toFixed(2)} ${p.heightPt.toFixed(2)}] /Resources ${res} /Contents ${content} 0 R >>`]);
    const csb = enc(cs);
    obj(content, [`<< /Length ${csb.length} >>\nstream\n`, csb, "\nendstream"]);
    if (img && p.jpeg) obj(img, [`<< /Type /XObject /Subtype /Image /Width ${p.jpeg.w} /Height ${p.jpeg.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.jpeg.data.length} >>\nstream\n`, p.jpeg.data, "\nendstream"]);
  }

  const xref = pos;
  let x = `xref\n0 ${n}\n0000000000 65535 f \n`;
  for (let i = 1; i < n; i++) x += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  push(enc(x + `trailer\n<< /Size ${n} /Root 1 0 R /Info 4 0 R >>\nstartxref\n${xref}\n%%EOF\n`));
  return new Blob(chunks as BlobPart[], { type: "application/pdf" });
}

/** Loads an image File/URL into a JPEG suitable for PDF embedding (EXIF orientation handled by the browser). */
export async function imageToJpeg(src: string, maxSide = 1800, quality = 0.85, filter = "none"): Promise<{ data: Uint8Array; w: number; h: number }> {
  const img = await new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
  const s = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement("canvas"); c.width = Math.round(img.naturalWidth * s); c.height = Math.round(img.naturalHeight * s);
  const g = c.getContext("2d")!; g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.filter = filter; g.drawImage(img, 0, 0, c.width, c.height);
  return { data: dataUrlToBytes(c.toDataURL("image/jpeg", quality)), w: c.width, h: c.height };
}
