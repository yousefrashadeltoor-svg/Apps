import { useEffect, useState } from "react";
import "./styles.css";
import { StatusBar, Toast } from "./components";
import { Icon } from "./icons";
import { Collections } from "./screens/Collections";
import { ImageEditor } from "./screens/ImageEditor";
import { Onboarding, Splash } from "./screens/Intro";
import { Library } from "./screens/Library";
import { PdfEditor } from "./screens/PdfEditor";
import { Reader } from "./screens/Reader";
import { Scanner } from "./screens/Scanner";
import { SettingsScreen, Stats } from "./screens/StatsSettings";
import { TextEditor } from "./screens/TextEditor";
import { Tools } from "./screens/Tools";
import { AppProvider, useApp, type Route, type Tab, type ThemeName } from "./store";

function RouteView({ r }: { r: Route }) {
  const { tab } = useApp();
  switch (r.name) {
    case "splash": return <Splash />;
    case "onboarding": return <Onboarding />;
    case "main": return (
      <div className="view" key={tab} style={{ animation: "fade var(--dur-medium) var(--ease-standard)" }}>
        {tab === "library" && <Library />}
        {tab === "tools" && <Tools />}
        {tab === "scanner" && <Scanner />}
        {tab === "collections" && <Collections />}
        {tab === "settings" && <SettingsScreen />}
      </div>
    );
    case "reader": return <Reader bookId={r.bookId} />;
    case "pdf": return <PdfEditor bookId={r.bookId} />;
    case "text": return <TextEditor kind={r.kind} />;
    case "image": return <ImageEditor />;
    case "stats": return <Stats />;
    case "quotes": return <Collections />;
  }
}

function LockScreen({ onUnlock }: { onUnlock: () => void }) {
  const { t } = useApp();
  return (
    <div className="view" style={{ background: "var(--c-background)", zIndex: 95, alignItems: "center", justifyContent: "center", textAlign: "center" }}>
      <Icon name="lock" size={28} style={{ color: "var(--c-primary)" }} />
      <div className="title-l" style={{ marginTop: 12 }}>{t.biometricTitle}</div>
      <button className="bio" onClick={onUnlock} aria-label={t.biometricBody}><span className="fp" style={{ display: "grid" }}><Icon name="finger" size={32} /></span></button>
      <div className="label-l muted">{t.biometricBody}</div>
    </div>
  );
}

function Phone() {
  const { theme, dir, lang, reduceMotion, stack, settings, route } = useApp();
  const [locked, setLocked] = useState(settings.appLock);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const showLock = locked && settings.appLock && route.name !== "splash";
  return (
    <div className="phone">
      <div className="screen">
        <div className="app" data-theme={theme} dir={dir} data-reduce-motion={reduceMotion}>
          {stack.map((r, i) => {
            const top = i === stack.length - 1;
            return (
              <div key={`${i}-${r.name}`} className={`view ${top && i > 0 && r.name !== "main" && r.name !== "onboarding" ? "push-enter" : ""}`} style={{ display: top ? "flex" : "none", background: "var(--c-background)" }}>
                <RouteView r={r} />
              </div>
            );
          })}
          {route.name !== "splash" && route.name !== "image" && route.name !== "reader" && <div style={{ position: "absolute", top: 0, left: 0, right: 0, zIndex: 41, pointerEvents: "none" }}><StatusBar /></div>}
          {(route.name === "image" || route.name === "reader") && <div style={{ position: "absolute", top: 0, left: 0, right: 0, zIndex: 41, pointerEvents: "none" }}><StatusBar light={route.name === "image"} /></div>}
          {showLock && <LockScreen onUnlock={() => setLocked(false)} />}
          <Toast />
          {settings.blueLight && <div className="blue-filter" />}
        </div>
      </div>
    </div>
  );
}

function Panel() {
  const { theme, setTheme, lang, setLang, reduceMotion, setReduceMotion, resetTo, push, setTab, t } = useApp();
  const themes: ThemeName[] = ["dark", "light", "amoled", "sepia", "dynamic"];
  const goTab = (tb: Tab) => { resetTo({ name: "main" }); setTab(tb); };
  const go = (r: Route, tb: Tab = "library") => { resetTo({ name: "main" }); setTab(tb); setTimeout(() => push(r), 0); };
  const screens: [string, () => void][] = [
    ["Splash", () => resetTo({ name: "splash" })],
    ["Onboarding", () => resetTo({ name: "onboarding" })],
    [t.navLibrary, () => goTab("library")],
    ["Reader · EN", () => go({ name: "reader", bookId: "b1" })],
    ["القارئ · AR", () => go({ name: "reader", bookId: "b2" })],
    [t.pdfEditor, () => go({ name: "pdf", bookId: "b4" })],
    [t.textEditor, () => go({ name: "text" }, "tools")],
    [t.imageEditor, () => go({ name: "image" }, "tools")],
    [t.navScanner, () => goTab("scanner")],
    [t.navTools, () => goTab("tools")],
    [t.navCollections, () => goTab("collections")],
    [t.stats, () => go({ name: "stats" })],
    [t.navSettings, () => goTab("settings")],
  ];
  return (
    <aside className="stage-panel" dir={lang === "ar" ? "rtl" : "ltr"}>
      <h1 dir="ltr"><span className="mono">𝒥𝒪</span> bat</h1>
      <p>Obsidian &amp; Champagne · com.jobat.reader</p>
      <div className="grp"><div className="lbl">Theme</div><div className="row">{themes.map((x) => <button key={x} className={`stage-btn ${theme === x ? "on" : ""}`} onClick={() => setTheme(x)}>{t[x]}</button>)}</div></div>
      <div className="grp"><div className="lbl">Language · Direction</div><div className="row"><button className={`stage-btn ${lang === "ar" ? "on" : ""}`} onClick={() => setLang("ar")}>العربية · RTL</button><button className={`stage-btn ${lang === "en" ? "on" : ""}`} onClick={() => setLang("en")}>English · LTR</button></div></div>
      <div className="grp"><div className="lbl">Motion</div><div className="row"><button className={`stage-btn ${reduceMotion ? "on" : ""}`} onClick={() => setReduceMotion(!reduceMotion)}>{t.reduceMotion}</button></div></div>
      <div className="grp"><div className="lbl">{t.screens}</div><div className="row">{screens.map(([l, fn]) => <button key={l} className="stage-btn" onClick={fn}>{l}</button>)}</div></div>
      <div className="stage-note">⚠︎ {t.previewNote}<br /><br />Tokens: <code>design-system/tokens/tokens.json</code> → Compose <code>JoBatTokens.kt</code> + CSS <code>tokens.generated.css</code>.<br />{lang === "ar" ? "اختصارات: الأسهم/المسافة للتقليب، PageUp/PageDown = أزرار الصوت، Ctrl+Z للتراجع، Ctrl+عجلة للتكبير، نقر مزدوج للتكبير، ضغط مطوّل لقائمة الكتاب." : "Shortcuts: arrows/space to turn pages, PageUp/PageDown = volume keys, Ctrl+Z undo, Ctrl+wheel or double-tap to zoom, long-press a book for actions."}</div>
    </aside>
  );
}

export default function PreviewApp() {
  return (
    <AppProvider>
      <div className="stage">
        <Panel />
        <Phone />
      </div>
    </AppProvider>
  );
}
