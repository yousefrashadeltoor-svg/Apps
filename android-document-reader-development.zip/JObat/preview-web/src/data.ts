export type Cat = "docs" | "books" | "comics" | "images" | "text";
export type Format = "PDF" | "EPUB" | "MOBI" | "AZW3" | "FB2" | "DJVU" | "CBZ" | "CBR" | "DOCX" | "XLSX" | "MD" | "TXT" | "HTML" | "JPG" | "PNG" | "ZIP";

export interface Book {
  id: string;
  title: string;
  author: string;
  format: Format;
  cat: Cat;
  pages: number;
  sizeMB: number;
  addedDays: number;
  lastReadHours: number | null;
  progress: number;
  cover: [string, string, number]; // gradient a, b, ornament style
  fav: boolean;
  archived: boolean;
  trashed: boolean;
  collections: string[];
  tags: string[];
  rtl: boolean;
  content: string; // key into CONTENT
  locked?: boolean;
}

export const BOOKS: Book[] = [
  { id: "b1", title: "Pride and Prejudice", author: "Jane Austen", format: "EPUB", cat: "books", pages: 432, sizeMB: 0.8, addedDays: 21, lastReadHours: 2, progress: 0.42, cover: ["#2B3A55", "#121826", 0], fav: true, archived: false, trashed: false, collections: ["c1"], tags: ["classic", "novel"], rtl: false, content: "pride" },
  { id: "b2", title: "رسائل في فنّ القراءة", author: "سلمى الراشد", format: "EPUB", cat: "books", pages: 214, sizeMB: 1.2, addedDays: 9, lastReadHours: 20, progress: 0.68, cover: ["#5A3D22", "#1F150C", 1], fav: true, archived: false, trashed: false, collections: ["c1", "c3"], tags: ["مقالات"], rtl: true, content: "rasail" },
  { id: "b3", title: "The Art of War", author: "Sun Tzu", format: "PDF", cat: "books", pages: 96, sizeMB: 2.4, addedDays: 40, lastReadHours: 72, progress: 0.15, cover: ["#5B1E1E", "#1C0B0B", 2], fav: false, archived: false, trashed: false, collections: ["c1"], tags: ["strategy"], rtl: false, content: "pride" },
  { id: "b4", title: "Annual Report 2025", author: "Northwind Ltd.", format: "PDF", cat: "docs", pages: 48, sizeMB: 6.3, addedDays: 3, lastReadHours: 5, progress: 0.25, cover: ["#E9E2D2", "#CFC4AC", 3], fav: false, archived: false, trashed: false, collections: ["c2"], tags: ["work"], rtl: false, content: "report" },
  { id: "b5", title: "عقد خدمات — مسودة", author: "الشؤون القانونية", format: "PDF", cat: "docs", pages: 12, sizeMB: 0.4, addedDays: 1, lastReadHours: null, progress: 0, cover: ["#DCD6C8", "#B9AF98", 3], fav: false, archived: false, trashed: false, collections: ["c2"], tags: ["عمل", "توقيع"], rtl: true, content: "report", locked: true },
  { id: "b6", title: "Meditations", author: "Marcus Aurelius", format: "MOBI", cat: "books", pages: 254, sizeMB: 0.6, addedDays: 60, lastReadHours: 300, progress: 1, cover: ["#3B4A3A", "#141A14", 0], fav: true, archived: false, trashed: false, collections: ["c1"], tags: ["philosophy"], rtl: false, content: "pride" },
  { id: "b7", title: "Nightfall Vol. 1", author: "K. Morita", format: "CBZ", cat: "comics", pages: 188, sizeMB: 64, addedDays: 12, lastReadHours: 140, progress: 0.33, cover: ["#1A1A2E", "#E94560", 4], fav: false, archived: false, trashed: false, collections: [], tags: ["manga"], rtl: false, content: "pride" },
  { id: "b8", title: "ألف ليلة وليلة — مختارات", author: "تراث", format: "FB2", cat: "books", pages: 512, sizeMB: 1.9, addedDays: 30, lastReadHours: 500, progress: 0.08, cover: ["#24324A", "#0D1320", 1], fav: false, archived: false, trashed: false, collections: ["c3"], tags: ["تراث"], rtl: true, content: "rasail" },
  { id: "b9", title: "Thesis — Final Draft", author: "M. Haddad", format: "DOCX", cat: "docs", pages: 86, sizeMB: 3.1, addedDays: 5, lastReadHours: 26, progress: 0.9, cover: ["#F2EEE6", "#D9D1C1", 3], fav: false, archived: false, trashed: false, collections: ["c2"], tags: ["research"], rtl: false, content: "report" },
  { id: "b10", title: "Project notes", author: "You", format: "MD", cat: "text", pages: 3, sizeMB: 0.01, addedDays: 2, lastReadHours: 8, progress: 0, cover: ["#1E2128", "#0B0C10", 5], fav: false, archived: false, trashed: false, collections: [], tags: ["notes"], rtl: false, content: "report" },
  { id: "b11", title: "Old Map Archive", author: "Library scans", format: "DJVU", cat: "docs", pages: 140, sizeMB: 22, addedDays: 90, lastReadHours: null, progress: 0, cover: ["#6B5A3A", "#2A2214", 2], fav: false, archived: true, trashed: false, collections: [], tags: ["maps"], rtl: false, content: "report" },
  { id: "b12", title: "Reading corner", author: "Camera", format: "JPG", cat: "images", pages: 1, sizeMB: 2.8, addedDays: 4, lastReadHours: 30, progress: 0, cover: ["#8A6A3A", "#2E2010", 6], fav: false, archived: false, trashed: false, collections: [], tags: ["photo"], rtl: false, content: "report" },
  { id: "b13", title: "Moby-Dick", author: "Herman Melville", format: "AZW3", cat: "books", pages: 720, sizeMB: 1.4, addedDays: 75, lastReadHours: null, progress: 0, cover: ["#1F3B4D", "#0A141B", 0], fav: false, archived: false, trashed: false, collections: ["c1"], tags: ["classic"], rtl: false, content: "pride" },
  { id: "b14", title: "Invoice 0425", author: "Atlas Studio", format: "PDF", cat: "docs", pages: 1, sizeMB: 0.2, addedDays: 14, lastReadHours: null, progress: 0, cover: ["#EDE7DA", "#CBBF9F", 3], fav: false, archived: false, trashed: true, collections: [], tags: ["finance"], rtl: false, content: "report" },
];

export interface Collection { id: string; name: string; color: string }
export const COLLECTIONS: Collection[] = [
  { id: "c1", name: "Classics · كلاسيكيات", color: "#D4B26A" },
  { id: "c2", name: "Work · العمل", color: "#7FA7C9" },
  { id: "c3", name: "عربي", color: "#C98F7F" },
];

export interface Chapter { title: string; paras: string[] }

export const CONTENT: Record<string, Chapter[]> = {
  pride: [
    { title: "Chapter 1", paras: [
      "It is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife.",
      "However little known the feelings or views of such a man may be on his first entering a neighbourhood, this truth is so well fixed in the minds of the surrounding families, that he is considered the rightful property of some one or other of their daughters.",
      "“My dear Mr. Bennet,” said his lady to him one day, “have you heard that Netherfield Park is let at last?”",
      "Mr. Bennet replied that he had not.",
      "“But it is,” returned she; “for Mrs. Long has just been here, and she told me all about it.”",
      "Mr. Bennet made no answer.",
      "“Do you not want to know who has taken it?” cried his wife impatiently.",
      "“You want to tell me, and I have no objection to hearing it.”",
      "This was invitation enough.",
      "“Why, my dear, you must know, Mrs. Long says that Netherfield is taken by a young man of large fortune from the north of England; that he came down on Monday in a chaise and four to see the place, and was so much delighted with it, that he agreed with Mr. Morris immediately; that he is to take possession before Michaelmas, and some of his servants are to be in the house by the end of next week.”",
      "“What is his name?” “Bingley.” “Is he married or single?” “Oh! Single, my dear, to be sure! A single man of large fortune; four or five thousand a year. What a fine thing for our girls!”",
    ]},
    { title: "Chapter 2", paras: [
      "Mr. Bennet was among the earliest of those who waited on Mr. Bingley. He had always intended to visit him, though to the last always assuring his wife that he should not go; and till the evening after the visit was paid she had no knowledge of it.",
      "It was then disclosed in the following manner. Observing his second daughter employed in trimming a hat, he suddenly addressed her with: “I hope Mr. Bingley will like it, Lizzy.”",
      "“We are not in a way to know what Mr. Bingley likes,” said her mother resentfully, “since we are not to visit.”",
      "“But you forget, mamma,” said Elizabeth, “that we shall meet him at the assemblies, and that Mrs. Long promised to introduce him.”",
      "“I do not believe Mrs. Long will do any such thing. She has two nieces of her own. She is a selfish, hypocritical woman, and I have no opinion of her.”",
    ]},
    { title: "Chapter 3", paras: [
      "Not all that Mrs. Bennet, however, with the assistance of her five daughters, could ask on the subject, was sufficient to draw from her husband any satisfactory description of Mr. Bingley.",
      "They attacked him in various ways—with barefaced questions, ingenious suppositions, and distant surmises; but he eluded the skill of them all, and they were at last obliged to accept the second-hand intelligence of their neighbour, Lady Lucas.",
      "Her report was highly favourable. Sir William had been delighted with him. He was quite young, wonderfully handsome, extremely agreeable, and, to crown the whole, he meant to be at the next assembly with a large party.",
      "Nothing could be more delightful! To be fond of dancing was a certain step towards falling in love; and very lively hopes of Mr. Bingley’s heart were entertained.",
    ]},
  ],
  rasail: [
    { title: "الرسالة الأولى: في الصبر على الصفحة", paras: [
      "يا صديقي، ليست القراءة سباقًا نحو الصفحة الأخيرة، بل إقامةٌ قصيرة في بيتٍ بناه غيرُك بالكلمات. ادخله بتمهّل، وتأمّل نوافذه قبل أن تبحث عن الباب الخلفي.",
      "حين تفتح كتابًا جديدًا، امنحه عشر صفحات من الصبر. فالكتب الجيدة كالأصدقاء الحقيقيين؛ لا تكشف عن نفسها في اللقاء الأول، بل تنتظر منك أن تعود.",
      "وإذا وجدت جملةً أوقفتك، فلا تمضِ عنها مسرعًا. ضع تحتها خطًّا، أو اكتب في الهامش سؤالك. فالهامش هو المكان الذي يتحاور فيه القارئ مع المؤلف دون أن يقاطعه.",
      "أما الكتاب الذي لا يترك فيك أثرًا، فلا تلُم نفسك على تركه. ليس كل بابٍ مكتوبًا لك، وليس كل طريقٍ يلزمك أن تسيره حتى آخره.",
      "وتذكّر أن القراءة في الليل تختلف عن القراءة في الصباح؛ ففي الصباح تقرأ بعقلك، وفي الليل تقرأ بقلبك. فاختر لكل وقتٍ كتابه.",
    ]},
    { title: "الرسالة الثانية: في الضوء والورق", paras: [
      "للضوء أثرٌ في المعنى أكثر مما نظن. الورق العاجي في ضوء المصباح الدافئ يُليّن الكلمات، والشاشة الساطعة في العتمة تجعلها حادّةً كالزجاج.",
      "لذلك اعتنِ بمكان قراءتك: كرسيٌّ يحتمل جلوسك الطويل، وضوءٌ يأتي من خلف كتفك، وصمتٌ لا تقطعه الإشعارات.",
      "وإن قرأت على جهاز، فاجعله يشبه الورق ما استطعت؛ خفّف سطوعه، واختر لونًا هادئًا للصفحة، ودَع الحروف تتنفس بين السطور.",
      "إن العين التي ترتاح تقرأ أبعد، والذهن الذي لا يتعب يفهم أعمق.",
    ]},
    { title: "الرسالة الثالثة: في الاقتباس", paras: [
      "الاقتباس ليس سرقةً للجمال، بل اعترافٌ به. حين تنقل جملةً إلى دفترك، فأنت تقول للكاتب: لقد وصلتني رسالتك.",
      "اجمع اقتباساتك في مكان واحد، وعُد إليها في آخر كل شهر. ستكتشف أنك كنت تبحث عن الشيء نفسه في كتب مختلفة، وأن كل تلك الجمل كانت ترسم وجهك أنت.",
      "وإذا شاركت اقتباسًا، فاذكر صاحبه؛ فالأمانة في الكلمة أول أخلاق القارئ.",
    ]},
  ],
  report: [
    { title: "1. Executive summary", paras: [
      "Fiscal year 2025 marked a period of disciplined growth. Revenue increased 18% year over year to $42.6M, driven by expansion in the EMEA region and the launch of two new product lines.",
      "Operating margin improved from 11.2% to 14.8% as a result of supply-chain consolidation and the automation of key fulfilment processes.",
      "The board recommends a dividend of $0.42 per share, subject to shareholder approval at the annual general meeting.",
    ]},
    { title: "2. Operations", paras: [
      "Our three distribution centres processed 1.9 million orders, with an average dispatch time of 21 hours — an improvement of six hours compared with 2024.",
      "Carbon emissions per order fell by 23%, reflecting the transition of 60% of the delivery fleet to electric vehicles.",
      "Employee engagement reached 81%, the highest score recorded since the survey began.",
    ]},
    { title: "3. Outlook", paras: [
      "For 2026 we expect revenue growth between 12% and 15%, with continued investment in research, regional partnerships and accessibility across all our digital products.",
      "Risks include currency volatility and component lead times; mitigation plans are described in section 7.",
    ]},
  ],
};

export interface Quote { id: string; bookId: string; text: string; note?: string; color: string; page: number; date: string }
export const QUOTES: Quote[] = [
  { id: "q1", bookId: "b1", text: "It is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife.", color: "#D4B26A", page: 1, date: "2026-03-02", note: "The most famous opening line." },
  { id: "q2", bookId: "b2", text: "الكتب الجيدة كالأصدقاء الحقيقيين؛ لا تكشف عن نفسها في اللقاء الأول، بل تنتظر منك أن تعود.", color: "#7FBF8E", page: 3, date: "2026-03-05" },
  { id: "q3", bookId: "b6", text: "You have power over your mind — not outside events. Realize this, and you will find strength.", color: "#7FA7C9", page: 44, date: "2026-02-18" },
  { id: "q4", bookId: "b2", text: "إن العين التي ترتاح تقرأ أبعد، والذهن الذي لا يتعب يفهم أعمق.", color: "#D4B26A", page: 12, date: "2026-03-08", note: "تذكير بضبط ثيم القراءة ليلًا" },
];

export const WEEK_MINUTES = [34, 52, 18, 66, 41, 75, 48];
export const HEATMAP = Array.from({ length: 84 }, (_, i) => {
  const v = Math.sin(i * 1.7) * 0.5 + Math.cos(i * 0.43) * 0.5;
  return i % 9 === 4 ? 0 : Math.max(0, Math.round((v + 1) * 2));
});

export const SAMPLE_MD = `# Project notes — JO bat

A **luxury** offline reader. Ideas for the next sprint:

## Reader
- [x] Paged & scroll modes
- [x] Sepia / Midnight themes
- [ ] Curl animation polish

> Motion should serve reading, never slow it down.

\`\`\`kotlin
val zoom = widthPx / page.width
doc.renderPage(index, bitmap, zoom)
\`\`\`

| Format | Engine |
|---|---|
| PDF | MuPDF |
| DjVu | djvulibre |

Visit the [docs](https://example.com) for more.
`;

export const SAMPLE_HTML = `<!doctype html>
<html lang="en">
<head>
  <style>
    body { font-family: Georgia, serif; background: #F6F1E7; color: #26231E; padding: 24px; }
    h1 { color: #9C7A35; font-weight: 600; }
    .card { border: 1px solid #D6CCB8; border-radius: 12px; padding: 16px; }
  </style>
</head>
<body>
  <h1>Hello, JO bat</h1>
  <div class="card">
    <p>Edit this HTML and watch the <b>live preview</b>.</p>
  </div>
</body>
</html>
`;

export const SAMPLE_CSV = `title,author,format,pages
Pride and Prejudice,Jane Austen,EPUB,432
The Art of War,Sun Tzu,PDF,96
Meditations,Marcus Aurelius,MOBI,254
`;

export const OCR_TEXT = `Building Healthier Communities
People. Places. A Stronger Tomorrow.

Healthy communities are the foundation of a fair and prosperous society. When people have access to safe housing, clean environments, quality education and reliable healthcare, they are more likely to thrive. These conditions not only improve individual well-being but also create stronger, more resilient communities for generations to come.

Creating healthier communities requires collaboration. Local governments, community organisations, businesses and residents all have a role to play.`;
