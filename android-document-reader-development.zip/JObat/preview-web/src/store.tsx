import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { BOOKS, COLLECTIONS, QUOTES, type Book, type Collection, type Quote } from "./data";
import { strings, type Lang, type Strings } from "./i18n";

export type ThemeName = "dark" | "light" | "amoled" | "sepia" | "dynamic";
export type Tab = "library" | "tools" | "scanner" | "collections" | "settings";
export type Route =
  | { name: "splash" }
  | { name: "onboarding" }
  | { name: "main" }
  | { name: "reader"; bookId: string }
  | { name: "pdf"; bookId?: string }
  | { name: "text"; kind?: "md" | "html" | "csv" }
  | { name: "image" }
  | { name: "stats" }
  | { name: "quotes" };

export interface Settings {
  appLock: boolean;
  vault: boolean;
  blueLight: boolean;
  blueSchedule: boolean;
  haptics: boolean;
  volumeKeys: boolean;
  folders: string[];
  dailyGoal: number;
}

interface ToastState { id: number; msg: string; action?: { label: string; run: () => void } }

interface Store {
  theme: ThemeName; setTheme: (t: ThemeName) => void;
  lang: Lang; setLang: (l: Lang) => void; t: Strings; dir: "rtl" | "ltr";
  reduceMotion: boolean; setReduceMotion: (b: boolean) => void;
  tab: Tab; setTab: (t: Tab) => void;
  stack: Route[]; route: Route; push: (r: Route) => void; pop: () => void; resetTo: (r: Route) => void;
  books: Book[]; updateBook: (id: string, patch: Partial<Book>) => void;
  quotes: Quote[]; addQuote: (q: Omit<Quote, "id" | "date">) => void; removeQuote: (id: string) => void;
  collections: Collection[]; addCollection: (name: string) => void;
  settings: Settings; setSetting: <K extends keyof Settings>(k: K, v: Settings[K]) => void;
  signatures: string[]; addSignature: (d: string) => void;
  toast: ToastState | null; showToast: (msg: string, action?: ToastState["action"]) => void; dismissToast: () => void;
  haptic: () => void;
  exportBackup: () => void; importBackup: (file: File) => Promise<void>;
  download: (name: string, content: string | Blob, mime?: string) => void;
}

const Ctx = createContext<Store | null>(null);
const LS = "jobat-preview";

function load<T>(key: string, fallback: T): T {
  try { const raw = localStorage.getItem(`${LS}:${key}`); return raw ? (JSON.parse(raw) as T) : fallback; } catch { return fallback; }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeS] = useState<ThemeName>(() => load("theme", "dark"));
  const [lang, setLangS] = useState<Lang>(() => load("lang", "ar"));
  const [reduceMotion, setRM] = useState<boolean>(() => load("rm", typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches));
  const [tab, setTabS] = useState<Tab>("library");
  const [stack, setStack] = useState<Route[]>([{ name: "splash" }]);
  const [books, setBooks] = useState<Book[]>(() => load("books", BOOKS));
  const [quotes, setQuotes] = useState<Quote[]>(() => load("quotes", QUOTES));
  const [collections, setCollections] = useState<Collection[]>(() => load("collections", COLLECTIONS));
  const [settings, setSettings] = useState<Settings>(() => load("settings", {
    appLock: false, vault: true, blueLight: false, blueSchedule: true, haptics: true, volumeKeys: true,
    folders: ["/Download", "/Documents/Books"], dailyGoal: 45,
  }));
  const [signatures, setSignatures] = useState<string[]>(() => load("sigs", []));
  const [toast, setToast] = useState<ToastState | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  useEffect(() => { localStorage.setItem(`${LS}:theme`, JSON.stringify(theme)); }, [theme]);
  useEffect(() => { localStorage.setItem(`${LS}:lang`, JSON.stringify(lang)); }, [lang]);
  useEffect(() => { localStorage.setItem(`${LS}:rm`, JSON.stringify(reduceMotion)); }, [reduceMotion]);
  useEffect(() => { localStorage.setItem(`${LS}:books`, JSON.stringify(books)); }, [books]);
  useEffect(() => { localStorage.setItem(`${LS}:quotes`, JSON.stringify(quotes)); }, [quotes]);
  useEffect(() => { localStorage.setItem(`${LS}:collections`, JSON.stringify(collections)); }, [collections]);
  useEffect(() => { localStorage.setItem(`${LS}:settings`, JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem(`${LS}:sigs`, JSON.stringify(signatures)); }, [signatures]);

  const haptic = useCallback(() => {
    if (settings.haptics && "vibrate" in navigator) { try { navigator.vibrate(8); } catch { /* unsupported */ } }
  }, [settings.haptics]);

  const showToast = useCallback((msg: string, action?: ToastState["action"]) => {
    window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), msg, action });
    toastTimer.current = window.setTimeout(() => setToast(null), action ? 4500 : 2600);
  }, []);

  const download = useCallback((name: string, content: string | Blob, mime = "text/plain") => {
    const blob = typeof content === "string" ? new Blob([content], { type: `${mime};charset=utf-8` }) : content;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }, []);

  const value = useMemo<Store>(() => ({
    theme, setTheme: setThemeS,
    lang, setLang: setLangS, t: strings[lang], dir: lang === "ar" ? "rtl" : "ltr",
    reduceMotion, setReduceMotion: setRM,
    tab, setTab: (t) => { setTabS(t); },
    stack, route: stack[stack.length - 1],
    push: (r) => setStack((s) => [...s, r]),
    pop: () => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)),
    resetTo: (r) => setStack([r]),
    books, updateBook: (id, patch) => setBooks((bs) => bs.map((b) => (b.id === id ? { ...b, ...patch } : b))),
    quotes,
    addQuote: (q) => setQuotes((qs) => [{ ...q, id: `q${Date.now()}`, date: new Date().toISOString().slice(0, 10) }, ...qs]),
    removeQuote: (id) => setQuotes((qs) => qs.filter((q) => q.id !== id)),
    collections, addCollection: (name) => setCollections((cs) => [...cs, { id: `c${Date.now()}`, name, color: ["#D4B26A", "#7FA7C9", "#C98F7F", "#7FBF8E", "#B39DDB"][cs.length % 5] }]),
    settings, setSetting: (k, v) => setSettings((s) => ({ ...s, [k]: v })),
    signatures, addSignature: (d) => setSignatures((s) => [d, ...s].slice(0, 4)),
    toast, showToast, dismissToast: () => setToast(null),
    haptic,
    download,
    exportBackup: () => {
      const payload = { app: "com.jobat.reader", format: 1, createdAt: new Date().toISOString(), theme, lang, settings, books, quotes, collections, signatures };
      download(`jobat-backup-${new Date().toISOString().slice(0, 10)}.jobat`, JSON.stringify(payload, null, 2), "application/json");
    },
    importBackup: async (file) => {
      const data = JSON.parse(await file.text());
      if (data.app !== "com.jobat.reader") throw new Error("Not a JO bat backup");
      if (data.settings) setSettings(data.settings);
      if (data.books) setBooks(data.books);
      if (data.quotes) setQuotes(data.quotes);
      if (data.collections) setCollections(data.collections);
      if (data.signatures) setSignatures(data.signatures);
      if (data.theme) setThemeS(data.theme);
      if (data.lang) setLangS(data.lang);
    },
  }), [theme, lang, reduceMotion, tab, stack, books, quotes, collections, settings, signatures, toast, showToast, haptic, download]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useApp outside provider");
  return c;
}
