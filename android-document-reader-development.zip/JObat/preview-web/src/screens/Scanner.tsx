/// <reference path="../assets.d.ts" />
import { useEffect, useRef, useState } from "react";
import docImg from "../../assets/document.jpg";
import { BottomNav, IconBtn, Sheet } from "../components";
import { OCR_TEXT } from "../data";
import { Icon } from "../icons";
import { buildPdf, dataUrlToBytes, wrapText } from "../pdf";
import { useApp } from "../store";

type Pt = [number, number];
type Enh = "orig" | "color" | "gray" | "bw";
interface ScanPage { id: string; corners: Pt[]; enh: Enh; rot: number }
// Corners found by the edge detector for the sample frame (normalized TL, TR, BR, BL)
const DETECTED: Pt[] = [[0.178, 0.113], [0.901, 0.146], [0.889, 0.934], [0.052, 0.887]];

let srcCache: ImageData | null = null;
async function sourcePixels(): Promise<ImageData> {
  if (srcCache) return srcCache;
  const img = await new Promise<HTMLImageElement>((r) => { const i = new Image(); i.onload = () => r(i); i.src = docImg; });
  const c = document.createElement("canvas"); c.width = img.naturalWidth; c.height = img.naturalHeight;
  const g = c.getContext("2d")!; g.drawImage(img, 0, 0); srcCache = g.getImageData(0, 0, c.width, c.height);
  return srcCache;
}

/** Perspective correction: square→quad homography (Heckbert) + bilinear sampling. Mirrors core-native's warp. */
function warp(src: ImageData, q: Pt[], maxSide = 900): ImageData {
  const P = q.map(([x, y]) => [x * src.width, y * src.height]);
  const dist = (a: number[], b: number[]) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  let W = Math.max(dist(P[0], P[1]), dist(P[3], P[2])), H = Math.max(dist(P[0], P[3]), dist(P[1], P[2]));
  const s = Math.min(1, maxSide / Math.max(W, H)); W = Math.round(W * s); H = Math.round(H * s);
  const [x0, y0] = P[0], [x1, y1] = P[1], [x2, y2] = P[2], [x3, y3] = P[3];
  const dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3, dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
  const den = dx1 * dy2 - dx2 * dy1;
  const g = (dx3 * dy2 - dx2 * dy3) / den, h = (dx1 * dy3 - dx3 * dy1) / den;
  const a = x1 - x0 + g * x1, b = x3 - x0 + h * x3, d = y1 - y0 + g * y1, e = y3 - y0 + h * y3;
  const out = new ImageData(W, H); const o = out.data, sd = src.data, sw = src.width, sh = src.height;
  for (let j = 0; j < H; j++) {
    const v = j / (H - 1);
    for (let i = 0; i < W; i++) {
      const u = i / (W - 1); const z = g * u + h * v + 1;
      const sx = (a * u + b * v + x0) / z, sy = (d * u + e * v + y0) / z;
      const ix = Math.floor(sx), iy = Math.floor(sy), fx = sx - ix, fy = sy - iy;
      const k = (j * W + i) * 4;
      if (ix < 0 || iy < 0 || ix >= sw - 1 || iy >= sh - 1) { o[k] = o[k + 1] = o[k + 2] = 255; o[k + 3] = 255; continue; }
      const p00 = (iy * sw + ix) * 4, p10 = p00 + 4, p01 = p00 + sw * 4, p11 = p01 + 4;
      for (let c = 0; c < 3; c++) o[k + c] = (sd[p00 + c] * (1 - fx) + sd[p10 + c] * fx) * (1 - fy) + (sd[p01 + c] * (1 - fx) + sd[p11 + c] * fx) * fy;
      o[k + 3] = 255;
    }
  }
  return out;
}

/** JS port of core-native adaptiveThreshold (integral image, block mean − c). */
function adaptiveThreshold(img: ImageData, block = 31, c = 12) {
  const { width: w, height: h, data: d } = img; const I = new Float64Array((w + 1) * (h + 1)); const L = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) { let row = 0; for (let x = 0; x < w; x++) { const k = (y * w + x) * 4; const l = (d[k] * 77 + d[k + 1] * 150 + d[k + 2] * 29) >> 8; L[y * w + x] = l; row += l; I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + row; } }
  const r = block >> 1;
  for (let y = 0; y < h; y++) { const y0 = Math.max(0, y - r), y1 = Math.min(h - 1, y + r); for (let x = 0; x < w; x++) {
    const x0 = Math.max(0, x - r), x1 = Math.min(w - 1, x + r);
    const sum = I[(y1 + 1) * (w + 1) + x1 + 1] - I[y0 * (w + 1) + x1 + 1] - I[(y1 + 1) * (w + 1) + x0] + I[y0 * (w + 1) + x0];
    const v = L[y * w + x] < sum / ((x1 - x0 + 1) * (y1 - y0 + 1)) - c ? 0 : 255; const k = (y * w + x) * 4; d[k] = d[k + 1] = d[k + 2] = v;
  } }
}

async function renderScan(p: ScanPage): Promise<string> {
  const src = await sourcePixels(); const img = warp(src, p.corners);
  if (p.enh === "bw") adaptiveThreshold(img);
  const c = document.createElement("canvas"); c.width = img.width; c.height = img.height; c.getContext("2d")!.putImageData(img, 0, 0);
  const out = document.createElement("canvas"); const swap = p.rot % 180 !== 0; out.width = swap ? c.height : c.width; out.height = swap ? c.width : c.height;
  const g = out.getContext("2d")!; g.translate(out.width / 2, out.height / 2); g.rotate((p.rot * Math.PI) / 180);
  g.filter = p.enh === "color" ? "contrast(1.35) brightness(1.08) saturate(1.2)" : p.enh === "gray" ? "grayscale(1) contrast(1.2) brightness(1.05)" : "none";
  g.drawImage(c, -c.width / 2, -c.height / 2);
  return out.toDataURL("image/jpeg", 0.88);
}

export function Scanner() {
  const { t, showToast, download, haptic, lang } = useApp();
  const [phase, setPhase] = useState<"camera" | "review">("camera");
  const [detected, setDetected] = useState(false);
  const [auto, setAuto] = useState(true);
  const [flash, setFlash] = useState(false);
  const [fx, setFx] = useState(0);
  const [pages, setPages] = useState<ScanPage[]>([]);
  const [cur, setCur] = useState(0);
  const [rendered, setRendered] = useState<Record<string, string>>({});
  const [editCorners, setEditCorners] = useState(false);
  const [ocr, setOcr] = useState<"idle" | "running" | "done">("idle");
  const [ocrOpen, setOcrOpen] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const dragC = useRef<number | null>(null);

  useEffect(() => {
    if (phase !== "camera") return;
    setDetected(false);
    const a = setTimeout(() => setDetected(true), 1300);
    return () => clearTimeout(a);
  }, [phase, pages.length]);
  useEffect(() => {
    if (!(phase === "camera" && detected && auto && pages.length === 0)) return;
    const id = setTimeout(capture, 1800);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detected, auto, phase]);

  const page = pages[cur];
  const key = page ? `${page.id}-${page.enh}-${page.rot}-${page.corners.flat().join(",")}` : "";
  useEffect(() => {
    if (!page || rendered[key]) return;
    let live = true; renderScan(page).then((u) => live && setRendered((r) => ({ ...r, [key]: u })));
    return () => { live = false; };
  }, [key, page, rendered]);

  function capture() {
    haptic(); setFx((f) => f + 1);
    setPages((ps) => [...ps, { id: `s${Date.now()}`, corners: DETECTED.map((c) => [...c] as Pt), enh: "color", rot: 0 }]);
  }
  const update = (patch: Partial<ScanPage>) => setPages((ps) => ps.map((p, i) => (i === cur ? { ...p, ...patch } : p)));

  const exportPdf = async () => {
    const imgs = await Promise.all(pages.map(renderScan));
    const pdfPages = await Promise.all(imgs.map(async (u, i) => {
      const im = await new Promise<HTMLImageElement>((r) => { const x = new Image(); x.onload = () => r(x); x.src = u; });
      const wPt = 595, hPt = (595 * im.height) / im.width;
      return { widthPt: wPt, heightPt: hPt, jpeg: { data: dataUrlToBytes(u), w: im.width, h: im.height }, text: ocr === "done" && i === 0 ? { lines: wrapText(OCR_TEXT, 78), invisible: true, size: 10, margin: 60 } : undefined };
    }));
    download(`Scan ${new Date().toISOString().slice(0, 10)}.pdf`, buildPdf(pdfPages, "JO bat scan"));
    showToast(ocr === "done" ? t.searchablePdf : `${t.exportPdf} ✓`);
  };
  const runOcr = () => { setOcr("running"); setTimeout(() => { setOcr("done"); setOcrOpen(true); }, 1900); };

  const corners = page?.corners ?? DETECTED;
  const poly = (cs: Pt[]) => cs.map(([x, y]) => `${x * 100},${y * 100}`).join(" ");

  if (phase === "camera") return (
    <div className="view" style={{ background: "#000" }}>
      <div className="cam" style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ position: "relative", width: "100%", aspectRatio: "1086/1448", filter: flash ? "brightness(1.18)" : undefined }}>
          <img className="feed" src={docImg} alt="" style={{ animation: "none" }} />
          <svg className="quad" viewBox="0 0 100 100" preserveAspectRatio="none">
            {detected ? <polygon points={poly(DETECTED)} fill="rgba(212,178,106,.16)" stroke="#D4B26A" strokeWidth=".6" style={{ animation: "fade var(--dur-medium) both" }} /> : null}
          </svg>
          {!detected && <div className="scan-line" />}
        </div>
        {fx > 0 && <div className="flash-fx" key={fx} />}
        <div style={{ position: "absolute", top: 54, left: 0, right: 0, display: "flex", justifyContent: "space-between", padding: "0 12px", color: "#fff" }}>
          <button className={`chip ${auto ? "on" : ""}`} style={{ color: auto ? undefined : "#fff", borderColor: "rgba(255,255,255,.4)", background: auto ? undefined : "rgba(0,0,0,.35)" }} onClick={() => setAuto(!auto)}>{t.auto}</button>
          <button className="ib" style={{ color: flash ? "var(--brand-champagne)" : "#fff", background: "rgba(0,0,0,.35)" }} onClick={() => setFlash(!flash)} aria-label={t.flash}><Icon name="flash" /></button>
        </div>
        <div style={{ position: "absolute", bottom: 210, left: 0, right: 0, textAlign: "center" }}>
          <span className="label-l" style={{ background: "rgba(0,0,0,.55)", color: detected ? "#D4B26A" : "#fff", padding: "6px 14px", borderRadius: 999, backdropFilter: "blur(8px)" }}>{detected ? t.detected : t.detecting}</span>
        </div>
      </div>
      <div style={{ position: "absolute", bottom: 100, left: 0, right: 0, display: "flex", alignItems: "center", justifyContent: "space-around" }}>
        <div style={{ width: 52, height: 52 }}>
          {pages.length > 0 && rendered[`${pages[pages.length - 1].id}-color-0-${pages[pages.length - 1].corners.flat().join(",")}`] ? null : null}
          {pages.length > 0 && <div style={{ width: 44, height: 56, borderRadius: 6, background: "#fff", border: "2px solid #fff", position: "relative", boxShadow: "0 4px 12px rgba(0,0,0,.5)" }}><span style={{ position: "absolute", top: -8, insetInlineEnd: -8, minWidth: 20, height: 20, borderRadius: 10, background: "var(--brand-champagne)", color: "#1A1408", font: "600 11px/20px Inter", textAlign: "center" }}>{pages.length}</span><div style={{ position: "absolute", inset: 6, background: "repeating-linear-gradient(#ccc 0 1.5px, transparent 1.5px 5px)" }} /></div>}
        </div>
        <button className="shutter" onClick={capture} aria-label={t.capture}><i /></button>
        <button className="btn sm" style={{ visibility: pages.length ? "visible" : "hidden" }} onClick={() => { setCur(pages.length - 1); setPhase("review"); }}>{t.done}</button>
      </div>
      <BottomNav />
    </div>
  );

  return (
    <div className="view">
      <div style={{ height: 44 }} />
      <div className="top">
        <IconBtn name="camera" label={t.retake} onClick={() => setPhase("camera")} />
        <div className="grow"><div className="title-m">{t.scans}</div><div className="label-s muted">{cur + 1} / {pages.length}</div></div>
        <IconBtn name="rotate" label={t.rotate} onClick={() => update({ rot: (page.rot + 90) % 360 })} />
        <IconBtn name="crop" label={t.adjustCorners} on={editCorners} onClick={() => setEditCorners(!editCorners)} />
        <IconBtn name="trash" label={t.delete} onClick={() => { const n = pages.filter((_, i) => i !== cur); setPages(n); if (!n.length) setPhase("camera"); else setCur(Math.max(0, cur - 1)); }} />
      </div>
      <div style={{ flex: 1, display: "grid", placeItems: "center", padding: 16, background: "var(--c-surface-high)", position: "relative", overflow: "hidden", minHeight: 0 }}>
        {editCorners ? (
          <div ref={boxRef} style={{ position: "relative", height: "100%", aspectRatio: "1086/1448", maxWidth: "100%", touchAction: "none" }}
            onPointerMove={(e) => { if (dragC.current == null) return; const r = boxRef.current!.getBoundingClientRect(); const c = [...corners]; c[dragC.current] = [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))]; update({ corners: c }); }}
            onPointerUp={() => (dragC.current = null)}>
            <img src={docImg} alt="" style={{ width: "100%", height: "100%", objectFit: "fill", borderRadius: 8 }} />
            <svg className="quad" viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}><polygon points={poly(corners)} fill="rgba(212,178,106,.14)" stroke="#D4B26A" strokeWidth=".6" /></svg>
            {corners.map(([x, y], i) => <span key={i} className="quad-h" style={{ left: `${x * 100}%`, top: `${y * 100}%` }} onPointerDown={(e) => { (e.target as Element).setPointerCapture(e.pointerId); dragC.current = i; }} />)}
            <div className="label-s" style={{ position: "absolute", bottom: 8, left: 0, right: 0, textAlign: "center", color: "#fff", textShadow: "0 1px 3px #000" }}>{t.adjustCorners}</div>
          </div>
        ) : rendered[key] ? (
          <img src={rendered[key]} alt="" className="zoom-enter" key={key} style={{ maxWidth: "100%", maxHeight: "100%", boxShadow: "var(--elev-3)", borderRadius: 2 }} />
        ) : <div className="skel" style={{ width: "70%", aspectRatio: "0.72" }} />}
        {ocr === "running" && <><div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,.35)" }} /><div className="scan-line" /><div className="label-l" style={{ position: "absolute", bottom: 20, color: "#fff", background: "rgba(0,0,0,.6)", padding: "6px 14px", borderRadius: 99 }}>{t.ocrRunning}</div></>}
      </div>
      <div className="chips" style={{ padding: "12px 16px 4px" }}>
        {([["orig", t.eOriginal], ["color", t.eColor], ["gray", t.eGray], ["bw", t.eBw]] as [Enh, string][]).map(([k, l]) => <button key={k} className={`chip ${page.enh === k ? "on" : ""}`} onClick={() => update({ enh: k })}>{l}</button>)}
      </div>
      <div className="row" style={{ overflowX: "auto", gap: 8, padding: "8px 16px", scrollbarWidth: "none" }}>
        {pages.map((p, i) => <button key={p.id} onClick={() => setCur(i)} style={{ width: 40, height: 52, borderRadius: 6, background: "#fff", border: `2px solid ${i === cur ? "var(--c-primary)" : "var(--c-outline)"}`, flexShrink: 0, font: "600 10px Inter", color: "#333" }}>{i + 1}</button>)}
        <button onClick={() => setPhase("camera")} style={{ width: 40, height: 52, borderRadius: 6, border: "1.5px dashed var(--c-outline)", color: "var(--c-primary)", display: "grid", placeItems: "center", flexShrink: 0 }}><Icon name="plus" size={18} /></button>
      </div>
      <div className="row pad" style={{ gap: 8, paddingBottom: 100, paddingTop: 4 }}>
        <button className="btn tonal" style={{ flex: 1 }} onClick={ocr === "done" ? () => setOcrOpen(true) : runOcr} disabled={ocr === "running"}><Icon name="text" size={18} />OCR</button>
        <button className="btn" style={{ flex: 1.4 }} onClick={exportPdf}><Icon name="file" size={18} />{t.exportPdf}</button>
      </div>
      <BottomNav />
      <Sheet open={ocrOpen} onClose={() => setOcrOpen(false)} title={t.ocrDone} actions={<button className="btn sm tonal" onClick={() => { navigator.clipboard?.writeText(OCR_TEXT); showToast(t.copied); }}><Icon name="copy" size={16} />{t.copyText}</button>}>
        <pre style={{ whiteSpace: "pre-wrap", font: "400 13px/1.6 var(--font-reading)", margin: 0, direction: "ltr", textAlign: "left" }}>{OCR_TEXT}</pre>
        <div className="label-s muted" style={{ marginTop: 12 }}>{lang === "ar" ? "في المعاينة: النتيجة محسوبة مسبقًا. التطبيق يستخدم ML Kit على الجهاز أو Tesseract (نماذج تُنزَّل عند الطلب)." : "Preview: result is pre-computed. The app uses on-device ML Kit or Tesseract (models downloaded on demand)."}</div>
      </Sheet>
    </div>
  );
}
