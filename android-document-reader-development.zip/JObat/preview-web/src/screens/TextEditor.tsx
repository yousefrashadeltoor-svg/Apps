import { useEffect, useMemo, useRef, useState } from "react";
import { IconBtn } from "../components";
import { SAMPLE_CSV, SAMPLE_HTML, SAMPLE_MD } from "../data";
import { Icon } from "../icons";
import { useApp } from "../store";

type Kind = "md" | "html" | "csv";
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

/** Tokenizer mirrors feature-editor-text's SyntaxHighlighter (regex-based, line-safe). */
function highlight(code: string, kind: Kind, find: RegExp | null): string {
  const marks: [number, number][] = [];
  if (find) { let m: RegExpExecArray | null; find.lastIndex = 0; while ((m = find.exec(code)) && marks.length < 2000) { if (!m[0].length) { find.lastIndex++; continue; } marks.push([m.index, m.index + m[0].length]); } }
  const rules: [RegExp, string][] = kind === "html"
    ? [[/<!--[\s\S]*?-->/y, "c"], [/<\/?[a-zA-Z!][\w-]*/y, "t"], [/\s[\w-:]+(?==)/y, "a"], [/"[^"]*"|'[^']*'/y, "s"], [/\/?>/y, "t"], [/#[0-9a-fA-F]{3,8}\b|\b\d+(px|%|em)?\b/y, "n"], [/\b(body|h1|div|p|color|background|font-family|padding|border|border-radius|font-weight)\b/y, "k"]]
    : kind === "md"
      ? [[/^#{1,6} .*$/my, "h"], [/```[\s\S]*?```/y, "s"], [/`[^`\n]+`/y, "s"], [/\*\*[^*\n]+\*\*/y, "k"], [/\[[^\]\n]*\]\([^)\n]*\)/y, "a"], [/^\s*[-*] (\[[ x]\])?/my, "t"], [/^>.*$/my, "c"], [/\|/y, "n"]]
      : [[/^[^\n]*$/my, ""], [/,/y, "t"], [/\b\d+\b/y, "n"]];
  let out = "", i = 0, mi = 0;
  const wrapMark = (s: string, start: number) => {
    let r = "", p = 0;
    while (mi < marks.length && marks[mi][1] <= start) mi++;
    for (let k = mi; k < marks.length && marks[k][0] < start + s.length; k++) {
      const a = Math.max(0, marks[k][0] - start), b = Math.min(s.length, marks[k][1] - start);
      r += esc(s.slice(p, a)) + `<span class="tk-m">${esc(s.slice(a, b))}</span>`; p = b;
    }
    return r + esc(s.slice(p));
  };
  const csvRules = kind === "csv";
  while (i < code.length) {
    let matched = false;
    if (!csvRules || code[i] === "," || /\d/.test(code[i])) {
      for (const [re, cls] of rules) {
        if (!cls) continue;
        re.lastIndex = i;
        const m = re.exec(code);
        if (m && m.index === i && m[0].length) {
          out += `<span class="tk-${cls}">${wrapMark(m[0], i)}</span>`;
          i += m[0].length; matched = true; break;
        }
      }
    }
    if (!matched) {
      if (csvRules && i === 0) { const nl = code.indexOf("\n"); const end = nl < 0 ? code.length : nl; out += `<span class="tk-h">${wrapMark(code.slice(0, end), 0)}</span>`; i = end; continue; }
      out += wrapMark(code[i], i); i++;
    }
  }
  return out + "\n";
}

function md(src: string): string {
  const lines = src.split("\n"); let html = ""; let inList = false; let i = 0;
  const inline = (s: string) => esc(s).replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>").replace(/\*([^*]+)\*/g, "<i>$1</i>").replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith("```")) { const buf: string[] = []; i++; while (i < lines.length && !lines[i].startsWith("```")) buf.push(lines[i++]); html += `<pre><code>${esc(buf.join("\n"))}</code></pre>`; i++; continue; }
    if (/^\s*[-*] /.test(l)) { if (!inList) { html += "<ul>"; inList = true; } const item = l.replace(/^\s*[-*] /, ""); const cb = item.match(/^\[([ x])\] (.*)/); html += `<li>${cb ? `<input type="checkbox" disabled ${cb[1] === "x" ? "checked" : ""}/> ${inline(cb[2])}` : inline(item)}</li>`; i++; continue; }
    if (inList) { html += "</ul>"; inList = false; }
    if (/^\|/.test(l)) { const rows: string[][] = []; while (i < lines.length && /^\|/.test(lines[i])) { if (!/^\|[-| :]+\|$/.test(lines[i])) rows.push(lines[i].split("|").slice(1, -1).map((c) => c.trim())); i++; } html += `<table>${rows.map((r, ri) => `<tr>${r.map((c) => (ri ? `<td>${inline(c)}</td>` : `<th>${inline(c)}</th>`)).join("")}</tr>`).join("")}</table>`; continue; }
    const h = l.match(/^(#{1,6}) (.*)/);
    if (h) html += `<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`;
    else if (l.startsWith(">")) html += `<blockquote>${inline(l.replace(/^>\s?/, ""))}</blockquote>`;
    else if (l.trim()) html += `<p>${inline(l)}</p>`;
    i++;
  }
  if (inList) html += "</ul>";
  return html;
}

export function TextEditor({ kind: initial = "md" }: { kind?: Kind }) {
  const { t, pop, showToast, download } = useApp();
  const [kind, setKind] = useState<Kind>(initial);
  const [docs, setDocs] = useState<Record<Kind, string>>(() => {
    try { const s = localStorage.getItem("jobat-preview:texts"); if (s) return JSON.parse(s); } catch { /* ignore */ }
    return { md: SAMPLE_MD, html: SAMPLE_HTML, csv: SAMPLE_CSV };
  });
  const [hist, setHist] = useState<{ past: string[]; future: string[] }>({ past: [], future: [] });
  const [view, setView] = useState<"code" | "split" | "preview">("code");
  const [findOpen, setFindOpen] = useState(false);
  const [find, setFind] = useState("");
  const [rep, setRep] = useState("");
  const [useRe, setUseRe] = useState(false);
  const [mc, setMc] = useState(false);
  const [saved, setSaved] = useState(true);
  const code = docs[kind];
  const taRef = useRef<HTMLTextAreaElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);
  const areaRef = useRef<HTMLDivElement>(null);
  const snapTimer = useRef<number | undefined>(undefined);
  const lastSnap = useRef(code);

  const findRe = useMemo(() => {
    if (!find) return null;
    try { return new RegExp(useRe ? find : find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), mc ? "g" : "gi"); } catch { return null; }
  }, [find, useRe, mc]);
  const count = useMemo(() => (findRe ? (code.match(findRe) ?? []).length : 0), [code, findRe]);
  const html = useMemo(() => highlight(code, kind, findRe), [code, kind, findRe]);

  useEffect(() => {
    setSaved(false);
    const id = setTimeout(() => { localStorage.setItem("jobat-preview:texts", JSON.stringify(docs)); setSaved(true); }, 700);
    return () => clearTimeout(id);
  }, [docs]);

  const setCode = (v: string, snapshotNow = false) => {
    setDocs((d) => ({ ...d, [kind]: v }));
    window.clearTimeout(snapTimer.current);
    const snap = () => { if (lastSnap.current !== v) { setHist((h) => ({ past: [...h.past, lastSnap.current].slice(-500), future: [] })); lastSnap.current = v; } };
    if (snapshotNow) snap(); else snapTimer.current = window.setTimeout(snap, 400);
  };
  const undo = () => { if (!hist.past.length) return; const prev = hist.past[hist.past.length - 1]; setHist({ past: hist.past.slice(0, -1), future: [code, ...hist.future] }); lastSnap.current = prev; setDocs((d) => ({ ...d, [kind]: prev })); };
  const redo = () => { if (!hist.future.length) return; const nx = hist.future[0]; setHist({ past: [...hist.past, code], future: hist.future.slice(1) }); lastSnap.current = nx; setDocs((d) => ({ ...d, [kind]: nx })); };
  const switchKind = (k: Kind) => { setKind(k); setHist({ past: [], future: [] }); lastSnap.current = docs[k]; };

  const replaceAll = () => { if (!findRe) return; const n = count; setCode(code.replace(findRe, rep), true); showToast(`${n} ${t.replacedN}`); };
  const replaceOne = () => {
    if (!findRe) return;
    const ta = taRef.current!; const re = new RegExp(findRe.source, findRe.flags.replace("g", "") + "g"); re.lastIndex = ta.selectionEnd;
    let m = re.exec(code); if (!m) { re.lastIndex = 0; m = re.exec(code); } if (!m) return;
    const v = code.slice(0, m.index) + m[0].replace(new RegExp(findRe.source, findRe.flags.replace("g", "")), rep) + code.slice(m.index + m[0].length);
    setCode(v, true);
    requestAnimationFrame(() => { ta.focus(); ta.setSelectionRange(m!.index, m!.index + rep.length); });
  };
  const findNext = () => {
    if (!findRe) return; const ta = taRef.current!; const re = new RegExp(findRe.source, findRe.flags); re.lastIndex = ta.selectionEnd;
    let m = re.exec(code); if (!m) { re.lastIndex = 0; m = re.exec(code); } if (!m) return;
    ta.focus(); ta.setSelectionRange(m.index, m.index + m[0].length);
    const line = code.slice(0, m.index).split("\n").length; areaRef.current!.scrollTop = Math.max(0, line * 20 - 100);
  };

  const onKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const ta = e.currentTarget;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") { e.preventDefault(); setFindOpen(true); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") { e.preventDefault(); download(`notes.${kind}`, code); return; }
    if (e.key === "Tab") { e.preventDefault(); const s = ta.selectionStart; setCode(code.slice(0, s) + "  " + code.slice(ta.selectionEnd), true); requestAnimationFrame(() => ta.setSelectionRange(s + 2, s + 2)); }
    if (e.key === "Enter") {
      const s = ta.selectionStart; const lineStart = code.lastIndexOf("\n", s - 1) + 1; const indent = code.slice(lineStart).match(/^(\s*([-*] (\[[ x]\] )?)?)/)?.[1] ?? "";
      if (indent) { e.preventDefault(); const ins = "\n" + indent.replace("[x]", "[ ]"); setCode(code.slice(0, s) + ins + code.slice(ta.selectionEnd), true); requestAnimationFrame(() => ta.setSelectionRange(s + ins.length, s + ins.length)); }
    }
  };

  const lines = code.split("\n").length;
  const words = (code.match(/[\p{L}\p{N}]+/gu) ?? []).length;
  const preview = kind === "md"
    ? <div className="md-prev" dangerouslySetInnerHTML={{ __html: md(code) }} />
    : kind === "html"
      ? <iframe title="preview" sandbox="" srcDoc={code} style={{ flex: 1, border: 0, background: "#fff", width: "100%" }} />
      : <div className="md-prev"><table>{code.trim().split("\n").map((r, i) => <tr key={i}>{r.split(",").map((c, j) => (i ? <td key={j}>{c}</td> : <th key={j}>{c}</th>))}</tr>)}</table></div>;

  return (
    <div className="view" style={{ background: "var(--c-surface)" }}>
      <div style={{ height: 44 }} />
      <div className="top">
        <IconBtn name="back" label={t.cancel} onClick={pop} className="flip-rtl" />
        <div className="grow"><div className="title-m">{t.textEditor}</div><div className="label-s" style={{ color: saved ? "var(--c-success)" : "var(--c-on-surface-variant)" }}>{saved ? `✓ ${t.autosaved}` : t.unsaved}</div></div>
        <IconBtn name="undo" label={t.undo} onClick={undo} disabled={!hist.past.length} />
        <IconBtn name="redo" label="Redo" onClick={redo} disabled={!hist.future.length} />
        <IconBtn name="search" label={t.find} on={findOpen} onClick={() => setFindOpen(!findOpen)} />
        <IconBtn name="download" label={t.save} onClick={() => { download(`notes.${kind === "html" ? "html" : kind}`, code, kind === "html" ? "text/html" : "text/plain"); showToast(t.downloaded); }} />
      </div>
      <div className="row pad" style={{ gap: 8, paddingBottom: 8 }}>
        <div className="seg" style={{ flex: 1 }}>{(["md", "html", "csv"] as Kind[]).map((k) => <button key={k} className={kind === k ? "on" : ""} onClick={() => switchKind(k)}>.{k}</button>)}</div>
        <div className="seg">{([["code", "code"], ["split", "splitI"], ["preview", "eye"]] as const).map(([v, ic]) => <button key={v} className={view === v ? "on" : ""} style={{ width: 40 }} onClick={() => setView(v)} aria-label={t[v]}><Icon name={ic} size={16} /></button>)}</div>
      </div>
      {findOpen && (
        <div className="findbar">
          <div className="row" style={{ gap: 6 }}>
            <input value={find} onChange={(e) => setFind(e.target.value)} placeholder={t.find} autoFocus onKeyDown={(e) => e.key === "Enter" && findNext()} style={!findRe && find ? { borderColor: "var(--c-error)" } : undefined} />
            <span className="label-s muted" style={{ minWidth: 28, textAlign: "center" }}>{count}</span>
            <button className={`chip ${useRe ? "on" : ""}`} style={{ height: 30, padding: "0 8px", fontFamily: "var(--font-mono)" }} onClick={() => setUseRe(!useRe)}>.*</button>
            <button className={`chip ${mc ? "on" : ""}`} style={{ height: 30, padding: "0 8px" }} onClick={() => setMc(!mc)}>Aa</button>
          </div>
          <div className="row" style={{ gap: 6 }}>
            <input value={rep} onChange={(e) => setRep(e.target.value)} placeholder={t.replace} />
            <button className="btn tonal sm" style={{ padding: "0 10px", height: 32 }} onClick={replaceOne}>{t.replace}</button>
            <button className="btn sm" style={{ padding: "0 10px", height: 32 }} onClick={replaceAll}>{t.replaceAll}</button>
          </div>
        </div>
      )}
      <div style={{ flex: 1, display: "flex", flexDirection: view === "split" ? "column" : "row", minHeight: 0 }}>
        {view !== "preview" && (
          <div className="code-wrap" style={{ flex: 1 }}>
            <div className="gutter" ref={gutterRef}>{Array.from({ length: lines }, (_, i) => <div key={i}>{i + 1}</div>)}</div>
            <div className="code-area" ref={areaRef} onScroll={(e) => { gutterRef.current!.scrollTop = e.currentTarget.scrollTop; }}>
              <div style={{ position: "relative", minHeight: "100%", display: "inline-block", minWidth: "100%", verticalAlign: "top" }}>
                <pre dangerouslySetInnerHTML={{ __html: html }} />
                <textarea ref={taRef} value={code} spellCheck={false} onChange={(e) => setCode(e.target.value)} onKeyDown={onKey} aria-label={t.textEditor} />
              </div>
            </div>
          </div>
        )}
        {view !== "code" && <div style={{ flex: 1, display: "flex", minHeight: 0, borderTop: view === "split" ? "1px solid var(--c-outline)" : undefined }}>{preview}</div>}
      </div>
      <div className="statusline"><span>{lines} {t.lines} · {words} {t.words}</span><span>UTF-8 · LF · {kind.toUpperCase()}</span></div>
    </div>
  );
}
