/// <reference path="../assets.d.ts" />
import { useEffect, useRef, useState } from "react";
import photo from "../../assets/photo.jpg";
import { IconBtn, Sheet } from "../components";
import { Icon } from "../icons";
import { useApp } from "../store";

interface Adj { brightness: number; contrast: number; saturation: number; warmth: number; sharpness: number }
interface Stroke { kind: "draw" | "blur"; pts: [number, number][]; color: string; w: number }
const ZERO: Adj = { brightness: 0, contrast: 0, saturation: 0, warmth: 0, sharpness: 0 };
const PRESETS: { id: string; key: "fOriginal" | "fNoir" | "fChampagne" | "fVintage" | "fCool" | "fVivid" | "fFade"; adj: Adj; extra: string }[] = [
  { id: "orig", key: "fOriginal", adj: ZERO, extra: "" },
  { id: "noir", key: "fNoir", adj: { ...ZERO, contrast: 25 }, extra: "grayscale(1)" },
  { id: "champ", key: "fChampagne", adj: { ...ZERO, warmth: 30, brightness: 6, saturation: -10 }, extra: "" },
  { id: "vint", key: "fVintage", adj: { ...ZERO, contrast: -10, warmth: 20 }, extra: "sepia(.35)" },
  { id: "cool", key: "fCool", adj: { ...ZERO, warmth: -35, contrast: 8 }, extra: "" },
  { id: "vivid", key: "fVivid", adj: { ...ZERO, saturation: 40, contrast: 12 }, extra: "" },
  { id: "fade", key: "fFade", adj: { ...ZERO, contrast: -25, brightness: 10, saturation: -20 }, extra: "" },
];
const RATIOS: [string, number | null][] = [["free", null], ["1:1", 1], ["4:3", 4 / 3], ["16:9", 16 / 9], ["3:4", 3 / 4]];

function sharpen(ctx: CanvasRenderingContext2D, w: number, h: number, amount: number) {
  const src = ctx.getImageData(0, 0, w, h); const d = src.data; const out = ctx.createImageData(w, h); const o = out.data;
  const a = amount / 100; const k = [0, -a, 0, -a, 1 + 4 * a, -a, 0, -a, 0];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4;
    if (x === 0 || y === 0 || x === w - 1 || y === h - 1) { o[i] = d[i]; o[i + 1] = d[i + 1]; o[i + 2] = d[i + 2]; o[i + 3] = 255; continue; }
    for (let c = 0; c < 3; c++) {
      const v = k[1] * d[i - w * 4 + c] + k[3] * d[i - 4 + c] + k[4] * d[i + c] + k[5] * d[i + 4 + c] + k[7] * d[i + w * 4 + c];
      o[i + c] = v < 0 ? 0 : v > 255 ? 255 : v;
    }
    o[i + 3] = 255;
  }
  ctx.putImageData(out, 0, 0);
}

export function ImageEditor() {
  const { t, pop, showToast, download, haptic } = useApp();
  const viewRef = useRef<HTMLCanvasElement>(null);
  const baseRef = useRef<HTMLCanvasElement | null>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(0);
  const [tab, setTab] = useState<"adjust" | "filters" | "crop" | "draw" | "blur">("adjust");
  const [adj, setAdj] = useState<Adj>(ZERO);
  const [preset, setPreset] = useState("orig");
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [penColor, setPenColor] = useState("#D4B26A");
  const [penW, setPenW] = useState(8);
  const [crop, setCrop] = useState({ x: 0.1, y: 0.1, w: 0.8, h: 0.8 });
  const [ratio, setRatio] = useState<number | null>(null);
  const [exportOpen, setExportOpen] = useState(false);
  const [quality, setQuality] = useState(0.9);
  const [fmt, setFmt] = useState<"image/jpeg" | "image/webp" | "image/png">("image/jpeg");
  const [history, setHistory] = useState<HTMLCanvasElement[]>([]);
  const drawing = useRef<Stroke | null>(null);
  const cropDrag = useRef<{ mode: string; sx: number; sy: number; c: typeof crop } | null>(null);

  useEffect(() => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas"); const max = 1400; const s = Math.min(1, max / Math.max(img.width, img.height));
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s); c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      baseRef.current = c; setReady((r) => r + 1);
    };
    img.src = photo;
  }, []);

  const filterStr = (a: Adj) => `brightness(${1 + a.brightness / 100}) contrast(${1 + a.contrast / 100}) saturate(${1 + a.saturation / 100}) ${PRESETS.find((p) => p.id === preset)?.extra ?? ""}`;

  const renderTo = (target: HTMLCanvasElement) => {
    const base = baseRef.current; if (!base) return;
    target.width = base.width; target.height = base.height;
    const g = target.getContext("2d", { willReadFrequently: true })!;
    g.filter = filterStr(adj); g.drawImage(base, 0, 0); g.filter = "none";
    if (adj.warmth) { g.globalCompositeOperation = "soft-light"; g.fillStyle = adj.warmth > 0 ? `rgba(255,150,40,${adj.warmth / 120})` : `rgba(40,130,255,${-adj.warmth / 120})`; g.fillRect(0, 0, target.width, target.height); g.globalCompositeOperation = "source-over"; }
    if (adj.sharpness > 0) sharpen(g, target.width, target.height, adj.sharpness);
    for (const s of strokes) {
      const path = new Path2D(); s.pts.forEach(([x, y], i) => (i ? path.lineTo(x, y) : path.moveTo(x, y)));
      if (s.kind === "draw") { g.strokeStyle = s.color; g.lineWidth = s.w; g.lineCap = "round"; g.lineJoin = "round"; g.stroke(path); }
      else {
        const mask = document.createElement("canvas"); mask.width = target.width; mask.height = target.height; const m = mask.getContext("2d")!;
        m.strokeStyle = "#000"; m.lineWidth = s.w; m.lineCap = "round"; m.lineJoin = "round"; m.stroke(path);
        m.globalCompositeOperation = "source-in"; m.filter = "blur(14px)"; m.drawImage(target, 0, 0); g.drawImage(mask, 0, 0);
      }
    }
  };
  useEffect(() => { if (viewRef.current) renderTo(viewRef.current); });

  const toImg = (e: React.PointerEvent): [number, number] => { const r = viewRef.current!.getBoundingClientRect(); return [((e.clientX - r.left) / r.width) * viewRef.current!.width, ((e.clientY - r.top) / r.height) * viewRef.current!.height]; };
  const snapshot = () => { const b = baseRef.current!; const c = document.createElement("canvas"); c.width = b.width; c.height = b.height; c.getContext("2d")!.drawImage(b, 0, 0); setHistory((h) => [...h.slice(-9), c]); };
  const transformBase = (fn: (g: CanvasRenderingContext2D, b: HTMLCanvasElement, c: HTMLCanvasElement) => void, swap = false) => {
    snapshot(); const b = baseRef.current!; const c = document.createElement("canvas"); c.width = swap ? b.height : b.width; c.height = swap ? b.width : b.height;
    fn(c.getContext("2d")!, b, c); baseRef.current = c; setStrokes([]); setReady((r) => r + 1); haptic();
  };
  const rotate = () => transformBase((g, b, c) => { g.translate(c.width, 0); g.rotate(Math.PI / 2); g.drawImage(b, 0, 0); }, true);
  const flip = () => transformBase((g, b, c) => { g.translate(c.width, 0); g.scale(-1, 1); g.drawImage(b, 0, 0); });
  const applyCrop = () => transformBase((g, b, c) => {
    const sx = crop.x * b.width, sy = crop.y * b.height, sw = crop.w * b.width, sh = crop.h * b.height;
    c.width = Math.round(sw); c.height = Math.round(sh); g.drawImage(b, sx, sy, sw, sh, 0, 0, c.width, c.height);
  });
  const undo = () => { if (strokes.length) { setStrokes(strokes.slice(0, -1)); return; } const last = history[history.length - 1]; if (last) { baseRef.current = last; setHistory(history.slice(0, -1)); setReady((r) => r + 1); } };

  const setRatioFix = (r: number | null) => {
    setRatio(r); if (!r || !baseRef.current) return;
    const b = baseRef.current; const imgR = b.width / b.height; let w = 0.8, h = (0.8 * imgR) / r; if (h > 0.9) { h = 0.9; w = (0.9 * r) / imgR; }
    setCrop({ x: (1 - w) / 2, y: (1 - h) / 2, w, h });
  };
  const cropMove = (e: React.PointerEvent) => {
    const d = cropDrag.current; if (!d) return; const r = viewRef.current!.getBoundingClientRect();
    const dx = (e.clientX - d.sx) / r.width, dy = (e.clientY - d.sy) / r.height; let { x, y, w, h } = d.c;
    if (d.mode === "move") { x = Math.min(1 - w, Math.max(0, x + dx)); y = Math.min(1 - h, Math.max(0, y + dy)); }
    else {
      if (d.mode.includes("l")) { x = Math.max(0, Math.min(x + w - 0.08, x + dx)); w = d.c.x + d.c.w - x; }
      if (d.mode.includes("r")) w = Math.max(0.08, Math.min(1 - x, w + dx));
      if (d.mode.includes("t")) { y = Math.max(0, Math.min(y + h - 0.08, y + dy)); h = d.c.y + d.c.h - y; }
      if (d.mode.includes("b")) h = Math.max(0.08, Math.min(1 - y, h + dy));
      if (ratio && baseRef.current) { const imgR = baseRef.current.width / baseRef.current.height; h = Math.min(1 - y, (w * imgR) / ratio); }
    }
    setCrop({ x, y, w, h });
  };

  const doExport = () => {
    const c = document.createElement("canvas"); renderTo(c);
    c.toBlob((blob) => { if (blob) { download(`JObat-edit.${fmt.split("/")[1].replace("jpeg", "jpg")}`, blob); showToast(`${t.exported} · ${(blob.size / 1024).toFixed(0)} KB`); } }, fmt, quality);
    setExportOpen(false);
  };

  const vr = viewRef.current?.getBoundingClientRect(); const sr = stageRef.current?.getBoundingClientRect();
  const off = vr && sr ? { left: vr.left - sr.left, top: vr.top - sr.top, w: vr.width, h: vr.height } : null;
  const sliders: [keyof Adj, string, number, number][] = [["brightness", t.brightness, -50, 50], ["contrast", t.contrastL, -50, 50], ["saturation", t.saturation, -100, 100], ["warmth", t.warmth, -50, 50], ["sharpness", t.sharpness, 0, 100]];

  return (
    <div className="view" style={{ background: "#050506" }}>
      <div style={{ height: 44 }} />
      <div className="top" style={{ color: "#ECE7DC" }}>
        <IconBtn name="back" label={t.cancel} onClick={pop} className="flip-rtl" />
        <div className="grow title-m" style={{ color: "#ECE7DC" }}>{t.imageEditor}</div>
        <IconBtn name="undo" label={t.undo} onClick={undo} disabled={!strokes.length && !history.length} />
        <IconBtn name="rotate" label={t.rotate} onClick={rotate} />
        <IconBtn name="flip" label={t.flipH} onClick={flip} />
        <button className="btn sm" onClick={() => setExportOpen(true)}>{t.export}</button>
      </div>
      <div className="img-stage" ref={stageRef} onPointerMove={cropMove} onPointerUp={() => (cropDrag.current = null)}>
        <canvas ref={viewRef} key={ready} style={{ cursor: tab === "draw" || tab === "blur" ? "crosshair" : "default" }}
          onPointerDown={(e) => { if (tab !== "draw" && tab !== "blur") return; (e.target as Element).setPointerCapture(e.pointerId); const scale = viewRef.current!.width / viewRef.current!.getBoundingClientRect().width; drawing.current = { kind: tab, pts: [toImg(e)], color: penColor, w: (tab === "blur" ? 40 : penW) * scale }; setStrokes((s) => [...s, drawing.current!]); }}
          onPointerMove={(e) => { if (!drawing.current) return; drawing.current.pts.push(toImg(e)); setStrokes((s) => [...s.slice(0, -1), { ...drawing.current! }]); }}
          onPointerUp={() => (drawing.current = null)} />
        {tab === "crop" && off && (
          <div className="crop-box" style={{ left: off.left + crop.x * off.w, top: off.top + crop.y * off.h, width: crop.w * off.w, height: crop.h * off.h }}
            onPointerDown={(e) => { cropDrag.current = { mode: "move", sx: e.clientX, sy: e.clientY, c: crop }; }}>
            {["tl", "tr", "bl", "br"].map((m) => (
              <span key={m} className="crop-h" onPointerDown={(e) => { e.stopPropagation(); cropDrag.current = { mode: m, sx: e.clientX, sy: e.clientY, c: crop }; }}
                style={{ [m[0] === "t" ? "top" : "bottom"]: -4, [m[1] === "l" ? "left" : "right"]: -4, cursor: m === "tl" || m === "br" ? "nwse-resize" : "nesw-resize",
                  borderWidth: `${m[0] === "t" ? 3 : 0}px ${m[1] === "r" ? 3 : 0}px ${m[0] === "b" ? 3 : 0}px ${m[1] === "l" ? 3 : 0}px` } as React.CSSProperties} />
            ))}
          </div>
        )}
      </div>
      <div style={{ background: "var(--c-surface)", padding: "12px 16px 4px", minHeight: 150 }}>
        {tab === "adjust" && <div style={{ display: "grid", gap: 8 }}>{sliders.map(([k, l, mn, mx]) => <div key={k} className="adj-row"><span className="lbl">{l}</span><input className="range" type="range" min={mn} max={mx} value={adj[k]} onChange={(e) => setAdj({ ...adj, [k]: +e.target.value })} /><span className="val">{adj[k]}</span></div>)}
          <button className="label-l gold" style={{ justifySelf: "end" }} onClick={() => { setAdj(ZERO); setPreset("orig"); }}>{t.reset}</button></div>}
        {tab === "filters" && <div className="row" style={{ overflowX: "auto", gap: 10, paddingBottom: 6, scrollbarWidth: "none" }}>{PRESETS.map((p) => (
          <button key={p.id} className={`filter-thumb ${preset === p.id ? "on" : ""}`} onClick={() => { setPreset(p.id); setAdj(p.adj); haptic(); }}>
            <img src={photo} alt="" style={{ filter: `${`brightness(${1 + p.adj.brightness / 100}) contrast(${1 + p.adj.contrast / 100}) saturate(${1 + p.adj.saturation / 100})`} ${p.extra} ${p.adj.warmth > 0 ? "sepia(.25)" : p.adj.warmth < 0 ? "hue-rotate(-12deg)" : ""}` }} />{t[p.key]}
          </button>))}</div>}
        {tab === "crop" && <div><div className="row" style={{ gap: 6, flexWrap: "wrap" }}>{RATIOS.map(([l, r]) => <button key={l} className={`chip ${ratio === r ? "on" : ""}`} onClick={() => setRatioFix(r)}>{l === "free" ? t.free : l}</button>)}</div>
          <button className="btn block" style={{ marginTop: 14 }} onClick={() => { applyCrop(); setCrop({ x: 0.1, y: 0.1, w: 0.8, h: 0.8 }); showToast(t.applied); setTab("adjust"); }}><Icon name="check" size={18} />{t.apply}</button></div>}
        {tab === "draw" && <div className="row" style={{ gap: 10 }}>{["#D4B26A", "#FFFFFF", "#111111", "#E5786D", "#7FA7C9", "#7FBF8E"].map((c) => <button key={c} className={`swatch ${penColor === c ? "on" : ""}`} style={{ background: c }} onClick={() => setPenColor(c)} />)}<input className="range" type="range" min={2} max={24} value={penW} onChange={(e) => setPenW(+e.target.value)} style={{ flex: 1 }} /></div>}
        {tab === "blur" && <p className="muted" style={{ margin: 0 }}>{t.blur}: {document.querySelector(".app")?.getAttribute("dir") === "rtl" ? "مرّر إصبعك فوق المنطقة المراد إخفاؤها (وجوه، أرقام، بيانات حساسة)." : "Brush over areas to hide (faces, numbers, sensitive data)."}</p>}
      </div>
      <div className="toolrail" style={{ paddingBottom: 26, justifyContent: "space-around" }}>
        {([["adjust", "sliders", t.adjust], ["filters", "wand", t.filters], ["crop", "crop", t.crop], ["draw", "pen", t.draw], ["blur", "drop", t.blur]] as const).map(([id, ic, l]) => <button key={id} className={`tool ${tab === id ? "on" : ""}`} onClick={() => { setTab(id); setReady((r) => r); }}><Icon name={ic} size={20} />{l}</button>)}
      </div>
      <Sheet open={exportOpen} onClose={() => setExportOpen(false)} title={t.export}>
        <div className="seg">{([["image/jpeg", "JPG"], ["image/webp", "WEBP"], ["image/png", "PNG"]] as const).map(([f, l]) => <button key={f} className={fmt === f ? "on" : ""} onClick={() => setFmt(f)}>{l}</button>)}</div>
        {fmt !== "image/png" && <div className="adj-row" style={{ marginTop: 16 }}><span className="lbl">{t.quality}</span><input className="range" type="range" min={0.3} max={1} step={0.05} value={quality} onChange={(e) => setQuality(+e.target.value)} /><span className="val">{Math.round(quality * 100)}</span></div>}
        <div className="label-s muted" style={{ marginTop: 8 }}>{baseRef.current?.width} × {baseRef.current?.height}px</div>
        <button className="btn block" style={{ marginTop: 16 }} onClick={doExport}><Icon name="download" size={18} />{t.export}</button>
      </Sheet>
    </div>
  );
}
