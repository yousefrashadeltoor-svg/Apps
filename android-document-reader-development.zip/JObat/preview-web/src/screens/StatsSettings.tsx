import { useRef, useState } from "react";
import { BottomNav, Dialog, IconBtn, Logo, Ring, Sheet, Switch } from "../components";
import { HEATMAP, WEEK_MINUTES } from "../data";
import { Icon } from "../icons";
import { useApp, type ThemeName } from "../store";

export function Stats() {
  const { t, pop, books, settings, setSetting, lang } = useApp();
  const days = lang === "ar" ? ["س", "ح", "ن", "ث", "ر", "خ", "ج"] : ["S", "S", "M", "T", "W", "T", "F"];
  const max = Math.max(...WEEK_MINUTES);
  const today = WEEK_MINUTES[WEEK_MINUTES.length - 1];
  const finished = books.filter((b) => b.progress >= 1).length;
  const pagesRead = Math.round(books.reduce((s, b) => s + b.pages * b.progress, 0));
  const fmts = Object.entries(books.reduce<Record<string, number>>((m, b) => ({ ...m, [b.format]: (m[b.format] ?? 0) + 1 }), {})).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const fmtTotal = fmts.reduce((s, [, n]) => s + n, 0);
  const colors = ["#D4B26A", "#7FA7C9", "#C98F7F", "#7FBF8E", "#B39DDB"];
  let acc = 0;
  return (
    <div className="view">
      <div style={{ height: 44 }} />
      <div className="top"><IconBtn name="back" label={t.cancel} onClick={pop} className="flip-rtl" /><div className="grow title-l">{t.stats}</div></div>
      <div className="scroll pad">
        <div className="card enter" style={{ padding: 20, display: "flex", alignItems: "center", gap: 20 }}>
          <Ring value={Math.min(1, today / settings.dailyGoal)} size={96} stroke={7} label={<span style={{ textAlign: "center" }}><span style={{ font: "600 24px var(--font-display)", display: "block" }}>{today}</span><span className="label-s muted">{t.min}</span></span>} />
          <div style={{ flex: 1 }}>
            <div className="label-s gold" style={{ textTransform: "uppercase" }}>{t.today}</div>
            <div className="title-l" style={{ margin: "4px 0" }}>{today} / {settings.dailyGoal} {t.minutes}</div>
            <div className="adj-row"><span className="label-s muted" style={{ width: 54 }}>{t.goal}</span><input className="range" type="range" min={10} max={120} step={5} value={settings.dailyGoal} onChange={(e) => setSetting("dailyGoal", +e.target.value)} /></div>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginTop: 12 }}>
          {[["flame", "12", t.streak], ["check", String(finished), t.booksFinished], ["pages", pagesRead.toLocaleString(), t.pagesRead]].map(([ic, v, l], i) => (
            <div key={l} className="stat-tile enter" style={{ animationDelay: `${i * 50}ms`, padding: 14 }}><Icon name={ic} size={18} style={{ color: "var(--c-primary)" }} /><div className="big" style={{ fontSize: 24 }}>{v}</div><div className="label-s muted">{l}</div></div>
          ))}
        </div>
        <div className="card enter" style={{ padding: 16, marginTop: 12 }}>
          <div className="row between" style={{ marginBottom: 14 }}><span className="title-m">{t.thisWeek}</span><span className="label-l gold">{(WEEK_MINUTES.reduce((a, b) => a + b, 0) / 60).toFixed(1)} {t.hours}</span></div>
          <div className="bars">{WEEK_MINUTES.map((m, i) => <div key={i} className={`bar ${i === 6 ? "today" : ""}`}><span className="label-s muted">{m}</span><i style={{ height: `${(m / max) * 100}%`, animationDelay: `${i * 50}ms`, opacity: i === 6 ? 1 : 0.75 }} /><span className="label-s muted">{days[i]}</span></div>)}</div>
        </div>
        <div className="card enter" style={{ padding: 16, marginTop: 12 }}>
          <div className="title-m" style={{ marginBottom: 12 }}>{t.last12}</div>
          <div className="heat">{HEATMAP.map((v, i) => <i key={i} style={v ? { background: `color-mix(in srgb, var(--c-primary) ${v * 22}%, var(--c-surface-highest))` } : undefined} title={`${v * 15} min`} />)}</div>
        </div>
        <div className="card enter" style={{ padding: 16, marginTop: 12, display: "flex", gap: 16, alignItems: "center" }}>
          <svg width="96" height="96" viewBox="0 0 42 42" style={{ transform: "rotate(-90deg)" }}>
            {fmts.map(([f, n], i) => { const len = (n / fmtTotal) * 100; const el = <circle key={f} cx="21" cy="21" r="15.9" fill="none" stroke={colors[i]} strokeWidth="5" strokeDasharray={`${len} ${100 - len}`} strokeDashoffset={-acc} />; acc += len; return el; })}
          </svg>
          <div style={{ flex: 1 }}><div className="title-m" style={{ marginBottom: 8 }}>{t.topFormats}</div>{fmts.map(([f, n], i) => <div key={f} className="row label-l" style={{ gap: 8, marginBottom: 4 }}><i style={{ width: 8, height: 8, borderRadius: 4, background: colors[i] }} /><span style={{ flex: 1 }}>{f}</span><span className="muted">{n}</span></div>)}</div>
        </div>
        <div style={{ height: 40 }} />
      </div>
    </div>
  );
}

export function SettingsScreen() {
  const { t, theme, setTheme, lang, setLang, reduceMotion, setReduceMotion, settings, setSetting, showToast, exportBackup, importBackup, push, resetTo } = useApp();
  const [bio, setBio] = useState(false);
  const [about, setAbout] = useState(false);
  const [folderOpen, setFolderOpen] = useState(false);
  const [folder, setFolder] = useState("/Documents/");
  const [widgets, setWidgets] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const themes: [ThemeName, string, string, string][] = [["dark", t.dark, "#0B0C10", "#D4B26A"], ["light", t.light, "#F6F1E7", "#9C7A35"], ["amoled", t.amoled, "#000000", "#D4B26A"], ["sepia", t.sepia, "#F1E6D0", "#8F6A2C"], ["dynamic", t.dynamic, "#0E1113", "#8CCFC4"]];
  const Row = ({ icon, label, sub, right, onClick }: { icon: string; label: string; sub?: string; right?: React.ReactNode; onClick?: () => void }) => (
    <div className="list-item" style={{ cursor: onClick ? "pointer" : "default" }} onClick={onClick}>
      <span className="li-icon"><Icon name={icon} size={20} /></span>
      <div className="li-text"><div className="body-l">{label}</div>{sub && <div className="label-s muted">{sub}</div>}</div>
      {right}
    </div>
  );
  return (
    <div className="view">
      <div style={{ height: 44 }} />
      <div className="pad" style={{ padding: "8px 16px 8px" }}><h1 className="display-s">{t.settings}</h1></div>
      <div className="scroll">
        <div className="section-title pad">{t.appearance}</div>
        <div className="pad" style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 8 }}>
          {themes.map(([id, l, bg, acc]) => (
            <button key={id} onClick={() => setTheme(id)} style={{ textAlign: "center" }} aria-pressed={theme === id}>
              <div style={{ aspectRatio: ".62", borderRadius: 12, background: bg, border: `2px solid ${theme === id ? "var(--c-primary)" : "var(--c-outline)"}`, padding: 6, display: "flex", flexDirection: "column", gap: 4, transition: "border-color var(--dur-short)", boxShadow: theme === id ? "0 0 0 3px color-mix(in srgb, var(--c-primary) 25%, transparent)" : undefined }}>
                <i style={{ height: 6, width: "60%", borderRadius: 3, background: acc }} /><i style={{ height: 14, borderRadius: 4, background: id === "light" || id === "sepia" ? "rgba(0,0,0,.07)" : "rgba(255,255,255,.08)" }} /><i style={{ height: 14, borderRadius: 4, background: id === "light" || id === "sepia" ? "rgba(0,0,0,.07)" : "rgba(255,255,255,.08)" }} /><i style={{ marginTop: "auto", height: 8, borderRadius: 4, background: acc, opacity: 0.6 }} />
              </div>
              <div className="label-s" style={{ marginTop: 6, color: theme === id ? "var(--c-primary)" : "var(--c-on-surface-variant)" }}>{l}</div>
            </button>
          ))}
        </div>
        <Row icon="globe" label={t.language} right={<div className="seg" style={{ width: 130 }}><button className={lang === "ar" ? "on" : ""} onClick={() => setLang("ar")}>عربي</button><button className={lang === "en" ? "on" : ""} onClick={() => setLang("en")}>EN</button></div>} />
        <Row icon="motion" label={t.reduceMotion} right={<Switch on={reduceMotion} onChange={setReduceMotion} label={t.reduceMotion} />} />
        <Row icon="moon" label={t.blueLight} sub={settings.blueSchedule ? t.schedule : undefined} right={<Switch on={settings.blueLight} onChange={(v) => setSetting("blueLight", v)} label={t.blueLight} />} />

        <div className="section-title pad">{t.security}</div>
        <Row icon="finger" label={t.appLock} right={<Switch on={settings.appLock} onChange={(v) => { if (v) setBio(true); else setSetting("appLock", false); }} label={t.appLock} />} />
        <Row icon="vault" label={t.vault} sub="AES-256-GCM · Android Keystore" right={<Switch on={settings.vault} onChange={(v) => setSetting("vault", v)} label={t.vault} />} />

        <div className="section-title pad">{t.readingDefaults}</div>
        <Row icon="keyboard" label={t.volumeKeys} right={<Switch on={settings.volumeKeys} onChange={(v) => setSetting("volumeKeys", v)} label={t.volumeKeys} />} />
        <Row icon="drop" label={t.haptics} right={<Switch on={settings.haptics} onChange={(v) => setSetting("haptics", v)} label={t.haptics} />} />
        <Row icon="chart" label={t.stats} onClick={() => push({ name: "stats" })} right={<Icon name="back" size={18} className="flip-rtl" style={{ transform: lang === "ar" ? undefined : "scaleX(-1)" }} />} />

        <div className="section-title pad">{t.library}</div>
        {settings.folders.map((f) => <Row key={f} icon="folder" label={f} right={<button className="ib" onClick={() => setSetting("folders", settings.folders.filter((x) => x !== f))} aria-label={t.delete}><Icon name="close" size={18} /></button>} />)}
        <Row icon="plus" label={t.addFolder} onClick={() => setFolderOpen(true)} />
        <Row icon="widget" label={t.widgets} onClick={() => setWidgets(true)} />

        <div className="section-title pad">{t.backup}</div>
        <Row icon="backup" label={t.backupNow} sub=".jobat (JSON)" onClick={() => { exportBackup(); showToast(t.backupDone); }} />
        <Row icon="restoreI" label={t.restoreBackup} onClick={() => fileRef.current?.click()} />
        <input ref={fileRef} type="file" accept=".jobat,application/json" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { await importBackup(f); showToast(t.restoreDone); } catch (err) { showToast(String((err as Error).message)); } e.target.value = ""; }} />

        <div className="section-title pad">{t.about}</div>
        <Row icon="info" label={t.licenses} sub={`${t.version} 1.0.0 (1)`} onClick={() => setAbout(true)} />
        <Row icon="play" label={t.replay} onClick={() => { localStorage.removeItem("jobat-preview:onboarded"); resetTo({ name: "splash" }); }} />
        <div style={{ height: 120 }} />
      </div>
      <BottomNav />

      <Dialog open={bio} onClose={() => setBio(false)}>
        <div className="bio">
          <div className="title-l">{t.biometricTitle}</div>
          <div className="muted" style={{ marginTop: 4 }}>BiometricPrompt</div>
          <button className="fp" onClick={() => { setSetting("appLock", true); setBio(false); showToast(t.unlocked); }} aria-label={t.biometricBody}><Icon name="finger" size={32} /></button>
          <div className="label-l muted">{t.biometricBody}</div>
          <button className="btn ghost sm" style={{ marginTop: 16 }} onClick={() => setBio(false)}>{t.cancel}</button>
        </div>
      </Dialog>
      <Dialog open={folderOpen} onClose={() => setFolderOpen(false)}>
        <div className="title-l" style={{ marginBottom: 12 }}>{t.addFolder}</div>
        <input className="input" value={folder} onChange={(e) => setFolder(e.target.value)} style={{ direction: "ltr" }} />
        <div className="label-s muted" style={{ marginTop: 6 }}>ACTION_OPEN_DOCUMENT_TREE</div>
        <div className="row" style={{ justifyContent: "flex-end", gap: 8, marginTop: 16 }}><button className="btn ghost sm" onClick={() => setFolderOpen(false)}>{t.cancel}</button><button className="btn sm" onClick={() => { if (folder.trim()) setSetting("folders", [...settings.folders, folder.trim()]); setFolderOpen(false); showToast(t.indexing); }}>{t.create}</button></div>
      </Dialog>
      <Sheet open={widgets} onClose={() => setWidgets(false)} title={t.widgets}>
        <div style={{ borderRadius: 24, padding: 16, background: "linear-gradient(135deg, #1E2128, #0B0C10)", color: "#ECE7DC", display: "flex", gap: 14, alignItems: "center" }}>
          <div style={{ width: 52, height: 78, borderRadius: 6, background: "linear-gradient(160deg,#2B3A55,#121826)" }} />
          <div style={{ flex: 1 }}><div style={{ font: "500 10px Inter", color: "#D4B26A", letterSpacing: ".1em" }}>{t.continueReading.toUpperCase()}</div><div style={{ font: "600 15px Inter", margin: "4px 0" }}>Pride and Prejudice</div><div style={{ height: 4, borderRadius: 4, background: "#272A33" }}><div style={{ width: "42%", height: "100%", borderRadius: 4, background: "#D4B26A" }} /></div></div>
        </div>
        <div className="label-s muted" style={{ margin: "6px 0 14px" }}>Glance · 4×2</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
          {[["scan", t.scanner], ["search", t.search], ["edit", t.tPdfEd], ["library", t.continueReading]].map(([ic, l]) => <div key={l} style={{ textAlign: "center" }}><div style={{ width: 52, height: 52, borderRadius: 16, margin: "0 auto 6px", background: "var(--c-primary-container)", color: "var(--c-primary)", display: "grid", placeItems: "center" }}><Icon name={ic} /></div><div className="label-s muted" style={{ fontSize: 10 }}>{l}</div></div>)}
        </div>
        <div className="label-s muted" style={{ marginTop: 8 }}>App Shortcuts · Quick Settings Tile ({t.scanner})</div>
      </Sheet>
      <Sheet open={about} onClose={() => setAbout(false)} title={t.licenses}>
        <div style={{ textAlign: "center", padding: "8px 0 16px" }}><Logo size={40} /><p className="muted" style={{ margin: "8px 0 0" }}>{t.aboutBody}</p></div>
        {[["Librera Reader", "GPL-3.0", "© Ivan Ivanenko — core engines (modified)"], ["MuPDF", "AGPL-3.0", "© Artifex Software"], ["djvulibre", "GPL-2.0+", "© Léon Bottou"], ["Jetpack Compose · AndroidX", "Apache-2.0", "© AOSP"], ["Kotlin · Coroutines", "Apache-2.0", "© JetBrains"], ["Dagger Hilt", "Apache-2.0", "© Dagger Authors"], ["Coil", "Apache-2.0", "© Coil Contributors"], ["Inter · Cormorant · IBM Plex Arabic", "OFL-1.1", "Fonts (subset)"]].map(([n, l, c]) => (
          <div key={n} className="row" style={{ padding: "10px 0", borderBottom: "1px solid var(--c-outline-variant)" }}><div style={{ flex: 1 }}><div className="body-l">{n}</div><div className="label-s muted">{c}</div></div><span className="label-s gold" style={{ padding: "3px 8px", borderRadius: 6, background: "var(--c-primary-container)" }}>{l}</span></div>
        ))}
      </Sheet>
    </div>
  );
}
