import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type CSSProperties, type ReactElement } from "react";
import { IconBtn, Sheet } from "../components";
import { CONTENT } from "../data";
import { Icon } from "../icons";
import { useApp } from "../store";

type RTheme = "paper" | "sepia" | "ivory" | "graphite" | "midnight" | "amoled";
type Mode = "paged" | "scroll" | "curl" | "two";
interface Block { kind: "title" | "p"; text: string; ch: number; para: number; first?: boolean; cont?: boolean; offset: number }
interface Mark { s: number; e: number; cls: string }

const FONTS = [
  { id: "Literata", css: "'Literata', 'Amiri', serif" },
  { id: "Amiri", css: "'Amiri', serif" },
  { id: "Cormorant", css: "'Cormorant Garamond', 'Amiri', serif" },
  { id: "Inter", css: "'Inter', 'IBM Plex Sans Arabic', sans-serif" },
  { id: "Noto Kufi", css: "'Noto Kufi Arabic', 'Inter', sans-serif" },
];
const DICT: Record<string, string> = {
  fortune: "n. — wealth, riches; chance or luck as a force in human affairs.",
  truth: "n. — that which is true or in accordance with fact or reality.",
  neighbourhood: "n. — a district or community within a town or city.",
  القراءة: "مصدر قرأ: النظر في المكتوب وفهمه، أو النطق به.",
  الهامش: "الحاشية؛ ما يُترك خاليًا على جانب الصفحة، ويُكتب فيه التعليق.",
  الضوء: "ما يُرى به الأشياء؛ النور.",
};

function renderMarked(text: string, marks: Mark[]) {
  if (!marks.length) return text;
  const sorted = [...marks].sort((a, b) => a.s - b.s);
  const out: (string | ReactElement)[] = [];
  let pos = 0;
  sorted.forEach((m, i) => {
    if (m.s < pos) return;
    if (m.s > pos) out.push(text.slice(pos, m.s));
    const Tag = m.cls.startsWith("mk") ? "mark" : "span";
    out.push(<Tag key={i} className={m.cls === "mk" ? "" : m.cls === "mkc" ? "cur" : m.cls}>{text.slice(m.s, m.e)}</Tag>);
    pos = m.e;
  });
  if (pos < text.length) out.push(text.slice(pos));
  return out;
}

function splitSentences(text: string): [number, number][] {
  const res: [number, number][] = [];
  const re = /[^.!?؟…\n]+[.!?؟…”"]*\s*/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) { if (m[0].trim()) res.push([m.index, m.index + m[0].length]); }
  return res;
}

export function Reader({ bookId }: { bookId: string }) {
  const { books, t, pop, updateBook, addQuote, quotes, showToast, settings, setSetting, push, haptic, lang } = useApp();
  const book = books.find((b) => b.id === bookId)!;
  const chapters = CONTENT[book.content] ?? CONTENT.pride;
  const rtlBook = book.rtl;

  const [rTheme, setRTheme] = useState<RTheme>(() => (document.querySelector(".app")?.getAttribute("data-theme") === "light" ? "ivory" : document.querySelector(".app")?.getAttribute("data-theme") === "sepia" ? "sepia" : "graphite"));
  const [fontSize, setFontSize] = useState(17);
  const [lh, setLh] = useState(1.6);
  const [margin, setMargin] = useState(26);
  const [align, setAlign] = useState<"start" | "justify">("justify");
  const [font, setFont] = useState(rtlBook ? "Amiri" : "Literata");
  const [mode, setMode] = useState<Mode>("paged");
  const [rtlPaging, setRtlPaging] = useState(rtlBook);
  const [contrast, setContrast] = useState(false);
  const [reflow, setReflow] = useState(book.cat !== "docs");
  const [bars, setBars] = useState(true);
  const [sheet, setSheet] = useState<null | "toc" | "search" | "display" | "define">(null);
  const [tocTab, setTocTab] = useState<"toc" | "bm">("toc");
  const [pages, setPages] = useState<Block[][]>([]);
  const [page, setPage] = useState(0);
  const [dir, setDir] = useState<1 | -1>(1);
  const [curlFrom, setCurlFrom] = useState<number | null>(null);
  const [bookmarks, setBookmarks] = useState<number[]>([]);
  const [query, setQuery] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  const [hitIdx, setHitIdx] = useState(0);
  const [scrub, setScrub] = useState<number | null>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [origin, setOrigin] = useState("50% 50%");
  const [sel, setSel] = useState<{ x: number; y: number; text: string } | null>(null);
  const [defineWord, setDefineWord] = useState("");
  const [tts, setTts] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [rate, setRate] = useState(1);
  const [pitch, setPitch] = useState(1);
  const [sleepMin, setSleepMin] = useState(0);
  const [ttsPos, setTtsPos] = useState<{ block: number; s: number; e: number } | null>(null);

  const measureRef = useRef<HTMLDivElement>(null);
  const areaRef = useRef<HTMLDivElement>(null);
  const pointer = useRef<{ x: number; y: number; t: number; panX: number; panY: number } | null>(null);
  const lastTap = useRef(0);
  const progressFrac = useRef(book.progress);
  const playingRef = useRef(false);
  const sleepTimer = useRef<number | undefined>(undefined);

  const two = mode === "two";
  const blocks = useMemo<Block[]>(() => {
    const out: Block[] = [];
    chapters.forEach((c, ci) => {
      out.push({ kind: "title", text: c.title, ch: ci, para: -1, offset: 0 });
      c.paras.forEach((p, pi) => out.push({ kind: "p", text: p, ch: ci, para: pi, first: pi === 0, offset: 0 }));
    });
    return out;
  }, [chapters]);

  // ---- Measured pagination (same algorithm as feature-reader's ReflowPaginator) ----
  useLayoutEffect(() => {
    const root = measureRef.current;
    if (!root || mode === "scroll") return;
    const inner = root.querySelector(".page-inner") as HTMLDivElement;
    const result: Block[][] = [];
    let cur: Block[] = [];
    const mk = (b: Block) => {
      const el = document.createElement(b.kind === "title" ? "h2" : "p");
      el.className = b.kind === "title" ? "ch-title" : b.first && !b.cont ? "first" : "";
      if (b.cont) el.style.textIndent = "0";
      el.textContent = b.text;
      return el;
    };
    const fits = () => inner.scrollHeight <= inner.clientHeight + 1;
    const flush = () => { result.push(cur); cur = []; inner.innerHTML = ""; };
    for (const b of blocks) {
      if (b.kind === "title" && cur.length) flush();
      let piece: Block = { ...b };
      while (true) {
        const el = mk(piece);
        inner.appendChild(el);
        if (fits()) { cur.push(piece); break; }
        inner.removeChild(el);
        if (piece.kind === "title") { if (cur.length) { flush(); continue; } cur.push(piece); break; }
        const words = piece.text.split(" ");
        let lo = 0, hi = words.length;
        while (lo < hi) {
          const mid = Math.ceil((lo + hi) / 2);
          el.textContent = words.slice(0, mid).join(" ");
          inner.appendChild(el);
          const ok = fits();
          inner.removeChild(el);
          if (ok) lo = mid; else hi = mid - 1;
        }
        if (lo === 0) { if (cur.length) { flush(); continue; } lo = 1; }
        const head = words.slice(0, lo).join(" ");
        cur.push({ ...piece, text: head });
        inner.appendChild(mk({ ...piece, text: head }));
        flush();
        piece = { ...piece, text: words.slice(lo).join(" "), cont: true, first: false, offset: piece.offset + head.length + 1 };
        if (!piece.text) break;
      }
    }
    if (cur.length) result.push(cur);
    inner.innerHTML = "";
    setPages(result);
    setPage(Math.min(result.length - 1, Math.round(progressFrac.current * (result.length - 1))));
  }, [blocks, fontSize, lh, margin, font, align, mode, reflow]);

  const total = pages.length || 1;
  const go = useCallback((delta: number, animate = true) => {
    setPage((p) => {
      const step = two ? 2 : 1;
      const n = Math.max(0, Math.min(total - 1, p + delta * step));
      if (n !== p) {
        setDir(delta > 0 ? 1 : -1);
        if (animate && mode === "curl") setCurlFrom(p);
        haptic();
      }
      return n;
    });
    setSel(null);
  }, [total, mode, two, haptic]);

  useEffect(() => { if (curlFrom != null) { const id = setTimeout(() => setCurlFrom(null), 460); return () => clearTimeout(id); } }, [curlFrom]);
  useEffect(() => {
    if (!pages.length) return;
    const f = total > 1 ? page / (total - 1) : 1;
    progressFrac.current = f;
    updateBook(book.id, { progress: Math.max(book.progress >= 1 ? 1 : 0, Math.round(f * 100) / 100), lastReadHours: 0 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, pages.length]);

  // keyboard & "volume keys" (PageUp/PageDown) navigation
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === "INPUT") return;
      const fwdKey = rtlPaging ? "ArrowLeft" : "ArrowRight";
      const backKey = rtlPaging ? "ArrowRight" : "ArrowLeft";
      if (e.key === fwdKey || e.key === " " || (settings.volumeKeys && e.key === "PageDown")) { e.preventDefault(); go(1); }
      else if (e.key === backKey || (settings.volumeKeys && e.key === "PageUp")) { e.preventDefault(); go(-1); }
      else if (e.key === "Escape") { if (zoom > 1) { setZoom(1); setPan({ x: 0, y: 0 }); } else pop(); }
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [go, rtlPaging, settings.volumeKeys, zoom, pop]);

  // ---- Search ----
  const hits = useMemo(() => {
    const qq = activeQuery.trim().toLowerCase();
    if (!qq) return [] as { page: number; snippet: string; block: number; pos: number }[];
    const res: { page: number; snippet: string; block: number; pos: number }[] = [];
    pages.forEach((pg, pi) => pg.forEach((b, bi) => {
      const low = b.text.toLowerCase();
      let i = low.indexOf(qq);
      while (i >= 0) {
        res.push({ page: pi, block: bi, pos: i, snippet: (i > 30 ? "…" : "") + b.text.slice(Math.max(0, i - 30), i + qq.length + 40) + "…" });
        i = low.indexOf(qq, i + qq.length);
      }
    }));
    return res;
  }, [activeQuery, pages]);
  const jumpHit = (i: number) => { if (!hits.length) return; const k = (i + hits.length) % hits.length; setHitIdx(k); setPage(hits[k].page); };

  // ---- TTS (Web Speech API stands in for Android TextToSpeech in the preview) ----
  const pageBlocks = pages[page] ?? [];
  const speakFrom = useCallback((blockIdx: number, sentIdx: number) => {
    const pg = pages[page];
    if (!pg || !playingRef.current) return;
    if (blockIdx >= pg.length) {
      if (page < total - 1) { setPage((p) => p + 1); setTtsPos({ block: -1, s: 0, e: 0 }); } else { setPlaying(false); playingRef.current = false; }
      return;
    }
    const b = pg[blockIdx];
    const sents = splitSentences(b.text);
    if (sentIdx >= sents.length) { speakFrom(blockIdx + 1, 0); return; }
    const [s, e] = sents[sentIdx];
    setTtsPos({ block: blockIdx, s, e });
    const text = b.text.slice(s, e);
    const synth = typeof window !== "undefined" ? window.speechSynthesis : undefined;
    const advance = () => { if (playingRef.current) speakFrom(blockIdx, sentIdx + 1); };
    if (synth) {
      synth.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = rtlBook ? "ar-SA" : "en-GB";
      u.rate = rate; u.pitch = pitch;
      const v = synth.getVoices().find((x) => x.lang.startsWith(rtlBook ? "ar" : "en"));
      if (v) u.voice = v;
      let done = false;
      const fallback = window.setTimeout(() => { if (!done) { done = true; advance(); } }, Math.max(1500, (text.length * 70) / rate) + 4000);
      u.onend = () => { if (!done) { done = true; clearTimeout(fallback); advance(); } };
      u.onerror = () => { if (!done) { done = true; clearTimeout(fallback); window.setTimeout(advance, (text.length * 55) / rate); } };
      synth.speak(u);
    } else {
      window.setTimeout(advance, (text.length * 55) / rate);
    }
  }, [pages, page, total, rate, pitch, rtlBook]);

  useEffect(() => {
    if (playing && ttsPos?.block === -1) speakFrom(0, 0);
  }, [page, playing, ttsPos, speakFrom]);

  const togglePlay = () => {
    if (playing) { playingRef.current = false; setPlaying(false); window.speechSynthesis?.cancel(); }
    else { playingRef.current = true; setPlaying(true); speakFrom(ttsPos && ttsPos.block >= 0 ? ttsPos.block : 0, 0); }
  };
  useEffect(() => () => { playingRef.current = false; window.speechSynthesis?.cancel(); clearTimeout(sleepTimer.current); }, []);
  const setSleep = (m: number) => {
    setSleepMin(m); clearTimeout(sleepTimer.current);
    if (m) sleepTimer.current = window.setTimeout(() => { playingRef.current = false; setPlaying(false); window.speechSynthesis?.cancel(); showToast(`${t.sleepTimer} ✓`); }, m * 60000);
  };

  // ---- Pointer: tap zones, swipe, double-tap zoom, pan ----
  const onDown = (e: React.PointerEvent) => { pointer.current = { x: e.clientX, y: e.clientY, t: Date.now(), panX: pan.x, panY: pan.y }; };
  const onMove = (e: React.PointerEvent) => {
    if (!pointer.current || zoom === 1) return;
    setPan({ x: pointer.current.panX + (e.clientX - pointer.current.x), y: pointer.current.panY + (e.clientY - pointer.current.y) });
  };
  const onUp = (e: React.PointerEvent) => {
    const p = pointer.current; pointer.current = null;
    if (!p) return;
    const dx = e.clientX - p.x, dy = e.clientY - p.y;
    const selection = window.getSelection()?.toString().trim() ?? "";
    if (selection.length > 1) {
      const r = window.getSelection()!.getRangeAt(0).getBoundingClientRect();
      const a = areaRef.current!.getBoundingClientRect();
      setSel({ x: Math.min(Math.max(r.left + r.width / 2 - a.left, 120), a.width - 120), y: Math.max(r.top - a.top - 8, 110), text: selection });
      return;
    }
    setSel(null);
    if (zoom > 1) { if (Math.abs(dx) < 5 && Math.abs(dy) < 5 && Date.now() - lastTap.current < 300) { setZoom(1); setPan({ x: 0, y: 0 }); } lastTap.current = Date.now(); return; }
    if (mode !== "scroll" && Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) { const fwd = rtlPaging ? dx > 0 : dx < 0; go(fwd ? 1 : -1); return; }
    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) return;
    const now = Date.now();
    const a = areaRef.current!.getBoundingClientRect();
    if (now - lastTap.current < 280) {
      lastTap.current = 0;
      setOrigin(`${((e.clientX - a.left) / a.width) * 100}% ${((e.clientY - a.top) / a.height) * 100}%`);
      setZoom(1.8);
      return;
    }
    lastTap.current = now;
    const x = (e.clientX - a.left) / a.width;
    window.setTimeout(() => {
      if (lastTap.current !== now) return;
      if (mode === "scroll" || (x > 0.3 && x < 0.7)) setBars((b) => !b);
      else { const fwd = rtlPaging ? x < 0.3 : x > 0.7; go(fwd ? 1 : -1); }
    }, 230);
  };
  const onWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey) { e.preventDefault(); setZoom((z) => Math.max(1, Math.min(3, z - e.deltaY * 0.01))); }
    else if (mode !== "scroll" && Math.abs(e.deltaY) > 30) { go(e.deltaY > 0 ? 1 : -1); }
  };

  // ---- Styling ----
  const pageStyle: CSSProperties = {
    background: `var(--reader-${rTheme}-page)`, color: `var(--reader-${rTheme}-text)`,
    ["--accent" as string]: `var(--reader-${rTheme}-accent)`, ["--m" as string]: `${two ? margin / 2 : margin}px`,
    fontFamily: FONTS.find((f) => f.id === font)!.css, fontSize: reflow ? fontSize * (two ? 0.62 : 1) : 9, lineHeight: lh, textAlign: align,
    filter: contrast ? "contrast(1.18) saturate(1.05)" : undefined,
  };
  const currentChapter = pageBlocks[0]?.ch ?? 0;
  const chapterPage = (ci: number) => pages.findIndex((pg) => pg.some((b) => b.kind === "title" && b.ch === ci));
  const quoteTexts = quotes.filter((q) => q.bookId === book.id).map((q) => q.text);

  const marksFor = (b: Block, bi: number, pi: number): Mark[] => {
    const m: Mark[] = [];
    const qq = activeQuery.trim().toLowerCase();
    if (qq) {
      const low = b.text.toLowerCase(); let i = low.indexOf(qq);
      while (i >= 0) { const h = hits[hitIdx]; m.push({ s: i, e: i + qq.length, cls: h && h.page === pi && h.block === bi && h.pos === i ? "mkc" : "mk" }); i = low.indexOf(qq, i + qq.length); }
    }
    quoteTexts.forEach((qt) => { const i = b.text.indexOf(qt.slice(0, 40)); if (i >= 0) m.push({ s: i, e: Math.min(b.text.length, i + qt.length), cls: "hl" }); });
    if (tts && ttsPos && pi === page && ttsPos.block === bi) m.push({ s: ttsPos.s, e: ttsPos.e, cls: "tts" });
    return m;
  };

  const renderPage = (pi: number, extraClass = "", style?: CSSProperties) => {
    const pg = pages[pi];
    if (!pg) return null;
    return (
      <div key={`${pi}-${extraClass}`} className={`page ${extraClass}`} style={{ ...pageStyle, ...style }} dir={rtlBook ? "rtl" : "ltr"}>
        <div className="page-inner" style={{ height: "100%", overflow: "hidden", ...(reflow ? {} : { background: "#fff", color: "#1c1c1c", padding: 18, boxShadow: "var(--elev-2)", borderRadius: 2 }) }}>
          {pg.map((b, bi) => b.kind === "title"
            ? <h2 key={bi} className="ch-title">{renderMarked(b.text, marksFor(b, bi, pi))}</h2>
            : <p key={bi} className={b.first && !b.cont ? "first" : ""} style={b.cont ? { textIndent: 0 } : undefined}>{renderMarked(b.text, marksFor(b, bi, pi))}</p>)}
        </div>
        <div className="page-foot">{pi + 1} / {total}{!two && ` · ${Math.max(1, Math.round((total - pi) * 1.1))} ${t.minLeft}`}</div>
      </div>
    );
  };

  const isBookmarked = bookmarks.includes(page);
  const slideAnim = mode === "paged" ? { animation: `${(dir > 0) !== rtlPaging ? "slideInEnd" : "slideInStart"} var(--dur-medium) var(--ease-emphasized-decelerate) both` } : undefined;

  return (
    <div className="reader" style={{ background: `var(--reader-${rTheme}-page)` }}>
      {/* hidden measuring page */}
      <div ref={measureRef} className="page" aria-hidden style={{ ...pageStyle, visibility: "hidden", pointerEvents: "none", ...(two ? { width: "50%" } : {}) }} dir={rtlBook ? "rtl" : "ltr"}>
        <div className="page-inner" style={{ height: "100%", overflow: "hidden", ...(reflow ? {} : { padding: 18 }) }} />
      </div>

      <div ref={areaRef} className={`page-area ${mode === "curl" ? "curl-wrap" : ""}`} onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onWheel={onWheel}>
        <div style={{ position: "absolute", inset: 0, transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: origin, transition: pointer.current ? "none" : "transform var(--dur-medium) var(--ease-emphasized-decelerate)" }}>
          {mode === "scroll" ? (
            <div className="page" style={{ ...pageStyle, overflowY: "auto", position: "absolute" }} dir={rtlBook ? "rtl" : "ltr"}
              onScroll={(e) => { const el = e.currentTarget; const f = el.scrollTop / Math.max(1, el.scrollHeight - el.clientHeight); progressFrac.current = f; updateBook(book.id, { progress: Math.round(f * 100) / 100 }); }}>
              {blocks.map((b, bi) => b.kind === "title" ? <h2 key={bi} className="ch-title" style={{ marginTop: bi ? "1.6em" : 0 }}>{b.text}</h2> : <p key={bi} className={b.first ? "first" : ""}>{renderMarked(b.text, marksFor(b, bi, -1))}</p>)}
              <div style={{ height: 80 }} />
            </div>
          ) : two ? (
            <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: rtlPaging ? "row-reverse" : "row" }}>
              {[page, page + 1].map((pi) => <div key={pi} style={{ position: "relative", flex: 1, borderInlineEnd: "1px solid rgba(0,0,0,.08)" }}>{renderPage(pi, "", slideAnim)}</div>)}
            </div>
          ) : (
            <>
              {renderPage(page, "", slideAnim)}
              {mode === "curl" && curlFrom != null && renderPage(curlFrom, dir > 0 !== rtlPaging ? "curl-out-next" : "curl-out-prev")}
            </>
          )}
        </div>
        {sel && (
          <div className="sel-pop" style={{ left: sel.x, top: sel.y }} onPointerDown={(e) => e.stopPropagation()} onPointerUp={(e) => e.stopPropagation()}>
            <button onClick={() => { addQuote({ bookId: book.id, text: sel.text, color: "#D4B26A", page: page + 1 }); showToast(t.highlighted); setSel(null); window.getSelection()?.removeAllRanges(); }}>{t.highlight}</button>
            <button onClick={() => { navigator.clipboard?.writeText(sel.text); showToast(t.copied); setSel(null); }}>{t.copy}</button>
            <button onClick={() => { setDefineWord(sel.text.split(/\s+/)[0].replace(/[^\p{L}]/gu, "")); setSheet("define"); setSel(null); }}>{t.define}</button>
            <button onClick={async () => { try { if (navigator.share) await navigator.share({ text: `“${sel.text}” — ${book.title}` }); else showToast(t.shared); } catch { /* cancelled */ } setSel(null); }}>{t.share}</button>
          </div>
        )}
      </div>

      {/* top bar */}
      <div className={`reader-bar top-bar ${bars ? "" : "hide"}`}>
        <div className="top" style={{ minHeight: 52 }}>
          <IconBtn name="back" label={t.cancel} onClick={() => { window.speechSynthesis?.cancel(); pop(); }} className="flip-rtl" />
          <div className="grow"><div className="title-m" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{book.title}</div><div className="label-s muted">{chapters[currentChapter]?.title}</div></div>
          {activeQuery && hits.length > 0 && (
            <div className="row" style={{ gap: 0 }}>
              <span className="label-s gold">{hitIdx + 1}/{hits.length}</span>
              <IconBtn name="back" label="prev" onClick={() => jumpHit(hitIdx - 1)} size={18} className="flip-rtl" />
              <IconBtn name="back" label="next" onClick={() => jumpHit(hitIdx + 1)} size={18} className={lang === "ar" ? "" : "flip-rtl"} />
              <IconBtn name="close" label={t.clear} onClick={() => { setActiveQuery(""); setQuery(""); }} size={18} />
            </div>
          )}
          {!activeQuery && <IconBtn name="search" label={t.search} onClick={() => setSheet("search")} />}
          <IconBtn name="bookmark" label={t.bookmarks} on={isBookmarked} onClick={() => { setBookmarks(isBookmarked ? bookmarks.filter((x) => x !== page) : [...bookmarks, page]); showToast(isBookmarked ? t.bookmarkRemoved : t.bookmarkAdded); }} />
        </div>
      </div>

      {/* bottom bar / TTS panel */}
      <div className={`reader-bar bottom-bar ${bars ? "" : "hide"}`}>
        {tts ? (
          <div style={{ padding: "4px 8px" }}>
            <div className="row between" style={{ marginBottom: 8 }}>
              <div className="row" style={{ gap: 10 }}>{playing ? <div className="tts-wave">{[0, 1, 2, 3, 4].map((i) => <i key={i} style={{ animationDelay: `${i * 0.12}s` }} />)}</div> : <Icon name="headphones" style={{ color: "var(--c-primary)" }} />}<span className="label-l">{t.reading}</span></div>
              <IconBtn name="close" label={t.cancel} onClick={() => { playingRef.current = false; setPlaying(false); setTts(false); setTtsPos(null); window.speechSynthesis?.cancel(); }} />
            </div>
            <div className="row" style={{ justifyContent: "center", gap: 18 }}>
              <IconBtn name="prev" label="prev" onClick={() => go(-1)} className="flip-rtl" />
              <button className="btn" style={{ width: 56, height: 56, borderRadius: 28, padding: 0 }} onClick={togglePlay} aria-label={playing ? "pause" : "play"}><Icon name={playing ? "pause" : "play"} size={24} /></button>
              <IconBtn name="nextI" label="next" onClick={() => go(1)} className="flip-rtl" />
            </div>
            <div className="adj-row" style={{ marginTop: 10 }}><span className="lbl">{t.speed}</span><input className="range" type="range" min={0.5} max={2} step={0.1} value={rate} onChange={(e) => setRate(+e.target.value)} /><span className="val">{rate.toFixed(1)}×</span></div>
            <div className="adj-row" style={{ marginTop: 6 }}><span className="lbl">{t.pitch}</span><input className="range" type="range" min={0.5} max={1.5} step={0.1} value={pitch} onChange={(e) => setPitch(+e.target.value)} /><span className="val">{pitch.toFixed(1)}</span></div>
            <div className="row" style={{ marginTop: 10, gap: 6, flexWrap: "wrap" }}><Icon name="timer" size={18} style={{ color: "var(--c-on-surface-variant)" }} />{[0, 15, 30, 60].map((m) => <button key={m} className={`chip ${sleepMin === m ? "on" : ""}`} style={{ height: 28 }} onClick={() => setSleep(m)}>{m ? `${m} ${t.min}` : t.off}</button>)}</div>
          </div>
        ) : (
          <>
            <div className="scrub">
              {scrub != null && pages[scrub] && (
                <div className="scrub-tip" style={{ left: `${(scrub / Math.max(1, total - 1)) * 100}%` }}>
                  <div className="mini" style={{ background: `var(--reader-${rTheme}-page)`, color: `var(--reader-${rTheme}-text)` }} dir={rtlBook ? "rtl" : "ltr"}>{pages[scrub].map((b) => b.text).join(" ").slice(0, 700)}</div>
                  <div className="label-s">{t.page} {scrub + 1}</div>
                </div>
              )}
              <input className="range" type="range" min={0} max={Math.max(0, total - 1)} value={scrub ?? page} dir={rtlPaging ? "rtl" : "ltr"} aria-label={t.page}
                onChange={(e) => setScrub(+e.target.value)}
                onPointerUp={() => { if (scrub != null) { setPage(scrub); setScrub(null); } }}
                onKeyUp={() => { if (scrub != null) { setPage(scrub); setScrub(null); } }} />
              <div className="row between label-s muted" style={{ marginTop: 6 }}><span>{t.page} {page + 1} {t.of} {total}</span><span>{Math.round((page / Math.max(1, total - 1)) * 100)}%</span></div>
            </div>
            <div className="row" style={{ justifyContent: "space-around", marginTop: 4 }}>
              <IconBtn name="toc" label={t.contents} onClick={() => setSheet("toc")} />
              <IconBtn name="type" label={t.themes} onClick={() => setSheet("display")} />
              <IconBtn name="headphones" label={t.listen} onClick={() => { setTts(true); }} />
              <IconBtn name="zoomIn" label={t.zoom} on={zoom > 1} onClick={() => { if (zoom > 1) { setZoom(1); setPan({ x: 0, y: 0 }); } else { setOrigin("50% 40%"); setZoom(1.6); } }} />
              {(book.format === "PDF" || book.cat === "docs") && <IconBtn name="edit" label={t.editPdf} onClick={() => push({ name: "pdf", bookId: book.id })} />}
            </div>
          </>
        )}
      </div>

      <Sheet open={sheet === "toc"} onClose={() => setSheet(null)}>
        <div className="seg" style={{ marginBottom: 12 }}>
          <button className={tocTab === "toc" ? "on" : ""} onClick={() => setTocTab("toc")}>{t.contents}</button>
          <button className={tocTab === "bm" ? "on" : ""} onClick={() => setTocTab("bm")}>{t.bookmarks} ({bookmarks.length})</button>
        </div>
        {tocTab === "toc" ? chapters.map((c, ci) => (
          <button key={ci} className="list-item" style={{ padding: "12px 4px" }} onClick={() => { const p = chapterPage(ci); if (p >= 0) setPage(p); setSheet(null); }}>
            <span className="li-text body-l" style={{ color: ci === currentChapter ? "var(--c-primary)" : undefined }}>{c.title}</span><span className="label-s muted">{chapterPage(ci) + 1}</span>
          </button>
        )) : bookmarks.length === 0 ? <p className="muted" style={{ textAlign: "center", padding: 24 }}>{t.noBookmarks}</p> : [...bookmarks].sort((a, b) => a - b).map((bm) => (
          <button key={bm} className="list-item" style={{ padding: "12px 4px" }} onClick={() => { setPage(bm); setSheet(null); }}>
            <Icon name="bookmark" size={18} style={{ color: "var(--c-primary)" }} /><span className="li-text body-l" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{pages[bm]?.[0]?.text.slice(0, 60)}</span><span className="label-s muted">{bm + 1}</span>
          </button>
        ))}
      </Sheet>

      <Sheet open={sheet === "search"} onClose={() => setSheet(null)} title={t.searchIn}>
        <label className="field"><Icon name="search" size={20} />
          <input autoFocus value={query} onChange={(e) => { setQuery(e.target.value); setActiveQuery(e.target.value); setHitIdx(0); }} placeholder={rtlBook ? "القراءة" : "fortune"} />
        </label>
        <div className="label-l muted" style={{ margin: "12px 0 4px" }}>{hits.length} {t.results}</div>
        {hits.slice(0, 50).map((h, i) => (
          <button key={i} className="list-item" style={{ padding: "10px 4px", alignItems: "flex-start" }} onClick={() => { setHitIdx(i); setPage(h.page); setSheet(null); }}>
            <span className="label-s gold" style={{ minWidth: 28 }}>{h.page + 1}</span><span className="li-text" dir={rtlBook ? "rtl" : "ltr"} style={{ fontSize: 13 }}>{h.snippet}</span>
          </button>
        ))}
      </Sheet>

      <Sheet open={sheet === "display"} onClose={() => setSheet(null)} title={t.themes}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8 }}>
          {(["paper", "sepia", "ivory", "graphite", "midnight", "amoled"] as RTheme[]).map((k) => (
            <button key={k} className={`theme-swatch ${rTheme === k ? "on" : ""}`} style={{ background: `var(--reader-${k}-page)`, color: `var(--reader-${k}-text)`, border: rTheme === k ? undefined : "1px solid var(--c-outline)" }} onClick={() => setRTheme(k)} aria-label={k}>Aa</button>
          ))}
        </div>
        <div className="row" style={{ justifyContent: "space-between", marginTop: 4 }}>{["Paper", "Sepia", "Ivory", "Graphite", "Midnight", "AMOLED"].map((n) => <span key={n} className="label-s muted" style={{ width: "16%", textAlign: "center", fontSize: 9 }}>{n}</span>)}</div>
        <div className="section-title">{t.font}</div>
        <div className="row" style={{ gap: 6, flexWrap: "wrap" }}>{FONTS.map((f) => <button key={f.id} className={`chip ${font === f.id ? "on" : ""}`} style={{ fontFamily: f.css }} onClick={() => setFont(f.id)}>{f.id}</button>)}</div>
        <div style={{ display: "grid", gap: 12, marginTop: 16 }}>
          <div className="adj-row"><span className="lbl">{t.fontSize}</span><input className="range" type="range" min={13} max={28} value={fontSize} onChange={(e) => setFontSize(+e.target.value)} /><span className="val">{fontSize}</span></div>
          <div className="adj-row"><span className="lbl">{t.lineHeight}</span><input className="range" type="range" min={1.2} max={2.1} step={0.05} value={lh} onChange={(e) => setLh(+e.target.value)} /><span className="val">{lh.toFixed(2)}</span></div>
          <div className="adj-row"><span className="lbl">{t.margins}</span><input className="range" type="range" min={12} max={48} value={margin} onChange={(e) => setMargin(+e.target.value)} /><span className="val">{margin}</span></div>
        </div>
        <div className="section-title">{t.align}</div>
        <div className="seg"><button className={align === "start" ? "on" : ""} onClick={() => setAlign("start")}><Icon name={rtlBook ? "alignR" : "alignL"} size={16} /></button><button className={align === "justify" ? "on" : ""} onClick={() => setAlign("justify")}><Icon name="alignJ" size={16} /></button></div>
        <div className="section-title">{t.mode}</div>
        <div className="seg">{([["paged", t.mPaged], ["scroll", t.mScroll], ["curl", t.mCurl], ["two", t.mTwo]] as [Mode, string][]).map(([m, l]) => <button key={m} className={mode === m ? "on" : ""} onClick={() => setMode(m)}>{l}</button>)}</div>
        <div style={{ marginTop: 8 }}>
          {[
            [t.rtlPaging, rtlPaging, setRtlPaging],
            [t.blueLight, settings.blueLight, (v: boolean) => setSetting("blueLight", v)],
            [t.contrast, contrast, setContrast],
            ...(book.cat === "docs" ? [[t.reflow, reflow, setReflow]] : []),
            [t.cropMargins, margin <= 14, (v: boolean) => setMargin(v ? 12 : 26)],
            [t.rotationLock, false, () => showToast(`${t.rotationLock} ✓`)],
          ].map(([l, v, fn]) => (
            <div key={l as string} className="row between" style={{ padding: "12px 0", borderBottom: "1px solid var(--c-outline-variant)" }}>
              <span className="body-l">{l as string}</span>
              <button role="switch" aria-checked={!!v} className={`switch ${v ? "on" : ""}`} onClick={() => (fn as (b: boolean) => void)(!v)} />
            </div>
          ))}
        </div>
      </Sheet>

      <Sheet open={sheet === "define"} onClose={() => setSheet(null)} title={defineWord}>
        <p className="body-l" style={{ marginTop: 0 }} dir={/[\u0600-\u06FF]/.test(defineWord) ? "rtl" : "ltr"}>
          {DICT[defineWord.toLowerCase()] ?? DICT[defineWord] ?? (lang === "ar" ? "لا يوجد تعريف في القاموس المحلي المضمَّن. يمكنك تنزيل قاموس StarDict/DICT للعمل دون إنترنت." : "No entry in the bundled offline dictionary. Install a StarDict/DICT pack for full offline definitions.")}
        </p>
        <div className="label-s muted">{lang === "ar" ? "قاموس محلي — دون إنترنت" : "Offline dictionary"}</div>
      </Sheet>
    </div>
  );
}
