import { useMemo, useRef, useState } from "react";
import { BottomNav, Cover, Dialog, EmptyArt, IconBtn, Logo, Ring, Sheet } from "../components";
import { CONTENT, type Book, type Cat } from "../data";
import { Icon } from "../icons";
import { useApp } from "../store";

type SortKey = "name" | "date" | "size" | "last" | "progress";
type View = "grid" | "list" | "compact";

export function openBook(book: Book, push: ReturnType<typeof useApp>["push"]) {
  if (book.cat === "images") push({ name: "image" });
  else if (book.cat === "text") push({ name: "text", kind: book.format === "HTML" ? "html" : "md" });
  else push({ name: "reader", bookId: book.id });
}

export function PasswordDialog({ book, onClose, onOk }: { book: Book | null; onClose: () => void; onOk: () => void }) {
  const { t, lang } = useApp();
  const [pw, setPw] = useState("");
  const [err, setErr] = useState(false);
  if (!book) return null;
  const submit = () => { if (pw === "1234") { setPw(""); setErr(false); onOk(); } else { setErr(true); } };
  return (
    <Dialog open onClose={onClose}>
      <div style={{ textAlign: "center" }}>
        <div style={{ width: 52, height: 52, borderRadius: 26, margin: "0 auto 12px", display: "grid", placeItems: "center", background: "var(--c-primary-container)", color: "var(--c-primary)" }}><Icon name="lock" /></div>
        <h3 className="title-l">{lang === "ar" ? "مستند محمي" : "Protected document"}</h3>
        <p className="muted" style={{ margin: "6px 0 16px" }}>{book.title}</p>
      </div>
      <input className="input" type="password" autoFocus value={pw} placeholder={t.password} onChange={(e) => { setPw(e.target.value); setErr(false); }}
        onKeyDown={(e) => e.key === "Enter" && submit()} style={err ? { borderColor: "var(--c-error)", animation: "shake 300ms" } : undefined} />
      <div className="label-s" style={{ marginTop: 6, color: err ? "var(--c-error)" : "var(--c-on-surface-variant)" }}>
        {err ? (lang === "ar" ? "كلمة مرور غير صحيحة — حاول مجددًا" : "Incorrect password — try again") : (lang === "ar" ? "للتجربة: 1234" : "Demo password: 1234")}
      </div>
      <div className="row" style={{ justifyContent: "flex-end", marginTop: 18, gap: 8 }}>
        <button className="btn ghost sm" onClick={onClose}>{t.cancel}</button>
        <button className="btn sm" onClick={submit} disabled={!pw}>{lang === "ar" ? "فتح" : "Unlock"}</button>
      </div>
      <style>{`@keyframes shake { 25% { transform: translateX(-6px) } 75% { transform: translateX(6px) } }`}</style>
    </Dialog>
  );
}

export function Library() {
  const { t, books, push, updateBook, showToast, collections, haptic, lang } = useApp();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<Cat | "all">("all");
  const [sort, setSort] = useState<SortKey>("last");
  const [asc, setAsc] = useState(false);
  const [view, setView] = useState<View>("grid");
  const [sortOpen, setSortOpen] = useState(false);
  const [menuBook, setMenuBook] = useState<Book | null>(null);
  const [collPick, setCollPick] = useState(false);
  const [lockBook, setLockBook] = useState<Book | null>(null);
  const [scrollY, setScrollY] = useState(0);
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const pullStart = useRef<number | null>(null);
  const pressTimer = useRef<number | undefined>(undefined);
  const longPressed = useRef(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const visible = books.filter((b) => !b.trashed && !b.archived);
  const cont = [...visible].filter((b) => b.lastReadHours != null && b.progress > 0 && b.progress < 1).sort((a, b) => a.lastReadHours! - b.lastReadHours!)[0];

  const results = useMemo(() => {
    const needle = q.trim().toLowerCase();
    let list = visible.filter((b) => cat === "all" || b.cat === cat).map((b) => {
      if (!needle) return { b, inContent: false };
      const meta = `${b.title} ${b.author} ${b.tags.join(" ")} ${b.format}`.toLowerCase().includes(needle);
      const inContent = !meta && (CONTENT[b.content] ?? []).some((c) => c.paras.some((p) => p.toLowerCase().includes(needle)));
      return meta || inContent ? { b, inContent } : null;
    }).filter(Boolean) as { b: Book; inContent: boolean }[];
    const cmp: Record<SortKey, (x: Book, y: Book) => number> = {
      name: (x, y) => x.title.localeCompare(y.title, lang),
      date: (x, y) => x.addedDays - y.addedDays,
      size: (x, y) => y.sizeMB - x.sizeMB,
      last: (x, y) => (x.lastReadHours ?? 1e9) - (y.lastReadHours ?? 1e9),
      progress: (x, y) => y.progress - x.progress,
    };
    list = list.sort((x, y) => cmp[sort](x.b, y.b) * (asc ? -1 : 1));
    return list;
  }, [visible, q, cat, sort, asc, lang]);

  const open = (b: Book) => {
    if (longPressed.current) { longPressed.current = false; return; }
    haptic();
    if (b.locked) { setLockBook(b); return; }
    updateBook(b.id, { lastReadHours: 0 });
    openBook(b, push);
  };
  const pressStart = (b: Book) => {
    longPressed.current = false;
    pressTimer.current = window.setTimeout(() => { longPressed.current = true; haptic(); setMenuBook(b); }, 480);
  };
  const pressEnd = () => window.clearTimeout(pressTimer.current);

  const doRefresh = () => {
    setRefreshing(true);
    setTimeout(() => { setRefreshing(false); showToast(t.indexed); }, 1400);
  };

  const hour = new Date().getHours();
  const cats: [Cat | "all", string][] = [["all", t.all], ["books", t.books], ["docs", t.docs], ["comics", t.comics], ["images", t.images], ["text", t.text]];
  const sorts: [SortKey, string][] = [["last", t.sLast], ["name", t.sName], ["date", t.sDate], ["size", t.sSize], ["progress", t.sProgress]];
  const itemProps = (b: Book) => ({
    onClick: () => open(b),
    onPointerDown: () => pressStart(b), onPointerUp: pressEnd, onPointerLeave: pressEnd,
    onContextMenu: (e: React.MouseEvent) => { e.preventDefault(); setMenuBook(b); },
  });
  const minsLeft = (b: Book) => Math.round(b.pages * (1 - b.progress) * 1.1);

  return (
    <div className="view">
      <div className="scroll" ref={scrollRef}
        onScroll={(e) => setScrollY((e.target as HTMLDivElement).scrollTop)}
        onPointerDown={(e) => { if (scrollRef.current!.scrollTop <= 0) pullStart.current = e.clientY; }}
        onPointerMove={(e) => { if (pullStart.current != null) setPull(Math.max(0, Math.min(90, (e.clientY - pullStart.current) * 0.5))); }}
        onPointerUp={() => { if (pull > 56 && !refreshing) doRefresh(); pullStart.current = null; setPull(0); }}
        onPointerCancel={() => { pullStart.current = null; setPull(0); }}>
        <div className="ptr" style={{ height: refreshing ? 44 : pull }}>
          {(refreshing || pull > 10) && <><span className="spinner" style={{ animationPlayState: refreshing ? "running" : "paused", transform: `rotate(${pull * 4}deg)` }} />{refreshing ? t.indexing : ""}</>}
        </div>
        <header className="lib-head" style={{ transform: `translateY(${scrollY * 0.35}px)`, opacity: Math.max(0, 1 - scrollY / 140) }}>
          <div className="row between">
            <div>
              <div className="label-l muted">{hour < 17 ? t.goodMorning : t.goodEvening}</div>
              <Logo size={34} />
            </div>
            <div className="row" style={{ gap: 0 }}>
              <IconBtn name="chart" label={t.stats} onClick={() => push({ name: "stats" })} />
              <IconBtn name={view === "grid" ? "grid" : view === "list" ? "list" : "compact"} label={t[view]} onClick={() => setView(view === "grid" ? "list" : view === "list" ? "compact" : "grid")} />
            </div>
          </div>
        </header>

        {cont && !q && (
          <div className="cont-card enter" onClick={() => open(cont)}>
            <Cover book={cont} width={64} />
            <div style={{ flex: 1, minWidth: 0, position: "relative", zIndex: 1 }}>
              <div className="label-s gold" style={{ textTransform: "uppercase", letterSpacing: lang === "ar" ? 0 : ".1em" }}>{t.continueReading}</div>
              <div className="title-m" style={{ marginTop: 4, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{cont.title}</div>
              <div className="label-s muted" style={{ marginTop: 2 }}>{cont.author}</div>
              <div className="label-s muted" style={{ marginTop: 8 }}>{t.page} {Math.round(cont.pages * cont.progress)} {t.of} {cont.pages} · {minsLeft(cont)} {t.minLeft}</div>
            </div>
            <Ring value={cont.progress} />
          </div>
        )}

        <div className="pad" style={{ marginTop: 16 }}>
          <label className="field">
            <Icon name="search" size={20} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.searchLibrary} aria-label={t.search} />
            {q && <button onClick={() => setQ("")} aria-label={t.clear}><Icon name="close" size={18} /></button>}
          </label>
        </div>
        <div className="chips" style={{ marginTop: 12 }}>
          {cats.map(([id, l]) => <button key={id} className={`chip ${cat === id ? "on" : ""}`} onClick={() => { haptic(); setCat(id); }}>{cat === id && <Icon name="check" size={14} stroke={2.2} />}{l}</button>)}
        </div>
        <div className="row between pad" style={{ margin: "14px 0 10px" }}>
          <span className="label-l muted">{results.length} {t.items}</span>
          <button className="row label-l gold" style={{ gap: 4 }} onClick={() => setSortOpen(true)}><Icon name="sort" size={18} />{sorts.find((s) => s[0] === sort)![1]}</button>
        </div>

        {refreshing ? (
          <div className="grid">{Array.from({ length: 6 }).map((_, i) => <div key={i}><div className="skel" style={{ aspectRatio: "2/3" }} /><div className="skel" style={{ height: 10, marginTop: 8, width: "80%" }} /><div className="skel" style={{ height: 8, marginTop: 6, width: "50%" }} /></div>)}</div>
        ) : results.length === 0 ? (
          <div className="empty enter"><EmptyArt /><div className="title-m" style={{ color: "var(--c-on-surface)" }}>{t.noResults}</div><p style={{ margin: "6px 0 16px" }}>{t.noResultsBody}</p><button className="btn ghost sm" onClick={() => { setQ(""); setCat("all"); }}>{t.clear}</button></div>
        ) : view === "grid" ? (
          <div className="grid">
            {results.map(({ b, inContent }, i) => (
              <div key={b.id} className="g-item enter" style={{ animationDelay: `${Math.min(i, 9) * 30}ms` }} {...itemProps(b)}>
                <Cover book={b} width={104} style={{ width: "100%", height: "auto", aspectRatio: "2/3" }} />
                {b.fav && <span className="fav-dot"><Icon name="heart" size={14} stroke={2.2} /></span>}
                <div className="g-title">{b.title}</div>
                <div className="g-meta">{inContent ? `“${q}” · ${t.text}` : b.progress >= 1 ? "✓ " + t.done : `${b.format} · ${b.pages} ${t.pages}`}</div>
                {b.progress > 0 && b.progress < 1 && <div className="pbar"><i style={{ width: `${b.progress * 100}%` }} /></div>}
              </div>
            ))}
          </div>
        ) : (
          <div>
            {results.map(({ b }, i) => (
              <div key={b.id} className="l-item enter" style={{ animationDelay: `${Math.min(i, 9) * 25}ms`, padding: view === "compact" ? "6px 16px" : undefined }} {...itemProps(b)}>
                {view === "list" ? <Cover book={b} width={46} /> : <span className="li-icon" style={{ width: 32, height: 32, borderRadius: 8, display: "grid", placeItems: "center", background: "var(--c-surface-high)", color: "var(--c-primary)", font: "600 8px var(--font-ui)" }}>{b.format}</span>}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="title-m" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", fontSize: view === "compact" ? 14 : undefined }}>{b.title}</div>
                  <div className="label-s muted">{b.author} · {b.sizeMB < 1 ? `${Math.round(b.sizeMB * 1024)} KB` : `${b.sizeMB} MB`}{view === "list" ? ` · ${b.pages} ${t.pages}` : ""}</div>
                  {view === "list" && b.progress > 0 && <div className="pbar" style={{ maxWidth: 160 }}><i style={{ width: `${b.progress * 100}%` }} /></div>}
                </div>
                {b.fav && <Icon name="heart" size={16} style={{ color: "var(--c-primary)" }} />}
                <button className="ib" aria-label={t.info} onClick={(e) => { e.stopPropagation(); setMenuBook(b); }}><Icon name="more" size={20} /></button>
              </div>
            ))}
          </div>
        )}
        <div style={{ height: 120 }} />
      </div>
      <BottomNav />

      <Sheet open={sortOpen} onClose={() => setSortOpen(false)} title={t.sortBy}
        actions={<button className="ib" onClick={() => setAsc(!asc)} aria-label="direction"><Icon name="sort" style={{ transform: asc ? "scaleY(-1)" : undefined }} /></button>}>
        {sorts.map(([k, l]) => (
          <button key={k} className="list-item" style={{ padding: "12px 4px" }} onClick={() => { setSort(k); setSortOpen(false); }}>
            <span className="li-text body-l">{l}</span>{sort === k && <Icon name="check" style={{ color: "var(--c-primary)" }} />}
          </button>
        ))}
        <div className="section-title">{t.grid} / {t.list}</div>
        <div className="seg">{(["grid", "list", "compact"] as View[]).map((v) => <button key={v} className={view === v ? "on" : ""} onClick={() => setView(v)}><Icon name={v} size={16} />{t[v]}</button>)}</div>
      </Sheet>

      <Sheet open={!!menuBook && !collPick} onClose={() => setMenuBook(null)}>
        {menuBook && (
          <>
            <div className="row" style={{ marginBottom: 12 }}>
              <Cover book={menuBook} width={60} />
              <div style={{ minWidth: 0 }}>
                <div className="title-m">{menuBook.title}</div>
                <div className="label-s muted">{menuBook.author}</div>
                <div className="label-s muted" style={{ marginTop: 4 }}>{menuBook.format} · {menuBook.pages} {t.pages} · {menuBook.sizeMB} MB</div>
                <div className="row" style={{ gap: 4, marginTop: 6, flexWrap: "wrap" }}>{menuBook.tags.map((tg) => <span key={tg} className="label-s" style={{ padding: "2px 8px", borderRadius: 6, background: "var(--c-surface-high)" }}>#{tg}</span>)}</div>
              </div>
            </div>
            {[
              ["library", t.open, () => { const b = menuBook; setMenuBook(null); open(b); }],
              ["heart", menuBook.fav ? t.unfavorite : t.favorite, () => { updateBook(menuBook.id, { fav: !menuBook.fav }); setMenuBook(null); }],
              ["collections", t.addToCollection, () => setCollPick(true)],
              ["edit", t.edit, () => { const b = menuBook; setMenuBook(null); b.cat === "images" ? push({ name: "image" }) : b.cat === "text" ? push({ name: "text" }) : push({ name: "pdf", bookId: b.id }); }],
              ["share", t.share, async () => { const b = menuBook; setMenuBook(null); try { if (navigator.share) await navigator.share({ title: b.title, text: `${b.title} — ${b.author}` }); else showToast(t.shared); } catch { /* user cancelled */ } }],
              ["widget", t.pin, () => { setMenuBook(null); showToast(t.pinned); }],
              ["trash", t.delete, () => { const id = menuBook.id; updateBook(id, { trashed: true }); setMenuBook(null); showToast(t.movedToTrash, { label: t.undo, run: () => updateBook(id, { trashed: false }) }); }],
            ].map(([ic, l, fn]) => (
              <button key={l as string} className="list-item" style={{ padding: "10px 4px", color: ic === "trash" ? "var(--c-error)" : undefined }} onClick={fn as () => void}>
                <span className="li-icon" style={ic === "trash" ? { color: "var(--c-error)" } : undefined}><Icon name={ic as string} size={20} /></span><span className="li-text body-l">{l as string}</span>
              </button>
            ))}
          </>
        )}
      </Sheet>

      <Sheet open={collPick} onClose={() => { setCollPick(false); setMenuBook(null); }} title={t.addToCollection}>
        {collections.map((c) => {
          const inIt = menuBook?.collections.includes(c.id);
          return (
            <button key={c.id} className="list-item" style={{ padding: "12px 4px" }} onClick={() => {
              if (!menuBook) return;
              updateBook(menuBook.id, { collections: inIt ? menuBook.collections.filter((x) => x !== c.id) : [...menuBook.collections, c.id] });
              if (!inIt) showToast(`${t.addedTo} ${c.name}`);
              setCollPick(false); setMenuBook(null);
            }}>
              <span style={{ width: 12, height: 12, borderRadius: 6, background: c.color }} /><span className="li-text body-l">{c.name}</span>{inIt && <Icon name="check" style={{ color: "var(--c-primary)" }} />}
            </button>
          );
        })}
      </Sheet>

      <PasswordDialog book={lockBook} onClose={() => setLockBook(null)} onOk={() => { const b = lockBook!; setLockBook(null); push({ name: "reader", bookId: b.id }); }} />
    </div>
  );
}
