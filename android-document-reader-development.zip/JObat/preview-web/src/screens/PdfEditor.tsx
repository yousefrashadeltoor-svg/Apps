import { useEffect, useRef, useState } from "react";
import { IconBtn, Sheet } from "../components";
import { CONTENT } from "../data";
import { Icon } from "../icons";
import { useApp } from "../store";

type Tool = "select" | "pen" | "hl" | "eraser" | "rect" | "circle" | "arrow" | "line" | "text" | "note" | "sign" | "stamp" | "form";
interface Anno { id: string; type: Exclude<Tool, "select" | "eraser" | "form">; pts?: [number, number][]; x: number; y: number; x2?: number; y2?: number; color: string; w: number; text?: string; d?: string; dx: number; dy: number }
interface PageItem { id: string; rot: number; blank: boolean; src: number }

const W = 320, H = 452;
const COLORS = ["#1C1C1C", "#C0392B", "#2E6FD8", "#2E9E5B", "#D4B26A", "#8E44AD"];
const HL_COLORS = ["#F7E26B", "#9BE59B", "#8FD3FF", "#FFB3C7"];

function ptsToPath(pts: [number, number][]) {
  if (pts.length < 2) return pts.length ? `M${pts[0][0]} ${pts[0][1]}l.1 .1` : "";
  let d = `M${pts[0][0]} ${pts[0][1]}`;
  for (let i = 1; i < pts.length - 1; i++) {
    const [x1, y1] = pts[i], [x2, y2] = pts[i + 1];
    d += ` Q${x1} ${y1} ${(x1 + x2) / 2} ${(y1 + y2) / 2}`;
  }
  const l = pts[pts.length - 1];
  return d + ` L${l[0]} ${l[1]}`;
}

function SignaturePad({ onSave }: { onSave: (d: string) => void }) {
  const { t } = useApp();
  const ref = useRef<HTMLCanvasElement>(null);
  const strokes = useRef<[number, number][][]>([]);
  const drawing = useRef(false);
  const redraw = () => {
    const c = ref.current!; const g = c.getContext("2d")!;
    g.clearRect(0, 0, c.width, c.height);
    g.strokeStyle = "#1B2A4A"; g.lineWidth = 2.6; g.lineCap = "round"; g.lineJoin = "round";
    strokes.current.forEach((s) => { const p = new Path2D(ptsToPath(s)); g.stroke(p); });
  };
  useEffect(() => { const c = ref.current!; c.width = 300; c.height = 160; }, []);
  const pos = (e: React.PointerEvent): [number, number] => { const r = ref.current!.getBoundingClientRect(); return [Math.round(((e.clientX - r.left) / r.width) * 300), Math.round(((e.clientY - r.top) / r.height) * 160)]; };
  return (
    <div>
      <canvas ref={ref} className="sigpad"
        onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); drawing.current = true; strokes.current.push([pos(e)]); redraw(); }}
        onPointerMove={(e) => { if (!drawing.current) return; strokes.current[strokes.current.length - 1].push(pos(e)); redraw(); }}
        onPointerUp={() => (drawing.current = false)} />
      <div className="label-s muted" style={{ textAlign: "center", marginTop: 6 }}>{t.signHere}</div>
      <div className="row" style={{ marginTop: 12, gap: 8 }}>
        <button className="btn ghost" style={{ flex: 1 }} onClick={() => { strokes.current = []; redraw(); }}>{t.clearPad}</button>
        <button className="btn" style={{ flex: 1 }} onClick={() => { if (strokes.current.length) onSave(strokes.current.map(ptsToPath).join(" ")); }}>{t.useSignature}</button>
      </div>
    </div>
  );
}

export function PdfEditor({ bookId }: { bookId?: string }) {
  const { t, pop, showToast, signatures, addSignature, books, download, haptic } = useApp();
  const book = books.find((b) => b.id === bookId) ?? books.find((b) => b.id === "b4")!;
  const content = CONTENT.report;
  const [pages, setPages] = useState<PageItem[]>(() => [0, 1, 2, 3].map((i) => ({ id: `p${i}`, rot: 0, blank: false, src: i })));
  const [cur, setCur] = useState(0);
  const [annos, setAnnos] = useState<Record<string, Anno[]>>({});
  const [undo, setUndo] = useState<Record<string, Anno[]>[]>([]);
  const [redo, setRedo] = useState<Record<string, Anno[]>[]>([]);
  const [tool, setTool] = useState<Tool>("pen");
  const [color, setColor] = useState(COLORS[2]);
  const [hlColor, setHlColor] = useState(HL_COLORS[0]);
  const [width, setWidth] = useState(2.2);
  const [stamp, setStamp] = useState<"approved" | "confidential" | "draft" | "paid">("approved");
  const [sigIdx, setSigIdx] = useState(0);
  const [draft, setDraft] = useState<Anno | null>(null);
  const [textAt, setTextAt] = useState<{ x: number; y: number; type: "text" | "note"; edit?: string } | null>(null);
  const [textVal, setTextVal] = useState("");
  const [sheet, setSheet] = useState<null | "pages" | "sign">(null);
  const [zoom, setZoom] = useState(1);
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [overIdx, setOverIdx] = useState<number | null>(null);
  const [selected, setSelected] = useState<number[]>([]);
  const [form, setForm] = useState({ name: "", date: "", agree: false });
  const moving = useRef<{ id: string; sx: number; sy: number; dx: number; dy: number; snap: Record<string, Anno[]> } | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const erasing = useRef(false);

  const page = pages[cur];
  const list = annos[page?.id] ?? [];
  const commit = (next: Record<string, Anno[]>) => { setUndo((u) => [...u, annos]); setRedo([]); setAnnos(next); };
  const setList = (l: Anno[]) => commit({ ...annos, [page.id]: l });
  const doUndo = () => { if (!undo.length) return; setRedo((r) => [annos, ...r]); setAnnos(undo[undo.length - 1]); setUndo((u) => u.slice(0, -1)); haptic(); };
  const doRedo = () => { if (!redo.length) return; setUndo((u) => [...u, annos]); setAnnos(redo[0]); setRedo((r) => r.slice(1)); haptic(); };

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === "INPUT" || (e.target as HTMLElement).tagName === "TEXTAREA") return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); e.shiftKey ? doRedo() : doUndo(); }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") { e.preventDefault(); doRedo(); }
    };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  });

  const pt = (e: React.PointerEvent): [number, number] => {
    const r = svgRef.current!.getBoundingClientRect();
    let x = ((e.clientX - r.left) / r.width) * W, y = ((e.clientY - r.top) / r.height) * H;
    const rot = ((page.rot % 360) + 360) % 360;
    if (rot === 90) [x, y] = [((e.clientY - r.top) / r.height) * W, H - ((e.clientX - r.left) / r.width) * H];
    if (rot === 180) [x, y] = [W - x, H - y];
    if (rot === 270) [x, y] = [W - ((e.clientY - r.top) / r.height) * W, ((e.clientX - r.left) / r.width) * H];
    return [Math.round(x * 10) / 10, Math.round(y * 10) / 10];
  };

  const down = (e: React.PointerEvent) => {
    const [x, y] = pt(e);
    const id = `a${Date.now()}`;
    if (tool === "eraser") { erasing.current = true; return; }
    if (tool === "select" || tool === "form") return;
    (e.target as Element).setPointerCapture?.(e.pointerId);
    if (tool === "pen" || tool === "hl") setDraft({ id, type: tool, pts: [[x, y]], x, y, color: tool === "hl" ? hlColor : color, w: tool === "hl" ? 11 : width, dx: 0, dy: 0 });
    else if (["rect", "circle", "arrow", "line"].includes(tool)) setDraft({ id, type: tool as Anno["type"], x, y, x2: x, y2: y, color, w: width, dx: 0, dy: 0 });
    else if (tool === "text" || tool === "note") { setTextAt({ x, y, type: tool }); setTextVal(""); }
    else if (tool === "sign") { if (!signatures.length) { setSheet("sign"); return; } setList([...list, { id, type: "sign", x: x - 45, y: y - 24, color: "#1B2A4A", w: 1, d: signatures[sigIdx], dx: 0, dy: 0 }]); }
    else if (tool === "stamp") setList([...list, { id, type: "stamp", x: x - 50, y: y - 16, color: stamp === "approved" || stamp === "paid" ? "#2E9E5B" : "#C0392B", w: 1, text: t[stamp], dx: 0, dy: 0 }]);
  };
  const move = (e: React.PointerEvent) => {
    if (moving.current) {
      const [x, y] = pt(e); const m = moving.current;
      setAnnos((a) => ({ ...a, [page.id]: (a[page.id] ?? []).map((an) => (an.id === m.id ? { ...an, dx: m.dx + x - m.sx, dy: m.dy + y - m.sy } : an)) }));
      return;
    }
    if (!draft) return;
    const [x, y] = pt(e);
    if (draft.pts) setDraft({ ...draft, pts: draft.type === "hl" && draft.pts.length > 1 ? [draft.pts[0], [x, draft.pts[0][1] + (y - draft.pts[0][1]) * 0.15]] : [...draft.pts, [x, y]] });
    else setDraft({ ...draft, x2: x, y2: y });
  };
  const up = () => {
    erasing.current = false;
    if (moving.current) { const snap = moving.current.snap; moving.current = null; setUndo((u) => [...u, snap]); setRedo([]); return; }
    if (draft) { const ok = draft.pts ? draft.pts.length > 1 : Math.hypot((draft.x2 ?? 0) - draft.x, (draft.y2 ?? 0) - draft.y) > 4; if (ok) setList([...list, draft]); setDraft(null); }
  };
  const annoDown = (a: Anno) => (e: React.PointerEvent) => {
    if (tool === "eraser") { e.stopPropagation(); erasing.current = true; setList(list.filter((x) => x.id !== a.id)); haptic(); return; }
    if (tool === "select") { e.stopPropagation(); const [x, y] = pt(e); moving.current = { id: a.id, sx: x, sy: y, dx: a.dx, dy: a.dy, snap: annos }; (e.target as Element).setPointerCapture?.(e.pointerId); }
    if (a.type === "note" && tool !== "select") { e.stopPropagation(); setTextAt({ x: a.x, y: a.y, type: "note", edit: a.id }); setTextVal(a.text ?? ""); }
  };
  const annoEnter = (a: Anno) => () => { if (tool === "eraser" && erasing.current) setList(list.filter((x) => x.id !== a.id)); };

  const renderAnno = (a: Anno) => {
    const common = { onPointerDown: annoDown(a), onPointerEnter: annoEnter(a), style: { cursor: tool === "select" ? "move" : tool === "eraser" ? "not-allowed" : undefined } as React.CSSProperties };
    const tr = `translate(${a.dx} ${a.dy})`;
    switch (a.type) {
      case "pen": return <path key={a.id} {...common} transform={tr} d={ptsToPath(a.pts!)} stroke={a.color} strokeWidth={a.w} fill="none" strokeLinecap="round" strokeLinejoin="round" />;
      case "hl": return <path key={a.id} {...common} transform={tr} d={ptsToPath(a.pts!)} stroke={a.color} strokeWidth={a.w} fill="none" strokeLinecap="butt" opacity={0.45} style={{ ...common.style, mixBlendMode: "multiply" }} />;
      case "rect": return <rect key={a.id} {...common} transform={tr} x={Math.min(a.x, a.x2!)} y={Math.min(a.y, a.y2!)} width={Math.abs(a.x2! - a.x)} height={Math.abs(a.y2! - a.y)} stroke={a.color} strokeWidth={a.w} fill="transparent" rx={2} />;
      case "circle": return <ellipse key={a.id} {...common} transform={tr} cx={(a.x + a.x2!) / 2} cy={(a.y + a.y2!) / 2} rx={Math.abs(a.x2! - a.x) / 2} ry={Math.abs(a.y2! - a.y) / 2} stroke={a.color} strokeWidth={a.w} fill="transparent" />;
      case "line": return <line key={a.id} {...common} transform={tr} x1={a.x} y1={a.y} x2={a.x2} y2={a.y2} stroke={a.color} strokeWidth={a.w} strokeLinecap="round" />;
      case "arrow": {
        const ang = Math.atan2(a.y2! - a.y, a.x2! - a.x), L = 8 + a.w * 2;
        const p1 = [a.x2! - L * Math.cos(ang - 0.45), a.y2! - L * Math.sin(ang - 0.45)], p2 = [a.x2! - L * Math.cos(ang + 0.45), a.y2! - L * Math.sin(ang + 0.45)];
        return <g key={a.id} {...common} transform={tr}><line x1={a.x} y1={a.y} x2={a.x2} y2={a.y2} stroke={a.color} strokeWidth={a.w} strokeLinecap="round" /><path d={`M${p1} L${a.x2} ${a.y2} L${p2}`} stroke={a.color} strokeWidth={a.w} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>;
      }
      case "text": return <text key={a.id} {...common} transform={tr} x={a.x} y={a.y} fill={a.color} fontSize={8 + a.w * 1.5} fontFamily="Inter, 'IBM Plex Sans Arabic'" fontWeight={500}>{a.text}</text>;
      case "note": return <g key={a.id} {...common} transform={tr}><rect x={a.x - 9} y={a.y - 9} width={18} height={18} rx={3} fill="#F7E26B" stroke="#C9A825" /><path d={`M${a.x - 4} ${a.y - 3}h8M${a.x - 4} ${a.y + 1}h8M${a.x - 4} ${a.y + 5}h5`} stroke="#7a6610" strokeWidth={1} /></g>;
      case "sign": return <g key={a.id} {...common} transform={`${tr} translate(${a.x} ${a.y}) scale(.3)`}><rect width={300} height={160} fill="transparent" /><path d={a.d} stroke={a.color} strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>;
      case "stamp": return <g key={a.id} {...common} transform={`${tr} rotate(-8 ${a.x + 50} ${a.y + 16})`}><rect x={a.x} y={a.y} width={100} height={32} rx={5} fill="transparent" stroke={a.color} strokeWidth={2} /><rect x={a.x + 3} y={a.y + 3} width={94} height={26} rx={3} fill="transparent" stroke={a.color} strokeWidth={0.6} /><text x={a.x + 50} y={a.y + 21} textAnchor="middle" fill={a.color} fontSize={12} fontWeight={700} fontFamily="Inter, 'IBM Plex Sans Arabic'" letterSpacing={1.5}>{a.text}</text><text x={a.x + 50} y={a.y + 29} textAnchor="middle" fill={a.color} fontSize={4} fontFamily="Inter">{new Date().toLocaleDateString()}</text></g>;
    }
  };

  const confirmText = () => {
    if (!textAt) return;
    if (textAt.edit) { setList(textVal ? list.map((a) => (a.id === textAt.edit ? { ...a, text: textVal } : a)) : list.filter((a) => a.id !== textAt.edit)); }
    else if (textVal.trim()) setList([...list, { id: `a${Date.now()}`, type: textAt.type, x: textAt.x, y: textAt.y, color, w: width, text: textVal, dx: 0, dy: 0 }]);
    setTextAt(null);
  };

  const exportXfdf = () => {
    const esc = (s: string) => s.replace(/[<&"]/g, (c) => ({ "<": "&lt;", "&": "&amp;", '"': "&quot;" })[c]!);
    const items = pages.flatMap((p, pi) => (annos[p.id] ?? []).map((a) => {
      const bx = (a.x + a.dx).toFixed(1), by = (H - a.y - a.dy).toFixed(1);
      const map: Record<string, string> = { pen: "ink", hl: "highlight", rect: "square", circle: "circle", line: "line", arrow: "line", text: "freetext", note: "text", sign: "ink", stamp: "stamp" };
      return `    <${map[a.type]} page="${pi}" color="${a.color}" width="${a.w}" rect="${bx},${by},${bx},${by}" name="${a.id}"${a.text ? ` subject="${esc(a.text)}"` : ""}>${a.pts ? `<inklist><gesture>${a.pts.map(([x, y]) => `${(x + a.dx).toFixed(1)},${(H - y - a.dy).toFixed(1)}`).join(";")}</gesture></inklist>` : ""}${a.text ? `<contents>${esc(a.text)}</contents>` : ""}</${map[a.type]}>`;
    }));
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<xfdf xmlns="http://ns.adobe.com/xfdf/" xml:space="preserve">\n  <f href="${esc(book.title)}.pdf"/>\n  <fields>\n    <field name="full_name"><value>${esc(form.name)}</value></field>\n    <field name="date"><value>${esc(form.date)}</value></field>\n    <field name="agree"><value>${form.agree ? "Yes" : "Off"}</value></field>\n  </fields>\n  <annots>\n${items.join("\n")}\n  </annots>\n</xfdf>\n`;
    download(`${book.title} (annotated).xfdf`, xml, "application/vnd.adobe.xfdf");
    showToast(t.savedCopy);
  };

  // ---- page management ----
  const reorder = (from: number, to: number) => {
    if (from === to) return;
    const curId = pages[cur].id;
    const n = [...pages]; const [m] = n.splice(from, 1); n.splice(to, 0, m);
    setPages(n); setCur(n.findIndex((p) => p.id === curId)); haptic();
  };
  const targets = selected.length ? selected : [cur];
  const pageOp = (op: "rotate" | "delete" | "dup" | "blank" | "extract") => {
    if (op === "rotate") setPages(pages.map((p, i) => (targets.includes(i) ? { ...p, rot: p.rot + 90 } : p)));
    if (op === "delete") { if (pages.length - targets.length < 1) return; const n = pages.filter((_, i) => !targets.includes(i)); setPages(n); setCur(Math.min(cur, n.length - 1)); setSelected([]); showToast(`${targets.length} ✕`); }
    if (op === "dup") { const n = [...pages]; targets.slice().sort((a, b) => b - a).forEach((i) => n.splice(i + 1, 0, { ...pages[i], id: `p${Date.now()}${i}` })); setPages(n); }
    if (op === "blank") { const n = [...pages]; n.splice(cur + 1, 0, { id: `p${Date.now()}`, rot: 0, blank: true, src: -1 }); setPages(n); }
    if (op === "extract") { showToast(`${t.extract}: ${targets.map((i) => i + 1).join(", ")} → ${t.outputSaved}`); }
  };

  const drawTools: [Tool, string, string][] = [["select", "edit", t.tSelect], ["pen", "pen", t.tPen], ["hl", "marker", t.tHighlighter], ["eraser", "eraser", t.tEraser], ["rect", "rect", t.tRect], ["circle", "circle", t.tCircle], ["arrow", "arrow", t.tArrow], ["line", "line", t.tLine], ["text", "text", t.tText], ["note", "note", t.tNote], ["sign", "sign", t.tSign], ["stamp", "stamp", t.tStamp], ["form", "check", t.tForm]];
  const pageContent = (p: PageItem, small = false) => p.blank ? null : (
    <div className="pc" style={small ? { fontSize: 2.2, padding: 6 } : undefined}>
      {p.src === 0 && <><h2 style={small ? { fontSize: 4 } : undefined}>{book.title}</h2><div style={{ color: "#7a7466", marginBottom: 8 }}>{book.author} · FY2025</div></>}
      {(content[p.src % content.length]?.paras ?? []).concat(content[(p.src + 1) % content.length].paras).map((para, i) => (<div key={i}>{i === 0 && <h3>{content[p.src % content.length].title}</h3>}<p>{para}</p></div>))}
    </div>
  );

  return (
    <div className="view" style={{ background: "var(--c-surface)" }}>
      <div style={{ height: 44 }} />
      <div className="top">
        <IconBtn name="back" label={t.cancel} onClick={pop} className="flip-rtl" />
        <div className="grow"><div className="title-m" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.pdfEditor}</div><div className="label-s muted">{book.title} · {t.page} {cur + 1}/{pages.length}</div></div>
        <IconBtn name="undo" label={t.undo} onClick={doUndo} disabled={!undo.length} />
        <IconBtn name="redo" label="Redo" onClick={doRedo} disabled={!redo.length} />
        <IconBtn name="pages" label={t.pagesMgr} onClick={() => setSheet("pages")} />
        <IconBtn name="save" label={t.save} onClick={() => showToast(t.saved, { label: t.saveCopy, run: exportXfdf })} />
      </div>
      <div className="pdf-canvas-wrap">
        <div className="pdf-page" style={{ transform: `scale(${zoom}) rotate(${page.rot}deg)`, transformOrigin: "top center", margin: page.rot % 180 ? "60px 0" : undefined }}>
          {pageContent(page)}
          {page.src === 0 && (
            <>
              <input className="form-field" style={{ left: 24, top: 360, width: 130, boxShadow: tool === "form" ? "0 0 0 2px #D4B26A" : undefined }} placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <input className="form-field" type="date" style={{ left: 170, top: 360, width: 120, boxShadow: tool === "form" ? "0 0 0 2px #D4B26A" : undefined }} value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              <label style={{ position: "absolute", left: 24, top: 384, font: "500 7px Inter", color: "#1C1C1C", display: "flex", gap: 4, alignItems: "center" }}><input type="checkbox" className="form-check" style={{ position: "static" }} checked={form.agree} onChange={(e) => setForm({ ...form, agree: e.target.checked })} />I agree to the terms</label>
              <div style={{ position: "absolute", left: 170, top: 392, width: 120, borderTop: "1px solid #999", font: "500 6px Inter", color: "#7a7466", paddingTop: 2 }}>Signature</div>
            </>
          )}
          <svg ref={svgRef} className="anno" viewBox={`0 0 ${W} ${H}`} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerLeave={up}
            style={{ pointerEvents: tool === "form" ? "none" : "auto", cursor: tool === "select" ? "default" : tool === "text" ? "text" : "crosshair" }}>
            {list.map(renderAnno)}
            {draft && renderAnno(draft)}
          </svg>
        </div>
      </div>

      {(["pen", "rect", "circle", "arrow", "line", "text"] as Tool[]).includes(tool) && (
        <div className="subrail">
          {COLORS.map((c) => <button key={c} className={`swatch ${color === c ? "on" : ""}`} style={{ background: c }} onClick={() => setColor(c)} aria-label={c} />)}
          <input className="range" type="range" min={0.8} max={6} step={0.2} value={width} onChange={(e) => setWidth(+e.target.value)} aria-label={t.thickness} style={{ flex: 1 }} />
          <span style={{ width: 20, height: 20, display: "grid", placeItems: "center" }}><i style={{ width: width * 2.4, height: width * 2.4, borderRadius: 99, background: color, display: "block" }} /></span>
        </div>
      )}
      {tool === "hl" && <div className="subrail">{HL_COLORS.map((c) => <button key={c} className={`swatch ${hlColor === c ? "on" : ""}`} style={{ background: c }} onClick={() => setHlColor(c)} />)}<span className="label-s muted">{t.tHighlighter}</span></div>}
      {tool === "stamp" && <div className="subrail" style={{ overflowX: "auto" }}>{(["approved", "confidential", "draft", "paid"] as const).map((s) => <button key={s} className={`chip ${stamp === s ? "on" : ""}`} onClick={() => setStamp(s)}>{t[s]}</button>)}</div>}
      {tool === "sign" && (
        <div className="subrail" style={{ overflowX: "auto" }}>
          {signatures.map((d, i) => <button key={i} onClick={() => setSigIdx(i)} style={{ background: "#FFFCF6", borderRadius: 8, border: `2px solid ${sigIdx === i ? "var(--c-primary)" : "transparent"}`, flexShrink: 0 }}><svg width="72" height="38" viewBox="0 0 300 160"><path d={d} stroke="#1B2A4A" strokeWidth="7" fill="none" strokeLinecap="round" /></svg></button>)}
          <button className="chip" onClick={() => setSheet("sign")}><Icon name="plus" size={16} />{t.tSign}</button>
        </div>
      )}
      <div className="row" style={{ position: "absolute", insetInlineEnd: 12, bottom: 150, flexDirection: "column", gap: 6, zIndex: 4 }}>
        <button className="ib" style={{ background: "var(--c-surface)", boxShadow: "var(--elev-2)" }} onClick={() => setZoom(Math.min(2, zoom + 0.2))} aria-label="zoom in"><Icon name="plus" size={18} /></button>
        <button className="ib" style={{ background: "var(--c-surface)", boxShadow: "var(--elev-2)" }} onClick={() => setZoom(Math.max(0.6, zoom - 0.2))} aria-label="zoom out"><Icon name="line" size={18} style={{ transform: "rotate(45deg)" }} /></button>
      </div>
      <div className="toolrail" style={{ paddingBottom: 26 }}>
        {drawTools.map(([id, ic, l]) => <button key={id} className={`tool ${tool === id ? "on" : ""}`} onClick={() => { haptic(); setTool(id); if (id === "sign" && !signatures.length) setSheet("sign"); }}><Icon name={ic} size={20} />{l}</button>)}
      </div>

      {textAt && (
        <>
          <div className="scrim" onClick={() => setTextAt(null)} />
          <div className="dialog">
            <div className="title-m" style={{ marginBottom: 12 }}>{textAt.type === "note" ? t.tNote : t.tText}</div>
            <textarea className="input" style={{ height: 90, padding: 10, resize: "none" }} autoFocus value={textVal} onChange={(e) => setTextVal(e.target.value)} placeholder={t.typeText} />
            <div className="row" style={{ justifyContent: "flex-end", gap: 8, marginTop: 12 }}>
              <button className="btn ghost sm" onClick={() => setTextAt(null)}>{t.cancel}</button>
              <button className="btn sm" onClick={confirmText}>{t.save}</button>
            </div>
          </div>
        </>
      )}

      <Sheet open={sheet === "sign"} onClose={() => setSheet(null)} title={t.tSign}>
        <SignaturePad onSave={(d) => { addSignature(d); setSigIdx(0); setTool("sign"); setSheet(null); showToast(t.savedSignatures + " ✓"); }} />
      </Sheet>

      <Sheet open={sheet === "pages"} onClose={() => { setSheet(null); setSelected([]); }} title={`${t.pagesMgr} · ${pages.length}`}>
        <div className="label-s muted" style={{ marginBottom: 10 }}>{t.dragReorder}</div>
        <div className="thumbs">
          {pages.map((p, i) => (
            <div key={p.id} draggable className={`thumb ${selected.includes(i) || (selected.length === 0 && i === cur) ? "sel" : ""} ${dragIdx === i ? "dragging" : ""} ${overIdx === i && dragIdx !== i ? "over" : ""}`}
              onDragStart={() => setDragIdx(i)} onDragOver={(e) => { e.preventDefault(); setOverIdx(i); }} onDragEnd={() => { setDragIdx(null); setOverIdx(null); }}
              onDrop={() => { if (dragIdx != null) reorder(dragIdx, i); setDragIdx(null); setOverIdx(null); }}
              onClick={(e) => { if (e.shiftKey || e.metaKey || selected.length) setSelected(selected.includes(i) ? selected.filter((x) => x !== i) : [...selected, i]); else { setCur(i); setSheet(null); } }}
              onContextMenu={(e) => { e.preventDefault(); setSelected(selected.includes(i) ? selected.filter((x) => x !== i) : [...selected, i]); }}
              style={{ transform: `rotate(${p.rot}deg) scale(${p.rot % 180 ? 0.72 : 1})` }}>
              {!p.blank && <div className="tl" />}
              {(annos[p.id]?.length ?? 0) > 0 && <span style={{ position: "absolute", top: 4, insetInlineEnd: 4, width: 8, height: 8, borderRadius: 4, background: "var(--c-primary)" }} />}
              <span className="tn" style={{ transform: `translateX(-50%) rotate(${-p.rot}deg)` }}>{i + 1}</span>
            </div>
          ))}
        </div>
        <div className="row" style={{ marginTop: 10, gap: 4 }}>
          <IconBtn name="back" label="←" onClick={() => cur > 0 && reorder(cur, cur - 1)} className="flip-rtl" />
          <span className="label-s muted" style={{ flex: 1, textAlign: "center" }}>{selected.length ? `${selected.length} ✓` : `${t.page} ${cur + 1}`}</span>
          <IconBtn name="back" label="→" onClick={() => cur < pages.length - 1 && reorder(cur, cur + 1)} className={document.querySelector(".app")?.getAttribute("dir") === "rtl" ? "" : "flip-rtl"} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 6, marginTop: 8 }}>
          {([["rotate", "rotate", t.rotate], ["dup", "copy", t.duplicate], ["blank", "plus", t.insertBlank], ["extract", "download", t.extract], ["delete", "trash", t.delete.split(" ")[0]]] as const).map(([op, ic, l]) => (
            <button key={op} className="tool" style={{ minWidth: 0, color: op === "delete" ? "var(--c-error)" : undefined }} onClick={() => pageOp(op)}><Icon name={ic} size={20} />{l}</button>
          ))}
        </div>
      </Sheet>
    </div>
  );
}
