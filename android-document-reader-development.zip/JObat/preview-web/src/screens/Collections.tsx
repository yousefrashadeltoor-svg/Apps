import { useState } from "react";
import { BottomNav, Cover, Dialog, EmptyArt, Sheet } from "../components";
import type { Book, Quote } from "../data";
import { Icon } from "../icons";
import { useApp } from "../store";
import { openBook } from "./Library";

function drawQuoteCard(q: Quote, book: Book | undefined): Promise<Blob | null> {
  const c = document.createElement("canvas"); c.width = 1080; c.height = 1350; const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(860, 0, 50, 860, 0, 1300); grd.addColorStop(0, "#2A2418"); grd.addColorStop(0.7, "#0B0C10"); g.fillStyle = grd; g.fillRect(0, 0, c.width, c.height);
  g.strokeStyle = "rgba(212,178,106,.35)"; g.lineWidth = 2; g.strokeRect(48, 48, c.width - 96, c.height - 96);
  const rtl = /[\u0600-\u06FF]/.test(q.text);
  g.fillStyle = "#D4B26A"; g.font = "600 220px 'Cormorant Garamond', serif"; g.textAlign = rtl ? "right" : "left"; g.fillText("“", rtl ? c.width - 110 : 110, 330);
  g.fillStyle = "#ECE7DC"; g.font = `${rtl ? "400 58px Amiri" : "500 62px 'Cormorant Garamond'"}, serif`; g.direction = rtl ? "rtl" : "ltr";
  const words = q.text.split(" "); const lines: string[] = []; let line = "";
  words.forEach((w) => { const test = line ? `${line} ${w}` : w; if (g.measureText(test).width > c.width - 240) { lines.push(line); line = w; } else line = test; }); if (line) lines.push(line);
  const lh = rtl ? 96 : 84; let y = 430; lines.slice(0, 9).forEach((l) => { g.fillText(l, rtl ? c.width - 120 : 120, y); y += lh; });
  g.fillStyle = "#D4B26A"; g.fillRect(rtl ? c.width - 200 : 120, y + 30, 80, 3);
  g.fillStyle = "#9A9AA3"; g.font = `500 34px ${rtl ? "'IBM Plex Sans Arabic'" : "Inter"}, sans-serif`; g.fillText(`${book?.title ?? ""} — ${book?.author ?? ""}`, rtl ? c.width - 120 : 120, y + 100);
  g.direction = "ltr"; g.textAlign = "right"; g.fillStyle = "#D4B26A"; g.font = "italic 600 44px 'Cormorant Garamond', serif"; g.fillText("𝒥𝒪 bat", c.width - 100, c.height - 100);
  return new Promise((r) => c.toBlob(r, "image/png"));
}

export function Collections() {
  const { t, books, collections, addCollection, push, updateBook, quotes, removeQuote, download, showToast, lang } = useApp();
  const [tab, setTab] = useState<"coll" | "quotes">("coll");
  const [openColl, setOpenColl] = useState<{ title: string; list: Book[]; trash?: boolean } | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [name, setName] = useState("");
  const [cardQuote, setCardQuote] = useState<Quote | null>(null);
  const live = books.filter((b) => !b.trashed);
  const tags = Array.from(new Set(live.flatMap((b) => b.tags)));
  const bookOf = (id: string) => books.find((b) => b.id === id);

  const exportQuotes = (fmt: "md" | "txt") => {
    const grouped = new Map<string, Quote[]>(); quotes.forEach((q) => grouped.set(q.bookId, [...(grouped.get(q.bookId) ?? []), q]));
    let out = fmt === "md" ? `# ${t.quotes}\n\n` : `${t.quotes.toUpperCase()}\n\n`;
    grouped.forEach((qs, id) => {
      const b = bookOf(id);
      out += fmt === "md" ? `## ${b?.title} — *${b?.author}*\n\n` : `${b?.title} — ${b?.author}\n${"-".repeat(40)}\n`;
      qs.forEach((q) => { out += fmt === "md" ? `> ${q.text}\n>\n> — ${t.page} ${q.page} · ${q.date}\n${q.note ? `\n📝 ${q.note}\n` : ""}\n` : `"${q.text}" (${t.page} ${q.page}, ${q.date})${q.note ? `\n  Note: ${q.note}` : ""}\n\n`; });
    });
    download(`JObat-quotes.${fmt}`, out, fmt === "md" ? "text/markdown" : "text/plain"); showToast(t.downloaded);
  };

  const smart: { k: string; icon: string; title: string; list: Book[]; trash?: boolean }[] = [
    { k: "fav", icon: "heart", title: t.favorites, list: live.filter((b) => b.fav) },
    { k: "arc", icon: "archive", title: t.archive, list: live.filter((b) => b.archived) },
    { k: "trash", icon: "trash", title: t.trash, list: books.filter((b) => b.trashed), trash: true },
  ];

  return (
    <div className="view">
      <div style={{ height: 44 }} />
      <div className="row between pad" style={{ padding: "8px 16px 12px" }}><h1 className="display-s">{t.collections}</h1>{tab === "coll" && <button className="ib" onClick={() => setNewOpen(true)} aria-label={t.newCollection}><Icon name="plus" /></button>}</div>
      <div className="pad" style={{ marginBottom: 12 }}><div className="seg"><button className={tab === "coll" ? "on" : ""} onClick={() => setTab("coll")}><Icon name="collections" size={16} />{t.collections}</button><button className={tab === "quotes" ? "on" : ""} onClick={() => setTab("quotes")}><Icon name="quote" size={16} />{t.quotes}</button></div></div>
      <div className="scroll">
        {tab === "coll" ? (
          <>
            <div className="pad" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
              {smart.map((s) => (
                <button key={s.k} className="card enter" style={{ padding: 12, textAlign: "start" }} onClick={() => setOpenColl(s)}>
                  <Icon name={s.icon} size={20} style={{ color: s.k === "trash" ? "var(--c-error)" : "var(--c-primary)" }} />
                  <div className="label-l" style={{ marginTop: 8 }}>{s.title}</div><div className="label-s muted">{s.list.length} {t.items}</div>
                </button>
              ))}
            </div>
            <div className="pad" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 16 }}>
              {collections.map((c, i) => {
                const list = live.filter((b) => b.collections.includes(c.id));
                return (
                  <button key={c.id} className="coll-card enter" style={{ animationDelay: `${i * 40}ms` }} onClick={() => setOpenColl({ title: c.name, list })}>
                    <span style={{ position: "absolute", insetInlineEnd: -30, top: -30, width: 100, height: 100, borderRadius: 50, background: c.color, opacity: 0.12 }} />
                    <div className="coll-stack">{list.slice(0, 3).map((b) => <Cover key={b.id} book={b} width={38} />)}{!list.length && <div style={{ height: 57 }} />}</div>
                    <div style={{ marginTop: 12 }}><div className="title-m" style={{ fontSize: 14 }}>{c.name}</div><div className="label-s muted">{list.length} {t.items}</div></div>
                  </button>
                );
              })}
            </div>
            <div className="section-title pad">{t.tags}</div>
            <div className="pad row" style={{ flexWrap: "wrap", gap: 8 }}>
              {tags.map((tg) => <button key={tg} className="chip" onClick={() => setOpenColl({ title: `#${tg}`, list: live.filter((b) => b.tags.includes(tg)) })}><Icon name="tag" size={14} />{tg}</button>)}
            </div>
          </>
        ) : (
          <div className="pad" style={{ display: "grid", gap: 12 }}>
            <div className="row" style={{ gap: 8 }}><button className="btn tonal sm" style={{ flex: 1 }} onClick={() => exportQuotes("md")}><Icon name="download" size={16} />Markdown</button><button className="btn tonal sm" style={{ flex: 1 }} onClick={() => exportQuotes("txt")}><Icon name="download" size={16} />TXT</button></div>
            {quotes.length === 0 && <div className="empty"><EmptyArt /><div>{t.emptyHere}</div></div>}
            {quotes.map((q, i) => {
              const b = bookOf(q.bookId); const rtl = /[\u0600-\u06FF]/.test(q.text);
              return (
                <div key={q.id} className="quote-card enter" style={{ ["--qc" as string]: q.color, animationDelay: `${i * 40}ms` }}>
                  <p dir={rtl ? "rtl" : "ltr"} style={{ margin: 0, font: `400 ${rtl ? 17 : 16}px/1.6 ${rtl ? "Amiri" : "var(--font-reading)"}` }}>“{q.text}”</p>
                  {q.note && <div className="label-l" style={{ marginTop: 8, color: "var(--c-on-surface-variant)" }}>📝 {q.note}</div>}
                  <div className="row between" style={{ marginTop: 10 }}>
                    <span className="label-s muted" style={{ flex: 1, minWidth: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{b?.title} · {t.page} {q.page}</span>
                    <button className="ib" style={{ width: 32, height: 32 }} onClick={() => setCardQuote(q)} aria-label={t.quoteCard}><Icon name="image" size={18} /></button>
                    <button className="ib" style={{ width: 32, height: 32 }} onClick={() => { navigator.clipboard?.writeText(`“${q.text}” — ${b?.title}`); showToast(t.copied); }} aria-label={t.copy}><Icon name="copy" size={18} /></button>
                    <button className="ib" style={{ width: 32, height: 32 }} onClick={() => removeQuote(q.id)} aria-label={t.delete}><Icon name="trash" size={18} /></button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        <div style={{ height: 120 }} />
      </div>
      <BottomNav />

      <Sheet open={!!openColl} onClose={() => setOpenColl(null)} title={openColl?.title}
        actions={openColl?.trash && openColl.list.length ? <button className="label-l" style={{ color: "var(--c-error)" }} onClick={() => { openColl.list.forEach((b) => updateBook(b.id, { trashed: false, archived: true })); setOpenColl(null); showToast(t.emptyTrash + " ✓"); }}>{t.emptyTrash}</button> : undefined}>
        {openColl && (openColl.list.length === 0 ? <div className="empty"><EmptyArt size={96} /><div>{t.emptyHere}</div></div> :
          openColl.list.map((b) => (
            <div key={b.id} className="l-item" style={{ padding: "8px 0" }} onClick={() => { if (!openColl.trash) { setOpenColl(null); openBook(b, push); } }}>
              <Cover book={b} width={40} />
              <div style={{ flex: 1, minWidth: 0 }}><div className="title-m" style={{ fontSize: 14, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{b.title}</div><div className="label-s muted">{b.author}</div></div>
              {openColl.trash && <button className="btn sm ghost" onClick={(e) => { e.stopPropagation(); updateBook(b.id, { trashed: false }); setOpenColl({ ...openColl, list: openColl.list.filter((x) => x.id !== b.id) }); showToast(t.restored); }}>{t.restore}</button>}
              {openColl.title === t.archive && <button className="btn sm ghost" onClick={(e) => { e.stopPropagation(); updateBook(b.id, { archived: false }); setOpenColl({ ...openColl, list: openColl.list.filter((x) => x.id !== b.id) }); showToast(t.restored); }}>{t.restore}</button>}
            </div>
          )))}
      </Sheet>

      <Dialog open={newOpen} onClose={() => setNewOpen(false)}>
        <div className="title-l" style={{ marginBottom: 12 }}>{t.newCollection}</div>
        <input className="input" autoFocus value={name} placeholder={t.name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && name.trim()) { addCollection(name.trim()); setName(""); setNewOpen(false); } }} />
        <div className="row" style={{ justifyContent: "flex-end", gap: 8, marginTop: 16 }}><button className="btn ghost sm" onClick={() => setNewOpen(false)}>{t.cancel}</button><button className="btn sm" disabled={!name.trim()} onClick={() => { addCollection(name.trim()); setName(""); setNewOpen(false); }}>{t.create}</button></div>
      </Dialog>

      <Sheet open={!!cardQuote} onClose={() => setCardQuote(null)} title={t.quoteCard}>
        {cardQuote && (() => { const b = bookOf(cardQuote.bookId); const rtl = /[\u0600-\u06FF]/.test(cardQuote.text); return (
          <>
            <div className="quote-art" dir={rtl ? "rtl" : "ltr"} style={{ width: "78%", margin: "0 auto" }}>
              <div style={{ font: "600 60px/0.6 'Cormorant Garamond'", color: "#D4B26A" }}>“</div>
              <div style={{ font: rtl ? "400 16px/1.7 Amiri" : "500 17px/1.45 'Cormorant Garamond'", flex: 1, marginTop: 12 }}>{cardQuote.text}</div>
              <div><div style={{ width: 28, height: 2, background: "#D4B26A", marginBottom: 8 }} /><div style={{ font: "500 10px/1.3 var(--font-ui)", color: "#9A9AA3" }}>{b?.title} — {b?.author}</div><div style={{ textAlign: "end", font: "italic 600 14px 'Cormorant Garamond'", color: "#D4B26A", direction: "ltr" }}>𝒥𝒪 bat</div></div>
            </div>
            <button className="btn block" style={{ marginTop: 16 }} onClick={async () => { const blob = await drawQuoteCard(cardQuote, b); if (blob) { download("JObat-quote.png", blob); showToast(t.downloaded); } }}><Icon name="download" size={18} />PNG 1080×1350</button>
            <div className="label-s muted" style={{ textAlign: "center", marginTop: 8 }}>{lang === "ar" ? "جاهزة للمشاركة على الشبكات الاجتماعية" : "Ready to share on social media"}</div>
          </>
        ); })()}
      </Sheet>
    </div>
  );
}
