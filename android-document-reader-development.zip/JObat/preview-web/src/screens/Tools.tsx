import { useRef, useState } from "react";
import { BottomNav, Sheet } from "../components";
import { Icon } from "../icons";
import { buildPdf, imageToJpeg, wrapText } from "../pdf";
import { useApp } from "../store";
import type { Strings } from "../i18n";

type ToolId = "merge" | "split" | "compress" | "img2pdf" | "pdf2img" | "txt2pdf" | "protect" | "unlock" | "watermark" | "numbers" | "rotate" | "ocr" | "archives" | "print";
const TOOLS: { id: ToolId; icon: string; key: keyof Strings }[] = [
  { id: "img2pdf", icon: "image", key: "tImg2Pdf" }, { id: "txt2pdf", icon: "text", key: "tTxt2Pdf" },
  { id: "merge", icon: "merge", key: "tMerge" }, { id: "split", icon: "splitI", key: "tSplit" },
  { id: "compress", icon: "compress", key: "tCompress" }, { id: "pdf2img", icon: "pages", key: "tPdf2Img" },
  { id: "protect", icon: "lock", key: "tProtect" }, { id: "unlock", icon: "unlock", key: "tUnlock" },
  { id: "watermark", icon: "drop", key: "tWatermark" }, { id: "numbers", icon: "hash", key: "tNumbers" },
  { id: "rotate", icon: "rotate", key: "tRotateP" }, { id: "ocr", icon: "scan", key: "tOcr" },
  { id: "archives", icon: "archive", key: "tArchives" }, { id: "print", icon: "print", key: "tPrint" },
];

export function Tools() {
  const { t, push, showToast, download, books, lang } = useApp();
  const [open, setOpen] = useState<ToolId | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [images, setImages] = useState<{ name: string; url: string }[]>([]);
  const [text, setText] = useState("JO bat — Text to PDF\n\nType or paste plain text here, or choose a .txt / .md file. Each paragraph is wrapped to the page width.");
  const [level, setLevel] = useState<"low" | "medium" | "high">("medium");
  const [pw, setPw] = useState("");
  const [wm, setWm] = useState("CONFIDENTIAL");
  const [ranges, setRanges] = useState("1-3, 5, 8-");
  const [picked, setPicked] = useState<string[]>(["b4", "b9"]);
  const imgInput = useRef<HTMLInputElement>(null);
  const txtInput = useRef<HTMLInputElement>(null);
  const pdfs = books.filter((b) => b.format === "PDF" || b.cat === "docs").filter((b) => !b.trashed);

  const close = () => { setOpen(null); setProgress(null); };
  const simulate = (doneMsg: string) => {
    setProgress(0);
    const start = performance.now();
    const tick = () => { const p = Math.min(1, (performance.now() - start) / 1500); setProgress(p); if (p < 1) requestAnimationFrame(tick); else { showToast(doneMsg); close(); } };
    requestAnimationFrame(tick);
  };

  const runImg2Pdf = async () => {
    if (!images.length) { imgInput.current?.click(); return; }
    setProgress(0.1);
    const pages = [];
    for (let i = 0; i < images.length; i++) {
      const j = await imageToJpeg(images[i].url, 2000, 0.85);
      const wPt = 595, hPt = (595 * j.h) / j.w; pages.push({ widthPt: wPt, heightPt: hPt, jpeg: j });
      setProgress(0.1 + (0.9 * (i + 1)) / images.length);
    }
    download("Images.pdf", buildPdf(pages, "Images"));
    showToast(`PDF · ${pages.length} ${t.pages}`); close();
  };
  const runTxt2Pdf = () => {
    const lines = wrapText(text, 88); const per = 50; const pages = [];
    for (let i = 0; i < Math.max(1, lines.length); i += per) pages.push({ widthPt: 595, heightPt: 842, text: { lines: lines.slice(i, i + per), size: 11 } });
    download("Text.pdf", buildPdf(pages, "Text"));
    showToast(`PDF · ${pages.length} ${t.pages}`); close();
  };

  const tool = TOOLS.find((x) => x.id === open);
  const simNote = <div className="label-s muted" style={{ marginTop: 10 }}>{lang === "ar" ? "في المعاينة تُعرض خطوات العملية فقط؛ التنفيذ الفعلي عبر MuPDF في تطبيق Android." : "Preview shows the flow only; the real operation runs via MuPDF in the Android app."}</div>;
  const filePicker = (
    <div style={{ display: "grid", gap: 6 }}>
      {pdfs.map((b) => (
        <button key={b.id} className="list-item" style={{ padding: "8px 4px" }} onClick={() => setPicked(picked.includes(b.id) ? picked.filter((x) => x !== b.id) : [...picked, b.id])}>
          <span className="li-icon"><Icon name="file" size={18} /></span><span className="li-text body-l" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{b.title}</span>
          <span style={{ width: 20, height: 20, borderRadius: 6, border: "2px solid var(--c-primary)", background: picked.includes(b.id) ? "var(--c-primary)" : "transparent", display: "grid", placeItems: "center", color: "var(--c-on-primary)" }}>{picked.includes(b.id) && <Icon name="check" size={14} stroke={3} />}</span>
        </button>
      ))}
    </div>
  );

  return (
    <div className="view">
      <div style={{ height: 44 }} />
      <div className="pad" style={{ padding: "8px 16px 16px" }}><h1 className="display-s">{t.tools}</h1></div>
      <div className="scroll">
        <div className="section-title pad">{t.edit}</div>
        <div className="tool-grid" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
          {([["pdf", "edit", t.tPdfEd], ["text", "code", t.tTextEd], ["image", "image", t.tImgEd]] as const).map(([r, ic, l], i) => (
            <button key={r} className="tool-card enter" style={{ minHeight: 96, animationDelay: `${i * 40}ms` }} onClick={() => push(r === "pdf" ? { name: "pdf", bookId: "b4" } : r === "text" ? { name: "text" } : { name: "image" })}>
              <span className="ti"><Icon name={ic} size={20} /></span><span className="label-l">{l}</span>
            </button>
          ))}
        </div>
        <div className="section-title pad">{t.tools}</div>
        <div className="tool-grid">
          {TOOLS.map((x, i) => (
            <button key={x.id} className="tool-card enter" style={{ animationDelay: `${(i + 3) * 30}ms` }} onClick={() => (x.id === "print" ? window.print() : setOpen(x.id))}>
              <span className="ti"><Icon name={x.icon} size={20} /></span>
              <span className="title-m" style={{ fontSize: 14 }}>{t[x.key] as string}</span>
            </button>
          ))}
        </div>
        <div style={{ height: 120 }} />
      </div>
      <BottomNav />

      <input ref={imgInput} type="file" accept="image/*" multiple hidden onChange={(e) => { const fs = Array.from(e.target.files ?? []); setImages((im) => [...im, ...fs.map((f) => ({ name: f.name, url: URL.createObjectURL(f) }))]); e.target.value = ""; }} />
      <input ref={txtInput} type="file" accept=".txt,.md,.csv,.html,text/*" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) setText(await f.text()); e.target.value = ""; }} />

      <Sheet open={!!open} onClose={close} title={tool ? (t[tool.key] as string) : ""}>
        {open === "img2pdf" && (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
              {images.map((im, i) => <div key={i} style={{ position: "relative" }}><img src={im.url} alt={im.name} style={{ width: "100%", aspectRatio: "3/4", objectFit: "cover", borderRadius: 8 }} /><button onClick={() => setImages(images.filter((_, k) => k !== i))} style={{ position: "absolute", top: 2, insetInlineEnd: 2, width: 20, height: 20, borderRadius: 10, background: "rgba(0,0,0,.6)", color: "#fff", display: "grid", placeItems: "center" }}><Icon name="close" size={12} /></button></div>)}
              <button onClick={() => imgInput.current?.click()} style={{ aspectRatio: "3/4", borderRadius: 8, border: "1.5px dashed var(--c-outline)", color: "var(--c-primary)", display: "grid", placeItems: "center" }}><Icon name="plus" /></button>
            </div>
            <button className="btn block" style={{ marginTop: 16 }} onClick={runImg2Pdf} disabled={progress != null}>{images.length ? `${t.run} · ${images.length}` : t.pick}</button>
          </>
        )}
        {open === "txt2pdf" && (
          <>
            <textarea className="input" style={{ height: 160, padding: 10, resize: "none", font: "13px/1.5 var(--font-mono)", direction: "ltr" }} value={text} onChange={(e) => setText(e.target.value)} />
            <div className="label-s muted" style={{ marginTop: 4 }}>{lang === "ar" ? "ملاحظة المعاينة: الخط القياسي Helvetica يدعم اللاتينية فقط؛ التطبيق يضمّن خطوطًا عربية عبر MuPDF." : "Preview note: standard Helvetica supports Latin only; the app embeds Arabic fonts via MuPDF."}</div>
            <div className="row" style={{ marginTop: 12, gap: 8 }}><button className="btn ghost" style={{ flex: 1 }} onClick={() => txtInput.current?.click()}>{t.pick}</button><button className="btn" style={{ flex: 1 }} onClick={runTxt2Pdf}>{t.run}</button></div>
          </>
        )}
        {(open === "merge" || open === "rotate" || open === "pdf2img" || open === "ocr" || open === "numbers") && <>{filePicker}</>}
        {open === "split" && <><div className="label-l muted" style={{ marginBottom: 6 }}>{t.ranges}</div><input className="input" value={ranges} onChange={(e) => setRanges(e.target.value)} style={{ direction: "ltr" }} /></>}
        {open === "compress" && <div className="seg">{(["low", "medium", "high"] as const).map((l) => <button key={l} className={level === l ? "on" : ""} onClick={() => setLevel(l)}>{t[l]}</button>)}</div>}
        {open === "compress" && <div className="label-s muted" style={{ marginTop: 8 }}>6.3 MB → ~{level === "low" ? "4.9" : level === "medium" ? "2.8" : "1.4"} MB</div>}
        {(open === "protect" || open === "unlock") && <><div className="label-l muted" style={{ marginBottom: 6 }}>{t.password}</div><input className="input" type="password" value={pw} onChange={(e) => setPw(e.target.value)} />{open === "protect" && <div className="label-s muted" style={{ marginTop: 6 }}>AES-256 · {pw.length >= 8 ? "✓" : "≥ 8"}</div>}</>}
        {open === "watermark" && <><div className="label-l muted" style={{ marginBottom: 6 }}>{t.wmText}</div><input className="input" value={wm} onChange={(e) => setWm(e.target.value)} />
          <div style={{ marginTop: 12, aspectRatio: "1.414", width: 120, background: "#fff", borderRadius: 4, position: "relative", overflow: "hidden", boxShadow: "var(--elev-1)" }}><span style={{ position: "absolute", top: "40%", left: "-10%", right: "-10%", textAlign: "center", transform: "rotate(-30deg)", color: "rgba(192,57,43,.35)", font: "700 14px Inter" }}>{wm}</span></div></>}
        {open === "archives" && <div>{["Comics/Nightfall Vol. 1.cbz", "Comics/Nightfall Vol. 2.cbr", "Backups/notes.7z", "Downloads/papers.zip"].map((f) => <div key={f} className="row" style={{ padding: "10px 0", borderBottom: "1px solid var(--c-outline-variant)" }}><Icon name="archive" size={18} style={{ color: "var(--c-primary)" }} /><span style={{ flex: 1, direction: "ltr", textAlign: "start" }}>{f}</span><Icon name="back" size={16} className={lang === "ar" ? "" : "flip-rtl"} /></div>)}</div>}
        {!["img2pdf", "txt2pdf"].includes(open ?? "") && open && (
          <>
            {progress != null && <div style={{ marginTop: 16 }}><div className="row between label-s muted" style={{ marginBottom: 6 }}><span>{t.running}</span><span>{Math.round(progress * 100)}%</span></div><div className="progress-line"><i style={{ width: `${progress * 100}%` }} /></div></div>}
            <button className="btn block" style={{ marginTop: 16 }} disabled={progress != null || ((open === "protect" || open === "unlock") && !pw)} onClick={() => simulate(`${t.done} · ${t.outputSaved}`)}>{t.run}</button>
            {simNote}
          </>
        )}
      </Sheet>
    </div>
  );
}
