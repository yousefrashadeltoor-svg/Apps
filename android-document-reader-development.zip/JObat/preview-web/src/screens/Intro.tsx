import { useEffect, useRef, useState } from "react";
import { Logo } from "../components";
import { Icon } from "../icons";
import { useApp } from "../store";

export function Splash() {
  const { resetTo, t, reduceMotion } = useApp();
  const [out, setOut] = useState(false);
  useEffect(() => {
    const onboarded = localStorage.getItem("jobat-preview:onboarded") === "1";
    const total = reduceMotion ? 500 : 1500;
    const a = setTimeout(() => setOut(true), total);
    const b = setTimeout(() => resetTo(onboarded ? { name: "main" } : { name: "onboarding" }), total + (reduceMotion ? 0 : 300));
    return () => { clearTimeout(a); clearTimeout(b); };
  }, [resetTo, reduceMotion]);
  return (
    <div className={`splash ${out ? "out" : ""}`}>
      <div className="logo-wrap">
        <div style={{ color: "#ECE7DC" }}><Logo size={64} /></div>
        <div className="line" />
        <div className="tag">{t.appTagline}</div>
      </div>
    </div>
  );
}

function Art({ i }: { i: number }) {
  if (i === 0) return (
    <svg width="230" height="200" viewBox="0 0 230 200">
      {[["PDF", -14, 30, "#2B3A55"], ["EPUB", -4, 72, "#5A3D22"], ["DJVU", 6, 114, "#3B4A3A"], ["CBZ", 14, 156, "#5B1E1E"]].map(([l, r, x, c], k) => (
        <g key={k} transform={`rotate(${r} ${(x as number) + 20} 150)`} style={{ animation: `rise var(--dur-long) var(--ease-emphasized-decelerate) ${k * 90}ms both` }}>
          <rect x={x as number} y="50" width="44" height="100" rx="4" fill={c as string} stroke="#D4B26A" strokeOpacity=".35" />
          <text x={(x as number) + 22} y="142" textAnchor="middle" fill="#EDE3CF" fontSize="9" fontFamily="Inter" fontWeight="600">{l}</text>
          <rect x={(x as number) + 8} y="64" width="28" height="1.5" fill="#D4B26A" opacity=".7" />
        </g>
      ))}
      <rect x="20" y="160" width="190" height="6" rx="3" fill="var(--c-primary)" opacity=".7" />
    </svg>
  );
  if (i === 1) return (
    <svg width="230" height="200" viewBox="0 0 230 200">
      <rect x="55" y="20" width="120" height="160" rx="6" fill="var(--c-surface-high)" stroke="var(--c-outline)" />
      {[44, 58, 72, 86, 100, 114].map((y) => <rect key={y} x="72" y={y} width={y === 72 ? 60 : 86} height="4" rx="2" fill="var(--c-on-surface-variant)" opacity=".35" />)}
      <rect x="70" y="69" width="66" height="10" rx="3" fill="var(--c-primary)" opacity=".35" />
      <path d="M78 150 c10-20 18-28 24-14 s10 10 18-6 12 4 20 0" fill="none" stroke="var(--c-primary)" strokeWidth="2.4" strokeLinecap="round" strokeDasharray="160" style={{ animation: "dash 1.6s var(--ease-emphasized-decelerate) both" }} />
      <g transform="translate(150 118) rotate(35)"><rect x="0" y="0" width="10" height="56" rx="3" fill="var(--c-primary)" /><path d="M0 56 l5 12 5-12z" fill="var(--c-primary-deep)" /></g>
      <style>{`@keyframes dash { from { stroke-dashoffset: 160 } to { stroke-dashoffset: 0 } }`}</style>
    </svg>
  );
  return (
    <svg width="230" height="200" viewBox="0 0 230 200">
      <path d="M115 22 L170 42 V96 C170 132 146 160 115 174 C84 160 60 132 60 96 V42 Z" fill="var(--c-surface-high)" stroke="var(--c-primary)" strokeWidth="1.6" />
      <path d="M115 72 a14 14 0 0 1 14 14 v8 h-28 v-8 a14 14 0 0 1 14 -14z" fill="none" stroke="var(--c-primary)" strokeWidth="2.4" />
      <rect x="95" y="94" width="40" height="32" rx="5" fill="var(--c-primary)" />
      <circle cx="115" cy="108" r="4" fill="var(--c-on-primary)" /><rect x="113.5" y="110" width="3" height="8" rx="1.5" fill="var(--c-on-primary)" />
    </svg>
  );
}

export function Onboarding() {
  const { t, resetTo, showToast, haptic } = useApp();
  const [i, setI] = useState(0);
  const [askFolders, setAskFolders] = useState(false);
  const startX = useRef<number | null>(null);
  const slides = [[t.ob1Title, t.ob1Body], [t.ob2Title, t.ob2Body], [t.ob3Title, t.ob3Body]];
  const finish = () => { localStorage.setItem("jobat-preview:onboarded", "1"); resetTo({ name: "main" }); };
  const next = () => { haptic(); if (i < 2) setI(i + 1); else setAskFolders(true); };

  return (
    <div className="ob"
      onPointerDown={(e) => (startX.current = e.clientX)}
      onPointerUp={(e) => {
        if (startX.current == null) return;
        const dx = e.clientX - startX.current; startX.current = null;
        const rtl = document.querySelector(".app")?.getAttribute("dir") === "rtl";
        const fwd = rtl ? dx > 50 : dx < -50; const back = rtl ? dx < -50 : dx > 50;
        if (fwd && i < 2) setI(i + 1); if (back && i > 0) setI(i - 1);
      }}>
      <div style={{ height: 44 }} />
      <div className="row between pad" style={{ height: 48 }}>
        <Logo size={24} />
        <button className="label-l muted" onClick={finish}>{t.skip}</button>
      </div>
      <div className="ob-art"><div className="halo" /><div key={i} className="zoom-enter"><Art i={i} /></div></div>
      <div className="pad enter" key={`t${i}`} style={{ textAlign: "center", flex: 1 }}>
        <h2 className="display-s" style={{ marginBottom: 12 }}>{slides[i][0]}</h2>
        <p className="body-l muted" style={{ margin: "0 auto", maxWidth: 300 }}>{slides[i][1]}</p>
      </div>
      <div className="pad" style={{ paddingBottom: 40, display: "grid", gap: 20 }}>
        <div className="ob-dots">{[0, 1, 2].map((k) => <i key={k} className={k === i ? "on" : ""} />)}</div>
        <button className="btn block" onClick={next}>{i < 2 ? t.next : t.start}</button>
      </div>

      {askFolders && (
        <>
          <div className="scrim" onClick={() => setAskFolders(false)} />
          <div className="sheet">
            <div className="grab" />
            <div className="sheet-body" style={{ paddingTop: 12 }}>
              <div className="row" style={{ marginBottom: 12 }}>
                <span className="li-icon" style={{ width: 44, height: 44, borderRadius: 12, display: "grid", placeItems: "center", background: "var(--c-primary-container)", color: "var(--c-primary)" }}><Icon name="folder" /></span>
                <div><div className="title-m">{t.folders}</div><div className="label-s muted">Storage Access Framework</div></div>
              </div>
              <p className="muted" style={{ marginTop: 0 }}>{t.ob3Body}</p>
              {["/Download", "/Documents/Books"].map((f) => (
                <div key={f} className="row" style={{ padding: "10px 0", borderBottom: "1px solid var(--c-outline-variant)" }}>
                  <Icon name="folder" size={18} style={{ color: "var(--c-primary)" }} /><span className="grow" style={{ flex: 1, direction: "ltr", textAlign: "start" }}>{f}</span><Icon name="check" size={18} style={{ color: "var(--c-success)" }} />
                </div>
              ))}
              <div className="row" style={{ marginTop: 20, gap: 8 }}>
                <button className="btn ghost" style={{ flex: 1 }} onClick={finish}>{t.later}</button>
                <button className="btn" style={{ flex: 1 }} onClick={() => { showToast(t.indexing); finish(); }}>{t.allow}</button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
