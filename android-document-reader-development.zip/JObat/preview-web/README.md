# 𝒥𝒪 bat — Interactive Web Preview

> **For demonstration only.** This preview reproduces the app's visual design and behaviour inside a phone frame.
> The real logic lives in the Android code: MuPDF/Librera engines, Room, editors that write into files, CameraX, ML Kit, Keystore.

## How it stays identical to the app
- `../design-system/tokens/tokens.json` is the single source of truth.
- `node ../tools/generate-tokens.mjs` writes **both** `src/tokens.generated.css` (used here) and `JoBatTokens.kt` (Compose).
- Motion uses the same durations (150/300/450/600 ms), the same Material 3 emphasized curves (`cubic-bezier(.05,.7,.1,1)` etc.) and the same spring for the navigation indicator.
- Reduce Motion sets every duration to 0, just like `JoBatMotion` returns `snap()`.

## What is real in the preview vs. scripted
| Feature | Preview behaviour |
|---|---|
| Pagination, themes, fonts, TOC, search, bookmarks, zoom, RTL paging, curl/scroll/two-page | Real (measured DOM pagination) |
| TTS | Real (Web Speech API; Android uses TextToSpeech) with sentence highlighting, speed, pitch and sleep timer |
| PDF annotations, undo/redo, signature, stamps, notes, forms, page management | Real in memory; "Save as copy" exports **XFDF** |
| Text editor (highlighting, regex find/replace, undo/redo, MD/HTML/CSV preview, autosave) | Real |
| Image editor (adjustments, filters, crop, rotate/flip, draw, blur, export with quality) | Real (canvas) |
| Scanner perspective correction + B&W adaptive threshold | Real (JS port of `core-native`) |
| Scanner → PDF, Images → PDF, Text → PDF | Real PDF files (minimal PDF writer, `src/pdf.ts`) |
| OCR text | Pre-computed for the sample photo |
| Merge/Split/Compress/Protect/Watermark… | Progress flow only (needs MuPDF) |
| Backup / restore | Real `.jobat` JSON file |

## Run
From the repository root: `npm install && npm run build`. The Vite entry `src/App.tsx` imports `JObat/preview-web/src/App.tsx`.
