package com.jobat.domain

import com.google.common.truth.Truth.assertThat
import com.jobat.domain.model.DocumentFormat
import com.jobat.domain.model.EngineKind
import org.junit.Test

class DocumentFormatTest {
    @Test fun detectsByExtension() {
        assertThat(DocumentFormat.detect("Book.PDF")).isEqualTo(DocumentFormat.PDF)
        assertThat(DocumentFormat.detect("novel.azw3")).isEqualTo(DocumentFormat.MOBI)
        assertThat(DocumentFormat.detect("tale.fb2.zip")).isEqualTo(DocumentFormat.FB2)
        assertThat(DocumentFormat.detect("scan.heic")).isEqualTo(DocumentFormat.IMAGE)
    }

    @Test fun fallsBackToMime() {
        assertThat(DocumentFormat.detect("download", "application/epub+zip")).isEqualTo(DocumentFormat.EPUB)
    }

    @Test fun unknownReturnsNull() {
        assertThat(DocumentFormat.detect("archive.xyz")).isNull()
    }

    @Test fun routesEngines() {
        assertThat(DocumentFormat.DJVU.engine).isEqualTo(EngineKind.DJVU)
        assertThat(DocumentFormat.CBR.engine).isEqualTo(EngineKind.ARCHIVE_COMIC)
        assertThat(DocumentFormat.PDF.editable).isTrue()
    }
}
