package com.jobat.domain.model

/** Which engine renders a format. Mapping is the single source used by Library filters and the Reader router. */
enum class EngineKind { MUPDF, DJVU, ARCHIVE_COMIC, OFFICE_CONVERT, TEXT, WEB, IMAGE, ARCHIVE_BROWSER }

enum class FormatCategory { DOCUMENT, BOOK, COMIC, OFFICE, TEXT, WEB, IMAGE, ARCHIVE }

enum class DocumentFormat(
    val extensions: Set<String>,
    val mimeTypes: Set<String>,
    val engine: EngineKind,
    val category: FormatCategory,
    val editable: Boolean = false,
) {
    PDF(setOf("pdf"), setOf("application/pdf"), EngineKind.MUPDF, FormatCategory.DOCUMENT, editable = true),
    XPS(setOf("xps", "oxps"), setOf("application/vnd.ms-xpsdocument", "application/oxps"), EngineKind.MUPDF, FormatCategory.DOCUMENT),
    EPUB(setOf("epub"), setOf("application/epub+zip"), EngineKind.MUPDF, FormatCategory.BOOK),
    MOBI(setOf("mobi", "prc", "azw", "azw3", "kf8"), setOf("application/x-mobipocket-ebook", "application/vnd.amazon.ebook"), EngineKind.MUPDF, FormatCategory.BOOK),
    FB2(setOf("fb2", "fb2.zip", "fbz"), setOf("application/x-fictionbook+xml", "text/fb2+xml"), EngineKind.MUPDF, FormatCategory.BOOK),
    DJVU(setOf("djvu", "djv"), setOf("image/vnd.djvu", "image/x-djvu"), EngineKind.DJVU, FormatCategory.DOCUMENT),
    CBZ(setOf("cbz"), setOf("application/vnd.comicbook+zip", "application/x-cbz"), EngineKind.MUPDF, FormatCategory.COMIC),
    CBR(setOf("cbr"), setOf("application/vnd.comicbook-rar", "application/x-cbr"), EngineKind.ARCHIVE_COMIC, FormatCategory.COMIC),
    CB7(setOf("cb7"), setOf("application/x-cb7"), EngineKind.ARCHIVE_COMIC, FormatCategory.COMIC),
    RTF(setOf("rtf"), setOf("application/rtf", "text/rtf"), EngineKind.OFFICE_CONVERT, FormatCategory.OFFICE),
    DOC(setOf("doc"), setOf("application/msword"), EngineKind.OFFICE_CONVERT, FormatCategory.OFFICE),
    DOCX(setOf("docx"), setOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"), EngineKind.MUPDF, FormatCategory.OFFICE),
    ODT(setOf("odt"), setOf("application/vnd.oasis.opendocument.text"), EngineKind.OFFICE_CONVERT, FormatCategory.OFFICE),
    XLS(setOf("xls", "xlsx"), setOf("application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"), EngineKind.MUPDF, FormatCategory.OFFICE),
    PPT(setOf("ppt", "pptx"), setOf("application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation"), EngineKind.MUPDF, FormatCategory.OFFICE),
    TXT(setOf("txt", "log"), setOf("text/plain"), EngineKind.TEXT, FormatCategory.TEXT, editable = true),
    MD(setOf("md", "markdown"), setOf("text/markdown"), EngineKind.TEXT, FormatCategory.TEXT, editable = true),
    CSV(setOf("csv", "tsv"), setOf("text/csv", "text/tab-separated-values"), EngineKind.TEXT, FormatCategory.TEXT, editable = true),
    HTML(setOf("html", "htm", "xhtml"), setOf("text/html", "application/xhtml+xml"), EngineKind.WEB, FormatCategory.WEB, editable = true),
    MHT(setOf("mht", "mhtml"), setOf("multipart/related", "message/rfc822"), EngineKind.WEB, FormatCategory.WEB),
    XML(setOf("xml"), setOf("text/xml", "application/xml"), EngineKind.TEXT, FormatCategory.WEB, editable = true),
    IMAGE(setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif", "tif", "tiff"), setOf("image/jpeg", "image/png", "image/webp", "image/gif", "image/bmp", "image/heic", "image/heif", "image/avif", "image/tiff"), EngineKind.IMAGE, FormatCategory.IMAGE, editable = true),
    SVG(setOf("svg"), setOf("image/svg+xml"), EngineKind.MUPDF, FormatCategory.IMAGE),
    ZIP(setOf("zip"), setOf("application/zip"), EngineKind.ARCHIVE_BROWSER, FormatCategory.ARCHIVE),
    RAR(setOf("rar"), setOf("application/vnd.rar", "application/x-rar-compressed"), EngineKind.ARCHIVE_BROWSER, FormatCategory.ARCHIVE),
    SEVEN_Z(setOf("7z"), setOf("application/x-7z-compressed"), EngineKind.ARCHIVE_BROWSER, FormatCategory.ARCHIVE);

    companion object {
        private val byExt: Map<String, DocumentFormat> = entries.flatMap { f -> f.extensions.map { it to f } }.toMap()
        private val byMime: Map<String, DocumentFormat> = entries.flatMap { f -> f.mimeTypes.map { it to f } }.toMap()

        /** Resolves by file name first (handles double extensions like ".fb2.zip"), then MIME type. */
        fun detect(fileName: String?, mimeType: String? = null): DocumentFormat? {
            val name = fileName?.lowercase()?.trim().orEmpty()
            if (name.endsWith(".fb2.zip")) return FB2
            val ext = name.substringAfterLast('.', "")
            return byExt[ext] ?: mimeType?.lowercase()?.let { byMime[it] }
        }

        val allExtensions: Set<String> get() = byExt.keys
    }
}
