package com.jobat.domain.model

/** Outcome of opening any document: drives the elegant password sheet and corrupt-file states in the UI. */
sealed interface OpenResult<out T> {
    data class Success<T>(val value: T) : OpenResult<T>
    data object PasswordRequired : OpenResult<Nothing>
    data object WrongPassword : OpenResult<Nothing>
    data class Corrupted(val reason: String) : OpenResult<Nothing>
    data class Unsupported(val fileName: String) : OpenResult<Nothing>
}
