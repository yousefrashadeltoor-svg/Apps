# Build guide
1. Install JDK 17, Android SDK 35, NDK `27.2.12479018`, CMake `3.22.1`.
2. `cd JObat && gradle wrapper --gradle-version 8.11.1`
3. Optional signing: `cp keystore.properties.example keystore.properties` and fill it in.
4. `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-{abi}-release.apk`
5. `./gradlew bundleRelease` → AAB for Play.
6. Optional slimmer MuPDF: `core-native/scripts/build-mupdf-from-source.sh`.
7. Librera engine import (Phase 3): `core-engine/scripts/import-librera.sh`.
8. Web preview: from the repository root run `npm install && npm run build` (the Vite entry imports `JObat/preview-web/src/App.tsx`).
