# Phase 1 — Checklist & how to verify

| # | Item | Verify |
|---|---|---|
| 1 | Multi-module Gradle (KTS) + version catalog | `./gradlew projects` lists app, core-native, core-engine, design-system, domain |
| 2 | R8 full mode, shrinkResources, ABI splits, AAB, en/ar locale filter | `./gradlew assembleRelease bundleRelease` → 3 APKs + 1 AAB |
| 3 | Release signing via keystore.properties (debug fallback) | Build once without the file, then once with it |
| 4 | tokens.json → Compose + CSS | `node tools/generate-tokens.mjs && git diff --exit-code` (also runs in CI) |
| 5 | JoBatTheme: Dark/Light/AMOLED/Sepia/Dynamic/System, typography with subset fonts (460 KB) | Settings → Appearance |
| 6 | Motion that respects Reduce Motion (in-app toggle + system animator scale) | Settings → Reduce motion |
| 7 | DocumentFormat registry + unit tests | `./gradlew :domain:test` |
| 8 | MuPDF engine: open, password, corrupt handling, render, text, search, outline, metadata, reflow | Open a PDF/EPUB/XPS/CBZ through SAF; open an encrypted PDF |
| 9 | content:// opened without copying (/proc/self/fd), temp cleanup | Open from Drive/Files; check cacheDir/open-cache is empty after restart |
| 10 | C++17 JNI (auto-crop, contrast, adaptive threshold) built with CMake, 16 KB page aligned | `./gradlew :core-native:assembleRelease` |
| 11 | Splash Screen API with soft exit, adaptive + themed (monochrome) icon | Cold-start the app; Android 13+ themed icons |
| 12 | Open-with / Share intents for all formats, FileProvider, no cleartext, no INTERNET permission | `aapt dump permissions app-arm64-v8a-release.apk` |
| 13 | LICENSE (GPL-3.0 full text), NOTICE (modifications, AGPL note), PRIVACY, CHANGELOG, licenses screen | Settings → About |
| 14 | CI (GitHub Actions): token drift check, unit tests, release build, size summary | Push to main |
| 15 | Interactive web preview (all screens listed in the brief) | `npm run build` at the repo root → open dist/index.html |

**Next: Phase 2.** It adds `:data` (Room + FTS4 entities BookEntity/BookFts/CollectionEntity/TagEntity/AnnotationEntity/ReadingSessionEntity, DAOs, migrations, DataStore), `LibraryScanWorker` + `FolderObserver` with WorkManager, `CoverExtractor` (MuPDF page 0 → WebP disk cache), `:feature-library` (Grid/List/Compact, sort, filters, collections, tags, favorites, archive, trash, FTS search, Continue Reading), and their tests.
