# Dependency justification

| Dependency | Why | Approx. size impact | Alternative considered |
|---|---|---|---|
| MuPDF fitz (AGPL) | Rendering for PDF/XPS/EPUB/MOBI/FB2/CBZ/SVG/Office XML, text extraction, search, annotations, forms | ~7–9 MB/ABI (≈4–5 MB with the source build) | PdfRenderer: no EPUB, search or annotations |
| Jetpack Compose + Material 3 | Whole UI | ~2.5 MB after R8 | Views: slower to build this UI |
| Hilt | Dependency injection across 15 modules | ~150 KB | Manual DI: error-prone at this scale |
| Room (+FTS4) | Library, notes, full-text search | ~300 KB | SQLDelight: similar, but less AndroidX integration |
| DataStore | Settings | ~100 KB | SharedPreferences: blocking I/O |
| WorkManager | Background indexing and cover extraction | ~250 KB | JobScheduler: more boilerplate |
| Navigation Compose | Type-safe navigation | ~200 KB | Custom navigation |
| Coil (+gif, svg) | Image loading and caching | ~250 KB | Glide: larger |
| CameraX | Scanner | ~600 KB | Camera2 directly: much more code |
| ML Kit text (Play Services) | On-device OCR, model is not in the APK | ~200 KB stub | Tesseract (FOSS flavour), +tessdata on demand |
| Biometric + security-crypto | App lock, encrypted vault | ~150 KB | — |
| Glance | Widgets | ~300 KB | RemoteViews |
| commons-compress + xz + junrar | ZIP/7z/RAR browsing, CBR/CB7 | ~700 KB | libarchive via NDK: larger |
| PdfBox-Android | PDF page tools (merge, split, encrypt, watermark) where MuPDF lacks a Java API | ~2.5 MB, Phase 5 tools module only | MuPDF `PDFDocument.graftPage`, preferred where possible |
| commonmark | Markdown preview and MD→PDF | ~150 KB | — |
| profileinstaller + Baseline Profiles | Startup under 600 ms | ~30 KB | — |
