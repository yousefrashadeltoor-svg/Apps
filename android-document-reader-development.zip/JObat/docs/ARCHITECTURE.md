# Architecture

```
app ──► feature-* ──► domain (pure Kotlin: models, use cases)
 │          │            ▲
 │          └──► data ───┘ (Room+FTS, DataStore, repositories, WorkManager)
 │                 │
 └──► design-system (tokens, theme, components, motion)
                   └──► core-engine (DocumentEngine API; MuPDF, DjVu, archive, text, web engines)
                              └──► core-native (C++/JNI image ops) + MuPDF fitz (JNI)
```
- **Pattern:** MVVM with unidirectional state (MVI-style `StateFlow<UiState>` + intents) and Clean Architecture boundaries.
- **Threading:** each opened document gets its own single-thread dispatcher. MuPDF contexts are not thread-safe, so native calls never run concurrently on one document. Rendering can be cancelled through MuPDF `Cookie`.
- **Memory:** an LRU of 4 loaded pages per document. Bitmaps are rendered at view width and tiled for zoom, which is the Phase 3 tile renderer.
- **Tokens:** `tokens.json` is the single source. `tools/generate-tokens.mjs` writes `JoBatTokens.kt` and `preview-web/src/tokens.generated.css`. CI fails if they drift.
- **Navigation:** Navigation Compose. The bottom bar shows Library, Tools, Scanner, Collections and Settings as their modules land.
