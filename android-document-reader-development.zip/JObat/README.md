# 𝒥𝒪 bat — Offline Reader & Editor for Android

> قارئ ومحرر مستندات وصور شامل، فخم وخفيف، يعمل دون إنترنت بالكامل.
> Package: `com.jobat.reader` · License: **GPL-3.0-or-later** (MuPDF components: **AGPL-3.0**)

## ⚠️ المعاينة الويب للعرض فقط / Web preview is for demonstration only
`preview-web/` is an interactive **visual and behavioural mock-up** of the app running in a browser phone frame.
It shares the same `design-system/tokens/tokens.json`, so colours, type, spacing, radii and motion curves match.
**It does not open real files.** All real logic (engines, editing, storage, security) lives in the Android Kotlin/C++ code.

## Project status (phased delivery)
| Phase | Scope | Status |
|---|---|---|
| 1 | Gradle structure, version catalog, design tokens → Compose + CSS, design-system, domain, core-engine (MuPDF), core-native (C++ JNI), app shell (open via SAF/Intent, render, password, themes), licenses, CI | ✅ delivered |
| 2 | `:data` (Room + FTS4, DataStore), `:feature-library` (WorkManager indexing, grid/list, sort, collections, tags) | ⏳ next |
| 3 | `:feature-reader` (all modes, themes, TOC, search, TTS, DjVu/CBR/CB7/Office/Text/Web engines) | ⏳ |
| 4 | `:feature-editor-pdf`, `:feature-editor-text`, `:feature-editor-image` | ⏳ |
| 5 | `:feature-scanner-ocr`, `:feature-tools` | ⏳ |
| 6 | Vault/biometrics, stats, Glance widgets, backup, settings | ⏳ |
| 7 | Baseline profiles, size report, tests, store assets | ⏳ |

The interactive **web preview is delivered now** (it is the design reference for every later phase).

## Build
```bash
cd JObat
gradle wrapper --gradle-version 8.11.1   # once (wrapper jar is not committed)
./gradlew assembleRelease                # APK per ABI in app/build/outputs/apk/release/
./gradlew bundleRelease                  # AAB
./gradlew :domain:test                   # unit tests
node tools/generate-tokens.mjs           # regenerate Compose + CSS tokens after editing tokens.json
```
Requirements: JDK 17, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1, Node 18+ (token generator only).
Without `keystore.properties`, release builds are signed with the debug key so CI and fresh clones still build.

## Technical constraints (stated plainly)
1. **Licence is AGPL-3.0 in practice.** Librera is GPL-3.0, but it bundles MuPDF, which is AGPL-3.0. GPL-3.0 §13 lets you combine the two, and the MuPDF parts stay under AGPL. The app has no network features, so the AGPL network clause is never triggered. We still publish the full source, linked from *Settings → About*.
2. **MuPDF comes as a prebuilt library.** We use Artifex's official `com.artifex.mupdf:fitz` AAR, which includes JNI for every ABI and supports PDF, XPS, EPUB, MOBI, FB2, CBZ, SVG, images, and DOCX/XLSX/PPTX. `core-native/scripts/build-mupdf-from-source.sh` builds a slimmer version that drops the CJK and Noto fonts, saving about 3–4 MB per ABI.
3. **Librera is imported by a script, not copied by hand.** Librera has several hundred thousand lines. `core-engine/scripts/import-librera.sh` fetches it, records the commit, and removes ads, analytics, Firebase, billing and branding. Phase 3 then uses its DjVu, hyphenation and TTS parts.
4. **Old Office formats need conversion.** DOC, ODT and RTF have no light native renderer. Phase 3 converts them to HTML (RTF/ODT parsers, plus a basic text extractor for DOC), then reflows them. Complex layouts will not look exactly like the original.
5. **ML Kit is optional.** ML Kit text recognition comes through Google Play services. A fully FOSS build (F-Droid flavour) uses Tesseract instead, with language packs downloaded on demand.

## Structure
See `docs/ARCHITECTURE.md`, `docs/BUILD.md`, `docs/DEPENDENCIES.md` (dependency justification table).

## Credits
Built on **Librera Reader** (© Ivan Ivanenko, GPL-3.0) and **MuPDF** (© Artifex Software, AGPL-3.0). See `NOTICE`.
