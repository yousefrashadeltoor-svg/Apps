package com.jobat.reader

import android.animation.ObjectAnimator
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.animation.PathInterpolator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.animation.doOnEnd
import androidx.core.content.IntentCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import com.jobat.design.theme.JoBatTheme
import com.jobat.reader.ui.JoBatRoot
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Soft exit: icon scales up slightly + fades using the emphasized-accelerate curve (0.3,0,0.8,0.15), 300ms.
        splash.setOnExitAnimationListener { provider ->
            val icon: View = provider.iconView
            val easing = PathInterpolator(0.3f, 0f, 0.8f, 0.15f)
            ObjectAnimator.ofFloat(icon, View.ALPHA, 1f, 0f).apply { duration = 300; interpolator = easing; start() }
            ObjectAnimator.ofFloat(provider.view, View.ALPHA, 1f, 0f).apply {
                duration = 300; startDelay = 80; interpolator = easing
                doOnEnd { provider.remove() }
                start()
            }
            icon.animate().scaleX(1.08f).scaleY(1.08f).setDuration(300).setInterpolator(easing).start()
        }

        handleIntent(intent)

        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            JoBatTheme(theme = settings.theme, reduceMotion = settings.reduceMotion) {
                JoBatRoot(vm)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** "Open with", "Share", and drag & drop all funnel here. URIs are never re-exported. */
    private fun handleIntent(intent: Intent?) {
        val uri: Uri? = when (intent?.action) {
            Intent.ACTION_VIEW, Intent.ACTION_EDIT -> intent.data
            Intent.ACTION_SEND -> IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            Intent.ACTION_SEND_MULTIPLE -> IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.firstOrNull()
            else -> null
        }
        uri?.let { vm.open(it) }
    }
}
