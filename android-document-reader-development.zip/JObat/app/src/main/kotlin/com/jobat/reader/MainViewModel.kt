package com.jobat.reader

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jobat.core.engine.ContentUriResolver
import com.jobat.core.engine.OpenedDocument
import com.jobat.core.engine.ResolvedPath
import com.jobat.core.engine.mupdf.MuPdfEngine
import com.jobat.design.theme.AppTheme
import com.jobat.domain.model.DocumentFormat
import com.jobat.domain.model.OpenResult
import com.jobat.reader.settings.AppSettings
import com.jobat.reader.settings.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

sealed interface DocState {
    data object Idle : DocState
    data object Loading : DocState
    data class Ready(val name: String, val doc: OpenedDocument) : DocState
    data class NeedsPassword(val uri: Uri, val wrong: Boolean) : DocState
    data class Error(val message: String) : DocState
}

@HiltViewModel
class MainViewModel @Inject constructor(
    app: Application,
    private val settingsStore: SettingsStore,
) : AndroidViewModel(app) {

    val settings: StateFlow<AppSettings> = settingsStore.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _doc = MutableStateFlow<DocState>(DocState.Idle)
    val doc: StateFlow<DocState> = _doc.asStateFlow()

    private val _recent = MutableStateFlow<List<Pair<String, Uri>>>(emptyList())
    val recent: StateFlow<List<Pair<String, Uri>>> = _recent.asStateFlow()

    private val engine = MuPdfEngine()
    private var resolved: ResolvedPath? = null

    fun setTheme(t: AppTheme) = viewModelScope.launch { settingsStore.setTheme(t) }
    fun setReduceMotion(on: Boolean) = viewModelScope.launch { settingsStore.setReduceMotion(on) }

    fun open(uri: Uri, password: String? = null) = viewModelScope.launch {
        closeCurrent()
        _doc.value = DocState.Loading
        val ctx = getApplication<Application>()
        val path = runCatching { withContext(Dispatchers.IO) { ContentUriResolver.resolve(ctx, uri) } }.getOrElse {
            _doc.value = DocState.Error(it.message ?: "Cannot access file"); return@launch
        }
        if (DocumentFormat.detect(path.displayName) == null || !engine.canOpen(path.displayName, ctx.contentResolver.getType(uri))) {
            path.close()
            _doc.value = DocState.Error("“${path.displayName}” will be supported by its dedicated engine in a later phase.")
            return@launch
        }
        when (val r = engine.open(path.path, password)) {
            is OpenResult.Success -> {
                resolved = path
                _doc.value = DocState.Ready(path.displayName, r.value)
                _recent.value = (listOf(path.displayName to uri) + _recent.value.filterNot { it.second == uri }).take(20)
            }
            OpenResult.PasswordRequired -> { path.close(); _doc.value = DocState.NeedsPassword(uri, wrong = false) }
            OpenResult.WrongPassword -> { path.close(); _doc.value = DocState.NeedsPassword(uri, wrong = true) }
            is OpenResult.Corrupted -> { path.close(); _doc.value = DocState.Error(r.reason) }
            is OpenResult.Unsupported -> { path.close(); _doc.value = DocState.Error(r.fileName) }
        }
    }

    suspend fun render(doc: OpenedDocument, index: Int, widthPx: Int): Bitmap {
        val size = doc.pageSize(index)
        val zoom = widthPx / size.width
        val bmp = Bitmap.createBitmap(widthPx, (size.height * zoom).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        doc.renderPage(index, bmp, zoom)
        return bmp
    }

    fun closeDocument() { closeCurrent(); _doc.value = DocState.Idle }

    private fun closeCurrent() {
        (_doc.value as? DocState.Ready)?.doc?.close()
        resolved?.close(); resolved = null
    }

    override fun onCleared() { closeCurrent() }
}
