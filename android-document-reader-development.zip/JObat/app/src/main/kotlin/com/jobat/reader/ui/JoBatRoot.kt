package com.jobat.reader.ui

import android.content.Intent
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jobat.core.engine.OpenedDocument
import com.jobat.design.components.GlassBottomBar
import com.jobat.design.components.JoBatLogo
import com.jobat.design.components.NavDestination
import com.jobat.design.components.shimmer
import com.jobat.design.motion.JoBatMotion
import com.jobat.design.theme.AppTheme
import com.jobat.design.theme.JoBatTokens
import com.jobat.design.theme.LocalJoBat
import com.jobat.domain.model.DocumentFormat
import com.jobat.reader.DocState
import com.jobat.reader.MainViewModel
import com.jobat.reader.R

@Composable
fun JoBatRoot(vm: MainViewModel) {
    val docState by vm.doc.collectAsStateWithLifecycle()
    val palette = LocalJoBat.current.palette
    var tab by rememberSaveable { mutableStateOf("library") }
    val tabs = listOf(
        NavDestination("library", stringResource(R.string.nav_library), Icons.Outlined.LibraryBooks),
        NavDestination("settings", stringResource(R.string.nav_settings), Icons.Outlined.Settings),
    )

    val enterSpec = JoBatMotion.emphasized<Float>()
    val exitSpec = JoBatMotion.exit<Float>()
    Box(Modifier.fillMaxSize().background(palette.background)) {
        AnimatedContent(
            targetState = docState is DocState.Ready,
            transitionSpec = { fadeIn(enterSpec) togetherWith fadeOut(exitSpec) },
            label = "root",
        ) { reading ->
            if (reading) {
                val ready = docState as? DocState.Ready
                if (ready != null) PageViewer(ready.name, ready.doc, vm) { vm.closeDocument() }
            } else {
                Box(Modifier.fillMaxSize()) {
                    when (tab) {
                        "library" -> LibraryScreen(vm)
                        else -> SettingsScreen(vm)
                    }
                    GlassBottomBar(tabs, tab, { tab = it.route }, Modifier.align(Alignment.BottomCenter))
                }
            }
        }
        when (val s = docState) {
            DocState.Loading -> Box(Modifier.fillMaxSize().background(palette.scrim), Alignment.Center) {
                CircularProgressIndicator(color = palette.primary)
            }
            is DocState.NeedsPassword -> PasswordDialog(s.wrong, onDismiss = { vm.closeDocument() }) { vm.open(s.uri, it) }
            is DocState.Error -> AlertDialog(
                onDismissRequest = { vm.closeDocument() },
                title = { Text(stringResource(R.string.error_open_title)) },
                text = { Text(s.message) },
                confirmButton = { TextButton({ vm.closeDocument() }) { Text(stringResource(R.string.ok)) } },
            )
            else -> Unit
        }
    }
}

@Composable
private fun LibraryScreen(vm: MainViewModel) {
    val palette = LocalJoBat.current.palette
    val recent by vm.recent.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { vm.open(it) } }
    val launch = {
        picker.launch(arrayOf("*/*"))
    }
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(JoBatTokens.Spacing.lg, JoBatTokens.Spacing.xl, JoBatTokens.Spacing.lg, 120.dp),
        verticalArrangement = Arrangement.spacedBy(JoBatTokens.Spacing.md),
    ) {
        item { JoBatLogo(size = MaterialTheme.typography.displaySmall.fontSize) }
        item {
            Text(stringResource(R.string.library_subtitle), style = MaterialTheme.typography.bodyMedium, color = palette.onSurfaceVariant)
            Spacer(Modifier.height(JoBatTokens.Spacing.md))
            Button(
                onClick = { launch() },
                colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = palette.onPrimary),
                shape = RoundedCornerShape(JoBatTokens.Radius.md),
            ) {
                Icon(Icons.Outlined.FolderOpen, null)
                Spacer(Modifier.size(JoBatTokens.Spacing.sm))
                Text(stringResource(R.string.open_document))
            }
        }
        if (recent.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(top = JoBatTokens.Spacing.xxxl), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Description, null, tint = palette.primary, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(JoBatTokens.Spacing.md))
                    Text(stringResource(R.string.empty_library_title), style = MaterialTheme.typography.titleMedium, color = palette.onSurface)
                    Text(stringResource(R.string.empty_library_body), style = MaterialTheme.typography.bodyMedium, color = palette.onSurfaceVariant)
                }
            }
        } else {
            item { Text(stringResource(R.string.recent), style = MaterialTheme.typography.titleMedium, color = palette.onSurface) }
            items(recent, key = { it.second.toString() }) { (name, uri) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(JoBatTokens.Radius.md)).background(palette.surface)
                        .clickable { vm.open(uri) }.padding(JoBatTokens.Spacing.lg),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(36.dp, 48.dp).clip(RoundedCornerShape(4.dp)).background(palette.primaryContainer), Alignment.Center) {
                        Text(DocumentFormat.detect(name)?.name?.take(4) ?: "DOC", style = MaterialTheme.typography.labelSmall, color = palette.onPrimaryContainer)
                    }
                    Spacer(Modifier.size(JoBatTokens.Spacing.md))
                    Text(name, style = MaterialTheme.typography.bodyLarge, color = palette.onSurface, maxLines = 2)
                }
            }
        }
    }
}

@Composable
private fun PageViewer(name: String, doc: OpenedDocument, vm: MainViewModel, onClose: () -> Unit) {
    val palette = LocalJoBat.current.palette
    BackHandler(onBack = onClose)
    Column(Modifier.fillMaxSize().background(palette.background)) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(JoBatTokens.Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), tint = palette.onSurface) }
            Text(name, style = MaterialTheme.typography.titleMedium, color = palette.onSurface, maxLines = 1, modifier = Modifier.weight(1f))
            Text("${doc.pageCount}", style = MaterialTheme.typography.labelLarge, color = palette.primary, modifier = Modifier.padding(end = JoBatTokens.Spacing.lg))
        }
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val widthPx = with(LocalDensity.current) { (maxWidth - JoBatTokens.Spacing.lg * 2).roundToPx() }
            LazyColumn(
                contentPadding = PaddingValues(JoBatTokens.Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(JoBatTokens.Spacing.md),
            ) {
                items(doc.pageCount, key = { it }) { index ->
                    val bmp by produceState<Bitmap?>(null, index, widthPx) { value = vm.render(doc, index, widthPx) }
                    val ratio by produceState(0.707f, index) { val s = doc.pageSize(index); value = s.width / s.height }
                    val img = bmp
                    if (img == null) {
                        Box(Modifier.fillMaxWidth().aspectRatio(ratio).clip(RoundedCornerShape(JoBatTokens.Radius.sm)).shimmer())
                    } else {
                        Image(img.asImageBitmap(), stringResource(R.string.page_n, index + 1), Modifier.fillMaxWidth().clip(RoundedCornerShape(JoBatTokens.Radius.sm)), contentScale = ContentScale.FillWidth)
                    }
                }
            }
        }
    }
}

@Composable
private fun PasswordDialog(wrong: Boolean, onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Lock, null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text(stringResource(R.string.password_title)) },
        text = {
            OutlinedTextField(
                pw, { pw = it }, singleLine = true, isError = wrong,
                label = { Text(stringResource(if (wrong) R.string.password_wrong else R.string.password_hint)) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            )
        },
        confirmButton = { TextButton({ onSubmit(pw) }, enabled = pw.isNotEmpty()) { Text(stringResource(R.string.unlock)) } },
        dismissButton = { TextButton(onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun SettingsScreen(vm: MainViewModel) {
    val palette = LocalJoBat.current.palette
    val settings by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showLicenses by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
            .padding(JoBatTokens.Spacing.lg).padding(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(JoBatTokens.Spacing.md),
    ) {
        Text(stringResource(R.string.nav_settings), style = MaterialTheme.typography.displaySmall, color = palette.onBackground)
        Text(stringResource(R.string.appearance), style = MaterialTheme.typography.titleMedium, color = palette.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(JoBatTokens.Spacing.sm), modifier = Modifier.fillMaxWidth()) {
            AppTheme.entries.take(3).forEach { t -> FilterChip(settings.theme == t, { vm.setTheme(t) }, { Text(t.name) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(JoBatTokens.Spacing.sm), modifier = Modifier.fillMaxWidth()) {
            AppTheme.entries.drop(3).forEach { t -> FilterChip(settings.theme == t, { vm.setTheme(t) }, { Text(t.name) }) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.reduce_motion), style = MaterialTheme.typography.bodyLarge, color = palette.onSurface, modifier = Modifier.weight(1f))
            Switch(settings.reduceMotion, { vm.setReduceMotion(it) })
        }
        HorizontalDivider(color = palette.outlineVariant)
        Text(stringResource(R.string.about), style = MaterialTheme.typography.titleMedium, color = palette.primary)
        Text(stringResource(R.string.about_body), style = MaterialTheme.typography.bodyMedium, color = palette.onSurfaceVariant)
        TextButton({ showLicenses = true }) { Text(stringResource(R.string.licenses)) }
        TextButton({
            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://github.com/jobat-reader/jobat")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text(stringResource(R.string.source_code)) }
    }
    if (showLicenses) {
        AlertDialog(
            onDismissRequest = { showLicenses = false },
            title = { Text(stringResource(R.string.licenses)) },
            text = { Text(stringResource(R.string.licenses_body), modifier = Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton({ showLicenses = false }) { Text(stringResource(R.string.ok)) } },
        )
    }
}
