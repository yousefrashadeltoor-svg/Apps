package com.jobat.reader

import android.app.Application
import android.os.StrictMode
import com.jobat.core.engine.ContentUriResolver
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class JoBatApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build())
            StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().detectLeakedClosableObjects().detectFileUriExposure().penaltyLog().build())
        }
        // Remove stale temp copies of opened content:// documents from previous sessions (privacy + space).
        Thread { ContentUriResolver.cleanup(this) }.start()
    }
}
