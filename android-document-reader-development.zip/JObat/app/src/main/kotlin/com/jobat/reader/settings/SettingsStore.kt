package com.jobat.reader.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.jobat.design.theme.AppTheme
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "jobat_settings")

data class AppSettings(val theme: AppTheme = AppTheme.Dark, val reduceMotion: Boolean = false)

@Singleton
class SettingsStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val themeKey = stringPreferencesKey("theme")
    private val reduceMotionKey = booleanPreferencesKey("reduce_motion")

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            theme = p[themeKey]?.let { runCatching { AppTheme.valueOf(it) }.getOrNull() } ?: AppTheme.Dark,
            reduceMotion = p[reduceMotionKey] ?: false,
        )
    }

    suspend fun setTheme(theme: AppTheme) = context.dataStore.edit { it[themeKey] = theme.name }
    suspend fun setReduceMotion(on: Boolean) = context.dataStore.edit { it[reduceMotionKey] = on }
}
