# JO bat — R8 full mode rules
-keepattributes SourceFile,LineNumberTable,*Annotation*,Signature,InnerClasses,EnclosingMethod
-renamesourcefileattribute SourceFile
# MuPDF / native bridges (also declared as consumer rules in their modules)
-keep class com.artifex.mupdf.fitz.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
# Kotlin enums used by name in DataStore
-keepclassmembers enum com.jobat.** { public static **[] values(); public static ** valueOf(java.lang.String); }
# No analytics, ads or crash SDKs are present — nothing else to keep.
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
