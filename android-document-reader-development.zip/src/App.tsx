// Entry point: the interactive web preview lives in JObat/preview-web (single source with the Android design tokens).
import PreviewApp from "../JObat/preview-web/src/App";

export default function App() {
  return <PreviewApp />;
}
