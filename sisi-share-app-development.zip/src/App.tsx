import { useEffect } from "react";
// المصدر الوحيد للمعاينة هو مجلد JOPRO/ (Vanilla HTML/CSS/JS يعمل بالنقر المزدوج عبر file://).
// هذا الملف يضمّن نفس الملفات حرفيًا داخل dist/index.html (ملف واحد) بدون أي نسخة موازية من الكود.
import "../JOPRO/css/fonts.css";
import "../JOPRO/css/tokens.css";
import "../JOPRO/css/app.css";
import "../JOPRO/css/preview.css";
import qr from "../JOPRO/js/qr.js?raw";
import icons from "../JOPRO/js/icons.js?raw";
import sample from "../JOPRO/js/sample.js?raw";
import core from "../JOPRO/js/core.js?raw";
import screensA from "../JOPRO/js/screens-a.js?raw";
import screensB from "../JOPRO/js/screens-b.js?raw";
import gallery from "../JOPRO/js/gallery.js?raw";
import app from "../JOPRO/js/app.js?raw";

const SCRIPTS = [qr, icons, sample, core, screensA, screensB, gallery, app];

export default function App() {
  useEffect(() => {
    const w = window as unknown as { __sisiLoaded?: boolean };
    if (w.__sisiLoaded) return;
    w.__sisiLoaded = true;
    for (const code of SCRIPTS) {
      const s = document.createElement("script");
      s.textContent = code;
      document.body.appendChild(s);
    }
  }, []);
  return <div id="jopro-root" />;
}
