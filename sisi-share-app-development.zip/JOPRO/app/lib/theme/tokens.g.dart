// GENERATED FROM design/tokens.json — DO NOT EDIT. Run: node scripts/gen-tokens.mjs
// ignore_for_file: constant_identifier_names
import 'package:flutter/animation.dart';
import 'dart:ui';

abstract final class BrandColors {
  static const Color primary = Color(0xFF5B5BF7);
  static const Color primaryStrong = Color(0xFF4343E0);
  static const Color accent = Color(0xFF1ED3A0);
  static const Color warm = Color(0xFFFFB547);
  static const Color danger = Color(0xFFF2546B);
  static const Color info = Color(0xFF38B6FF);
}

abstract final class FileTypeColors {
  static const Color image = Color(0xFFFF8A5B);
  static const Color video = Color(0xFFF2546B);
  static const Color audio = Color(0xFFB36BFF);
  static const Color document = Color(0xFF38B6FF);
  static const Color archive = Color(0xFFFFB547);
  static const Color app = Color(0xFF1ED3A0);
  static const Color contact = Color(0xFF5B8CFF);
  static const Color other = Color(0xFF8C93AE);
}

const List<Color> kAvatarColors = [Color(0xFF5B5BF7), Color(0xFF1ED3A0), Color(0xFFFF8A5B), Color(0xFFB36BFF), Color(0xFF38B6FF), Color(0xFFF2546B), Color(0xFFFFB547), Color(0xFF2BB673)];

class SisiPalette {
  const SisiPalette({required this.bg, required this.bgElevated, required this.surface, required this.surface2, required this.surface3, required this.outline, required this.outlineSoft, required this.text, required this.textMuted, required this.textFaint, required this.primary, required this.onPrimary, required this.primaryContainer, required this.onPrimaryContainer, required this.accent, required this.accentContainer, required this.warm, required this.warmContainer, required this.danger, required this.dangerContainer, required this.success, required this.scrim, required this.radarRing, required this.homeWallpaperA, required this.homeWallpaperB});
  final Color bg;
  final Color bgElevated;
  final Color surface;
  final Color surface2;
  final Color surface3;
  final Color outline;
  final Color outlineSoft;
  final Color text;
  final Color textMuted;
  final Color textFaint;
  final Color primary;
  final Color onPrimary;
  final Color primaryContainer;
  final Color onPrimaryContainer;
  final Color accent;
  final Color accentContainer;
  final Color warm;
  final Color warmContainer;
  final Color danger;
  final Color dangerContainer;
  final Color success;
  final Color scrim;
  final Color radarRing;
  final Color homeWallpaperA;
  final Color homeWallpaperB;
  static const SisiPalette dark = SisiPalette(
    bg: Color(0xFF0A0C16),
    bgElevated: Color(0xFF10131F),
    surface: Color(0xFF151928),
    surface2: Color(0xFF1C2133),
    surface3: Color(0xFF252B40),
    outline: Color(0xFF2C3350),
    outlineSoft: Color(0xFF1F2438),
    text: Color(0xFFEEF0FA),
    textMuted: Color(0xFF9AA1BD),
    textFaint: Color(0xFF646B88),
    primary: Color(0xFF7B7BFF),
    onPrimary: Color(0xFF0A0C16),
    primaryContainer: Color(0xFF25265C),
    onPrimaryContainer: Color(0xFFD9D9FF),
    accent: Color(0xFF2EE6B0),
    accentContainer: Color(0xFF0E3D33),
    warm: Color(0xFFFFC266),
    warmContainer: Color(0xFF45331A),
    danger: Color(0xFFFF6B80),
    dangerContainer: Color(0xFF4A1C26),
    success: Color(0xFF2EE6B0),
    scrim: Color(0x9E04050C),
    radarRing: Color(0x387B7BFF),
    homeWallpaperA: Color(0xFF1B1F4A),
    homeWallpaperB: Color(0xFF0B3B3A),
  );
  static const SisiPalette light = SisiPalette(
    bg: Color(0xFFF4F5FB),
    bgElevated: Color(0xFFFFFFFF),
    surface: Color(0xFFFFFFFF),
    surface2: Color(0xFFEEF0F8),
    surface3: Color(0xFFE3E6F2),
    outline: Color(0xFFD3D7E6),
    outlineSoft: Color(0xFFE6E8F2),
    text: Color(0xFF12152A),
    textMuted: Color(0xFF5B6280),
    textFaint: Color(0xFF8C93AE),
    primary: Color(0xFF4B4BE8),
    onPrimary: Color(0xFFFFFFFF),
    primaryContainer: Color(0xFFE3E3FF),
    onPrimaryContainer: Color(0xFF1D1D6B),
    accent: Color(0xFF0C9F77),
    accentContainer: Color(0xFFD5F6EC),
    warm: Color(0xFFC77A0A),
    warmContainer: Color(0xFFFFEFD6),
    danger: Color(0xFFD93451),
    dangerContainer: Color(0xFFFFE1E6),
    success: Color(0xFF0C9F77),
    scrim: Color(0x6B12152A),
    radarRing: Color(0x294B4BE8),
    homeWallpaperA: Color(0xFFC9CCF7),
    homeWallpaperB: Color(0xFFBFEDE0),
  );
}

abstract final class SisiSpace {
  static const double s0 = 0.0;
  static const double s1 = 4.0;
  static const double s2 = 8.0;
  static const double s3 = 12.0;
  static const double s4 = 16.0;
  static const double s5 = 20.0;
  static const double s6 = 24.0;
  static const double s7 = 32.0;
  static const double s8 = 40.0;
  static const double s9 = 48.0;
  static const double s10 = 64.0;
}

abstract final class SisiRadius {
  static const double xs = 6.0;
  static const double sm = 10.0;
  static const double md = 14.0;
  static const double lg = 20.0;
  static const double xl = 28.0;
  static const double pill = 999.0;
  static const double widget = 22.0;
  static const double notification = 18.0;
}

abstract final class SisiSize {
  static const double touchMin = 48.0;
  static const double icon = 22.0;
  static const double iconSm = 18.0;
  static const double avatarSm = 36.0;
  static const double avatarMd = 48.0;
  static const double avatarLg = 72.0;
  static const double appBar = 64.0;
  static const double navBar = 72.0;
  static const double navRail = 88.0;
  static const double fab = 60.0;
  static const double thumb = 104.0;
  static const double listItem = 64.0;
  static const double radar = 280.0;
  static const double breakpointWide = 840.0;
}

class SisiTypeSpec {
  const SisiTypeSpec(this.size, this.line, this.weight, this.tracking);
  final double size, line, tracking;
  final int weight;
  double get height => line / size;
}

abstract final class SisiType {
  static const String familyBase = 'IBM Plex Sans Arabic';
  static const String familyNumeric = 'Space Grotesk';
  static const SisiTypeSpec display = SisiTypeSpec(34, 42, 700, -0.5);
  static const SisiTypeSpec headline = SisiTypeSpec(24, 32, 700, -0.2);
  static const SisiTypeSpec title = SisiTypeSpec(18, 26, 600, 0);
  static const SisiTypeSpec subtitle = SisiTypeSpec(15, 22, 600, 0);
  static const SisiTypeSpec body = SisiTypeSpec(14, 22, 400, 0);
  static const SisiTypeSpec label = SisiTypeSpec(13, 18, 500, 0.1);
  static const SisiTypeSpec caption = SisiTypeSpec(12, 16, 400, 0.2);
  static const SisiTypeSpec micro = SisiTypeSpec(10.5, 14, 600, 0.4);
  static const SisiTypeSpec metric = SisiTypeSpec(28, 32, 700, -0.5);
}

abstract final class SisiMotion {
  static const Duration instant = Duration(milliseconds: 90);
  static const Duration short = Duration(milliseconds: 160);
  static const Duration medium = Duration(milliseconds: 260);
  static const Duration long = Duration(milliseconds: 420);
  static const Duration extraLong = Duration(milliseconds: 640);
  static const Duration radarPulse = Duration(milliseconds: 2400);
  static const Duration progressTick = Duration(milliseconds: 1000);
  static const Cubic standardCurve = Cubic(0.2, 0, 0, 1);
  static const Cubic emphasizedCurve = Cubic(0.2, 0, 0, 1);
  static const Cubic emphasizedDecelerateCurve = Cubic(0.05, 0.7, 0.1, 1);
  static const Cubic emphasizedAccelerateCurve = Cubic(0.3, 0, 0.8, 0.15);
  static const Cubic springCurve = Cubic(0.34, 1.36, 0.64, 1);
  static const Cubic linearCurve = Cubic(0, 0, 1, 1);
  static const double lowEndDurationScale = 0.7;
  static const int lowEndRadarRings = 1;
}
