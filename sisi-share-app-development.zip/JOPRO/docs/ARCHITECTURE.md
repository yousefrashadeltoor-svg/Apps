# SISI Share — وثيقة المعمارية (مختصرة · v0.1)

> الحالة: **المرحلة 0 مكتملة** (التصميم + المعاينة). المراحل 1–8 تبدأ بعد موافقة المالك على الشكل.

## 1. الطبقات
```
┌──────────────────────── Flutter UI (app/  +  web_client/) ────────────────────────┐
│  الثيم من tokens.g.dart · Riverpod للحالة · go_router · Isolates للفهرسة والمصغرات │
└───────────────▲──────────────────────────────────────────────▲────────────────────┘
                │ flutter_rust_bridge (أحداث + أوامر، بلا بيانات كبيرة) │ MethodChannel/Pigeon
┌───────────────┴─────────── core/ (Rust) ───────┐   ┌──────────┴──── android/ (Kotlin) ─────────────┐
│ protocol/  LocalSend v2.1 + /api/nova/v1       │   │ TransferService (FGS: connectedDevice/        │
│ discovery/ multicast · mDNS · subnet · (BLE↔K) │   │   mediaPlayback/dataSync) + UIDT (API 34+)    │
│ transfer/  ranges · pipelining · resume ·      │   │ MediaStore/SAF → ParcelFileDescriptor.detachFd│
│            fan-out multi-send · BLAKE3         │◄──┤ WifiP2p · LocalOnlyHotspot · WifiAware · NSD  │
│ net/       tokio · hyper/axum · rustls · tune  │fd │ Locks (Wake/Wifi/Multicast) · bindSocket      │
│ security/  certs · pinning · PIN · ratelimit   │   │ Notifications · Glance widgets · QS Tile      │
│ web/       static (gz/br) · ZIP64 stream · up  │   │ PackageInstaller sessions · ARSCLib/apksig    │
│ watch/     Range · ring cache · WS sync · remux│   │ Contacts (vCard) · ShareTarget · Shortcuts    │
│ bench/     self-calibration (AES/conn/buffer)  │   │ Room (sessions/resume/history) · Keystore     │
└────────────────────────────────────────────────┘   └───────────────────────────────────────────────┘
```

## 2. القرارات الأساسية
| القرار | السبب |
|---|---|
| النواة بـ Rust وتعمل كخادم HTTP واحد على 53317 (LocalSend) و/api/nova/v1 للقدرات الإضافية | توافق مع تطبيقات LocalSend الأصلية + سرعة + قابلية النقل لسطح المكتب/iOS لاحقًا |
| الملفات تمر كـ **fd** وليس كبيانات (Kotlin يفتح `ParcelFileDescriptor` ← `detachFd()` ← Rust `File::from_raw_fd`) | لا نسخ بين Dart/Java/Rust، وأداء قريب من الملفات العادية لروابط content:// |
| الاستقبال: `fallocate` ثم `pwrite` بإزاحات من عدة خيوط، ثم `IS_PENDING=0` بعد التحقق | كشف امتلاء التخزين مبكرًا، وتجزؤ أقل، ونشر ذري |
| التوازي **يُقاس**: يبدأ بـ 2 اتصال ويزيد فقط عند تحسّن مُثبت | على رابط Wi-Fi واحد التوازي يخفي زمن الاستجابة ولا يزيد العرض الفيزيائي |
| التشفير: TLS 1.3 (rustls). AES-GCM إن وُجد تسريع عتادي (قياس فعلي + cpuinfo)، وإلا ChaCha20 | الأجهزة الضعيفة بلا AES عتادي تخسر كثيرًا مع AES |
| وضع الأداء الأقصى = بلا تشفير المحتوى + مصادقة كل مقطع (BLAKE3 keyed بمفتاح المصافحة) | سرعة `sendfile` مع منع حقن البيانات. معطّل افتراضيًا ومع تحذير |
| الحالة الدائمة في Room (Kotlin): الجلسات، والمقاطع المنتهية، والبصمات، والسجل، والثقة/الحظر | الاستئناف بعد قتل العملية، و`onTimeout` |
| Flavors: `play` / `full` | سياسات Google Play مقابل التوزيع المباشر/F-Droid |
| عميل الويب = Flutter Web (CanvasKit محلي) يخدمه core/web من assets مضغوطة مسبقًا | نفس الكود والتصميم، ويعمل بدون إنترنت |

## 3. تدفق الإرسال (مختصر)
1. المستخدم يختار الملفات (MediaStore/SAF/Share Target) ← URIs.
2. صفحة النقل: فحص الجاهزية (ConnectivityManager/WifiManager/الصلاحيات) ← اختيار المستلمين.
3. Kotlin يبدأ `TransferService` (أو UIDT على 34+) ← يفتح fds ← `core.send(session, fds, peers)`.
4. Rust: `/register` → `/prepare-upload` (أو `/api/nova/v1/prepare` عند تطابق القدرات) → رفع المقاطع (ranges) عبر N اتصالات → BLAKE3 → إتمام.
5. أحداث التقدم (≤ 1/ثانية) ← Dart (الواجهة) وKotlin (الإشعار + الويدجت). Isolate منفصل للمتوسط المتحرك.

## 4. خطة المراحل ومعايير القبول
| المرحلة | المخرجات | القبول |
|---|---|---|
| 0 ✅ | tokens، design-spec، معاينة كاملة، مولّد tokens، اختبارات المعاينة | `node scripts/test-preview.mjs` = ALL PASSED، وموافقة المالك |
| 1 | core/: البروتوكول، والاكتشاف، والنقل، والأمان، والقياس الذاتي، ووضع الأداء المصادَق | `cargo test` (البروتوكول/الاستئناف/التقسيم/المسارات)، واختبار توافق مع LocalSend 1.15 على شبكة حقيقية |
| 2 | Android: Manifest، والـ flavors، والصلاحيات JIT، وFGS/UIDT، ومجلد JOPRO، وShare Target، والمدير، والفهرسة، وXAPK (3 مستويات) | `./gradlew assemblePlayRelease assembleFullRelease`، واختبارات Instrumented، ومحاذاة 16KB لكل `.so` |
| 3 | واجهات Flutter مطابقة للمعاينة | golden tests بتفاوت ≤ 2% |
| 4 | الإشعارات، والويدجتس، وQS Tile، والاختصارات | مصفوفة Android 12/14/15 لمسارات البدء من الخلفية |
| 5 | سلّم الشبكات، وBLE، وNFC، وWi-Fi Aware، وكشف العزل، وQR/القارئ | جدول LIMITATIONS بنتائج أجهزة حقيقية |
| 6 | خادم الويب وعميله، وCA محلية، وبدائل WASM | Chrome/Firefox/Safari على HTTP وHTTPS |
| 7 | المشاهدة المشتركة وسلّم الترميز | 4 مشاهدين، وانحراف < 80ms |
| 8 | Benchmark، ولقطات التطابق، والصقل، ومساعد Shizuku | تقرير A20 مقابل جهاز متوسط |
