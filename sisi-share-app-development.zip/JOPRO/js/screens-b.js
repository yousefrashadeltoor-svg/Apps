/* screens-b.js — QR، الشبكات، السجل، الإعدادات، الثقة/الحظر، الويب، المشاهدة، الأذونات، الحالات، حالة النظام. (واجهة فقط · بيانات عيّنة) */
(function (g) {
  "use strict";
  var X = g.Sisi, S = X.S, L = X.L, tx = X.tx, C = X.C, I = X.I, D = X.D, SM = X.SM, esc = X.esc;
  var SC = g.SisiScreens;
  function screen(cls, inner) { return '<section class="screen ' + (cls || "") + '">' + inner + "</section>"; }
  var QR_SAMPLES = {
    device: "sisi://connect?ip=192.168.1.24&port=53317&fp=A39F2C71D04E88B1&t=Xk29fQ",
    wifi: "WIFI:T:WPA;S:DIRECT-xQ-SISI;P:k7m2-v9pa;;",
    web: "http://192.168.1.24:53318"
  };
  X.QR_SAMPLES = QR_SAMPLES;

  /* ================= SCAN ================= */
  SC.scan = function () {
    if (S.scanDenied) {
      return screen("", C.appbar(L("مسح QR", "Scan QR"), { back: true }) + '<div class="scroll">' + C.empty("camera", "warn", L("الكاميرا غير مسموحة", "Camera not allowed"), L("رفضتَ صلاحية الكاميرا نهائيًا. ما زال بإمكانك الاتصال يدويًا أو قراءة QR من صورة في المعرض.", "Camera permission was permanently denied. You can still connect manually or read a QR from a gallery image."),
        '<button class="btn filled" data-act="toast:openSettings">' + L("فتح إعدادات التطبيق", "Open app settings") + '</button><button class="btn tonal" data-act="manual">' + L("إدخال يدوي", "Enter manually") + '</button><button class="btn text" data-act="toggleScanDenied">' + L("عرض الماسح (معاينة)", "Show scanner (preview)") + "</button>") + "</div>");
    }
    return screen("", '<div class="scanner"><div class="cam"></div><div class="vf"><b></b><b></b><b></b><b></b><div class="line"></div></div>' +
      '<div class="sc-top"><button class="icon-btn" data-act="back" aria-label="back">' + I("back", "chev") + '</button><div class="grow t-subtitle">' + L("وجّه الكاميرا نحو رمز QR", "Point the camera at a QR code") + "</div></div>" +
      '<div class="sc-bottom"><div class="row g3" style="justify-content:center"><span class="t-caption" style="opacity:.8">1×</span><div class="slider" style="width:180px"><div class="tr"><i style="width:30%"></i></div><span class="th" style="inset-inline-start:30%"></span></div><span class="t-caption" style="opacity:.8">4×</span></div>' +
      '<div class="row" style="justify-content:center;gap:16px"><button class="icon-btn' + (S.torch ? " on" : "") + '" data-act="torch" aria-label="' + L("المصباح", "Torch") + '">' + I("flash") + '</button><button class="icon-btn" data-act="toast:gallery" aria-label="' + L("من المعرض", "From gallery") + '">' + I("image") + '</button><button class="icon-btn" data-act="manual" aria-label="' + L("إدخال يدوي", "Manual") + '">' + I("pin") + "</button></div>" +
      '<div class="t-caption" style="text-align:center;opacity:.75">' + L("قارئ مدمج يعمل بدون إنترنت · يقرأ روابط الاتصال وانضمام Wi-Fi", "Built-in offline reader · reads connect links and Wi-Fi join codes") + '</div><button class="btn text sm" style="color:#fff;align-self:center" data-act="toggleScanDenied">' + L("عرض حالة رفض الكاميرا", "Show camera-denied state") + "</button></div></div>");
  };
  SC.manualSheet = function () {
    return '<div class="t-title">' + L("اتصال يدوي", "Manual connection") + '</div><p class="muted t-caption" style="margin:4px 0 16px">' + L("أدخل العنوان والمنفذ أو الكود القصير المعروض على الجهاز الآخر.", "Enter IP and port, or the short code shown on the other device.") + "</p>" +
      '<div class="field"><label>IP : Port</label><div class="input focus ltr"><input value="192.168.1.31:53317" aria-label="IP:Port"></div></div><div style="height:12px"></div><div class="field"><label>' + L("أو الكود القصير", "Or short code") + '</label><div class="input"><input class="num" placeholder="482 913" aria-label="code"></div></div>' +
      '<div class="d-acts"><button class="btn text" data-act="closeOverlay">' + L("إلغاء", "Cancel") + '</button><button class="btn filled" data-act="toast:connecting">' + L("اتصال", "Connect") + "</button></div>";
  };

  /* ================= QR SHOW ================= */
  SC.qrshow = function () {
    var m = S.qrMode, txt = QR_SAMPLES[m];
    var sub = m === "device" ? L("يحمل العنوان والمنفذ وبصمة الشهادة وتوكن مؤقت", "Carries IP, port, certificate fingerprint and a one-time token")
      : m === "wifi" ? L("امسحه بكاميرا أي هاتف للانضمام لشبكة Wi-Fi Direct", "Scan with any phone camera to join the Wi-Fi Direct network") : L("افتحه من أي متصفح على نفس الشبكة", "Open in any browser on the same network");
    var extra = m === "device" ? '<div class="card flat tight" style="margin-top:16px;text-align:center"><div class="t-caption muted">' + L("أو الكود القصير", "Or short code") + '</div><div class="code-big">482 913</div></div>'
      : m === "wifi" ? '<div class="list" style="margin-top:16px">' + C.li({ cls: "plain", t: L("اسم الشبكة", "Network"), s: '<span class="ltr num">DIRECT-xQ-SISI</span>', trail: '<button class="icon-btn" data-act="toast:copied">' + I("copy") + "</button>" }) + C.li({ cls: "plain", t: L("كلمة المرور", "Password"), s: '<span class="ltr num">k7m2-v9pa</span>', trail: '<button class="icon-btn" data-act="toast:copied">' + I("copy") + "</button>" }) + "</div>"
      : '<div class="card flat tight row" style="margin-top:16px"><span class="grow ltr num t-label">' + txt + '</span><button class="icon-btn" data-act="toast:copied">' + I("copy") + "</button></div>";
    return screen("", C.appbar(L("رمز QR", "QR code"), { back: true }) + '<div class="scroll"><div style="margin-top:4px">' + C.seg([["device", L("اتصال", "Connect")], ["wifi", L("انضمام Wi-Fi", "Join Wi-Fi")], ["web", L("رابط الويب", "Web link")]], m, "qrMode") + "</div>" +
      '<div style="margin-top:24px" data-qrwrap><div class="qr-box">' + g.SisiQR.svg(txt, { quiet: 2, fg: "#0A0C16" }) + '<div class="qr-logo">' + I(m === "wifi" ? "wifi" : m === "web" ? "globe" : "send", "", 22) + '</div></div></div><p class="t-caption muted" style="text-align:center;margin:14px 24px 0">' + sub + "</p>" + extra +
      '<div class="row" style="justify-content:center;margin-top:16px">' + C.chip(L("رمز حقيقي يُرسم محليًا", "Real QR rendered locally"), "ok", "check") + C.chip(L("PIN اختياري", "Optional PIN"), "", "lock") + '</div><div style="height:24px"></div></div>');
  };

  /* ================= NETWORK LADDER ================= */
  SC.network = function () {
    var lv = [
      ["hotspot", L("هوتسبوت باسم وكلمة مخصصين", "Hotspot with custom name & password"), L("يتطلب مساعد الصلاحيات (Shizuku/Root) · معطّل", "Requires Privileged Helper (Shizuku/Root) · off"), "opt", L("تفعيل المساعد", "Enable helper"), "go:settings"],
      ["direct", L("Wi-Fi Direct (Legacy-AP)", "Wi-Fi Direct (Legacy-AP)"), L("نشط · DIRECT-xQ-SISI · 2.4GHz (5GHz غير مدعوم لهذه المجموعة) · العنوان 192.168.49.1", "Active · DIRECT-xQ-SISI · 2.4GHz (5GHz unsupported for this group) · 192.168.49.1"), "ok", L("عرض QR الانضمام", "Show join QR"), "qrWifi"],
      ["hotspot", "LocalOnlyHotspot", L("الاسم وكلمة المرور يولّدهما النظام ولا يمكن تغييرهما", "Name & password are system-generated and cannot be changed"), "opt", L("تشغيل", "Start"), "toast:loh"],
      ["settings", L("الهوتسبوت اليدوي", "Manual hotspot"), L("لا يمكن تشغيله برمجيًا · نفتح الإعدادات ونكتشف التفعيل تلقائيًا", "Cannot be started programmatically · we open settings and auto-detect"), "opt", L("فتح الإعدادات", "Open settings"), "toast:openSettings"],
      ["direct", "Wi-Fi Aware (NAN)", L("غير مدعوم في عتاد هذا الجهاز · يُخفى في التطبيق الحقيقي", "Not supported by this device's hardware · hidden in the real app"), "bad", "", ""]
    ];
    return screen("", C.appbar(L("شبكة بدون راوتر", "No-router network"), { back: true, sub: L("سلّم القدرات · من الأقوى إلى الأضمن", "Capability ladder · strongest to safest") }) + '<div class="scroll">' +
      C.banner("ok", "check", "<b>" + L("المستوى الفعّال: Wi-Fi Direct", "Active level: Wi-Fi Direct") + "</b><br>" + L("الأعلى منه غير متاح لأن مساعد الصلاحيات معطّل.", "The higher level is unavailable because the Privileged Helper is off.")) +
      '<div class="list" style="margin-top:12px">' + lv.map(function (l, i) {
        return '<div class="li" style="align-items:flex-start;padding-top:12px;padding-bottom:12px"><div class="ready-ic ' + l[3] + '" style="margin-top:2px"><span class="num t-label" style="font-weight:700">' + (i + 1) + '</span></div><div class="grow"><div class="li-t">' + l[1] + '</div><div class="li-s" style="white-space:normal">' + l[2] + "</div>" + (l[4] ? '<button class="btn sm ' + (l[3] === "ok" ? "filled" : "outlined") + '" style="margin-top:8px" data-act="' + l[5] + '">' + l[4] + "</button>" : "") + "</div></div>";
      }).join("") + "</div>" +
      C.sectionH(L("الانضمام من الطرف الآخر", "Joining from the other side")) + '<div class="card t-caption muted" style="line-height:20px">' + L("Android 10+: WifiNetworkSpecifier للاتصال المحلي المؤقت · Android 11+: ACTION_WIFI_ADD_NETWORKS · الحاسوب والتابلت يتصلان كأي شبكة Wi-Fi عادية بدون التطبيق.", "Android 10+: WifiNetworkSpecifier for a temporary local link · Android 11+: ACTION_WIFI_ADD_NETWORKS · PCs and tablets join like any Wi-Fi network without the app.") + "</div>" +
      '<div class="card">' + C.banner("warn", "cloudOff", L("هذه الشبكة بلا إنترنت. نربط مقابس النقل بشبكة Wi-Fi (bindSocket) حتى لا يحوّل Android الاتصال إلى بيانات الجوال.", "This network has no internet. Transfer sockets are bound to the Wi-Fi network (bindSocket) so Android doesn't route over mobile data.")) + '</div><div style="height:24px"></div></div>');
  };

  /* ================= HISTORY ================= */
  SC.history = function () {
    var f = S.histFilter, items = D.history.filter(function (h) { return f === "all" || (f === "out" && h.dir === "out") || (f === "in" && h.dir === "in") || (f === "failed" && h.st !== "done"); });
    var chips = '<div class="row wrap" style="margin:4px 0 8px">' + [["all", L("الكل", "All")], ["out", L("مُرسَل", "Sent")], ["in", L("مُستلَم", "Received")], ["failed", L("فشل/أُلغي", "Failed")]].map(function (c) { return C.chip(c[1], f === c[0] ? "sel" : "", "", "histFilter:" + c[0]); }).join("") + "</div>";
    var body = "";
    if (!items.length) body = C.empty("history", "", L("لا شيء هنا", "Nothing here"), L("لا توجد عمليات بهذا التصنيف.", "No transfers match this filter."));
    [0, 1, 2].forEach(function (day) {
      var di = items.filter(function (h) { return h.day === day; }); if (!di.length) return;
      body += C.sectionH(tx(D.days[day])) + '<div class="list">' + di.map(function (h) {
        var dev = D.devices[h.dev], st = h.st === "done" ? C.chip(L("تم", "Done"), "ok") : h.st === "failed" ? C.chip(L("فشل", "Failed"), "bad") : C.chip(L("أُلغي", "Canceled"), "");
        return C.li({ act: h.st === "failed" ? "toast:retry" : "toast:open", lead: C.lead(h.k, '<span class="kind" style="position:absolute;bottom:2px;inset-inline-end:2px;width:16px;height:16px;border-radius:50%;background:var(--c-surface);color:' + (h.dir === "out" ? "var(--c-primary)" : "var(--c-accent)") + ';display:grid;place-items:center">' + I(h.dir === "out" ? "arrowUp" : "arrowDown", "", 11) + "</span>"),
          t: esc(tx(h.n)), s: (h.dir === "out" ? L("إلى ", "To ") : L("من ", "From ")) + esc(tx(dev.name)) + ' · <span class="num">' + h.s + " · " + h.time + "</span>", trail: st });
      }).join("") + "</div>";
    });
    return screen("", C.appbar(L("السجل", "History"), { right: '<button class="icon-btn" aria-label="clear" data-act="toast:cleared">' + I("trash") + "</button>" }) + '<div class="scroll">' + chips + body + '<div style="height:24px"></div></div>');
  };

  /* ================= SETTINGS ================= */
  function setLi(ic, tone, t, s, trail, act) { return C.li({ act: act, lead: '<div class="lead ftsoft ' + tone + '">' + I(ic) + "</div>", t: t, s: s, trail: trail || (act ? C.chev() : "") }); }
  function group(title, items) { return '<div class="set-group"><span class="t-micro">' + title + '</span><div class="list">' + items.join("") + "</div></div>"; }
  SC.settings = function () {
    var me = D.me;
    var profile = '<div class="card row g4" style="margin-top:4px">' + C.avatar(me.initials, me.color, "lg") + '<div class="grow"><div class="t-title">' + esc(tx(me.name)) + '</div><div class="t-caption muted">' + L("الاسم والصورة واللون يُرسلون مضغوطين عند الاكتشاف", "Name, photo and color are sent compressed on discovery") + '</div><div class="row" style="margin-top:8px;gap:6px">' + [0, 1, 2, 3, 4].map(function (c) { return '<span class="avatar av-' + c + '" style="width:22px;height:22px;' + (c === 0 ? "box-shadow:0 0 0 2px var(--c-bg),0 0 0 4px var(--c-primary)" : "") + '"></span>'; }).join("") + "</div></div></div>";
    return screen("", C.appbar(L("الإعدادات", "Settings")) + '<div class="scroll">' + profile +
      group(L("الاستقبال", "Receiving"), [
        setLi("folder", "c-primary", L("مجلد الاستقبال", "Receive folder"), '<span class="ltr">Download/JOPRO</span> · MediaStore', "", "folderSheet"),
        setLi("grid", "c-primary", L("التنظيم التلقائي", "Auto-organize"), L("حسب النوع: Images · Videos · Music · Documents · Apps · Contacts · Archives", "By type: Images · Videos · Music · Documents · Apps · Contacts · Archives"), '<span class="chip">' + L("النوع", "Type") + "</span>"),
        setLi("shield", "c-accent", L("الموافقة على الاتصالات", "Connection approval"), L("للأجهزة الجديدة فقط", "New devices only"), "", "go:trust")]) +
      group(L("الشبكة والنقل", "Network & transfer"), [
        setLi("hotspot", "c-accent", L("المنفذ", "Port"), '<span class="num">53317</span> · ' + L("متوافق مع LocalSend", "LocalSend compatible"), '<span class="chip num">53317</span>'),
        setLi("direct", "c-accent", L("اسم الشبكة وكلمة المرور", "Network name & password"), L("Wi-Fi Direct: DIRECT-xQ-<مخصص> · LocalOnlyHotspot: يحدده النظام", "Wi-Fi Direct: DIRECT-xQ-<custom> · LocalOnlyHotspot: system-defined"), "", "go:network"),
        setLi("bolt", "c-warm", L("وضع الأداء الأقصى", "Max performance mode"), L("بدون تشفير المحتوى · مع مصادقة كل مقطع", "No content encryption · every chunk authenticated"), C.sw(S.perfMode, "perfMode")),
        setLi("lock", "c-accent", L("التشفير", "Encryption"), "TLS 1.3 · " + L("AES-GCM تلقائيًا عند دعم العتاد وإلا ChaCha20", "AES-GCM when hardware supports it, else ChaCha20"), C.sw(S.encrypt, "toggleEncrypt")),
        setLi("swap", "c-primary", L("الاتصالات المتوازية", "Parallel connections"), S.parallelAuto ? L("تلقائي (مقاس) · 2–8", "Auto (measured) · 2–8") : L("يدوي · 4", "Manual · 4"), C.sw(S.parallelAuto, "parallelAuto")),
        setLi("shield", "c-primary", L("فحص السلامة BLAKE3", "BLAKE3 integrity"), L("افتراضي للملفات > 256MB", "Default for files > 256MB"), C.sw(S.integrity, "toggleIntegrity"))]) +
      group(L("الويب والخلفية", "Web & background"), [
        setLi("globe", "c-primary", L("مشاركة الويب", "Web share"), "HTTP · " + L("HTTPS اختياري بشهادة CA محلية · PIN", "optional HTTPS with local CA · PIN"), "", "go:web"),
        setLi("timer", "c-warm", L("سلوك الخلفية", "Background behavior"), L("وضع الاستقبال كخدمة أمامية · إيقاف بعد 30 د خمول", "Receive mode as foreground service · stop after 30 min idle"), ""),
        setLi("key", "c-warm", L("مساعد الصلاحيات (Shizuku/Root)", "Privileged Helper (Shizuku/Root)"), L("اختياري · معطّل · قائمة أوامر بيضاء ثابتة", "Optional · off · fixed command allow-list"), C.sw(S.helper, "helper"))]) +
      group(L("الإشعارات والويدجتس", "Notifications & widgets"), [
        setLi("bell", "c-primary", L("قنوات الإشعارات", "Notification channels"), L("الجلسات · الطلبات · الاكتمال · الويب/المشاهدة", "Sessions · Requests · Completion · Web/Watch"), "", "toast:channels"),
        setLi("lock", "c-primary", L("خصوصية شاشة القفل", "Lock-screen privacy"), L("إخفاء أسماء الملفات (نسخة عامة)", "Hide file names (public version)"), C.sw(S.lockPrivacy, "lockPrivacy")),
        setLi("widget", "c-primary", L("أسماء الملفات على الويدجتس", "File names on widgets"), L("مخفية افتراضيًا", "Hidden by default"), C.sw(S.showNames, "showNames"))]) +
      group(L("النظام", "System"), [
        setLi("key", "c-accent", L("الأذونات", "Permissions"), L("حالة حية لكل صلاحية", "Live status of every permission"), "", "go:permissions"),
        setLi("cpu", "c-accent", L("حالة النظام", "System status"), L("المستوى الفعّال لكل ميزة وقدرات الجهاز", "Active level per feature & device capabilities"), "", "go:system"),
        setLi("block", "c-danger", L("الحظر والموثوق", "Blocked & trusted"), L("4 موثوق · 1 محظور", "4 trusted · 1 blocked"), "", "go:trust"),
        setLi("history", "c-primary", L("السجل", "History"), L("مسح السجل", "Clear history"), "", "go:history"),
        setLi("language", "c-primary", L("اللغة والثيم", "Language & theme"), L("العربية · داكن (من شريط المعاينة)", "Arabic · dark (from preview bar)"), "")]) +
      '<p class="t-caption faint" style="text-align:center;margin:20px 0">SISI Share 0.1.0 · ' + L("بدون إنترنت · بدون تتبع", "Offline · no tracking") + '</p></div>');
  };
  SC.folderSheet = function () {
    var opt = function (on, t, s, badge) { return '<div class="li' + (on ? " selected" : "") + '" style="border-radius:14px;align-items:flex-start;padding-top:12px;padding-bottom:12px"><span class="checkbox' + (on ? " on" : "") + '" style="border-radius:50%;margin-top:2px">' + I("check") + '</span><div class="grow"><div class="li-t">' + t + (badge ? ' <span class="badge">' + badge + "</span>" : "") + '</div><div class="li-s" style="white-space:normal">' + s + "</div></div></div>"; };
    return '<div class="t-title">' + L("مجلد الاستقبال", "Receive folder") + '</div><div style="height:12px"></div>' +
      opt(true, '<span class="ltr">Download/JOPRO</span>', L("الافتراضي · عبر MediaStore بدون أي صلاحية (API 29+)", "Default · via MediaStore, no permission (API 29+)")) +
      opt(false, L("مجلد تختاره (SAF)", "A folder you choose (SAF)"), L("نرشدك لإنشاء مجلد JOPRO ومنحه · صلاحية دائمة", "We guide you to create & grant a JOPRO folder · persistable")) +
      opt(false, '<span class="ltr">/sdcard/JOPRO</span>', L("الجذر مباشرة يتطلب «الوصول لكل الملفات» على Android 11+ · نسخة full فقط", "Storage root needs All-files access on Android 11+ · full flavor only"), "full") +
      '<div class="d-acts"><button class="btn filled" data-act="closeOverlay">' + L("تم", "Done") + "</button></div>";
  };

  /* ================= TRUST / BLOCK ================= */
  SC.trust = function () {
    var body = S.trustSeg === "trusted"
      ? '<div class="list">' + D.devices.filter(function (d) { return d.trusted; }).concat([D.devices[3]]).map(function (d, i) { return C.li({ lead: C.devAvatar(d), t: esc(tx(d.name)), s: '<span class="fp" style="padding:0 4px">' + d.fp + "</span>", trail: '<div class="col" style="align-items:center;gap:2px"><span class="t-micro faint">' + L("تلقائي", "Auto") + "</span>" + C.sw(i < 2, "noop") + "</div>" }); }).join("") + '</div><p class="t-caption muted" style="margin-top:12px">' + L("القبول التلقائي متاح للمفضلة فقط. البصمة مُثبّتة (pinning) بعد أول اتصال.", "Auto-accept is available for favorites only. Fingerprints are pinned after first contact.") + "</p>"
      : '<div class="list">' + D.blocked.map(function (b) { return C.li({ lead: C.avatar("?", b.color), t: esc(b.name), s: '<span class="fp" style="padding:0 4px">' + b.fp + "</span> · " + tx(b.when), trail: '<button class="btn sm outlined" data-act="toast:unblocked">' + L("إلغاء الحظر", "Unblock") + "</button>" }); }).join("") + "</div>" +
        C.banner("info", "shield", L("الحظر بالبصمة لا بالاسم أو IP. الجهاز المحظور لا يرى حتى استجابات الاكتشاف.", "Blocking is by fingerprint, not name or IP. Blocked devices don't even see discovery responses."));
    return screen("", C.appbar(L("الحظر والموثوق", "Blocked & trusted"), { back: true }) + '<div class="scroll"><div style="margin:4px 0 16px">' + C.seg([["trusted", L("موثوق", "Trusted")], ["blocked", L("محظور", "Blocked")]], S.trustSeg, "trustSeg") + "</div>" + body + "</div>");
  };

  /* ================= WEB SHARE ================= */
  SC.web = function () {
    var url = QR_SAMPLES.web, on = S.webOn;
    var head = '<div class="card"><div class="row between"><div class="row g3"><div class="ready-ic ' + (on ? "ok" : "opt") + '">' + I("globe") + '</div><div><div class="t-subtitle">' + (on ? L("الخادم يعمل", "Server running") : L("الخادم متوقف", "Server stopped")) + '</div><div class="t-caption muted">' + (on ? L("جلستان · بانتظار موافقة واحدة", "2 sessions · 1 awaiting approval") : L("شغّله لمشاركة الملفات مع أي متصفح", "Start it to share with any browser")) + "</div></div></div>" + C.sw(on, "toggleWeb") + "</div>" +
      (on ? '<div class="row g4" style="margin-top:16px;align-items:center"><div class="qr-box" style="width:128px;padding:6px;margin:0">' + g.SisiQR.svg(url, { quiet: 1, fg: "#0A0C16" }) + '</div><div class="grow col"><span class="t-caption muted">' + L("الرابط", "Link") + '</span><span class="t-subtitle ltr num">' + url.replace("http://", "") + '</span><span class="t-caption muted ltr">jopro.local:53318</span><div class="row"><button class="btn sm tonal" data-act="toast:copied">' + I("copy", "", 16) + L("نسخ", "Copy") + "</button></div></div></div>" : "") + "</div>";
    var cfg = '<div class="list">' + C.li({ cls: "plain", t: L("البروتوكول", "Protocol"), s: S.webProto === "http" ? L("HTTP · يعمل كاملًا بدون سياق آمن", "HTTP · fully works without secure context") : L("HTTPS · شهادة CA محلية · يفتح Service Worker والحافظة", "HTTPS · local CA · unlocks Service Worker & clipboard"), trail: '<div style="width:150px">' + C.seg([["http", "HTTP"], ["https", "HTTPS"]], S.webProto, "webProto") + "</div>" }) +
      C.li({ cls: "plain", t: L("ما يُعرض للويب", "What the web can see"), s: S.webMode === "selected" ? L("ملفات ومجلدات محددة فقط", "Selected files & folders only") : L("تصفح المدير · قراءة ورفع", "Manager browse · read & upload"), trail: '<div style="width:170px">' + C.seg([["selected", L("محدد", "Selected")], ["browse", L("تصفح", "Browse")]], S.webMode, "webMode") + "</div>" }) +
      C.li({ cls: "plain", t: "PIN", s: L("مطلوب لكل جلسة جديدة · محاولات محدودة", "Required per new session · rate-limited"), trail: '<span class="chip pri num">4 8 1 9</span>' }) + "</div>";
    var sessions = '<div class="list">' + D.webSessions.map(function (s) {
      return C.li({ lead: '<div class="lead ftsoft c-primary">' + I(s.ua.indexOf("iPad") > 0 ? "tablet" : "desktop") + "</div>", t: s.ua, s: '<span class="num ltr">' + s.ip + "</span> · " + tx(s.exp), trail: s.st === "pending" ? '<div class="row" style="gap:4px"><button class="btn sm filled" data-act="toast:approved">' + L("موافقة", "Approve") + '</button><button class="icon-btn" data-act="toast:denied" aria-label="deny">' + I("close") + "</button></div>" : C.chip(L("موافَق", "Approved"), "ok") });
    }).join("") + "</div>";
    var shared = '<div class="list">' + D.webShared.slice(0, 4).map(function (f) { return C.li({ lead: f.seed && f.k === "image" ? '<div class="lead">' + SM.thumb(f.seed) + "</div>" : C.lead(f.k), t: '<span class="ltr">' + esc(f.n) + "</span>", s: '<span class="num">' + tx(f.s) + "</span>", trail: '<button class="icon-btn" aria-label="remove">' + I("close", "", 18) + "</button>" }); }).join("") + "</div>";
    return screen("", C.appbar(L("مشاركة الويب", "Web share"), { sub: L("بدون تثبيت · نفس الشبكة", "No install · same network"), right: '<button class="icon-btn" data-act="frame:desktop" aria-label="' + L("معاينة عميل الويب", "Preview web client") + '">' + I("desktop") + "</button>" }) + '<div class="scroll">' + head +
      C.sectionH(L("طلبات وجلسات المتصفح", "Browser sessions")) + sessions + C.sectionH(L("الإعدادات", "Settings")) + cfg + C.sectionH(L("المحتوى المشارك", "Shared content"), '<button class="btn text sm">' + I("plus", "", 16) + L("إضافة", "Add") + "</button>") + shared +
      '<div style="height:12px"></div>' + C.banner("info", "info", L("على HTTP لا نعتمد على ميزات السياق الآمن: التنزيل عبر مدير تنزيل المتصفح، والرفع مقطّع ومستأنف، وBLAKE3 بـ WASM.", "On HTTP we don't rely on secure-context APIs: downloads use the browser's download manager, uploads are chunked & resumable, BLAKE3 runs in WASM.")) + '<div style="height:24px"></div></div>');
  };

  /* ================= WATCH TOGETHER ================= */
  SC.watch = function () {
    var p = S.watchPlaying;
    var player = '<div class="player">' + SM.poster(7) + '<span class="chip sync-chip">' + I("users", "", 14) + L("4 مشاهدين · متزامن", "4 viewers · in sync") + '</span><div class="pl-center"><button class="pl-big" aria-label="-10" data-act="noop">' + I("refresh", "", 24) + '</button><button class="pl-big" style="width:76px;height:76px" data-act="togglePlay" aria-label="play/pause">' + I(p ? "pause" : "play", "", 30) + '</button><button class="pl-big" aria-label="+10" data-act="noop">' + I("refresh", "", 24) + "</button></div>" +
      '<div class="pl-ctrl"><div class="row between t-caption num" style="direction:ltr"><span>48:12</span><span>2:14:40</span></div><div class="bar buffer" style="--p:.36;--b:.47;margin-top:6px"><b></b><i style="transition:none"></i></div><div class="pl-row"><button class="icon-btn" aria-label="audio">' + I("audioTrack", "", 20) + '</button><button class="icon-btn" aria-label="subtitles">' + I("subtitles", "", 20) + '</button><button class="icon-btn" aria-label="speed">' + I("speed", "", 20) + '</button><span class="grow"></span><button class="icon-btn" aria-label="ratio">' + I("ratio", "", 20) + '</button><button class="icon-btn" aria-label="pip">' + I("pip", "", 20) + '</button><button class="icon-btn" aria-label="fullscreen">' + I("fullscreen", "", 20) + "</button></div></div></div>";
    var viewers = '<div class="list">' + D.viewers.map(function (v) { return C.li({ lead: C.avatar(tx(v.name).charAt(0), v.c, "sm"), t: esc(tx(v.name)), s: v.st === "host" ? L("يتحكم بالتشغيل", "Controls playback") : v.st === "sync" ? L("متزامن", "In sync") : L("متأخر · يُصحَّح تلقائيًا", "Behind · auto-correcting"), trail: v.st === "host" ? C.chip(L("المضيف", "Host"), "pri") : C.chip('<span class="num">' + v.off + "</span>", v.st === "sync" ? "ok" : "warn") }); }).join("") + "</div>";
    var ladder = '<div class="card"><div class="t-label" style="font-weight:600;margin-bottom:8px">' + L("التشغيل في المتصفحات", "Browser playback") + '</div><table class="table"><tr><th>' + L("المشاهد", "Viewer") + "</th><th>" + L("المستوى", "Level") + "</th></tr><tr><td>Chrome · PC</td><td>" + C.chip(L("تشغيل مباشر (Range)", "Direct (Range)"), "ok") + "</td></tr><tr><td>Safari · iPad</td><td>" + C.chip("fMP4 remux + AC3→AAC", "warn") + "</td></tr><tr><td>Pixel (SISI)</td><td>" + C.chip("ExoPlayer · " + L("كل الصيغ", "all formats"), "ok") + '</td></tr></table><div class="t-caption muted" style="margin-top:8px">' + L("لا تحويل فيديو ثقيل تلقائيًا. التحويل بالعتاد خيار أخير بتحذير صريح.", "No heavy video transcoding by default. Hardware transcode is an explicit, warned last resort.") + "</div></div>";
    return screen("", C.appbar(L("مشاهدة معًا", "Watch together"), { back: true, sub: '<span class="ltr">The.Long.Coast.2160p.HEVC.mkv · 18.4 GB</span>' }) + player + '<div class="scroll" style="padding-top:12px">' +
      '<div class="row between"><span class="t-label muted">' + L("من يتحكم؟", "Who controls?") + '</span><div style="width:190px">' + C.seg([["host", L("المضيف", "Host")], ["all", L("الجميع", "Everyone")]], S.watchCtrl, "watchCtrl") + "</div></div>" +
      '<div class="row wrap" style="margin-top:12px">' + C.chip("HEVC · EAC3 5.1", "", "video") + C.chip(L("3 مسارات صوت", "3 audio tracks"), "", "audioTrack") + C.chip("ASS · SRT", "", "subtitles") + C.chip(L("لا حفظ على القرص", "No disk writes"), "ok", "check") + "</div>" +
      C.sectionH(L("المشاهدون", "Viewers")) + viewers + C.sectionH(L("التوافق", "Compatibility")) + ladder + '<div style="height:12px"></div><button class="btn danger block" data-act="toast:roomEnded">' + I("stop") + L("إنهاء الغرفة", "End room") + '</button><div style="height:24px"></div></div>');
  };

  /* ================= PERMISSIONS ================= */
  var PERMS = [
    ["media", "image", ["الصور والفيديو والصوت", "Photos, videos & audio"], ["READ_MEDIA_* · VISUAL_USER_SELECTED", "READ_MEDIA_* · VISUAL_USER_SELECTED"]],
    ["notif", "bell", ["الإشعارات", "Notifications"], ["POST_NOTIFICATIONS · تُطلب عند أول نقل", "POST_NOTIFICATIONS · asked at first transfer"]],
    ["nearby", "direct", ["الأجهزة القريبة", "Nearby devices"], ["NEARBY_WIFI_DEVICES (neverForLocation)", "NEARBY_WIFI_DEVICES (neverForLocation)"]],
    ["camera", "camera", ["الكاميرا", "Camera"], ["CAMERA · لقارئ QR فقط", "CAMERA · QR reader only"]],
    ["contactsR", "contact", ["قراءة جهات الاتصال", "Read contacts"], ["READ_CONTACTS · للتصدير", "READ_CONTACTS · for export"]],
    ["contactsW", "users", ["إضافة جهات اتصال", "Write contacts"], ["WRITE_CONTACTS · للاستيراد", "WRITE_CONTACTS · for import"]],
    ["install", "app", ["تثبيت التطبيقات", "Install apps"], ["REQUEST_INSTALL_PACKAGES", "REQUEST_INSTALL_PACKAGES"]],
    ["battery", "battery", ["تجاهل تحسين البطارية", "Ignore battery optimization"], ["اختيارية · للنقل الطويل", "Optional · for long transfers"]],
    ["allFiles", "storage", ["الوصول لكل الملفات", "All files access"], ["MANAGE_EXTERNAL_STORAGE · نسخة full فقط", "MANAGE_EXTERNAL_STORAGE · full flavor only"]]
  ];
  var PST = { granted: ["ممنوحة", "Granted", "ok"], partial: ["جزئي", "Partial", "warn"], denied: ["مرفوضة", "Denied", "bad"], permanent: ["مرفوضة دائمًا", "Permanently denied", "bad"], unasked: ["تُطلب عند الحاجة", "Asked when needed", ""] };
  SC.permissions = function () {
    return screen("", C.appbar(L("الأذونات", "Permissions"), { back: true, sub: L("حالة حية · تُطلب فقط عند الحاجة", "Live status · requested only when needed") }) + '<div class="scroll">' +
      C.banner("info", "info", L("لا نطلب أي صلاحية عند أول تشغيل. كل صلاحية تُشرح قبل طلبها، والتطبيق يعمل بدون أغلبها.", "Nothing is requested at first launch. Every permission is explained first, and most features degrade gracefully without them.")) +
      '<div class="list" style="margin-top:12px">' + PERMS.map(function (p) {
        var st = S.perms[p[0]], s = PST[st];
        var btn = st === "granted" ? "" : st === "permanent" ? '<button class="btn sm outlined" data-act="toast:openSettings">' + L("الإعدادات", "Settings") + "</button>" : st === "partial" ? '<button class="btn sm tonal" data-act="toast:moreMedia">' + L("المزيد", "More") + "</button>" : '<button class="btn sm tonal" data-act="perm:' + p[0] + '">' + L("تفعيل", "Enable") + "</button>";
        return '<div class="li" style="padding-top:10px;padding-bottom:10px">' + '<div class="lead ftsoft c-primary">' + I(p[1]) + '</div><div class="grow"><div class="li-t">' + L(p[2][0], p[2][1]) + '</div><div class="li-s ltr" style="direction:inherit">' + L(p[3][0], p[3][1]) + '</div><div style="margin-top:6px">' + C.chip(L(s[0], s[1]), s[2]) + "</div></div>" + btn + "</div>";
      }).join("") + '</div><div style="height:24px"></div></div>');
  };
  SC.rationale = function (key) {
    var map = {
      nearby: ["direct", ["الأجهزة القريبة", "Nearby devices"], ["لإنشاء شبكة Wi-Fi Direct واكتشاف الأجهزة عندما لا يوجد راوتر. لا نستخدمها لتحديد موقعك.", "To create a Wi-Fi Direct network and discover devices when there's no router. Never used to locate you."], ["ستبقى الشبكة المحلية تعمل، لكن لن يتوفر Wi-Fi Direct.", "Local Wi-Fi keeps working, but Wi-Fi Direct won't be available."]],
      notif: ["bell", ["الإشعارات", "Notifications"], ["لعرض التقدم وأزرار الإيقاف والإلغاء وطلبات الاستقبال وأنت خارج التطبيق.", "To show progress, pause/cancel buttons and incoming requests while you're outside the app."], ["النقل يستمر، وتظهر التنبيهات داخل التطبيق فقط.", "Transfers continue; alerts appear in-app only."]],
      battery: ["battery", ["تحسين البطارية", "Battery optimization"], ["يقلل احتمال أن يوقف النظام النقل الطويل أو وضع الاستقبال.", "Reduces the chance the system stops long transfers or receive mode."], ["لا شيء يتعطل؛ قد يتوقف النقل الطويل جدًا في وضع Doze.", "Nothing breaks; very long transfers may pause in Doze."]],
      contactsW: ["users", ["إضافة جهات اتصال", "Write contacts"], ["لاستيراد ملف vCard المستلم بعد موافقتك.", "To import a received vCard after you confirm."], ["يمكنك حفظ ملف .vcf وفتحه بتطبيق جهات الاتصال.", "You can save the .vcf and open it with your contacts app."]],
      install: ["app", ["تثبيت التطبيقات", "Install apps"], ["لتثبيت تطبيق استلمته مباشرة. سنفتح شاشة «التثبيت من مصادر غير معروفة» لهذا التطبيق.", "To install an app you received. We'll open the “Install unknown apps” screen for SISI Share."], ["يُحفظ الملف في JOPRO/Apps ويمكنك تثبيته يدويًا.", "The file is saved to JOPRO/Apps for manual install."]],
      allFiles: ["storage", ["الوصول لكل الملفات", "All files access"], ["فقط لتبويب مجلد جذر أو وضع «تصفح المدير» للويب أو /sdcard/JOPRO.", "Only for a root-folder tab, web “Manager browse” mode, or /sdcard/JOPRO."], ["كل شيء يعمل عبر SAF والمجلد الافتراضي Download/JOPRO.", "Everything works via SAF and the default Download/JOPRO."]]
    };
    var m = map[key] || map.notif;
    return '<div class="d-ic">' + I(m[0], "", 28) + '</div><div class="t-headline">' + L(m[1][0], m[1][1]) + '</div><div class="t-label" style="font-weight:600;margin-top:16px">' + L("لماذا نحتاجها؟", "Why we need it") + '</div><p class="muted" style="margin:4px 0 0">' + L(m[2][0], m[2][1]) + '</p><div class="t-label" style="font-weight:600;margin-top:14px">' + L("ماذا لو رفضت؟", "If you decline") + '</div><p class="muted" style="margin:4px 0 0">' + L(m[3][0], m[3][1]) + "</p>" +
      '<div class="d-acts"><button class="btn text" data-act="closeOverlay">' + L("ليس الآن", "Not now") + '</button><button class="btn filled" data-act="grant:' + key + '">' + L("متابعة", "Continue") + "</button></div>";
  };

  /* ================= STATES ================= */
  SC.states = function () {
    var st = [
      ["radar", "pri", L("لا توجد أجهزة قريبة بعد", "No nearby devices yet"), L("تأكد أن الجهاز الآخر على نفس الشبكة وأن الاستقبال مفعّل فيه.", "Make sure the other device is on the same network with receiving on."), '<button class="btn tonal" data-act="go:qrshow">' + L("عرض QR", "Show QR") + "</button>"],
      ["wifiOff", "warn", L("Wi-Fi مغلق", "Wi-Fi is off"), L("نحتاج Wi-Fi أو شبكة Wi-Fi Direct للنقل المحلي.", "We need Wi-Fi or a Wi-Fi Direct network for local transfer."), '<button class="btn filled" data-act="toast:panel">' + L("فتح لوحة Wi-Fi", "Open Wi-Fi panel") + "</button>"],
      ["alert", "warn", L("الشبكة تعزل الأجهزة", "Network isolates devices"), L("سمعنا الجهاز لكن الراوتر يمنع الاتصال المباشر (AP isolation). أنشئ شبكة Wi-Fi Direct.", "We heard the device but the router blocks direct connections (AP isolation). Create a Wi-Fi Direct network."), '<button class="btn filled" data-act="go:network">' + L("التحويل لـ Wi-Fi Direct", "Switch to Wi-Fi Direct") + "</button>"],
      ["contact", "", L("جهات الاتصال مخفية", "Contacts hidden"), L("لم تسمح بقراءة جهات الاتصال، لذا التبويب فارغ. لا يُرسل شيء بدون اختيارك.", "You didn't allow reading contacts, so this tab is empty. Nothing is sent without your choice."), '<button class="btn tonal" data-act="toast:openSettings">' + L("تفعيل", "Enable") + "</button>"],
      ["storage", "bad", L("التخزين ممتلئ", "Storage full"), L("يحتاج النقل 2.4 GB والمتاح 1.1 GB. اكتشفنا ذلك قبل القبول.", "Transfer needs 2.4 GB but only 1.1 GB is free. Detected before accepting."), '<button class="btn tonal" data-act="toast:openSettings">' + L("إدارة التخزين", "Manage storage") + "</button>"],
      ["cloudOff", "bad", L("انقطع الاتصال عند 41%", "Connection lost at 41%"), L("حُفظت المقاطع المكتملة. يمكن المتابعة من آخر مقطع سليم.", "Completed chunks were saved. You can resume from the last verified chunk."), '<button class="btn filled" data-act="toast:retry">' + L("استئناف", "Resume") + "</button>"],
      ["timer", "warn", L("انتهت مهلة الخدمة (Android 15)", "Service time limit reached (Android 15)"), L("أوقف النظام النقل بعد حد dataSync اليومي. حفظنا حالة الاستئناف كاملة.", "The system stopped the transfer at the daily dataSync limit. Resume state was fully saved."), '<button class="btn filled" data-act="toast:retry">' + L("متابعة", "Continue") + "</button>"],
      ["archive", "warn", L("قيد FAT32", "FAT32 limit"), L("بطاقة الذاكرة بنظام FAT32 لا تقبل ملفات أكبر من 4GB. اختر التخزين الداخلي.", "This FAT32 SD card can't store files over 4GB. Choose internal storage."), '<button class="btn tonal" data-act="folderSheet">' + L("تغيير المجلد", "Change folder") + "</button>"]
    ];
    return screen("", C.appbar(L("الحالات الفارغة والأخطاء", "Empty & error states"), { back: true }) + '<div class="scroll">' + (S.frame === "tablet" ? '<div class="two-pane">' : "") +
      st.map(function (s) { return '<div class="card" style="margin-top:12px">' + C.empty(s[0], s[1], s[2], s[3], s[4]) + "</div>"; }).join("") + (S.frame === "tablet" ? "</div>" : "") +
      '<p class="t-caption muted" style="text-align:center;margin:16px 0">' + L("كل رسالة فشل: ماذا حدث · لماذا · الإجراء التالي بزر.", "Every failure: what happened · why · next action as a button.") + "</p></div>");
  };

  /* ================= SYSTEM STATUS ================= */
  SC.system = function () {
    var rows = [
      [L("الاكتشاف", "Discovery"), "UDP multicast", "ok", L("—", "—")],
      [L("شبكة بدون راوتر", "No-router network"), "Wi-Fi Direct", "warn", L("المساعد معطّل", "Helper off")],
      [L("الخلفية", "Background"), "UIDT (Android 14)", "ok", "—"],
      [L("التخزين", "Storage"), "MediaStore + fd", "ok", "—"],
      [L("تشفير النقل", "Transport crypto"), "AES-256-GCM", "ok", L("تسريع AES عتادي", "AES HW accel")],
      [L("التطبيقات", "Apps"), L("Splits أصلية", "Original splits"), "ok", "—"],
      [L("المتصفح", "Browser"), "HTTP + WASM", "warn", L("HTTPS غير مفعّل", "HTTPS off")],
      ["Wi-Fi Aware", L("غير متاح", "Unavailable"), "bad", L("العتاد لا يدعم", "No HW support")]
    ];
    var caps = [["phone", "Android 14 · API 34"], ["cpu", "arm64-v8a · 8 cores"], ["lock", "AES HW ✓"], ["wifi", "5GHz ✓ · Wi-Fi 6"], ["bluetooth", "BLE ✓"], ["nfc", "NFC ✓"], ["thermo", L("الحرارة: طبيعية", "Thermal: normal")], ["storage", "18.4 GB " + L("متاح", "free")]];
    return screen("", C.appbar(L("حالة النظام", "System status"), { back: true, sub: L("المستوى الفعّال لكل ميزة", "Active level per feature") }) + '<div class="scroll">' +
      '<div class="card"><table class="table"><tr><th>' + L("الميزة", "Feature") + "</th><th>" + L("المستوى الفعّال", "Active level") + "</th><th>" + L("لماذا ليس الأعلى", "Why not higher") + "</th></tr>" + rows.map(function (r) { return "<tr><td>" + r[0] + "</td><td>" + C.chip(r[1], r[2]) + '</td><td class="muted">' + r[3] + "</td></tr>"; }).join("") + "</table></div>" +
      C.sectionH(L("قدرات الجهاز المكتشفة", "Detected capabilities")) + '<div class="row wrap">' + caps.map(function (c) { return C.chip(c[1], "", c[0]); }).join("") + "</div>" +
      C.sectionH(L("صدق السرعة", "Honest speed")) + '<div class="card t-caption" style="line-height:20px">' + C.banner("warn", "signal", L("مثال Galaxy A20: Wi-Fi 2.4GHz فقط (Wi-Fi 4) · رابط 72Mbps · السقف العملي ~6MB/s. لا نعِد بسرعات 5GHz.", "Galaxy A20 example: 2.4GHz Wi-Fi only (Wi-Fi 4) · 72Mbps link · practical cap ~6MB/s. We never promise 5GHz speeds.")) + '</div><div style="height:24px"></div></div>');
  };
})(window);
