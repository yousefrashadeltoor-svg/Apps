/* core.js — حالة المعاينة + مكوّنات مشتركة + طبقات + حركات + محاكي تقدم (بيانات عيّنة فقط). */
(function (g) {
  "use strict";
  var I = g.SisiIcons.icon, SM = g.SisiSample, D = SM.data;
  var store = { get: function (k, d) { try { var v = localStorage.getItem("sisi.pv." + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem("sisi.pv." + k, JSON.stringify(v)); } catch (e) { /* file:// بدون تخزين: تجاهل */ } } };
  var weak = (navigator.hardwareConcurrency || 8) <= 4 && (navigator.deviceMemory || 8) <= 3;
  var prefersReduced = g.matchMedia && g.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var S = {
    theme: store.get("theme", "dark"), lang: store.get("lang", "ar"), frame: store.get("frame", "phone"),
    lowEnd: store.get("lowEnd", weak), reduced: store.get("reduced", prefersReduced), speed: store.get("speed", 1),
    autoLowEnd: weak, screen: store.get("screen", "home"),
    filesTab: "images", appsSeg: "installed", showSys: false, view: "grid", sel: new Set(), selecting: false,
    progressMode: "single", qrMode: "device", trustSeg: "trusted", histFilter: "all", galSeg: "notifs",
    recvOn: true, webOn: true, webMode: "selected", webProto: "http", watchPlaying: true, watchCtrl: "host",
    wcTab: "files", wcSel: new Set(), perfMode: false, encrypt: true, integrity: true, parallelAuto: true,
    showNames: false, lockPrivacy: true, helper: false, scanDenied: false, torch: false,
    ready: { wifi: "ok", net: "ok", iso: "bad", nearby: "need", storage: "ok", notif: "need", battery: "opt" },
    perms: { media: "partial", notif: "denied", nearby: "unasked", camera: "granted", contactsR: "permanent", contactsW: "unasked", install: "unasked", battery: "unasked", allFiles: "unasked" },
    pickedDevices: new Set(["d2", "d1"])
  };
  function save() { ["theme", "lang", "frame", "lowEnd", "reduced", "speed", "screen"].forEach(function (k) { store.set(k, S[k]); }); }
  function L(ar, en) { return S.lang === "ar" ? ar : en; }
  function tx(v) { return v == null ? "" : typeof v === "object" ? v[S.lang] : v; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function motionScale() { if (S.reduced) return 0.001; return (S.lowEnd ? 0.7 : 1) / S.speed; }
  function dur(name) { var base = { instant: 90, short: 160, medium: 260, long: 420, extraLong: 640 }[name] || 260; return base * motionScale(); }
  var EASE = { std: "cubic-bezier(0.2,0,0,1)", decel: "cubic-bezier(0.05,0.7,0.1,1)", accel: "cubic-bezier(0.3,0,0.8,0.15)", spring: "cubic-bezier(0.34,1.36,0.64,1)" };

  /* ---------- small components ---------- */
  var KIND_IC = { image: "image", video: "video", audio: "music", doc: "doc", archive: "archive", app: "app", contact: "contact", folder: "folder", other: "doc" };
  var C = {
    icon: I,
    avatar: function (initials, color, cls, kind) {
      return '<div class="avatar av-' + (color || 0) + " " + (cls || "") + '" aria-hidden="true">' + esc(tx(initials)) + (kind ? '<span class="kind">' + I(kind) + "</span>" : "") + "</div>";
    },
    devAvatar: function (d, cls) { return C.avatar(d.initials, d.color, cls, d.kind === "desktop" ? "desktop" : d.kind === "tablet" ? "tablet" : d.kind === "tv" ? "tv" : "phone"); },
    lead: function (kind, extra) { return '<div class="lead ft ft-' + kind + '">' + I(KIND_IC[kind] || "doc") + (extra || "") + "</div>"; },
    chip: function (text, cls, ic, act) { return '<span class="chip ' + (cls || "") + (act ? " tap" : "") + '"' + (act ? ' role="button" data-act="' + act + '"' : "") + ">" + (ic ? I(ic) : "") + text + "</span>"; },
    sw: function (on, act, label) { return '<button class="switch' + (on ? " on" : "") + '" role="switch" aria-checked="' + !!on + '" aria-label="' + esc(label || "") + '" data-act="' + act + '"></button>'; },
    seg: function (items, cur, act) {
      var i = Math.max(0, items.findIndex(function (x) { return x[0] === cur; }));
      return '<div class="seg" role="tablist" style="--n:' + items.length + '"><span class="seg-ind" style="width:calc((100% - 8px)/' + items.length + ");transform:translateX(calc(var(--dirx) * (" + i + ' * 100% + 4px)))"></span>' +
        items.map(function (x) { return '<button role="tab" aria-selected="' + (x[0] === cur) + '" class="' + (x[0] === cur ? "on" : "") + '" data-act="' + act + ":" + x[0] + '">' + x[1] + "</button>"; }).join("") + "</div>";
    },
    bar: function (p, cls, sim) { return '<div class="bar ' + (cls || "") + '" role="progressbar" aria-valuenow="' + Math.round(p * 100) + '" aria-valuemin="0" aria-valuemax="100" style="--p:' + p + '"' + (sim ? ' data-sim="p:' + sim + '"' : "") + "><i></i></div>"; },
    li: function (o) {
      return '<div class="li' + (o.act ? " tap" : "") + (o.cls ? " " + o.cls : "") + '"' + (o.act ? ' data-act="' + o.act + '"' : "") + (o.sel ? ' data-sel="' + o.sel + '"' : "") + (o.attr || "") + ">" + (o.lead || "") +
        '<div class="grow"><div class="li-t ellipsis">' + o.t + "</div>" + (o.s ? '<div class="li-s ellipsis">' + o.s + "</div>" : "") + "</div>" + (o.trail || "") + "</div>";
    },
    chev: function () { return I("chevron", "chev", 18); },
    sectionH: function (t, right) { return '<div class="section-h"><div class="t-subtitle">' + t + "</div>" + (right || "") + "</div>"; },
    appbar: function (title, opts) {
      opts = opts || {};
      return '<header class="appbar">' + (opts.back ? '<button class="icon-btn" aria-label="' + L("رجوع", "Back") + '" data-act="back">' + I("back", "chev") + "</button>" : "") +
        '<div class="ab-title"><div class="t-title ellipsis">' + title + "</div>" + (opts.sub ? '<div class="t-caption muted ellipsis">' + opts.sub + "</div>" : "") + "</div>" + (opts.right || "") + "</header>";
    },
    empty: function (ic, tone, title, text, btn) {
      return '<div class="empty"><div class="e-art ' + (tone || "") + '">' + I(ic) + '</div><div class="t-title">' + title + '</div><p class="muted">' + text + "</p>" + (btn || "") + "</div>";
    },
    banner: function (tone, ic, html, acts) { return '<div class="banner ' + tone + '">' + I(ic) + '<div class="grow">' + html + (acts ? '<div class="b-act">' + acts + "</div>" : "") + "</div></div>"; },
    kindOfFile: function (k) { return KIND_IC[k] ? k : "other"; }
  };

  /* ---------- overlays ---------- */
  var O = {
    host: function () { return document.querySelector(".app .overlay-host"); },
    open: function (html, type) {
      O.closeAll(true);
      var h = O.host(); if (!h) return;
      var wrap = document.createElement("div"); wrap.className = "ov"; wrap.style.cssText = "position:absolute;inset:0";
      wrap.innerHTML = '<div class="scrim" data-act="closeOverlay"></div>' + (type === "dialog" ? '<div class="dialog" role="dialog" aria-modal="true">' + html + "</div>" : '<div class="sheet" role="dialog" aria-modal="true"><div class="grab"></div>' + html + "</div>");
      h.appendChild(wrap);
      var f = wrap.querySelector("button"); if (f) f.focus({ preventScroll: true });
    },
    sheet: function (html) { O.open(html, "sheet"); },
    dialog: function (html) { O.open(html, "dialog"); },
    closeAll: function (instant) {
      var h = O.host(); if (!h) return;
      Array.prototype.forEach.call(h.querySelectorAll(".ov"), function (w) {
        if (instant) { w.remove(); return; }
        w.classList.add("closing"); setTimeout(function () { w.remove(); }, dur("medium") + 20);
      });
    },
    toast: function (text, ic) {
      var h = O.host(); if (!h) return;
      var t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status");
      t.innerHTML = I(ic || "info") + '<div class="grow">' + text + "</div>"; h.appendChild(t);
      setTimeout(function () { t.animate([{ opacity: 1 }, { opacity: 0 }], { duration: dur("short"), fill: "forwards" }).onfinish = function () { t.remove(); }; }, 2600);
    }
  };

  /* ---------- motion helpers ---------- */
  var M = {
    sharedAxis: function (host, newEl, forward) {
      var old = host.querySelector(".screen:not(.leaving)");
      host.appendChild(newEl);
      var d = dur("medium"), dx = 30 * (forward ? 1 : -1) * (S.lang === "ar" ? -1 : 1);
      if (old) {
        old.classList.add("leaving");
        var a = old.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: "translateX(" + (-dx) + "px)" }], { duration: d * 0.6, easing: EASE.accel, fill: "forwards" });
        a.onfinish = function () { old.remove(); };
      }
      newEl.animate([{ opacity: 0, transform: "translateX(" + dx + "px)" }, { opacity: 1, transform: "none" }], { duration: d, easing: EASE.decel, delay: old ? d * 0.25 : 0, fill: "backwards" });
    },
    hero: function (fromEl, html, appEl) {
      var r0 = fromEl.getBoundingClientRect(), ra = appEl.getBoundingClientRect(), scale = ra.width / appEl.offsetWidth || 1;
      var v = document.createElement("div"); v.className = "hero-viewer"; v.innerHTML = html; O.host().appendChild(v);
      var img = v.querySelector(".hv-img"), r1 = img.getBoundingClientRect();
      var sx = r0.width / r1.width, tx = (r0.left - r1.left) / scale, ty = (r0.top - r1.top) / scale;
      var kf = [{ transform: "translate(" + tx + "px," + ty + "px) scale(" + sx + ")", borderRadius: "12px" }, { transform: "none", borderRadius: "0" }];
      img.style.transformOrigin = "0 0";
      img.animate(kf, { duration: dur("long"), easing: EASE.std });
      v.animate([{ backgroundColor: "rgba(0,0,0,0)" }, { backgroundColor: "#000" }], { duration: dur("long"), easing: EASE.std });
      Array.prototype.forEach.call(v.querySelectorAll(".hv-bar,.hv-foot"), function (e) { e.animate([{ opacity: 0 }, { opacity: 1 }], { duration: dur("medium"), delay: dur("short"), fill: "backwards" }); });
      v._close = function () {
        var a = img.animate(kf.slice().reverse(), { duration: dur("medium"), easing: EASE.std, fill: "forwards" });
        v.animate([{ backgroundColor: "#000" }, { backgroundColor: "rgba(0,0,0,0)" }], { duration: dur("medium"), fill: "forwards" });
        Array.prototype.forEach.call(v.querySelectorAll(".hv-bar,.hv-foot"), function (e) { e.style.opacity = 0; });
        a.onfinish = function () { v.remove(); };
      };
      return v;
    }
  };

  /* ---------- progress simulator (sample data) ---------- */
  function mkT(total, base, opts) { return Object.assign({ total: total, done: 0, base: base, inst: base, ema: base, hist: [], state: "run" }, opts || {}); }
  var SIM = {
    paused: false,
    t: {
      single: mkT(1192, 4.7),
      m1: mkT(1192, 2.4), m2: mkT(1192, 1.6), m3: mkT(1192, 1.0, { failAt: 0.41 }),
      web: mkT(842, 2.0), up: mkT(268, 1.5)
    },
    tick: function (dt) {
      var r = Math.random;
      Object.keys(SIM.t).forEach(function (k) {
        var t = SIM.t[k];
        if (t.state === "done" || t.state === "failed") { t.hold = (t.hold || 0) + dt; if (t.hold > 4) { t.done = 0; t.state = "run"; t.hold = 0; t.hist = []; } return; }
        if (SIM.paused && (k === "single" || k[0] === "m")) { t.inst = 0; t.state = "paused"; } else {
          t.state = "run";
          t.inst = Math.max(0.4, t.base * (0.82 + r() * 0.36) + Math.sin(Date.now() / 3100 + k.length) * t.base * 0.08);
          t.done = Math.min(t.total, t.done + t.inst * dt * 6);
        }
        t.ema = t.ema * 0.82 + t.inst * 0.18;
        t.hist.push(t.inst); if (t.hist.length > 40) t.hist.shift();
        if (t.failAt && t.done / t.total >= t.failAt) { t.state = "failed"; t.done = t.total * t.failAt; }
        else if (t.done >= t.total) t.state = "done";
      });
    },
    p: function (k) { var t = SIM.t[k]; return t.done / t.total; },
    eta: function (k) {
      var t = SIM.t[k]; if (t.state === "done") return L("اكتمل", "Done"); if (t.state === "failed") return L("فشل", "Failed"); if (SIM.paused && k !== "web" && k !== "up") return L("متوقف مؤقتًا", "Paused");
      var s = Math.round((t.total - t.done) / Math.max(0.1, t.ema * 6)), m = Math.floor(s / 60);
      return m > 0 ? L(m + " د " + (s % 60) + " ث", m + "m " + (s % 60) + "s") : L(s + " ث", s + "s");
    },
    spd: function (k) { var t = SIM.t[k]; return (t.state === "run" ? t.inst * 6 : 0).toFixed(1); },
    spark: function (k) {
      var h = SIM.t[k].hist, n = 40, max = 0; h.forEach(function (v) { max = Math.max(max, v); }); max = max * 1.15 || 1;
      var pts = []; for (var i = 0; i < h.length; i++) pts.push(((n - h.length + i) / (n - 1) * 100).toFixed(1) + "," + (56 - (h[i] / max) * 50).toFixed(1));
      if (!pts.length) return { l: "", a: "" };
      var l = "M" + pts.join(" L"); return { l: l, a: l + " L100,56 L" + pts[0].split(",")[0] + ",56 Z" };
    },
    apply: function (root) {
      if (!root) return;
      Array.prototype.forEach.call(root.querySelectorAll("[data-sim]"), function (el) {
        var parts = el.getAttribute("data-sim").split(":"), kind = parts[0], k = parts[1], t = SIM.t[k];
        if (!t) return;
        if (kind === "p") { el.style.setProperty("--p", SIM.p(k).toFixed(4)); el.classList.toggle("fail", t.state === "failed"); el.classList.toggle("done", t.state === "done"); el.setAttribute("aria-valuenow", Math.round(SIM.p(k) * 100)); }
        else if (kind === "pct") el.textContent = Math.floor(SIM.p(k) * 100) + "%";
        else if (kind === "spd") el.textContent = SIM.spd(k);
        else if (kind === "eta") el.textContent = SIM.eta(k);
        else if (kind === "done") el.textContent = (t.done / 1024).toFixed(2) + " / " + (t.total / 1024).toFixed(2) + " GB";
        else if (kind === "doneMB") el.textContent = Math.round(t.done) + " / " + t.total + " MB";
        else if (kind === "ring") el.style.strokeDashoffset = (1 - SIM.p(k)) * 2 * Math.PI * 74;
        else if (kind === "spark") { var s = SIM.spark(k); el.querySelector(".l").setAttribute("d", s.l); el.querySelector(".a").setAttribute("d", s.a); }
        else if (kind === "st") { el.textContent = t.state === "failed" ? L("انقطع الاتصال", "Connection lost") : t.state === "done" ? L("اكتمل", "Completed") : SIM.paused && k !== "web" && k !== "up" ? L("متوقف مؤقتًا", "Paused") : L("جارٍ الإرسال", "Sending"); el.className = "chip " + (t.state === "failed" ? "bad" : t.state === "done" ? "ok" : SIM.paused ? "warn" : "pri"); }
        else if (kind === "file") {
          var idx = +parts[2], sizes = [6.2, 5.8, 1180], start = 0; for (var i = 0; i < idx; i++) start += sizes[i];
          var fp = Math.max(0, Math.min(1, (t.done - start) / sizes[idx])); el.style.setProperty("--p", fp.toFixed(4));
          var lbl = el.parentNode.querySelector("[data-fl]"); if (lbl) lbl.textContent = fp >= 1 ? L("تم ✓", "Done ✓") : fp > 0 ? Math.floor(fp * 100) + "%" : L("في الانتظار", "Queued");
        }
      });
    }
  };

  g.Sisi = { S: S, save: save, L: L, tx: tx, esc: esc, C: C, O: O, M: M, SIM: SIM, D: D, SM: SM, I: I, dur: dur, motionScale: motionScale, EASE: EASE, weak: weak };
})(window);
