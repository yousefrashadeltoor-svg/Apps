/* sample.js — بيانات عيّنة + رسومات مولّدة برمجيًا (SVG) للمعاينة فقط. لا تدخل في APK ولا web_client. */
(function (g) {
  "use strict";
  function rng(seed) { var s = seed >>> 0 || 1; return function () { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return (s % 100000) / 100000; }; }
  var uid = 0;

  /* صورة مصغرة: منظر طبيعي تجريدي */
  function thumb(seed) {
    var r = rng(seed * 7919 + 13), h = Math.floor(r() * 360), h2 = (h + 30 + r() * 80) % 360, id = "t" + (uid++);
    var sunX = 20 + r() * 60, sunY = 18 + r() * 25, m1 = 45 + r() * 20, m2 = 58 + r() * 20;
    return '<svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" class="gen"><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="hsl(' + h + ',70%,' + (55 + r() * 15) + '%)"/><stop offset="1" stop-color="hsl(' + h2 + ',65%,' + (75 + r() * 10) + '%)"/></linearGradient></defs>' +
      '<rect width="100" height="100" fill="url(#' + id + ')"/><circle cx="' + sunX + '" cy="' + sunY + '" r="' + (7 + r() * 8) + '" fill="hsl(' + ((h + 180) % 360) + ',90%,85%)" opacity=".9"/>' +
      '<path d="M0 ' + m1 + ' L' + (20 + r() * 20) + ' ' + (m1 - 15 - r() * 15) + ' L' + (50 + r() * 10) + ' ' + (m1 + 2) + ' L' + (70 + r() * 15) + ' ' + (m1 - 20) + ' L100 ' + (m1 - 4) + ' V100 H0Z" fill="hsl(' + h2 + ',35%,38%)" opacity=".8"/>' +
      '<path d="M0 ' + m2 + ' Q30 ' + (m2 - 12) + ' 55 ' + (m2 + 4) + ' T100 ' + (m2 - 6) + ' V100 H0Z" fill="hsl(' + h + ',40%,22%)"/></svg>';
  }
  /* غلاف ألبوم: هندسي */
  function cover(seed) {
    var r = rng(seed * 104729 + 7), h = Math.floor(r() * 360), s = '<svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" class="gen"><rect width="100" height="100" fill="hsl(' + h + ',55%,22%)"/>';
    for (var i = 0; i < 5; i++) s += '<circle cx="' + (r() * 100) + '" cy="' + (r() * 100) + '" r="' + (10 + r() * 35) + '" fill="hsl(' + ((h + i * 40) % 360) + ',80%,' + (50 + r() * 20) + '%)" opacity="' + (0.35 + r() * 0.4) + '"/>';
    return s + '<rect x="12" y="78" width="40" height="4" rx="2" fill="#fff" opacity=".8"/></svg>';
  }
  /* ملصق فيلم للمشاهدة المشتركة */
  function poster(seed) {
    var r = rng(seed * 31337), h = Math.floor(r() * 360);
    return '<svg viewBox="0 0 160 90" preserveAspectRatio="xMidYMid slice" class="gen"><defs><radialGradient id="pg' + seed + '" cx=".7" cy=".3" r="1"><stop offset="0" stop-color="hsl(' + ((h + 40) % 360) + ',80%,62%)"/><stop offset=".55" stop-color="hsl(' + h + ',60%,24%)"/><stop offset="1" stop-color="hsl(' + h + ',50%,8%)"/></radialGradient></defs>' +
      '<rect width="160" height="90" fill="url(#pg' + seed + ')"/><circle cx="112" cy="30" r="16" fill="hsl(' + ((h + 60) % 360) + ',90%,86%)" opacity=".85"/>' +
      '<path d="M0 70 L30 48 L52 62 L84 36 L120 64 L160 50 V90 H0Z" fill="hsl(' + h + ',40%,12%)"/><path d="M0 80 Q50 66 90 78 T160 74 V90 H0Z" fill="#05060c"/></svg>';
  }
  /* أيقونة تطبيق */
  function appIcon(seed, glyph) {
    var r = rng(seed * 6007 + 3), h = Math.floor(r() * 360), shape = Math.floor(r() * 3);
    var inner = shape === 0 ? '<circle cx="24" cy="24" r="10" fill="#fff" opacity=".92"/>' : shape === 1 ? '<rect x="14" y="14" width="20" height="20" rx="6" fill="#fff" opacity=".92"/>' : '<path d="M24 12l12 22H12z" fill="#fff" opacity=".92"/>';
    return '<svg viewBox="0 0 48 48" class="gen"><defs><linearGradient id="ai' + seed + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(' + h + ',80%,60%)"/><stop offset="1" stop-color="hsl(' + ((h + 50) % 360) + ',75%,45%)"/></linearGradient></defs><rect width="48" height="48" rx="13" fill="url(#ai' + seed + ')"/>' + inner +
      '<text x="24" y="28.5" text-anchor="middle" font-size="12" font-weight="700" font-family="Space Grotesk, sans-serif" fill="hsl(' + h + ',60%,30%)">' + (glyph || "") + "</text></svg>";
  }

  var D = {};
  D.me = { name: { ar: "هاتف سارة", en: "Sara's Phone" }, model: "Galaxy A54", ip: "192.168.1.24", port: 53317, webPort: 53318, fp: "A3:9F:2C:71:D0:4E:88:B1", color: 0, initials: { ar: "س", en: "S" } };
  D.devices = [
    { id: "d1", name: { ar: "حاسوب المكتب", en: "Office PC" }, model: "Windows 11 · LocalSend 1.15", kind: "desktop", color: 4, proto: "LocalSend v2.1", band: "5GHz", trusted: true, fp: "7C:12:E9:0A:55:3B:9D:C4", angle: 35, dist: 0.62, initials: "PC" },
    { id: "d2", name: { ar: "بكسل أحمد", en: "Ahmed's Pixel" }, model: "Pixel 7 · SISI Share", kind: "phone", color: 1, proto: "Nova v1", band: "5GHz", trusted: true, fp: "11:BE:4F:90:2D:7A:C3:08", angle: 140, dist: 0.8, initials: { ar: "أ", en: "A" } },
    { id: "d3", name: { ar: "آيباد ليلى", en: "Layla's iPad" }, model: "iPadOS · LocalSend 1.14", kind: "tablet", color: 3, proto: "LocalSend v2", band: "2.4GHz", trusted: false, fp: "E0:44:9A:6C:13:F2:58:B7", angle: 230, dist: 0.55, initials: { ar: "ل", en: "L" } },
    { id: "d4", name: { ar: "تلفاز الصالة", en: "Living-room TV" }, model: "Android TV · SISI Share", kind: "tv", color: 6, proto: "Nova v1", band: "5GHz", trusted: false, fp: "5A:D1:07:BC:E8:21:9F:36", angle: 300, dist: 0.85, initials: "TV" }
  ];
  D.albums = [
    { name: { ar: "الكاميرا", en: "Camera" }, count: 2481, seed: 3 }, { name: { ar: "لقطات الشاشة", en: "Screenshots" }, count: 612, seed: 8 },
    { name: { ar: "واتساب", en: "WhatsApp" }, count: 1934, seed: 15 }, { name: { ar: "التنزيلات", en: "Downloads" }, count: 88, seed: 21 }, { name: { ar: "رحلة الصيف", en: "Summer trip" }, count: 342, seed: 27 }
  ];
  D.images = []; for (var i = 0; i < 36; i++) D.images.push({ id: "img" + i, seed: 100 + i, size: 1.2 + ((i * 37) % 50) / 10, name: "IMG_2025" + (1100 + i) + ".jpg", group: i < 9 ? 0 : i < 21 ? 1 : 2 });
  D.imageGroups = [{ ar: "اليوم", en: "Today" }, { ar: "أمس", en: "Yesterday" }, { ar: "الأسبوع الماضي", en: "Last week" }];
  D.videos = []; for (i = 0; i < 12; i++) D.videos.push({ id: "vid" + i, seed: 300 + i, dur: ["0:42", "3:18", "12:05", "1:07", "24:51", "0:15", "7:33", "2:02", "58:10", "4:44", "0:09", "16:20"][i], size: [48, 312, 1240, 96, 2900, 12, 640, 180, 6400, 420, 6, 1600][i] });
  D.music = [
    { t: { ar: "ليالي الشرق", en: "Eastern Nights" }, a: { ar: "فرقة النخيل", en: "Palm Ensemble" }, d: "4:12", s: 21 },
    { t: { ar: "مدار", en: "Orbit" }, a: "Nova Trio", d: "3:47", s: 22 }, { t: { ar: "صدى المدينة", en: "City Echo" }, a: { ar: "رنا", en: "Rana" }, d: "5:03", s: 23 },
    { t: "Slow Tide", a: "Marea", d: "6:21", s: 24 }, { t: { ar: "طريق الساحل", en: "Coast Road" }, a: { ar: "سامي ك.", en: "Sami K." }, d: "2:58", s: 25 },
    { t: "Neon Garden", a: "Kites", d: "3:30", s: 26 }, { t: { ar: "حنين", en: "Longing" }, a: { ar: "فرقة النخيل", en: "Palm Ensemble" }, d: "4:40", s: 27 }
  ];
  D.docs = [
    { n: "Q3-Report.pdf", t: "PDF", s: "2.4 MB", d: { ar: "اليوم", en: "Today" } }, { n: "Contract_v2.docx", t: "DOCX", s: "184 KB", d: { ar: "أمس", en: "Yesterday" } },
    { n: "Budget-2025.xlsx", t: "XLSX", s: "612 KB", d: { ar: "١٢ نوفمبر", en: "Nov 12" } }, { n: "Pitch-deck.pptx", t: "PPTX", s: "18.9 MB", d: { ar: "٩ نوفمبر", en: "Nov 9" } },
    { n: "notes.txt", t: "TXT", s: "4 KB", d: { ar: "٢ نوفمبر", en: "Nov 2" } }, { n: "Passport-scan.pdf", t: "PDF", s: "1.1 MB", d: { ar: "٢٨ أكتوبر", en: "Oct 28" } }
  ];
  D.archives = [
    { n: "Project-assets.zip", t: "ZIP", s: "1.8 GB" }, { n: "Photos-backup.7z", t: "7Z", s: "6.2 GB" }, { n: "fonts.tar.gz", t: "TAR.GZ", s: "24 MB" }, { n: "Thesis.rar", t: "RAR", s: "310 MB" }
  ];
  D.installed = [
    { n: { ar: "دفتر الملاحظات", en: "Notebook" }, pkg: "com.example.notebook", v: "5.2.1", s: "48 MB", splits: 4, sys: false, seed: 41, glyph: "N" },
    { n: { ar: "خرائط المدينة", en: "City Maps" }, pkg: "org.citymaps.app", v: "11.0.3", s: "126 MB", splits: 6, sys: false, seed: 42, glyph: "M" },
    { n: { ar: "محرر الصور", en: "Photo Editor" }, pkg: "io.pixel.editor", v: "3.9", s: "84 MB", splits: 0, sys: false, seed: 43, glyph: "P" },
    { n: { ar: "قارئ الكتب", en: "Book Reader" }, pkg: "net.reader.books", v: "2.0.14", s: "31 MB", splits: 3, sys: false, seed: 44, glyph: "B" },
    { n: { ar: "الإعدادات", en: "Settings" }, pkg: "com.android.settings", v: "14", s: "22 MB", splits: 0, sys: true, seed: 45, glyph: "S" },
    { n: { ar: "لوحة المفاتيح", en: "Keyboard" }, pkg: "com.android.inputmethod", v: "14.1", s: "65 MB", splits: 2, sys: true, seed: 46, glyph: "K" }
  ];
  D.apkFiles = [
    { n: { ar: "لعبة المغامرة", en: "Adventure Game" }, f: "adventure-2.4.xapk", v: "2.4.0", s: "1.4 GB", type: "XAPK", obb: true, seed: 51, glyph: "G" },
    { n: { ar: "مدير المهام", en: "Task Manager" }, f: "tasks-7.1.apks", v: "7.1", s: "38 MB", type: "APKS", obb: false, seed: 52, glyph: "T" },
    { n: { ar: "مشغل الصوت", en: "Audio Player" }, f: "player-4.0.apk", v: "4.0.2", s: "12 MB", type: "APK", obb: false, seed: 53, glyph: "A" },
    { n: { ar: "المترجم", en: "Translator" }, f: "translator.apkm", v: "9.3", s: "56 MB", type: "APKM", obb: false, seed: 54, glyph: "L" }
  ];
  D.contacts = [
    { n: { ar: "أحمد سليم", en: "Ahmed Salim" }, p: "+966 55 120 4471", c: 1 }, { n: { ar: "ليلى منصور", en: "Layla Mansour" }, p: "+966 50 882 1903", c: 3 },
    { n: { ar: "خالد العتيبي", en: "Khaled Otaibi" }, p: "+966 54 300 7712", c: 4 }, { n: { ar: "مريم حداد", en: "Maryam Haddad" }, p: "+971 52 611 0045", c: 2 },
    { n: { ar: "يوسف ناصر", en: "Yousef Nasser" }, p: "+20 100 455 8812", c: 5 }, { n: { ar: "نور الهدى", en: "Nour Alhuda" }, p: "+962 79 812 3340", c: 6 }
  ];
  D.downloads = [
    { n: "invoice-8812.pdf", k: "doc", s: "220 KB" }, { n: "wallpaper-pack.zip", k: "archive", s: "86 MB" }, { n: "lecture-04.mp4", k: "video", s: "412 MB" },
    { n: "podcast-ep12.mp3", k: "audio", s: "54 MB" }, { n: "contacts-backup.vcf", k: "contact", s: "38 KB" }
  ];
  D.custom = { name: { ar: "مشاريع العمل", en: "Work projects" }, path: "Documents/Projects", items: [
    { n: "Brand-2025", folder: true, c: 14 }, { n: "Client-Atlas", folder: true, c: 32 }, { n: "brief.pdf", k: "doc", s: "1.3 MB" }, { n: "moodboard.png", k: "image", s: "4.8 MB" }, { n: "timeline.xlsx", k: "doc", s: "96 KB" }
  ] };
  D.history = [
    { dir: "out", n: { ar: "٣ ملفات · رحلة الصيف", en: "3 files · Summer trip" }, k: "image", dev: 1, s: "48 MB", st: "done", day: 0, time: "14:32" },
    { dir: "in", n: "Q3-Report.pdf", k: "doc", dev: 0, s: "2.4 MB", st: "done", day: 0, time: "11:05" },
    { dir: "out", n: "lecture-04.mp4", k: "video", dev: 3, s: "412 MB", st: "failed", day: 0, time: "09:48" },
    { dir: "in", n: "adventure-2.4.xapk", k: "app", dev: 1, s: "1.4 GB", st: "done", day: 1, time: "22:10" },
    { dir: "out", n: { ar: "١٢ جهة اتصال", en: "12 contacts" }, k: "contact", dev: 2, s: "38 KB", st: "done", day: 1, time: "18:41" },
    { dir: "in", n: "Project-assets.zip", k: "archive", dev: 0, s: "1.8 GB", st: "canceled", day: 1, time: "10:02" },
    { dir: "out", n: "Neon Garden.mp3", k: "audio", dev: 2, s: "8 MB", st: "done", day: 2, time: "20:15" }
  ];
  D.days = [{ ar: "اليوم", en: "Today" }, { ar: "أمس", en: "Yesterday" }, { ar: "الإثنين", en: "Monday" }];
  D.blocked = [{ name: "Unknown-Android", fp: "9E:03:7B:44:A1:C8:20:5F", when: { ar: "حُظر منذ ٣ أيام", en: "Blocked 3 days ago" }, color: 5 }];
  D.webSessions = [
    { ua: "Chrome · Windows", ip: "192.168.1.31", st: "approved", exp: { ar: "تنتهي بعد ٤٢ دقيقة", en: "Expires in 42 min" } },
    { ua: "Safari · iPad", ip: "192.168.1.40", st: "pending", exp: { ar: "بانتظار موافقتك", en: "Waiting for your approval" } }
  ];
  D.viewers = [
    { name: { ar: "أنت (المضيف)", en: "You (host)" }, c: 0, st: "host", off: "—" },
    { name: { ar: "بكسل أحمد", en: "Ahmed's Pixel" }, c: 1, st: "sync", off: "±12ms" },
    { name: { ar: "Chrome · حاسوب المكتب", en: "Chrome · Office PC" }, c: 4, st: "sync", off: "±31ms" },
    { name: { ar: "آيباد ليلى", en: "Layla's iPad" }, c: 3, st: "late", off: "+1.4s" }
  ];
  D.transferFiles = [
    { n: "summer-01.jpg", k: "image", size: 6.2, seed: 120 }, { n: "summer-02.jpg", k: "image", size: 5.8, seed: 121 },
    { n: "beach-walk.mp4", k: "video", size: 1180, seed: 305 }
  ];
  D.webShared = [
    { n: "Summer trip", k: "folder", s: { ar: "٣٤٢ عنصر", en: "342 items" } }, { n: "beach-walk.mp4", k: "video", s: "1.2 GB", seed: 305 },
    { n: "Q3-Report.pdf", k: "doc", s: "2.4 MB" }, { n: "summer-01.jpg", k: "image", s: "6.2 MB", seed: 120 },
    { n: "summer-02.jpg", k: "image", s: "5.8 MB", seed: 121 }, { n: "Neon Garden.mp3", k: "audio", s: "8 MB", seed: 26 }
  ];

  g.SisiSample = { data: D, thumb: thumb, cover: cover, poster: poster, appIcon: appIcon, rng: rng };
})(typeof window !== "undefined" ? window : globalThis);
