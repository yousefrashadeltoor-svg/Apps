/* screens-a.js — الرئيسية، الملفات، النقل، التقدم، الاستقبال. (واجهة فقط · بيانات عيّنة) */
(function (g) {
  "use strict";
  var X = g.Sisi, S = X.S, L = X.L, tx = X.tx, C = X.C, I = X.I, D = X.D, SM = X.SM, esc = X.esc;
  var SC = g.SisiScreens = g.SisiScreens || {};
  function screen(cls, inner) { return '<section class="screen ' + (cls || "") + '">' + inner + "</section>"; }
  function devName(d) { return esc(tx(d.name)); }

  /* ================= HOME ================= */
  SC.home = function () {
    var me = D.me, wide = S.frame === "tablet";
    var peers = D.devices.map(function (d, i) {
      var a = d.angle * Math.PI / 180, r = d.dist * 50;
      return '<button class="peer" style="left:' + (50 + Math.cos(a) * r) + "%;top:" + (50 + Math.sin(a) * r) + "%;animation-delay:" + (i * 120) + 'ms" data-act="go:transfer" aria-label="' + devName(d) + '">' + C.devAvatar(d, "sm") + "<span>" + devName(d) + "</span></button>";
    }).join("");
    var radar = '<div class="radar" aria-label="' + L("رادار البحث عن الأجهزة", "Device radar") + '"><div class="rr"></div><div class="rr r2"></div><div class="rr r3"></div><div class="sweep"></div><div class="pulse"></div><div class="pulse p2"></div><div class="pulse p3"></div>' +
      C.avatar(me.initials, me.color, "lg me") + peers + "</div>";
    var status = '<div class="card row g3" style="margin-top:4px"><div class="ready-ic ok">' + I("radar") + '</div><div class="grow"><div class="t-subtitle">' + (S.recvOn ? L("مرئي للأجهزة القريبة", "Visible to nearby devices") : L("الاستقبال متوقف", "Receiving is off")) +
      '</div><div class="t-caption muted"><span class="ltr num">Home_5G · 5GHz · ' + me.ip + "</span></div></div>" + C.sw(S.recvOn, "toggleRecv", L("الاستقبال", "Receiving")) + "</div>";
    var list = '<div class="list">' + D.devices.map(function (d) {
      return C.li({ act: "go:transfer", lead: C.devAvatar(d), t: devName(d) + (d.trusted ? ' <span class="c-warm" title="' + L("موثوق", "Trusted") + '">★</span>' : ""),
        s: esc(d.model) + " · " + d.band, trail: '<span class="icon-btn tonal" aria-hidden="true">' + I("send") + "</span>" });
    }).join("") + "</div>";
    var quick = [["files", "send", L("إرسال", "Send"), "pri"], ["receive", "receive", L("استقبال", "Receive"), ""], ["scan", "scan", L("مسح QR", "Scan QR"), ""], ["web", "globe", L("مشاركة الويب", "Web share"), ""], ["watch", "play", L("مشاهدة معًا", "Watch together"), ""], ["network", "direct", L("شبكة بدون راوتر", "No-router network"), ""]];
    var qa = '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">' + quick.map(function (q) {
      return '<button class="card tight col" style="align-items:flex-start;gap:10px;margin:0;' + (q[3] ? "background:var(--c-primary-container);border-color:transparent;color:var(--c-on-primary-container)" : "") + '" data-act="go:' + q[0] + '">' + I(q[1]) + '<span class="t-label" style="font-weight:600;text-align:start">' + q[2] + "</span></button>";
    }).join("") + "</div>";
    var link = '<div class="card row g3"><div class="ready-ic opt">' + I("signal") + '</div><div class="grow"><div class="t-label" style="font-weight:600">' + L("جودة الرابط", "Link quality") +
      '</div><div class="t-caption muted">' + L("الرابط الحالي ", "Current link ") + '<span class="num">433Mbps · −52dBm</span>' + L(" · المتوقع ", " · expected ") + '<span class="num">~28MB/s</span></div></div><div class="meter"><i class="on"></i><i class="on"></i><i class="on"></i><i></i></div></div>';
    var left = status + radar + '<p class="t-caption muted" style="text-align:center;margin:0 0 8px">' + L("يبحث عبر UDP multicast و mDNS…", "Discovering via UDP multicast & mDNS…") + "</p>";
    var right = C.sectionH(L("الأجهزة القريبة", "Nearby devices") + ' <span class="badge">' + D.devices.length + "</span>", C.chip(L("تحديث", "Refresh"), "", "refresh", "toast:refresh")) + list +
      C.sectionH(L("إجراءات سريعة", "Quick actions")) + qa + C.sectionH(L("الشبكة", "Network")) + link;
    var appbar = '<header class="appbar"><button class="icon-btn" data-act="go:settings" aria-label="' + L("الملف الشخصي", "Profile") + '">' + C.avatar(me.initials, me.color, "sm") +
      '</button><div class="ab-title"><div class="t-title">SISI Share</div><div class="t-caption muted">' + esc(tx(me.name)) + " · " + me.model + '</div></div><button class="icon-btn" data-act="go:qrshow" aria-label="' + L("رمز QR الخاص بي", "My QR") + '">' + I("qr") +
      '</button><button class="icon-btn" data-act="go:scan" aria-label="' + L("مسح QR", "Scan QR") + '">' + I("scan") + "</button></header>";
    return screen("", appbar + '<div class="scroll">' + (wide ? '<div class="two-pane"><div>' + left + "</div><div>" + right + "</div></div>" : left + right) + '<div style="height:72px"></div></div>' +
      '<button class="fab" data-act="go:files">' + I("send") + L("إرسال ملفات", "Send files") + "</button>");
  };

  /* ================= FILES ================= */
  var TABS = [["images", "image", ["صور", "Photos"]], ["videos", "video", ["فيديو", "Videos"]], ["music", "music", ["موسيقى", "Music"]], ["docs", "doc", ["مستندات", "Documents"]], ["archives", "archive", ["مضغوطة", "Archives"]],
    ["apps", "app", ["تطبيقات", "Apps"]], ["contacts", "contact", ["جهات الاتصال", "Contacts"]], ["downloads", "download", ["التنزيلات", "Downloads"]], ["custom", "folder", null]];
  function cb(id) { return '<span class="checkbox' + (S.sel.has(id) ? " on" : "") + '">' + I("check") + "</span>"; }
  function selLi(id, size, o) { o.sel = id; o.attr = ' data-size="' + size + '"'; o.cls = (S.sel.has(id) ? "selected" : ""); o.trail = (o.trail || "") + cb(id); return C.li(o); }
  function cell(id, size, art, extra, hero) {
    return '<div class="mcell' + (S.sel.has(id) ? " on" : "") + '" data-sel="' + id + '" data-size="' + size + '"' + (hero ? ' data-hero="' + hero + '"' : "") + ' role="checkbox" aria-checked="' + S.sel.has(id) + '" tabindex="0">' + art + '<span class="chk">' + I("check") + "</span>" + (extra || "") + "</div>";
  }
  function tabBody() {
    var t = S.filesTab, h = "";
    if (t === "images") {
      h += C.banner("info", "image", L("سمحتَ بالوصول إلى <b>36 صورة</b> فقط (وصول جزئي · <bdi>Android 14+</bdi>).", "You allowed access to <b>36 photos</b> only (partial access · Android 14+)."), '<button class="btn sm filled" data-act="toast:moreMedia">' + L("السماح بالمزيد", "Allow more") + "</button>");
      h += C.sectionH(L("الألبومات", "Albums")) + '<div class="albums">' + D.albums.map(function (a) { return '<div class="album"><div class="ac">' + SM.thumb(a.seed) + '</div><div class="t-label ellipsis" style="margin-top:6px;font-weight:600">' + tx(a.name) + '</div><div class="t-caption muted num">' + a.count + "</div></div>"; }).join("") + "</div>";
      D.imageGroups.forEach(function (gr, gi) {
        h += C.sectionH(tx(gr), '<button class="btn text sm" data-act="selGroup:' + gi + '">' + L("تحديد الكل", "Select all") + "</button>");
        var grp = D.images.filter(function (x) { return x.group === gi; });
        h += S.view === "grid" ? '<div class="mgrid">' + grp.map(function (x) { return cell(x.id, x.size, SM.thumb(x.seed), "", x.seed); }).join("") + "</div>"
          : '<div class="list">' + grp.map(function (x) { return selLi(x.id, x.size, { lead: '<div class="lead">' + SM.thumb(x.seed) + "</div>", t: '<span class="ltr">' + x.name + "</span>", s: '<span class="num">' + x.size.toFixed(1) + " MB</span>" }); }).join("") + "</div>";
      });
    } else if (t === "videos") {
      h += C.sectionH(L("كل الفيديوهات", "All videos") + ' <span class="badge">' + D.videos.length + "</span>");
      h += S.view === "grid" ? '<div class="mgrid" style="--cols:2">' + D.videos.map(function (v) { return cell(v.id, v.size, SM.poster(v.seed), '<span class="vplay">' + I("play", "", 18) + '</span><span class="dur">' + v.dur + "</span>"); }).join("") + "</div>"
        : '<div class="list">' + D.videos.map(function (v, i) { return selLi(v.id, v.size, { lead: '<div class="lead">' + SM.poster(v.seed) + "</div>", t: '<span class="ltr">VID_' + (2200 + i) + ".mp4</span>", s: '<span class="num">' + v.dur + " · " + (v.size >= 1024 ? (v.size / 1024).toFixed(1) + " GB" : v.size + " MB") + "</span>" }); }).join("") + "</div>";
    } else if (t === "music") {
      h += C.sectionH(L("الأغاني", "Songs")) + '<div class="list">' + D.music.map(function (m, i) { return selLi("mu" + i, 8, { lead: '<div class="lead">' + SM.cover(m.s) + "</div>", t: esc(tx(m.t)), s: esc(tx(m.a)) + ' · <span class="num">' + m.d + "</span>" }); }).join("") + "</div>";
    } else if (t === "docs" || t === "archives") {
      var arr = t === "docs" ? D.docs : D.archives;
      h += C.sectionH(t === "docs" ? L("المستندات", "Documents") : L("الملفات المضغوطة", "Archives"), '<button class="icon-btn" aria-label="sort">' + I("sort") + "</button>");
      h += '<div class="list">' + arr.map(function (f, i) { return selLi(t + i, parseFloat(f.s) * (f.s.indexOf("GB") > 0 ? 1024 : f.s.indexOf("KB") > 0 ? 0.001 : 1), { lead: C.lead(t === "docs" ? "doc" : "archive", ""), t: '<span class="ltr">' + esc(f.n) + "</span>", s: '<span class="badge">' + f.t + '</span> · <span class="num">' + f.s + "</span>" + (f.d ? " · " + tx(f.d) : "") }); }).join("") + "</div>";
      if (t === "archives") h += '<p class="t-caption muted" style="margin-top:12px">' + L("لا يُعاد ضغط الملفات المضغوطة أصلًا أثناء النقل.", "Already-compressed files are never re-compressed during transfer.") + "</p>";
    } else if (t === "apps") {
      h += '<div style="margin-top:8px">' + C.seg([["installed", L("مثبتة", "Installed")], ["files", L("غير مثبتة (ملفات)", "Not installed (files)")]], S.appsSeg, "appsSeg") + "</div>";
      if (S.appsSeg === "installed") {
        h += '<div class="row between" style="margin:14px 4px 10px"><span class="t-label muted">' + L("إظهار تطبيقات النظام", "Show system apps") + "</span>" + C.sw(S.showSys, "toggleSys", "") + "</div>";
        h += '<div class="list">' + D.installed.filter(function (a) { return S.showSys || !a.sys; }).map(function (a, i) {
          return selLi("app" + i, parseFloat(a.s), { lead: '<div class="lead">' + SM.appIcon(a.seed, a.glyph) + "</div>", t: esc(tx(a.n)), s: '<span class="num ltr">v' + a.v + " · " + a.s + "</span>" + (a.splits ? ' · <span class="badge">Splits ×' + a.splits + "</span>" : "") + (a.sys ? ' · <span class="badge">' + L("نظام", "System") + "</span>" : "") });
        }).join("") + "</div>";
        h += '<p class="t-caption muted" style="margin-top:12px">' + L("التطبيقات المبنية على Splits تُرسل بتوقيعها الأصلي إن كان المستقبِل يملك SISI Share، وإلا تُدمج في APK واحد مع تحذير تغيّر التوقيع.", "Split-based apps are sent with original signatures when the receiver has SISI Share; otherwise merged into one APK with a signature-change warning.") + "</p>";
      } else {
        h += '<div class="list" style="margin-top:14px">' + D.apkFiles.map(function (a, i) {
          return selLi("apk" + i, parseFloat(a.s) * (a.s.indexOf("GB") > 0 ? 1024 : 1), { lead: '<div class="lead">' + SM.appIcon(a.seed, a.glyph) + "</div>", t: esc(tx(a.n)), s: '<span class="badge">' + a.type + '</span> · <span class="num ltr">v' + a.v + " · " + a.s + "</span>" + (a.obb ? ' · <span class="chip warn" style="height:20px;padding:0 6px">OBB</span>' : "") });
        }).join("") + "</div>";
      }
    } else if (t === "contacts") {
      h += '<div class="row between" style="margin:12px 0"><span class="t-label muted">' + L("6 جهات اتصال", "6 contacts") + '</span><button class="btn sm tonal" data-act="toast:vcf">' + I("share", "", 16) + L("تصدير vCard", "Export vCard") + "</button></div>";
      h += '<div class="list">' + D.contacts.map(function (c, i) { return selLi("ct" + i, 0.004, { lead: C.avatar(tx(c.n).charAt(0), c.c), t: esc(tx(c.n)), s: '<span class="num ltr">' + c.p + "</span>" }); }).join("") + "</div>";
    } else if (t === "downloads") {
      h += C.sectionH("Download/") + '<div class="list">' + D.downloads.map(function (f, i) { return selLi("dl" + i, parseFloat(f.s), { lead: C.lead(f.k), t: '<span class="ltr">' + esc(f.n) + "</span>", s: '<span class="num">' + f.s + "</span>" }); }).join("") + "</div>";
    } else if (t === "custom") {
      h += '<div class="row" style="margin:12px 0 10px"><span class="chip pri">' + I("folder") + "SAF</span><span class=\"t-caption muted ltr\">" + D.custom.path + "</span></div>";
      h += '<div class="list">' + D.custom.items.map(function (f, i) {
        return f.folder ? C.li({ act: "toast:openFolder", lead: C.lead("folder"), t: esc(f.n), s: '<span class="num">' + f.c + "</span> " + L("عنصر", "items"), trail: C.chev() }) : selLi("cu" + i, parseFloat(f.s), { lead: C.lead(f.k), t: '<span class="ltr">' + esc(f.n) + "</span>", s: '<span class="num">' + f.s + "</span>" });
      }).join("") + "</div>";
      h += '<p class="t-caption muted" style="margin-top:12px">' + L("صلاحية دائمة (persistable URI) لهذا المجلد. يمكن إعادة تسمية التبويب أو حذفه.", "Persistable URI permission for this folder. Rename or remove the tab anytime.") + "</p>";
    }
    return h;
  }
  SC.files = function () {
    var tabs = '<div class="tabs" role="tablist">' + TABS.map(function (t) {
      var label = t[2] ? L(t[2][0], t[2][1]) : tx(D.custom.name);
      return '<button class="tab' + (S.filesTab === t[0] ? " on" : "") + '" role="tab" aria-selected="' + (S.filesTab === t[0]) + '" data-act="filesTab:' + t[0] + '">' + I(t[1]) + label + "</button>";
    }).join("") + '<button class="tab" data-act="manageTabs" aria-label="' + L("إدارة التبويبات", "Manage tabs") + '">' + I("plus") + "</button></div>";
    var normal = '<header class="appbar normal"><div class="ab-title"><div class="t-title">' + L("اختر ما تريد إرساله", "Choose what to send") + '</div></div><button class="icon-btn" aria-label="search" data-act="toast:search">' + I("search") +
      '</button><button class="icon-btn" aria-label="view" data-act="toggleView">' + I(S.view === "grid" ? "list" : "grid") + '</button><button class="icon-btn" aria-label="more" data-act="manageTabs">' + I("more") + "</button></header>";
    var sel = '<header class="appbar sel"><button class="icon-btn" data-act="clearSel" aria-label="' + L("إلغاء التحديد", "Clear selection") + '">' + I("close") + '</button><div class="ab-title"><div class="t-title" data-selcount></div><div class="t-caption" data-selsize></div></div><button class="icon-btn" data-act="selAll" aria-label="' + L("تحديد الكل", "Select all") + '">' + I("check") + "</button></header>";
    var selbar = '<div class="selbar"><div class="grow"><div class="t-label" style="font-weight:700" data-selcount></div><div class="t-caption" style="opacity:.7" data-selsize></div></div><button class="btn filled" data-act="go:transfer">' + I("send", "", 18) + L("التالي", "Next") + "</button></div>";
    return screen("files" + (S.sel.size ? " selecting" : ""), normal + sel + tabs + '<div class="scroll" data-selroot>' + tabBody() + '<div style="height:90px"></div></div>' + selbar);
  };

  /* ================= TRANSFER (readiness) ================= */
  var READY = {
    wifi: [["Wi-Fi مفعّل", "Wi-Fi is on"], ["", ""], "wifi"],
    net: [["متصل بشبكة Home_5G", "Connected to Home_5G"], ["5GHz · رابط 433Mbps", "5GHz · 433Mbps link"], "signal"],
    iso: [["احتمال عزل الأجهزة (AP isolation)", "Possible AP isolation"], ["سُمع إعلان «آيباد ليلى» لكن فشل اتصال TCP بها", "Heard “Layla's iPad” but TCP connection failed"], "alert", ["التحويل لـ Wi-Fi Direct", "Switch to Wi-Fi Direct"], "go:network"],
    nearby: [["الأجهزة القريبة", "Nearby devices"], ["مطلوبة لإنشاء Wi-Fi Direct عند الحاجة", "Needed to create Wi-Fi Direct if required"], "direct", ["تفعيل", "Enable"], "fix:nearby"],
    storage: [["الوصول للملفات المحددة", "Access to selected files"], ["عبر صلاحيات URI المؤقتة", "via temporary URI grants"], "storage"],
    notif: [["الإشعارات", "Notifications"], ["لعرض التقدم في الخلفية · النقل يعمل بدونها", "Shows background progress · transfer works without it"], "bell", ["تفعيل", "Enable"], "fix:notif"],
    battery: [["تحسين البطارية (اختياري)", "Battery optimization (optional)"], ["يقلل احتمال إيقاف النقل الطويل", "Reduces the chance of long transfers being stopped"], "battery", ["استثناء", "Exempt"], "fix:battery"]
  };
  SC.readinessCard = function () {
    var keys = Object.keys(READY), pending = keys.filter(function (k) { return S.ready[k] === "need" || S.ready[k] === "bad"; }).length;
    return '<div class="card"><div class="row between"><div class="t-subtitle">' + L("قائمة الجاهزية", "Readiness") + "</div>" + (pending ? C.chip(pending + L(" تحتاج إجراء", " need action"), "warn", "alert") : C.chip(L("جاهز تمامًا", "All set"), "ok", "check")) + "</div>" +
      keys.map(function (k) {
        var r = READY[k], st = S.ready[k], ic = st === "ok" ? "check" : r[2];
        return '<div class="ready-i" data-ready="' + k + '"><div class="ready-ic ' + st + '">' + I(ic, "", 18) + '</div><div class="grow"><div class="t-label" style="font-weight:600">' + L(r[0][0], r[0][1]) + "</div>" + (r[1][0] && st !== "ok" ? '<div class="t-caption muted">' + L(r[1][0], r[1][1]) + "</div>" : "") + "</div>" +
          (st !== "ok" && r[3] ? '<button class="btn sm ' + (st === "bad" ? "tonal" : st === "opt" ? "outlined" : "filled") + '" data-act="' + r[4] + '">' + L(r[3][0], r[3][1]) + "</button>" : "") + "</div>";
      }).join("") + "</div>";
  };
  SC.transfer = function () {
    var files = D.transferFiles, n = S.pickedDevices.size;
    var strip = '<div class="card row g3"><div style="position:relative;width:64px;height:52px;flex:none">' + files.map(function (f, i) { return '<div class="lead" style="position:absolute;inset-inline-start:' + (i * 10) + "px;top:" + (i * 3) + "px;transform:rotate(" + ((i - 1) * 6) + 'deg);box-shadow:0 0 0 2px var(--c-surface)">' + (f.k === "video" ? SM.poster(f.seed) : SM.thumb(f.seed)) + "</div>"; }).join("") +
      '</div><div class="grow"><div class="t-subtitle">' + L("3 ملفات", "3 files") + '</div><div class="t-caption muted num">1.17 GB</div></div><button class="btn text sm" data-act="go:files">' + L("تعديل", "Edit") + "</button></div>";
    var devs = '<div class="list">' + D.devices.map(function (d) {
      var on = S.pickedDevices.has(d.id);
      return C.li({ act: "pickDev:" + d.id, cls: on ? "selected" : "", lead: C.devAvatar(d), t: devName(d), s: esc(d.proto) + " · " + d.band + (d.id === "d3" ? ' · <span class="c-warm">' + L("تعذّر الوصول", "Unreachable") + "</span>" : ""), trail: '<span class="checkbox' + (on ? " on" : "") + '">' + I("check") + "</span>" });
    }).join("") + "</div>";
    var opts = '<div class="list">' +
      C.li({ cls: "plain", lead: '<div class="lead ftsoft c-accent">' + I("lock") + "</div>", t: L("تشفير كامل", "Full encryption"), s: "TLS 1.3 · AES-256-GCM " + L("(تسريع عتادي)", "(hardware accelerated)"), trail: C.sw(S.encrypt, "toggleEncrypt") }) +
      C.li({ cls: "plain", lead: '<div class="lead ftsoft c-primary">' + I("shield") + "</div>", t: L("فحص السلامة BLAKE3", "BLAKE3 integrity check"), s: L("افتراضي للملفات الكبيرة", "Default for large files"), trail: C.sw(S.integrity, "toggleIntegrity") }) +
      C.li({ cls: "plain", lead: '<div class="lead ftsoft c-warm">' + I("bolt") + "</div>", t: L("الاتصالات المتوازية", "Parallel connections"), s: L("تلقائي · يبدأ بـ 2 ويزيد فقط عند ثبوت التحسّن", "Auto · starts at 2, grows only if proven faster"), trail: '<span class="chip pri num">' + L("تلقائي", "Auto") + " · 3</span>" }) + "</div>";
    var level = C.banner("info", "wifi", "<b>" + L("يعمل عبر Wi-Fi المحلي", "Running over local Wi-Fi") + "</b> · UDP multicast + mDNS<br>" + L("للجهاز غير الموصول: Wi-Fi Direct جاهز كبديل.", "For the unreachable device: Wi-Fi Direct is ready as fallback."), '<button class="btn sm outlined" data-act="go:network">' + L("عرض البدائل", "See options") + "</button>");
    return screen("", C.appbar(L("صفحة النقل", "Transfer"), { back: true, sub: L("جاهزية · أجهزة · خيارات", "Readiness · devices · options") }) +
      '<div class="scroll">' + (S.frame === "tablet" ? '<div class="two-pane"><div>' + strip + '<div style="height:12px"></div>' + SC.readinessCard() + "</div><div>" + level + C.sectionH(L("اختر المستلمين", "Choose recipients")) + devs + C.sectionH(L("خيارات النقل", "Transfer options")) + opts + "</div></div>"
        : strip + '<div style="height:12px"></div>' + SC.readinessCard() + '<div style="height:12px"></div>' + level + C.sectionH(L("اختر المستلمين", "Choose recipients")) + devs + C.sectionH(L("خيارات النقل", "Transfer options")) + opts) +
      '<div style="height:16px"></div><button class="btn filled block" data-act="startSend"' + (n ? "" : " disabled") + ">" + I("send") + (n === 1 ? L("إرسال إلى جهاز واحد", "Send to 1 device") : L("إرسال إلى " + n + " أجهزة", "Send to " + n + " devices")) + "</button><div style=\"height:24px\"></div></div>");
  };

  /* ================= PROGRESS ================= */
  SC.progress = function () {
    var body;
    var ctl = '<div class="row g3" style="margin-top:16px"><button class="btn tonal grow" style="flex:1" data-act="togglePause">' + I(X.SIM.paused ? "play" : "pause", "", 18) + (X.SIM.paused ? L("استئناف", "Resume") : L("إيقاف مؤقت", "Pause")) + '</button><button class="btn danger" style="flex:1" data-act="cancelSend">' + I("close", "", 18) + L("إلغاء", "Cancel") + "</button></div>";
    if (S.progressMode === "single") {
      var d = D.devices[1];
      body = '<div class="card" style="margin-top:12px"><div class="row g3 between"><div class="row g3">' + C.avatar(D.me.initials, 0, "sm") + '<div style="width:56px" class="bar thin indet"><i></i></div>' + C.devAvatar(d, "sm") + '<div><div class="t-label" style="font-weight:600">' + devName(d) + '</div><div class="t-caption muted">' + d.proto + "</div></div></div><span data-sim=\"st:single\" class=\"chip pri\"></span></div>" +
        '<div style="display:grid;place-items:center;margin:20px 0 8px"><div class="ring" style="--size:176px"><svg viewBox="0 0 168 168"><defs><linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--c-primary)"/><stop offset="1" stop-color="var(--c-accent)"/></linearGradient></defs><circle class="rbg" cx="84" cy="84" r="74"/><circle class="rfg" cx="84" cy="84" r="74" stroke-dasharray="' + (2 * Math.PI * 74).toFixed(2) + '" data-sim="ring:single" style="stroke-dashoffset:' + (2 * Math.PI * 74).toFixed(2) + '"/></svg><div style="text-align:center"><div class="t-display num" data-sim="pct:single">0%</div><div class="t-caption muted num" data-sim="done:single"></div></div></div></div>' +
        '<div class="metric-grid"><div class="metric"><div class="m-v"><span data-sim="spd:single">0</span> <small class="t-caption">MB/s</small></div><div class="m-l">' + L("السرعة اللحظية", "Live speed") + '</div></div><div class="metric"><div class="m-v" data-sim="eta:single">—</div><div class="m-l">' + L("المتبقي (متوسط متحرك)", "Remaining (moving avg)") + '</div></div><div class="metric"><div class="m-v num">3</div><div class="m-l">' + L("اتصالات", "Connections") + "</div></div></div>" +
        '<svg class="spark" viewBox="0 0 100 56" preserveAspectRatio="none" data-sim="spark:single" style="margin-top:12px"><path class="a"/><path class="l"/></svg></div>';
      body += C.sectionH(L("الملفات", "Files")) + '<div class="list">' + D.transferFiles.map(function (f, i) {
        return '<div class="li"><div class="lead">' + (f.k === "video" ? SM.poster(f.seed) : SM.thumb(f.seed)) + '</div><div class="grow"><div class="row between"><span class="li-t ellipsis ltr">' + f.n + '</span><span class="t-caption muted num" data-fl></span></div><div class="bar thin" style="margin-top:8px" data-sim="file:single:' + i + '"><i></i></div></div></div>';
      }).join("") + "</div>";
      body += '<div class="row wrap" style="margin-top:12px">' + C.chip("TLS 1.3 · AES-GCM", "ok", "lock") + C.chip("BLAKE3", "ok", "shield") + C.chip("WifiLock · low-latency", "", "wifi") + C.chip(L("استئناف على مستوى المقطع", "Chunk-level resume"), "", "refresh") + "</div>";
    } else {
      var rec = [["m1", D.devices[1]], ["m2", D.devices[0]], ["m3", D.devices[3]]];
      body = '<div class="card" style="margin-top:12px"><div class="row between"><div><div class="t-subtitle">' + L("إرسال إلى 3 أجهزة", "Sending to 3 devices") + '</div><div class="t-caption muted">' + L("يُقرأ الملف مرة واحدة ويُوزَّع بعدالة على 3 اتصالات", "File is read once and fairly fanned out to 3 connections") + '</div></div><span class="t-headline num" data-sim="pct:m1">0%</span></div><div style="margin-top:12px">' + C.bar(0, "", "m1") + "</div></div>";
      body += C.sectionH(L("المستلمون", "Recipients")) + '<div class="list">' + rec.map(function (r) {
        var dd = r[1];
        return '<div class="li" style="align-items:flex-start;padding-top:12px;padding-bottom:12px">' + C.devAvatar(dd) + '<div class="grow"><div class="row between"><span class="li-t">' + devName(dd) + '</span><span data-sim="st:' + r[0] + '" class="chip"></span></div><div style="margin:8px 0 6px">' + C.bar(0, "thin", r[0]) +
          '</div><div class="row between t-caption muted"><span class="num"><span data-sim="spd:' + r[0] + '">0</span> MB/s</span><span class="num" data-sim="eta:' + r[0] + '"></span></div>' + (r[0] === "m3" ? '<div class="row" style="margin-top:8px"><button class="btn sm tonal" data-act="toast:retry">' + I("refresh", "", 16) + L("استئناف من آخر مقطع", "Resume from last chunk") + '</button><span class="t-caption muted">' + L("فشل هذا الجهاز لا يوقف الباقين", "This failure doesn't stop others") + "</span></div>" : "") + "</div></div>";
      }).join("") + "</div>";
    }
    return screen("", C.appbar(L("التقدم", "Progress"), { back: true, sub: L("بيانات عيّنة متحركة", "Animated sample data") }) + '<div class="scroll"><div style="margin-top:4px">' + C.seg([["single", L("مستلم واحد", "Single")], ["multi", L("عدة مستلمين", "Multiple")]], S.progressMode, "progressMode") + "</div>" + body + ctl + '<div style="height:24px"></div></div>');
  };

  /* ================= RECEIVE ================= */
  SC.receive = function () {
    var me = D.me;
    var hero = '<div class="card" style="text-align:center;padding:24px 16px;margin-top:4px"><div style="display:grid;place-items:center">' + C.avatar(me.initials, me.color, "lg") + '</div><div class="t-headline" style="margin-top:12px">' + esc(tx(me.name)) + '</div><div class="t-caption muted">' + me.model + ' · <span class="num ltr">' + me.ip + ":" + me.port + '</span></div><div style="margin-top:8px"><span class="fp">' + me.fp + "</span></div>" +
      '<div class="row between card flat tight" style="margin-top:16px;text-align:start"><div><div class="t-label" style="font-weight:600">' + L("الظهور للأجهزة القريبة", "Visible to nearby devices") + '</div><div class="t-caption muted">' + (S.recvOn ? L("وضع الاستقبال يعمل كخدمة أمامية", "Receive mode runs as a foreground service") : L("لن يراك أحد", "No one can see you")) + "</div></div>" + C.sw(S.recvOn, "toggleRecv") + "</div></div>";
    var ladder = '<div class="card"><div class="t-label" style="font-weight:600;margin-bottom:10px">' + L("طبقات الاكتشاف الفعّالة", "Active discovery layers") + '</div><div class="row wrap">' + C.chip("UDP multicast", "ok", "check") + C.chip("mDNS", "ok", "check") + C.chip(L("مسح السبنت", "Subnet scan"), "", "minus") + C.chip("BLE", "warn", "bluetooth") + C.chip("NFC", "", "nfc") + "</div><div class=\"t-caption muted\" style=\"margin-top:10px\">" + L("مسح السبنت يُفعَّل تلقائيًا فقط عند فشل multicast. BLE يحتاج صلاحية «الأجهزة القريبة».", "Subnet scan activates only if multicast fails. BLE needs the Nearby devices permission.") + "</div></div>";
    var folder = '<div class="list">' + C.li({ act: "go:settings", lead: '<div class="lead ftsoft c-primary">' + I("folder") + "</div>", t: L("مجلد الاستقبال", "Receive folder"), s: '<span class="ltr">Download/JOPRO</span> · ' + L("تنظيم حسب النوع", "Organized by type"), trail: C.chev() }) +
      C.li({ act: "go:trust", lead: '<div class="lead ftsoft c-accent">' + I("shield") + "</div>", t: L("الموافقة على الاتصالات", "Connection approval"), s: L("للأجهزة الجديدة فقط · تلقائي للموثوقين", "New devices only · auto for trusted"), trail: C.chev() }) +
      C.li({ lead: '<div class="lead ftsoft c-warm">' + I("timer") + "</div>", t: L("إيقاف تلقائي عند الخمول", "Auto-stop when idle"), s: L("بعد 30 دقيقة · إشعار قبل الإيقاف", "After 30 min · notifies before stopping"), trail: '<span class="chip num">30m</span>' }) + "</div>";
    return screen("", C.appbar(L("الاستقبال", "Receive"), { back: true }) + '<div class="scroll">' + hero + '<div style="height:12px"></div>' + ladder + C.sectionH(L("الإعدادات", "Settings")) + folder +
      '<div style="height:16px"></div><button class="btn tonal block" data-act="consent">' + I("bell") + L("عرض طلب اتصال وارد (معاينة)", "Show incoming request (preview)") + '</button><div style="height:24px"></div></div>');
  };
  SC.consentDialog = function () {
    var d = D.devices[2], circ = (2 * Math.PI * 19).toFixed(2);
    return '<div class="consent-head"><div class="row between" style="width:100%"><span class="chip warn">' + I("alert") + L("جهاز جديد", "New device") + '</span><div class="countdown" aria-label="60s"><svg viewBox="0 0 44 44"><circle class="cb" cx="22" cy="22" r="19"/><circle class="cf" cx="22" cy="22" r="19" stroke-dasharray="' + circ + '" data-countdown/></svg><span data-countnum>60</span></div></div>' +
      C.devAvatar(d, "lg") + '<div class="t-title">' + devName(d) + '</div><div class="t-caption muted">' + d.model + '</div><span class="fp">' + d.fp + "</span></div>" +
      '<div class="card flat tight" style="margin-top:16px"><div class="row g3"><div class="row" style="gap:4px">' + [130, 131, 132].map(function (s) { return '<div class="lead" style="width:36px;height:36px;border-radius:10px">' + SM.thumb(s) + "</div>"; }).join("") + '</div><div class="grow"><div class="t-label" style="font-weight:600">' + L("يريد إرسال 12 ملفًا", "Wants to send 12 files") + '</div><div class="t-caption muted num">2.4 GB</div></div></div>' +
      '<div class="row t-caption" style="margin-top:10px;color:var(--c-accent)">' + I("check", "", 16) + L("المساحة المتاحة 18.4 GB · يُحفظ في Download/JOPRO", "18.4 GB free · saves to Download/JOPRO") + "</div></div>" +
      '<div class="opt-grid"><button class="btn filled" data-act="consentDo:once">' + L("قبول مرة", "Accept once") + '</button><button class="btn tonal" data-act="consentDo:trust">' + I("star", "", 16) + L("قبول دائم", "Always accept") + '</button><button class="btn outlined" data-act="consentDo:deny">' + L("رفض", "Decline") + '</button><button class="btn danger" data-act="consentDo:block">' + I("block", "", 16) + L("حظر", "Block") + "</button></div>" +
      '<p class="t-caption muted" style="text-align:center;margin:12px 0 0">' + L("يُرفض تلقائيًا بعد 60 ثانية ويُبلَّغ المرسل. الحظر بالبصمة.", "Auto-declined after 60s and the sender is notified. Blocking uses the fingerprint.") + "</p>";
  };
})(window);
