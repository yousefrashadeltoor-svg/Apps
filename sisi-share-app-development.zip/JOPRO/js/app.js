/* app.js — غلاف المعاينة: شريط التحكم، التنقل، توزيع الأحداث، التحديد، المحاكاة. (معاينة تصميم فقط) */
(function (g) {
  "use strict";
  var X = g.Sisi, S = X.S, L = X.L, C = X.C, I = X.I, O = X.O, M = X.M, SIM = X.SIM, SC = g.SisiScreens, SM = X.SM, D = X.D;
  var root, stack = [];
  var ROOT_TABS = ["home", "files", "web", "history", "settings"];
  var DEPTH = { progress: 2, gallery: 1 };
  var NAV = [
    [["الرئيسية والإرسال", "Home & sending"], [["home", "radar", ["الرئيسية · الرادار", "Home · radar"]], ["files", "folder", ["مدير الملفات", "File manager"]], ["filesApps", "app", ["التطبيقات (مثبت/غير مثبت)", "Apps (installed/files)"]], ["filesCustom", "folderPlus", ["تبويب مخصص", "Custom tab"]], ["transfer", "send", ["صفحة النقل · الجاهزية", "Transfer · readiness"]], ["progress", "swap", ["التقدم (فردي/متعدد)", "Progress (single/multi)"]], ["receive", "receive", ["الاستقبال · الموافقة", "Receive · consent"]]]],
    [["الاتصال", "Connect"], [["scan", "scan", ["قارئ QR", "QR scanner"]], ["qrshow", "qr", ["عرض QR", "Show QR"]], ["network", "direct", ["شبكة بدون راوتر", "No-router network"]]]],
    [["المشاركة", "Sharing"], [["web", "globe", ["مشاركة الويب", "Web share"]], ["webclient", "desktop", ["عميل الويب (المتصفح)", "Web client (browser)"]], ["watch", "play", ["المشاهدة المشتركة", "Watch together"]]]],
    [["الإدارة", "Manage"], [["history", "history", ["السجل", "History"]], ["settings", "settings", ["الإعدادات المتقدمة", "Advanced settings"]], ["trust", "shield", ["الحظر والموثوق", "Blocked & trusted"]], ["permissions", "key", ["الأذونات", "Permissions"]], ["system", "cpu", ["حالة النظام", "System status"]]]],
    [["مراجع", "Reference"], [["gallery", "bell", ["الإشعارات والويدجتس", "Notifications & widgets"]], ["states", "alert", ["الحالات الفارغة والأخطاء", "Empty & error states"]]]]
  ];
  var TOASTS = {
    refresh: ["جارٍ البحث من جديد…", "Rescanning…"], moreMedia: ["سيفتح منتقي النظام لاختيار المزيد", "The system picker would open to allow more"], vcf: ["تصدير vCard مع الصور", "Export vCard with photos"],
    search: ["البحث داخل التبويب الحالي", "Search in current tab"], openFolder: ["فتح المجلد", "Open folder"], copied: ["تم النسخ", "Copied"], connecting: ["جارٍ الاتصال… (معاينة)", "Connecting… (preview)"],
    gallery: ["قراءة QR من صورة في المعرض", "Read QR from a gallery image"], openSettings: ["سيُفتح إعداد النظام المناسب ويتحدث العنصر عند العودة", "The right system settings would open and refresh on return"],
    loh: ["LocalOnlyHotspot: الاسم وكلمة المرور من النظام", "LocalOnlyHotspot: system-generated credentials"], retry: ["استئناف من آخر مقطع سليم (معاينة)", "Resuming from last verified chunk (preview)"],
    open: ["فتح الملف", "Open file"], cleared: ["مُسح السجل", "History cleared"], channels: ["فتح إعدادات القنوات في النظام", "Open system channel settings"], unblocked: ["أُلغي الحظر", "Unblocked"],
    approved: ["تمت الموافقة على الجلسة", "Session approved"], denied: ["رُفضت الجلسة", "Session denied"], roomEnded: ["انتهت الغرفة", "Room ended"], panel: ["Settings.Panel: Wi-Fi", "Settings.Panel: Wi-Fi"], zip: ["يبدأ تنزيل ZIP عبر مدير تنزيل المتصفح", "ZIP download starts via the browser's download manager"]
  };

  function navTab(s) { return ROOT_TABS.indexOf(s) >= 0 ? s : ({ transfer: "files", progress: "files", receive: "home", scan: "home", qrshow: "home", network: "home", watch: "web", trust: "settings", permissions: "settings", system: "settings", gallery: "settings", states: "settings" })[s] || "home"; }
  function depth(s) { return ROOT_TABS.indexOf(s) >= 0 ? 0 : DEPTH[s] || 1; }
  function appEl() { return root.querySelector(".app"); }

  /* ---------- shell ---------- */
  function grp(items, cur, act) { return '<div class="pv-grp">' + items.map(function (x) { return '<button class="' + (String(cur) === String(x[0]) ? "on" : "") + '" data-pv="' + act + ":" + x[0] + '" title="' + (x[2] || "") + '" aria-pressed="' + (String(cur) === String(x[0])) + '">' + x[1] + "</button>"; }).join("") + "</div>"; }
  function shell() {
    var curNav = S.frame === "desktop" ? "webclient" : S.screen === "files" && S.filesTab === "apps" ? "filesApps" : S.screen === "files" && S.filesTab === "custom" ? "filesCustom" : S.screen;
    var bar = '<header class="pv-bar"><button class="icon-btn pv-menu" data-pv="menu" aria-label="menu">' + I("menu") + '</button><div class="pv-brand"><div class="pv-logo">' + I("send", "", 18) + '</div><div>SISI Share<small>' + L("معاينة التصميم · المرحلة 0 · العقد البصري", "Design preview · Phase 0 · visual contract") + "</small></div></div>" +
      '<div class="pv-ctrls">' + grp([["dark", I("moon"), "Dark"], ["light", I("sun"), "Light"]], S.theme, "theme") + grp([["ar", "ع", "العربية RTL"], ["en", "EN", "English LTR"]], S.lang, "lang") +
      grp([["phone", I("phone"), L("هاتف", "Phone")], ["tablet", I("tablet"), L("تابلت", "Tablet")], ["desktop", I("desktop"), L("متصفح سطح مكتب (عميل الويب)", "Desktop browser (web client)")]], S.frame, "frame") +
      '<button class="pv-toggle' + (S.lowEnd ? " on" : "") + '" data-pv="lowEnd" title="Galaxy A20">' + I("cpu") + L("جهاز ضعيف", "Low-end") + (S.autoLowEnd ? " ✓" : "") + "</button>" +
      '<button class="pv-toggle' + (S.reduced ? " on" : "") + '" data-pv="reduced">' + I("eyeOff") + L("تقليل الحركة", "Reduce motion") + "</button>" +
      grp([[0.25, "¼×"], [0.5, "½×"], [1, "1×"]], S.speed, "speed") + "</div></header>";
    var nav = '<nav class="pv-nav" aria-label="screens">' + NAV.map(function (sec) {
      return "<h4>" + L(sec[0][0], sec[0][1]) + "</h4>" + sec[1].map(function (it) { return '<button class="' + (curNav === it[0] ? "on" : "") + '" data-pv="nav:' + it[0] + '">' + I(it[1]) + L(it[2][0], it[2][1]) + "</button>"; }).join("");
    }).join("") + "</nav>";
    var frame;
    if (S.frame === "desktop") {
      frame = '<div class="frame-browser"><div class="br-top"><div class="br-dots"><i></i><i></i><i></i></div><div class="br-url">' + I("unlock") + "<b>" + L("غير آمن", "Not secure") + '</b> http://192.168.1.24:53318</div></div><div class="app wc">' + g.SisiWeb.render() + "</div></div>";
    } else {
      var wide = S.frame === "tablet";
      var tabs = [["home", "home", L("الرئيسية", "Home")], ["files", "folder", L("الملفات", "Files")], ["web", "globe", L("الويب", "Web")], ["history", "history", L("السجل", "History")], ["settings", "settings", L("الإعدادات", "Settings")]];
      var t = navTab(S.screen);
      var items = tabs.map(function (x) { return '<button class="nav-item' + (t === x[0] ? " on" : "") + '" data-act="tab:' + x[0] + '" aria-current="' + (t === x[0]) + '"><span class="nav-pill">' + I(x[1]) + "</span>" + x[2] + "</button>"; }).join("");
      frame = '<div class="frame frame-' + S.frame + '"><div class="device"><div class="statusbar"><span>14:32</span><span class="sb-r">' + I("wifi") + I("signal") + I("battery") + "</span></div>" +
        '<div class="app' + (wide ? " wide" : "") + '">' + (wide ? '<aside class="rail"><button class="rail-fab" data-act="go:files" aria-label="send">' + I("send") + "</button>" + items + "</aside>" : "") +
        '<div class="app-main"><div class="screen-host"></div>' + (wide ? "" : '<nav class="navbar">' + items + "</nav>") + '</div><div class="overlay-host"></div></div><div class="gesture"><i></i></div></div></div>';
    }
    root.innerHTML = '<div class="pv ' + (S.lowEnd ? "lowend" : "glass") + (S.reduced ? " reduced" : "") + '" data-theme="' + S.theme + '" dir="' + (S.lang === "ar" ? "rtl" : "ltr") + '" lang="' + S.lang + '" style="--motion-scale:' + X.motionScale() + '">' + bar +
      '<div class="pv-body">' + nav + '<main class="pv-stage"><div class="pv-scaler">' + frame + "</div></main></div>" +
      '<div class="pv-badge" role="note">' + I("info") + L("معاينة تصميم · بيانات عيّنة · لا تنقل ملفات فعليًا", "Design preview · sample data · transfers nothing") + "</div></div>";
    document.documentElement.lang = S.lang;
    if (S.frame !== "desktop") renderScreen(null);
    fit(); SIM.apply(root);
  }
  function fit() {
    var st = root.querySelector(".pv-stage"), sc = root.querySelector(".pv-scaler"); if (!st || !sc) return;
    var f = sc.firstElementChild, s = Math.min(1, (st.clientWidth - 32) / f.offsetWidth, (st.clientHeight - 64) / f.offsetHeight);
    sc.style.transform = "translate(-50%, -50%) scale(" + Math.max(0.3, s) + ")";
  }

  /* ---------- screens ---------- */
  function segState(host) { var m = {}; Array.prototype.forEach.call(host.querySelectorAll(".seg"), function (s) { var b = s.querySelector("button.on"); if (b) m[b.getAttribute("data-act").split(":")[0]] = Array.prototype.indexOf.call(s.querySelectorAll("button"), b); }); return m; }
  function animateSegs(host, prev) {
    Array.prototype.forEach.call(host.querySelectorAll(".seg"), function (s) {
      var b = s.querySelector("button.on"); if (!b) return;
      var key = b.getAttribute("data-act").split(":")[0], ind = s.querySelector(".seg-ind");
      if (prev[key] == null || !ind) return;
      var final = ind.style.transform; ind.style.transition = "none"; ind.style.transform = "translateX(calc(var(--dirx) * (" + prev[key] + " * 100% + 4px)))";
      void ind.offsetWidth; ind.style.transition = ""; ind.style.transform = final;
    });
  }
  function renderScreen(dir) {
    var host = root.querySelector(".screen-host"); if (!host) return;
    var fn = SC[S.screen] || SC.home, tmp = document.createElement("div"); tmp.innerHTML = fn();
    var el = tmp.firstElementChild;
    if (dir === null) { host.innerHTML = ""; host.appendChild(el); }
    else if (dir === "fade") {
      var old = host.querySelector(".screen:not(.leaving)"); if (old) { old.classList.add("leaving"); old.animate([{ opacity: 1 }, { opacity: 0 }], { duration: X.dur("short"), fill: "forwards" }).onfinish = function () { old.remove(); }; }
      host.appendChild(el); el.animate([{ opacity: 0, transform: "scale(.96)" }, { opacity: 1, transform: "none" }], { duration: X.dur("medium"), delay: old ? X.dur("short") * 0.6 : 0, easing: X.EASE.decel, fill: "backwards" });
    } else M.sharedAxis(host, el, dir);
    updateSel(); SIM.apply(el);
  }
  function refresh() {
    var host = root.querySelector(".screen-host"); if (!host) { if (S.frame === "desktop") shell(); return; }
    var sc = host.querySelector(".screen:not(.leaving) .scroll"), top = sc ? sc.scrollTop : 0, prev = segState(host);
    renderScreen(null);
    var sc2 = host.querySelector(".scroll"); if (sc2) sc2.scrollTop = top;
    animateSegs(host, prev);
  }
  function go(name, opts) {
    opts = opts || {};
    if (name === "webclient") { S.frame = "desktop"; X.save(); shell(); return; }
    if (name === "filesApps") { S.filesTab = "apps"; name = "files"; }
    if (name === "filesCustom") { S.filesTab = "custom"; name = "files"; }
    if (S.frame === "desktop") { S.frame = "phone"; S.screen = name; X.save(); shell(); return; }
    var from = S.screen; if (from === name && !opts.force) { refresh(); return; }
    O.closeAll(true);
    if (!opts.back) { if (ROOT_TABS.indexOf(name) >= 0) stack = []; else stack.push(from); }
    S.screen = name; X.save();
    if (name !== "files" && from === "files") { S.sel.clear(); }
    var both = ROOT_TABS.indexOf(name) >= 0 && ROOT_TABS.indexOf(from) >= 0;
    renderScreen(both ? "fade" : opts.back ? false : depth(name) >= depth(from));
    updateChrome();
  }
  function updateChrome() {
    var t = navTab(S.screen);
    Array.prototype.forEach.call(root.querySelectorAll(".nav-item"), function (b) { var on = b.getAttribute("data-act") === "tab:" + t; b.classList.toggle("on", on); b.setAttribute("aria-current", on); });
    var cur = S.screen === "files" && S.filesTab === "apps" ? "filesApps" : S.screen === "files" && S.filesTab === "custom" ? "filesCustom" : S.screen;
    Array.prototype.forEach.call(root.querySelectorAll(".pv-nav button"), function (b) { b.classList.toggle("on", b.getAttribute("data-pv") === "nav:" + cur); });
  }

  /* ---------- selection ---------- */
  var selSizes = {};
  function fmtMB(mb) { return mb >= 1024 ? (mb / 1024).toFixed(2) + " GB" : mb >= 1 ? mb.toFixed(1) + " MB" : Math.max(1, Math.round(mb * 1024)) + " KB"; }
  function updateSel() {
    var scr = root.querySelector(".screen.files:not(.leaving)"); if (!scr) return;
    var n = S.sel.size, total = 0; S.sel.forEach(function (id) { total += selSizes[id] || 0; });
    scr.classList.toggle("selecting", n > 0);
    Array.prototype.forEach.call(scr.querySelectorAll("[data-selcount]"), function (e) { e.textContent = L(n + " محدد", n + " selected"); });
    Array.prototype.forEach.call(scr.querySelectorAll("[data-selsize]"), function (e) { e.textContent = fmtMB(total); });
    Array.prototype.forEach.call(scr.querySelectorAll("[data-sel]"), function (e) {
      var id = e.getAttribute("data-sel"), on = S.sel.has(id); selSizes[id] = parseFloat(e.getAttribute("data-size")) || 0;
      e.classList.toggle(e.classList.contains("mcell") ? "on" : "selected", on); e.setAttribute("aria-checked", on);
      var cbx = e.querySelector(".checkbox"); if (cbx) cbx.classList.toggle("on", on);
    });
  }
  function setSel(el, on) { var id = el.getAttribute("data-sel"); selSizes[id] = parseFloat(el.getAttribute("data-size")) || 0; if (on) S.sel.add(id); else S.sel.delete(id); updateSel(); }
  var press = null, dragging = false, dragAdd = true, suppress = false;
  function onDown(e) {
    var el = e.target.closest("[data-sel]"); if (!el || e.button > 0) return;
    press = { x: e.clientX, y: e.clientY, el: el, t: setTimeout(function () {
      dragging = true; dragAdd = !S.sel.has(el.getAttribute("data-sel")); setSel(el, dragAdd); suppress = true;
      el.animate([{ transform: "scale(1)" }, { transform: "scale(.94)" }, { transform: "scale(1)" }], { duration: X.dur("medium"), easing: X.EASE.spring });
    }, 450) };
  }
  function onMove(e) {
    if (!press) return;
    if (dragging) { var t = document.elementFromPoint(e.clientX, e.clientY), el = t && t.closest("[data-sel]"); if (el && S.sel.has(el.getAttribute("data-sel")) !== dragAdd) setSel(el, dragAdd); e.preventDefault(); return; }
    if (Math.abs(e.clientX - press.x) + Math.abs(e.clientY - press.y) > 8) { clearTimeout(press.t); press = null; }
  }
  function onUp() { if (press) clearTimeout(press.t); press = null; dragging = false; }

  /* ---------- actions ---------- */
  function rationale(k) { O.dialog(SC.rationale(k)); }
  var A = {
    go: function (a) { go(a); }, tab: function (a) { go(a); },
    back: function () { var p = stack.pop() || "home"; go(p, { back: true, force: true }); },
    frame: function (a) { S.frame = a; X.save(); shell(); },
    toast: function (a) { var t = TOASTS[a]; O.toast(t ? L(t[0], t[1]) : a); },
    closeOverlay: function () { O.closeAll(); stopCountdown(); },
    noop: function () {},
    filesTab: function (a, el) {
      S.filesTab = a; S.sel.clear();
      var scr = el.closest(".screen"); Array.prototype.forEach.call(scr.querySelectorAll(".tab"), function (b) { var on = b === el; b.classList.toggle("on", on); b.setAttribute("aria-selected", on); });
      el.scrollIntoView({ inline: "nearest", block: "nearest", behavior: S.reduced ? "auto" : "smooth" });
      var tmp = document.createElement("div"); tmp.innerHTML = SC.files(); var nsc = tmp.querySelector(".scroll"), sc = scr.querySelector(".scroll");
      sc.innerHTML = nsc.innerHTML; sc.scrollTop = 0;
      sc.animate([{ opacity: 0, transform: "translateY(8px)" }, { opacity: 1, transform: "none" }], { duration: X.dur("medium"), easing: X.EASE.decel });
      updateSel(); updateChrome();
    },
    appsSeg: function (a) { S.appsSeg = a; refresh(); }, progressMode: function (a) { S.progressMode = a; refresh(); }, qrMode: function (a) { S.qrMode = a; refresh(); var q = root.querySelector("[data-qrwrap] .qr-box"); if (q) q.animate([{ opacity: 0, transform: "scale(.92)" }, { opacity: 1, transform: "none" }], { duration: X.dur("medium"), easing: X.EASE.spring }); },
    trustSeg: function (a) { S.trustSeg = a; refresh(); }, histFilter: function (a) { S.histFilter = a; refresh(); }, galSeg: function (a) { S.galSeg = a; refresh(); },
    webProto: function (a) { S.webProto = a; refresh(); }, webMode: function (a) { S.webMode = a; refresh(); if (a === "browse") rationale("allFiles"); }, watchCtrl: function (a) { S.watchCtrl = a; refresh(); },
    toggleRecv: function () { S.recvOn = !S.recvOn; refresh(); }, toggleSys: function () { S.showSys = !S.showSys; refresh(); }, toggleView: function () { S.view = S.view === "grid" ? "list" : "grid"; refresh(); O.toast(L("طريقة العرض: ", "View: ") + (S.view === "grid" ? L("شبكة", "grid") : L("قائمة", "list"))); },
    toggleEncrypt: function () { S.encrypt = !S.encrypt; refresh(); if (!S.encrypt) O.toast(L("تحذير: المحتوى لن يُشفَّر", "Warning: content won't be encrypted"), "alert"); },
    toggleIntegrity: function () { S.integrity = !S.integrity; refresh(); }, parallelAuto: function () { S.parallelAuto = !S.parallelAuto; refresh(); },
    lockPrivacy: function () { S.lockPrivacy = !S.lockPrivacy; refresh(); }, showNames: function () { S.showNames = !S.showNames; refresh(); },
    perfMode: function () {
      if (S.perfMode) { S.perfMode = false; refresh(); return; }
      O.dialog('<div class="d-ic" style="background:var(--c-warm-container);color:var(--c-warm)">' + I("bolt", "", 28) + '</div><div class="t-headline">' + L("وضع الأداء الأقصى", "Max performance mode") + '</div><p class="muted">' + L("يُرسل المحتوى بدون تشفير لكن كل مقطع مُصادَق بمفتاح الجلسة (BLAKE3 keyed) فلا يمكن حقن بيانات. أي شخص على نفس الشبكة قد يرى المحتوى. استخدمه فقط على شبكة تثق بها.", "Content is sent unencrypted, but every chunk is authenticated with the session key (keyed BLAKE3) so data can't be injected. Anyone on the same network may see the content. Use only on networks you trust.") + '</p><div class="d-acts"><button class="btn text" data-act="closeOverlay">' + L("إلغاء", "Cancel") + '</button><button class="btn filled" data-act="perfOn">' + L("أفهم، فعّل", "I understand, enable") + "</button></div>");
    },
    perfOn: function () { S.perfMode = true; O.closeAll(); refresh(); },
    helper: function () {
      if (S.helper) { S.helper = false; refresh(); return; }
      O.dialog('<div class="d-ic">' + I("key", "", 28) + '</div><div class="t-headline">' + L("مساعد الصلاحيات", "Privileged Helper") + '</div><p class="muted">' + L("طبقة اختيارية عبر Shizuku أو Root تفتح: هوتسبوت باسم مخصص، تثبيت صامت، والوصول لـ Android/obb. التطبيق يعمل كاملًا بدونها. لا تُنفَّذ إلا أوامر من قائمة بيضاء ثابتة ولا يُمرَّر لها أي نص من الشبكة.", "Optional layer via Shizuku or Root that unlocks: custom-named hotspot, silent install and Android/obb access. The app works fully without it. Only a fixed allow-list of commands runs, never with network-provided text.") + '</p><div class="d-acts"><button class="btn text" data-act="closeOverlay">' + L("ليس الآن", "Not now") + '</button><button class="btn filled" data-act="helperOn">' + L("الاتصال بـ Shizuku", "Connect Shizuku") + "</button></div>");
    },
    helperOn: function () { S.helper = true; O.closeAll(); refresh(); },
    toggleWeb: function () { S.webOn = !S.webOn; refresh(); }, togglePlay: function () { S.watchPlaying = !S.watchPlaying; refresh(); },
    torch: function () { S.torch = !S.torch; refresh(); }, toggleScanDenied: function () { S.scanDenied = !S.scanDenied; refresh(); },
    pickDev: function (id) { if (S.pickedDevices.has(id)) S.pickedDevices.delete(id); else S.pickedDevices.add(id); refresh(); },
    startSend: function () { S.progressMode = S.pickedDevices.size > 1 ? "multi" : "single"; ["single", "m1", "m2", "m3"].forEach(function (k) { var t = SIM.t[k]; t.done = 0; t.state = "run"; t.hist = []; }); SIM.paused = false; go("progress"); },
    togglePause: function () { SIM.paused = !SIM.paused; refresh(); },
    cancelSend: function () { O.dialog('<div class="t-headline">' + L("إلغاء النقل؟", "Cancel transfer?") + '</div><p class="muted">' + L("سيُبلَّغ المستلم وتُحذف الأجزاء غير المكتملة لديه.", "The receiver is notified and partial data is removed on their side.") + '</p><div class="d-acts"><button class="btn text" data-act="closeOverlay">' + L("متابعة النقل", "Keep going") + '</button><button class="btn danger" data-act="cancelDo">' + L("إلغاء النقل", "Cancel transfer") + "</button></div>"); },
    cancelDo: function () { O.closeAll(); O.toast(L("أُلغي النقل", "Transfer canceled")); go("history"); },
    fix: function (k) { rationale(k); }, perm: function (k) { rationale(k); },
    grant: function (k) {
      O.closeAll();
      if (S.ready[k]) S.ready[k] = "ok";
      var pk = { notif: "notif", nearby: "nearby", battery: "battery", contactsW: "contactsW", install: "install", allFiles: "allFiles" }[k]; if (pk) S.perms[pk] = "granted";
      refresh();
      var ic = root.querySelector('[data-ready="' + k + '"] .ready-ic'); if (ic) { ic.classList.add("flip"); }
      O.toast(L("تم التفعيل · يتحدث العنصر تلقائيًا", "Enabled · item refreshed automatically"), "check");
    },
    consent: function () { O.dialog(SC.consentDialog()); startCountdown(); },
    consentDo: function (a) { stopCountdown(); O.closeAll(); O.toast({ once: L("قُبل مرة واحدة", "Accepted once"), trust: L("قُبل وأُضيف للموثوقين", "Accepted & trusted"), deny: L("رُفض الطلب وأُبلغ المرسل", "Declined; sender notified"), block: L("حُظر الجهاز بالبصمة", "Device blocked by fingerprint") }[a]); },
    manual: function () { O.sheet(SC.manualSheet()); }, folderSheet: function () { O.sheet(SC.folderSheet()); },
    manageTabs: function () {
      var rows = [["image", L("صور", "Photos")], ["video", L("فيديو", "Videos")], ["music", L("موسيقى", "Music")], ["doc", L("مستندات", "Documents")], ["archive", L("مضغوطة", "Archives")], ["app", L("تطبيقات", "Apps")], ["contact", L("جهات الاتصال", "Contacts")], ["download", L("التنزيلات", "Downloads")], ["folder", X.tx(D.custom.name)]];
      O.sheet('<div class="t-title">' + L("إدارة التبويبات", "Manage tabs") + '</div><p class="t-caption muted" style="margin:4px 0 12px">' + L("اسحب لإعادة الترتيب. التبويبات المخصصة تُضاف من مجلد عبر SAF.", "Drag to reorder. Custom tabs are added from a folder via SAF.") + '</p><div class="list">' +
        rows.map(function (r, i) { return C.li({ cls: "plain", lead: '<span class="faint">' + I("drag") + "</span>", t: '<span class="row">' + I(r[0], "", 18) + r[1] + "</span>", trail: i === 8 ? '<button class="icon-btn" aria-label="delete">' + I("trash", "", 18) + "</button>" : C.sw(true, "noop") }); }).join("") +
        '</div><div style="height:12px"></div><button class="btn tonal block" data-act="toast:openFolder">' + I("folderPlus") + L("إضافة تبويب من مجلد", "Add tab from folder") + "</button>");
    },
    qrWifi: function () { S.qrMode = "wifi"; go("qrshow"); },
    clearSel: function () { S.sel.clear(); updateSel(); },
    selAll: function () { Array.prototype.forEach.call(root.querySelectorAll(".screen.files [data-sel]"), function (e) { S.sel.add(e.getAttribute("data-sel")); }); updateSel(); },
    selGroup: function (gi) { D.images.forEach(function (x) { if (String(x.group) === gi) { S.sel.add(x.id); selSizes[x.id] = x.size; } }); updateSel(); },
    heroClose: function () { var v = root.querySelector(".hero-viewer"); if (v && v._close) v._close(); },
    heroSend: function () { var v = root.querySelector(".hero-viewer"); if (v) v.remove(); go("transfer"); },
    wcTab: function (a) { S.wcTab = a; shell(); }, wcSel: function (id) { if (S.wcSel.has(id)) S.wcSel.delete(id); else S.wcSel.add(id); shell(); }
  };
  var cd = null;
  function startCountdown() {
    stopCountdown(); var c = root.querySelector("[data-countdown]"), num = root.querySelector("[data-countnum]"); if (!c) return;
    var circ = 2 * Math.PI * 19, left = 60; c.style.strokeDashoffset = 0;
    cd = setInterval(function () {
      left--; if (!root.contains(c)) { stopCountdown(); return; }
      num.textContent = left; c.style.strokeDashoffset = (1 - left / 60) * circ;
      if (left <= 0) { stopCountdown(); O.closeAll(); O.toast(L("انتهت المهلة · رُفض تلقائيًا وأُبلغ المرسل", "Timed out · auto-declined, sender notified")); }
    }, 1000);
  }
  function stopCountdown() { if (cd) clearInterval(cd); cd = null; }

  function openHero(cell) {
    var seed = +cell.getAttribute("data-hero"), img = D.images.filter(function (x) { return x.seed === seed; })[0] || { name: "IMG", size: 4 };
    M.hero(cell, '<div class="hv-bar"><button class="icon-btn" style="color:#fff" data-act="heroClose" aria-label="' + L("إغلاق", "Close") + '">' + I("back", "chev") + '</button><div class="grow"><div class="t-subtitle ltr">' + img.name + '</div><div class="t-caption num" style="opacity:.7">' + img.size.toFixed(1) + ' MB · 4032×3024</div></div></div><div class="hv-img">' + SM.thumb(seed) +
      '</div><div class="hv-foot"><button class="btn filled" data-act="heroSend">' + I("send", "", 18) + L("إرسال", "Send") + '</button><button class="btn tonal" style="background:rgba(255,255,255,.14);color:#fff" data-act="heroClose">' + L("رجوع", "Back") + "</button></div>", appEl());
  }

  function onClick(e) {
    var pv = e.target.closest("[data-pv]");
    if (pv) {
      var p = pv.getAttribute("data-pv").split(":"), k = p[0], v = p.slice(1).join(":");
      if (k === "menu") { root.querySelector(".pv").classList.toggle("nav-open"); return; }
      if (k === "nav") { root.querySelector(".pv").classList.remove("nav-open"); go(v, { force: true }); return; }
      if (k === "speed") S.speed = parseFloat(v); else if (k === "lowEnd") { S.lowEnd = !S.lowEnd; S.autoLowEnd = false; } else if (k === "reduced") S.reduced = !S.reduced; else S[k] = v;
      X.save(); shell(); return;
    }
    var sel = e.target.closest("[data-sel]");
    if (sel && !e.target.closest("[data-act]")) {
      if (suppress) { suppress = false; return; }
      if (!S.sel.size && sel.hasAttribute("data-hero")) { openHero(sel); return; }
      setSel(sel, !S.sel.has(sel.getAttribute("data-sel"))); return;
    }
    var a = e.target.closest("[data-act]"); if (!a) return;
    var parts = a.getAttribute("data-act").split(":"), fn = A[parts[0]];
    if (fn) { e.preventDefault(); fn(parts.slice(1).join(":"), a, e); }
  }

  function boot(el) {
    if (!el || el.__sisi) return; el.__sisi = true; root = el;
    root.addEventListener("click", onClick);
    root.addEventListener("pointerdown", onDown);
    root.addEventListener("pointermove", onMove, { passive: false });
    g.addEventListener("pointerup", onUp); g.addEventListener("pointercancel", onUp);
    root.addEventListener("contextmenu", function (e) { if (e.target.closest("[data-sel]")) e.preventDefault(); });
    root.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { var v = root.querySelector(".hero-viewer"); if (v && v._close) v._close(); else { O.closeAll(); stopCountdown(); } }
      if ((e.key === "Enter" || e.key === " ") && e.target.matches("[data-sel]")) { e.preventDefault(); setSel(e.target, !S.sel.has(e.target.getAttribute("data-sel"))); }
    });
    g.addEventListener("resize", fit);
    shell();
    if (S.lowEnd && S.autoLowEnd) setTimeout(function () { O.toast(L("اكتُشف جهاز محدود القدرات · فُعّل تخفيف الحركات تلقائيًا", "Low-end device detected · lighter motion enabled automatically"), "cpu"); }, 600);
    setInterval(function () { if (document.hidden) return; SIM.tick(1); SIM.apply(root.querySelector(".pv-stage")); }, 1000);
  }
  g.SisiPreview = { boot: boot, go: go, state: S };
  var auto = document.getElementById("jopro-root"); if (auto) boot(auto);
})(window);
