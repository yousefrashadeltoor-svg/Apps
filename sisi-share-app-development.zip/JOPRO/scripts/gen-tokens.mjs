#!/usr/bin/env node
/**
 * gen-tokens.mjs — يولّد كل ملفات التصميم من design/tokens.json
 *   css/tokens.css                                   (معاينة التصميم + أساس عميل الويب)
 *   app/lib/theme/tokens.g.dart                      (ثيم Flutter)
 *   app/android/app/src/main/res/values/colors.xml   (ويدجتس/إشعارات — فاتح)
 *   app/android/app/src/main/res/values-night/colors.xml (داكن)
 *   app/android/app/src/main/res/values/dimens.xml
 * الاستخدام:  node scripts/gen-tokens.mjs        (من داخل JOPRO/)
 *            node scripts/gen-tokens.mjs --check (يفشل إن كانت الملفات المولّدة قديمة — للـ CI)
 * بدون أي اعتماديات خارجية.
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const T = JSON.parse(readFileSync(join(ROOT, "design/tokens.json"), "utf8"));
const CHECK = process.argv.includes("--check");
const HEADER = "GENERATED FROM design/tokens.json — DO NOT EDIT. Run: node scripts/gen-tokens.mjs";

const kebab = (s) => s.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const bez = (a) => `cubic-bezier(${a.join(", ")})`;

/* ---------------- CSS ---------------- */
function css() {
  const L = [`/* ${HEADER} */`, ":root {"];
  for (const [k, v] of Object.entries(T.color.brand)) L.push(`  --brand-${kebab(k)}: ${v};`);
  for (const [k, v] of Object.entries(T.color.fileType)) L.push(`  --ft-${kebab(k)}: ${v};`);
  T.color.avatar.forEach((v, i) => L.push(`  --avatar-${i}: ${v};`));
  const f = T.typography.family;
  L.push(`  --font-base: "${f.base}", ${f.fallback};`);
  L.push(`  --font-numeric: "${f.numeric}", "${f.base}", ${f.fallback};`);
  for (const [k, s] of Object.entries(T.typography.scale)) {
    L.push(`  --type-${k}-size: ${s.size}px;`, `  --type-${k}-line: ${s.line}px;`,
      `  --type-${k}-weight: ${s.weight};`, `  --type-${k}-tracking: ${s.tracking}px;`);
  }
  for (const [k, v] of Object.entries(T.space)) L.push(`  --space-${k}: ${v}px;`);
  for (const [k, v] of Object.entries(T.radius)) L.push(`  --radius-${kebab(k)}: ${v}px;`);
  for (const [k, v] of Object.entries(T.size)) L.push(`  --size-${kebab(k)}: ${v}px;`);
  L.push("  --motion-scale: 1;");
  for (const [k, v] of Object.entries(T.motion.duration)) {
    L.push(`  --dur-${kebab(k)}: ${v}ms;`);
    L.push(`  --t-${kebab(k)}: calc(var(--dur-${kebab(k)}) * var(--motion-scale));`);
  }
  for (const [k, v] of Object.entries(T.motion.easing)) L.push(`  --ease-${kebab(k)}: ${bez(v)};`);
  L.push(`  --blur-glass: ${T.blur.glass}px;`, `  --blur-scrim: ${T.blur.scrim}px;`);
  for (const [k, v] of Object.entries(T.opacity)) L.push(`  --opacity-${k}: ${v};`);
  L.push(`  --low-end-duration-scale: ${T.motion.lowEnd.durationScale};`);
  L.push("}");
  for (const mode of ["dark", "light"]) {
    L.push(`[data-theme="${mode}"] {`, `  color-scheme: ${mode};`);
    for (const [k, v] of Object.entries(T.color[mode])) L.push(`  --c-${kebab(k)}: ${v};`);
    for (const [k, v] of Object.entries(T.elevation[mode])) L.push(`  --elev-${k}: ${v};`);
    L.push("}");
  }
  return L.join("\n") + "\n";
}

/* ---------------- Dart ---------------- */
function dartColor(v) {
  const m = v.match(/^rgba\((\d+),(\d+),(\d+),([\d.]+)\)$/);
  if (m) {
    const a = Math.round(parseFloat(m[4]) * 255);
    return "0x" + [a, +m[1], +m[2], +m[3]].map((n) => n.toString(16).padStart(2, "0")).join("").toUpperCase();
  }
  return "0xFF" + v.replace("#", "").toUpperCase();
}
function dart() {
  const L = [`// ${HEADER}`, "// ignore_for_file: constant_identifier_names", "import 'package:flutter/animation.dart';", "import 'dart:ui';", ""];
  L.push("abstract final class BrandColors {");
  for (const [k, v] of Object.entries(T.color.brand)) L.push(`  static const Color ${k} = Color(${dartColor(v)});`);
  L.push("}", "");
  L.push("abstract final class FileTypeColors {");
  for (const [k, v] of Object.entries(T.color.fileType)) L.push(`  static const Color ${k} = Color(${dartColor(v)});`);
  L.push("}", "");
  L.push(`const List<Color> kAvatarColors = [${T.color.avatar.map((v) => `Color(${dartColor(v)})`).join(", ")}];`, "");
  L.push("class SisiPalette {");
  const keys = Object.keys(T.color.dark);
  L.push(`  const SisiPalette({${keys.map((k) => `required this.${k}`).join(", ")}});`);
  for (const k of keys) L.push(`  final Color ${k};`);
  for (const mode of ["dark", "light"]) {
    L.push(`  static const SisiPalette ${mode} = SisiPalette(`);
    for (const k of keys) L.push(`    ${k}: Color(${dartColor(T.color[mode][k])}),`);
    L.push("  );");
  }
  L.push("}", "");
  L.push("abstract final class SisiSpace {");
  for (const [k, v] of Object.entries(T.space)) L.push(`  static const double s${k} = ${v}.0;`);
  L.push("}", "", "abstract final class SisiRadius {");
  for (const [k, v] of Object.entries(T.radius)) L.push(`  static const double ${k} = ${v}.0;`);
  L.push("}", "", "abstract final class SisiSize {");
  for (const [k, v] of Object.entries(T.size)) L.push(`  static const double ${k} = ${v}.0;`);
  L.push("}", "", "class SisiTypeSpec {", "  const SisiTypeSpec(this.size, this.line, this.weight, this.tracking);",
    "  final double size, line, tracking;", "  final int weight;", "  double get height => line / size;", "}", "",
    "abstract final class SisiType {",
    `  static const String familyBase = '${T.typography.family.base}';`,
    `  static const String familyNumeric = '${T.typography.family.numeric}';`);
  for (const [k, s] of Object.entries(T.typography.scale)) L.push(`  static const SisiTypeSpec ${k} = SisiTypeSpec(${s.size}, ${s.line}, ${s.weight}, ${s.tracking});`);
  L.push("}", "", "abstract final class SisiMotion {");
  for (const [k, v] of Object.entries(T.motion.duration)) L.push(`  static const Duration ${k} = Duration(milliseconds: ${v});`);
  for (const [k, v] of Object.entries(T.motion.easing)) L.push(`  static const Cubic ${k}Curve = Cubic(${v.join(", ")});`);
  L.push(`  static const double lowEndDurationScale = ${T.motion.lowEnd.durationScale};`);
  L.push(`  static const int lowEndRadarRings = ${T.motion.lowEnd.radarRings};`);
  L.push("}", "");
  return L.join("\n");
}

/* ---------------- Android XML ---------------- */
function argb(v) {
  const m = v.match(/^rgba\((\d+),(\d+),(\d+),([\d.]+)\)$/);
  if (m) return "#" + [Math.round(+m[4] * 255), +m[1], +m[2], +m[3]].map((n) => n.toString(16).padStart(2, "0")).join("").toUpperCase();
  return v.toUpperCase();
}
const snake = (s) => kebab(s).replace(/-/g, "_");
function colorsXml(mode) {
  const L = ['<?xml version="1.0" encoding="utf-8"?>', `<!-- ${HEADER} -->`, "<resources>"];
  for (const [k, v] of Object.entries(T.color[mode])) L.push(`    <color name="sisi_${snake(k)}">${argb(v)}</color>`);
  if (mode === "light") {
    for (const [k, v] of Object.entries(T.color.brand)) L.push(`    <color name="sisi_brand_${snake(k)}">${argb(v)}</color>`);
    for (const [k, v] of Object.entries(T.color.fileType)) L.push(`    <color name="sisi_ft_${snake(k)}">${argb(v)}</color>`);
  }
  L.push("</resources>", "");
  return L.join("\n");
}
function dimensXml() {
  const L = ['<?xml version="1.0" encoding="utf-8"?>', `<!-- ${HEADER} -->`, "<resources>"];
  for (const [k, v] of Object.entries(T.space)) L.push(`    <dimen name="sisi_space_${k}">${v}dp</dimen>`);
  for (const [k, v] of Object.entries(T.radius)) if (v < 999) L.push(`    <dimen name="sisi_radius_${snake(k)}">${v}dp</dimen>`);
  for (const [k, v] of Object.entries(T.size)) L.push(`    <dimen name="sisi_size_${snake(k)}">${v}dp</dimen>`);
  for (const [k, s] of Object.entries(T.typography.scale)) L.push(`    <dimen name="sisi_text_${k}">${s.size}sp</dimen>`);
  L.push("</resources>", "");
  return L.join("\n");
}

const outputs = {
  "css/tokens.css": css(),
  "app/lib/theme/tokens.g.dart": dart(),
  "app/android/app/src/main/res/values/colors.xml": colorsXml("light"),
  "app/android/app/src/main/res/values-night/colors.xml": colorsXml("dark"),
  "app/android/app/src/main/res/values/dimens.xml": dimensXml(),
};

let stale = 0;
for (const [rel, content] of Object.entries(outputs)) {
  const p = join(ROOT, rel);
  if (CHECK) {
    if (!existsSync(p) || readFileSync(p, "utf8") !== content) { console.error("STALE: " + rel); stale++; }
    continue;
  }
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, content);
  console.log("wrote " + rel + " (" + content.length + " bytes)");
}
if (CHECK) { if (stale) process.exit(1); console.log("tokens up to date"); }
