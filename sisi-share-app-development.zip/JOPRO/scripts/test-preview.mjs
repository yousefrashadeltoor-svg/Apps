#!/usr/bin/env node
/**
 * test-preview.mjs — اختبارات قبول المرحلة 0 (معاينة التصميم).
 *  1) الـ tokens المولّدة محدّثة (gen-tokens --check).
 *  2) كل رمز QR يولّده js/qr.js يُفك ترميزه بمكتبة مستقلة (jsQR) ويطابق النص الأصلي.
 *  3) كل الشاشات تُصيَّر بالعربية والإنجليزية وعلى الهاتف والتابلت بلا أخطاء JS ولا "undefined/NaN".
 *  4) التفاعلات الحرجة: Hero، التحديد، الجاهزية، المحاكاة، الحوارات، عميل الويب، مفاتيح المعاينة.
 *  5) لا روابط شبكة خارجية (CDN) في ملفات المعاينة.
 * التشغيل (من داخل JOPRO/):  npm i --no-save jsdom@24 jsqr@1 && node scripts/test-preview.mjs
 */
import { readFileSync, readdirSync } from "node:fs";
import { join, resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
import { execFileSync } from "node:child_process";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(join(ROOT, "package.json"));
const { JSDOM } = require("jsdom");
const jsQR = require("jsqr");
let failures = 0;
const ok = (c, m) => { console.log((c ? "  ✓ " : "  ✗ ") + m); if (!c) failures++; };

console.log("1) tokens");
try { execFileSync("node", [join(ROOT, "scripts/gen-tokens.mjs"), "--check"], { stdio: "pipe" }); ok(true, "generated files up to date"); } catch { ok(false, "tokens stale — run gen-tokens.mjs"); }

console.log("2) QR round-trip");
const qrCtx = {}; new Function("window", readFileSync(join(ROOT, "js/qr.js"), "utf8"))(qrCtx);
for (const t of ["http://192.168.1.24:53318", "WIFI:T:WPA;S:DIRECT-xQ-SISI;P:k7m2-v9pa;;", "sisi://connect?ip=192.168.1.24&port=53317&fp=A39F2C71D04E88B1&t=Xk29fQ", "مرحبا SISI Share", "x".repeat(300)]) {
  const q = qrCtx.SisiQR.encode(t), s = 4, qz = 4, n = (q.size + qz * 2) * s, d = new Uint8ClampedArray(n * n * 4);
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
    const mx = Math.floor(x / s) - qz, my = Math.floor(y / s) - qz, dark = mx >= 0 && my >= 0 && mx < q.size && my < q.size && q.modules[my][mx], i = (y * n + x) * 4;
    d[i] = d[i + 1] = d[i + 2] = dark ? 0 : 255; d[i + 3] = 255;
  }
  const r = jsQR(d, n, n); ok(r && r.data === t, `v${q.version} decodes: ${t.slice(0, 40)}`);
}

console.log("3) screens");
const html = readFileSync(join(ROOT, "index.html"), "utf8").replace(/<script src="[^"]+"><\/script>/g, "");
const dom = new JSDOM(html, { runScripts: "outside-only", pretendToBeVisual: true, url: "file:///jopro/index.html" });
const w = dom.window, errors = [];
w.addEventListener("error", (e) => errors.push(e.message));
w.Element.prototype.animate = function () { return { set onfinish(f) { if (f) f(); }, cancel() {} }; }; // ينهي الحركة فورًا (مثل تقليل الحركة)
w.Element.prototype.scrollIntoView = function () {};
w.matchMedia = () => ({ matches: false }); w.document.elementFromPoint = () => null;
for (const f of ["qr", "icons", "sample", "core", "screens-a", "screens-b", "gallery", "app"]) w.eval(readFileSync(join(ROOT, "js", f + ".js"), "utf8"));
const P = w.SisiPreview, S = P.state, root = w.document.getElementById("jopro-root");
const click = (sel) => { const el = root.querySelector(sel); if (!el) { errors.push("missing " + sel); return; } el.dispatchEvent(new w.MouseEvent("click", { bubbles: true })); };
const live = (sel) => root.querySelector(".screen:not(.leaving) " + sel);
const screens = ["home", "files", "filesApps", "filesCustom", "transfer", "progress", "receive", "scan", "qrshow", "network", "history", "settings", "trust", "web", "watch", "permissions", "states", "system", "gallery"];
let n = 0;
for (const lang of ["ar", "en"]) for (const frame of ["phone", "tablet"]) {
  click(`[data-pv="lang:${lang}"]`); click(`[data-pv="frame:${frame}"]`);
  for (const s of screens) {
    click(`[data-pv="nav:${s}"]`); const scr = root.querySelector(".screen:not(.leaving)");
    if (!scr || scr.innerHTML.length < 200) errors.push(`empty ${s}`);
    else if (/undefined|NaN|\[object/.test(scr.textContent)) errors.push(`bad text in ${s}/${lang}`);
    n++;
  }
}
ok(n === screens.length * 4, `${n} screen renders`);

console.log("4) interactions");
click('[data-pv="nav:files"]'); click('[data-act="filesTab:images"]');
click(".screen:not(.leaving) [data-hero]"); ok(!!root.querySelector(".hero-viewer"), "hero viewer opens from thumbnail");
root.querySelectorAll(".hero-viewer").forEach((v) => v.remove());
click('[data-act="filesTab:music"]'); click(".screen:not(.leaving) [data-sel]");
ok(S.sel.size === 1 && /1/.test(live("[data-selcount]").textContent), "tap selects & counter updates");
click('[data-act="selAll"]'); ok(S.sel.size > 1, "select all"); click('[data-act="clearSel"]'); ok(S.sel.size === 0, "clear selection");
click('[data-pv="nav:transfer"]'); click('[data-act="fix:nearby"]'); ok(!!root.querySelector(".dialog"), "rationale shown before permission");
click('[data-act="grant:nearby"]'); ok(S.ready.nearby === "ok" && S.perms.nearby === "granted", "readiness item updates after grant");
click('[data-act="startSend"]'); for (let i = 0; i < 5; i++) { w.Sisi.SIM.tick(1); w.Sisi.SIM.apply(root); }
ok(/^\d+%$/.test(live('[data-sim^="pct:"]').textContent), "progress shows animated sample %");
click('[data-pv="nav:receive"]'); click('[data-act="consent"]'); ok(!!root.querySelector("[data-countdown]"), "consent dialog with 60s countdown");
click('[data-act="consentDo:block"]');
click('[data-pv="nav:qrshow"]'); for (const m of ["wifi", "web", "device"]) click(`[data-act="qrMode:${m}"]`); ok(root.querySelectorAll(".qr-svg").length === 1, "real QR rendered");
click('[data-pv="nav:settings"]'); click('[data-act="perfMode"]'); ok(!!root.querySelector(".dialog"), "performance mode warns first"); click('[data-act="perfOn"]'); ok(S.perfMode, "performance mode enabled after consent");
click('[data-pv="nav:webclient"]'); for (const t of ["upload", "watch", "approval", "files"]) click(`[data-act="wcTab:${t}"]`); ok(!!root.querySelector(".frame-browser .wc-grid"), "web client renders in desktop frame");
click('[data-pv="theme:light"]'); click('[data-pv="lowEnd"]'); click('[data-pv="reduced"]'); click('[data-pv="speed:0.25"]'); click('[data-pv="nav:home"]');
ok(root.querySelector(".pv").getAttribute("data-theme") === "light", "preview controls apply");
ok(errors.length === 0, "no runtime errors" + (errors.length ? ": " + errors.join(" | ") : ""));

console.log("5) offline");
const files = ["index.html", ...readdirSync(join(ROOT, "css")).map((f) => "css/" + f), ...readdirSync(join(ROOT, "js")).map((f) => "js/" + f)];
const ext = files.filter((f) => /(src|href)=["']https?:|url\(["']?https?:|@import\s+["']?https?:/.test(readFileSync(join(ROOT, f), "utf8")));
ok(ext.length === 0, "no external resources" + (ext.length ? ": " + ext.join(", ") : ""));

console.log(failures ? `\nFAILED: ${failures}` : "\nALL PASSED");
process.exit(failures ? 1 : 0);
