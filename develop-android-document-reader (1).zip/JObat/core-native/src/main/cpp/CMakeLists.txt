cmake_minimum_required(VERSION 3.22.1)
project("jobat_mupdf_jni" LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Support linking prebuilt/vendored Librera MuPDF + DjVuLibre + libarchive when present under third_party/mupdf
set(MUPDF_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/third_party/mupdf")
if (EXISTS "${MUPDF_ROOT}/include/mupdf/fitz.h")
    add_compile_definitions(JOBAT_HAS_MUPDF=1)
    include_directories("${MUPDF_ROOT}/include")
    add_library(mupdf STATIC IMPORTED)
    set_target_properties(mupdf PROPERTIES IMPORTED_LOCATION "${MUPDF_ROOT}/lib/${ANDROID_ABI}/libmupdf.a")
    add_library(mupdf_third STATIC IMPORTED)
    set_target_properties(mupdf_third PROPERTIES IMPORTED_LOCATION "${MUPDF_ROOT}/lib/${ANDROID_ABI}/libmupdf-third.a")
endif()

add_library(jobat_mupdf_jni SHARED jobat_mupdf_jni.cpp)

find_library(log-lib log)
find_library(jnigraphics-lib jnigraphics)
find_library(z-lib z)

target_link_options(jobat_mupdf_jni PRIVATE
    "-Wl,--gc-sections"
    "-Wl,--exclude-libs,ALL"
    "-Wl,-z,max-page-size=16384"
)

if (EXISTS "${MUPDF_ROOT}/include/mupdf/fitz.h")
    target_link_libraries(jobat_mupdf_jni PRIVATE mupdf mupdf_third ${jnigraphics-lib} ${z-lib} ${log-lib})
else()
    target_link_libraries(jobat_mupdf_jni PRIVATE ${jnigraphics-lib} ${z-lib} ${log-lib})
endif()
