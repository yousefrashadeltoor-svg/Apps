#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#ifdef JOBAT_HAS_MUPDF
extern "C" {
#include <mupdf/fitz.h>
#include <mupdf/pdf.h>
}
#endif

#define LOG_TAG "JObatMuPDF"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

struct NativeDocSession {
    std::mutex mutex;
    std::string path;
    bool needsPassword = false;
    bool authenticated = true;
#ifdef JOBAT_HAS_MUPDF
    fz_context* ctx = nullptr;
    fz_document* doc = nullptr;
#endif
};

std::mutex gRegistryMutex;
int64_t gNextHandle = 1;
std::unordered_map<int64_t, NativeDocSession*> gSessions;

NativeDocSession* getSession(jlong handle) {
    std::lock_guard<std::mutex> lock(gRegistryMutex);
    auto it = gSessions.find(static_cast<int64_t>(handle));
    return (it != gSessions.end()) ? it->second : nullptr;
}

} // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeIsMuPdfLinked(JNIEnv*, jobject) {
#ifdef JOBAT_HAS_MUPDF
    return JNI_TRUE;
#else
    return JNI_FALSE;
#endif
}

JNIEXPORT jlong JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeOpenDocument(
        JNIEnv* env, jobject, jstring jPath) {
    if (!jPath) return 0L;
    const char* rawPath = env->GetStringUTFChars(jPath, nullptr);
    std::string path(rawPath ? rawPath : "");
    env->ReleaseStringUTFChars(jPath, rawPath);
    if (path.empty()) return 0L;

#ifdef JOBAT_HAS_MUPDF
    fz_context* ctx = fz_new_context(nullptr, nullptr, 64 << 20); // 64MB store cap for low RAM
    if (!ctx) return 0L;

    fz_document* doc = nullptr;
    bool needsPwd = false;
    fz_try(ctx) {
        fz_register_document_handlers(ctx);
        doc = fz_open_document(ctx, path.c_str());
        needsPwd = fz_needs_password(ctx, doc) != 0;
    } fz_catch(ctx) {
        LOGE("fz_open_document failed: %s", fz_caught_message(ctx));
        fz_drop_context(ctx);
        return -1L; // Corrupt or unsupported stream
    }

    auto* session = new NativeDocSession();
    session->path = path;
    session->ctx = ctx;
    session->doc = doc;
    session->needsPassword = needsPwd;
    session->authenticated = !needsPwd;

    std::lock_guard<std::mutex> lock(gRegistryMutex);
    const int64_t handle = gNextHandle++;
    gSessions[handle] = session;
    return static_cast<jlong>(handle);
#else
    return 0L;
#endif
}

JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeNeedsPassword(
        JNIEnv*, jobject, jlong handle) {
    auto* s = getSession(handle);
    if (!s) return JNI_FALSE;
    std::lock_guard<std::mutex> lock(s->mutex);
    return (s->needsPassword && !s->authenticated) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeAuthenticate(
        JNIEnv* env, jobject, jlong handle, jstring jPassword) {
    auto* s = getSession(handle);
    if (!s || !jPassword) return JNI_FALSE;
    const char* pwd = env->GetStringUTFChars(jPassword, nullptr);
    bool ok = false;
#ifdef JOBAT_HAS_MUPDF
    std::lock_guard<std::mutex> lock(s->mutex);
    fz_try(s->ctx) {
        ok = fz_authenticate_password(s->ctx, s->doc, pwd) != 0;
        s->authenticated = ok;
    } fz_catch(s->ctx) {
        ok = false;
    }
#endif
    env->ReleaseStringUTFChars(jPassword, pwd);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeCountPages(
        JNIEnv*, jobject, jlong handle) {
#ifdef JOBAT_HAS_MUPDF
    auto* s = getSession(handle);
    if (!s) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    int count = 0;
    fz_try(s->ctx) {
        count = fz_count_pages(s->ctx, s->doc);
    } fz_catch(s->ctx) {
        count = 0;
    }
    return count;
#else
    (void)handle;
    return 0;
#endif
}

JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeRenderPage(
        JNIEnv* env, jobject, jlong handle, jint pageIndex, jobject bitmap,
        jfloat scale, jboolean autoCrop, jfloat contrastBoost) {
    if (!bitmap) return JNI_FALSE;
    AndroidBitmapInfo info{};
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS ||
        info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) {
        return JNI_FALSE;
    }
    void* pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS) {
        return JNI_FALSE;
    }

    bool rendered = false;
#ifdef JOBAT_HAS_MUPDF
    auto* s = getSession(handle);
    if (s) {
        std::lock_guard<std::mutex> lock(s->mutex);
        fz_page* page = nullptr;
        fz_pixmap* pix = nullptr;
        fz_device* dev = nullptr;
        fz_var(page);
        fz_var(pix);
        fz_var(dev);
        fz_try(s->ctx) {
            page = fz_load_page(s->ctx, s->doc, pageIndex);
            fz_rect bounds = fz_bound_page(s->ctx, page);
            const float marginTrim = autoCrop ? 0.045f : 0.0f;
            const float effScale = scale * (1.0f + marginTrim * 2.0f);
            fz_matrix ctm = fz_scale(effScale, effScale);
            if (autoCrop) {
                ctm = fz_pre_translate(ctm,
                        -(bounds.x1 - bounds.x0) * marginTrim,
                        -(bounds.y1 - bounds.y0) * marginTrim);
            }
            fz_irect bbox = fz_make_irect(0, 0,
                    static_cast<int>(info.width), static_cast<int>(info.height));
            pix = fz_new_pixmap_with_bbox_and_data(
                    s->ctx, fz_device_rgb(s->ctx), bbox, nullptr, 1,
                    static_cast<unsigned char*>(pixels));
            fz_clear_pixmap_with_value(s->ctx, pix, 255);
            dev = fz_new_draw_device(s->ctx, fz_identity, pix);
            fz_run_page(s->ctx, page, dev, ctm, nullptr);
            fz_close_device(s->ctx, dev);
            rendered = true;
        } fz_always(s->ctx) {
            fz_drop_device(s->ctx, dev);
            fz_drop_pixmap(s->ctx, pix);
            fz_drop_page(s->ctx, page);
        } fz_catch(s->ctx) {
            LOGE("nativeRenderPage failed: %s", fz_caught_message(s->ctx));
        }
    }
#else
    (void)handle;
    (void)pageIndex;
    (void)scale;
    (void)autoCrop;
#endif

    // Optional native contrast enhancement pass for scanned documents
    if (contrastBoost > 1.01f && pixels != nullptr) {
        auto* bytes = static_cast<uint8_t*>(pixels);
        const size_t total = static_cast<size_t>(info.height) * info.stride;
        for (size_t i = 0; i + 3 < total; i += 4) {
            for (int c = 0; c < 3; ++c) {
                float v = (static_cast<float>(bytes[i + c]) - 128.0f) * contrastBoost + 128.0f;
                bytes[i + c] = static_cast<uint8_t>(v < 0.0f ? 0.0f : (v > 255.0f ? 255.0f : v));
            }
        }
    }

    AndroidBitmap_unlockPixels(env, bitmap);
    return rendered ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeExtractPageText(
        JNIEnv* env, jobject, jlong handle, jint pageIndex) {
    std::string text;
#ifdef JOBAT_HAS_MUPDF
    auto* s = getSession(handle);
    if (s) {
        std::lock_guard<std::mutex> lock(s->mutex);
        fz_page* page = nullptr;
        fz_stext_page* stext = nullptr;
        fz_buffer* buf = nullptr;
        fz_output* out = nullptr;
        fz_var(page); fz_var(stext); fz_var(buf); fz_var(out);
        fz_try(s->ctx) {
            page = fz_load_page(s->ctx, s->doc, pageIndex);
            stext = fz_new_stext_page_from_page(s->ctx, page, nullptr);
            buf = fz_new_buffer(s->ctx, 4096);
            out = fz_new_output_with_buffer(s->ctx, buf);
            fz_print_stext_page_as_text(s->ctx, out, stext);
            fz_close_output(s->ctx, out);
            const char* str = fz_string_from_buffer(s->ctx, buf);
            if (str) text.assign(str);
        } fz_always(s->ctx) {
            fz_drop_output(s->ctx, out);
            fz_drop_buffer(s->ctx, buf);
            fz_drop_stext_page(s->ctx, stext);
            fz_drop_page(s->ctx, page);
        } fz_catch(s->ctx) {
            LOGE("nativeExtractPageText failed: %s", fz_caught_message(s->ctx));
        }
    }
#else
    (void)handle;
    (void)pageIndex;
#endif
    return env->NewStringUTF(text.c_str());
}

JNIEXPORT jfloatArray JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeSearchPage(
        JNIEnv* env, jobject, jlong handle, jint pageIndex, jstring jQuery) {
    std::vector<jfloat> rects;
#ifdef JOBAT_HAS_MUPDF
    auto* s = getSession(handle);
    if (s && jQuery) {
        const char* q = env->GetStringUTFChars(jQuery, nullptr);
        std::lock_guard<std::mutex> lock(s->mutex);
        fz_quad hits[128];
        fz_try(s->ctx) {
            int n = fz_search_page_number(s->ctx, s->doc, pageIndex, q, nullptr, hits, 128);
            rects.reserve(static_cast<size_t>(n) * 4);
            for (int i = 0; i < n; ++i) {
                fz_rect r = fz_rect_from_quad(hits[i]);
                rects.push_back(r.x0);
                rects.push_back(r.y0);
                rects.push_back(r.x1);
                rects.push_back(r.y1);
            }
        } fz_catch(s->ctx) {}
        env->ReleaseStringUTFChars(jQuery, q);
    }
#else
    (void)handle; (void)pageIndex; (void)jQuery;
#endif
    jfloatArray arr = env->NewFloatArray(static_cast<jsize>(rects.size()));
    if (!rects.empty() && arr) {
        env->SetFloatArrayRegion(arr, 0, static_cast<jsize>(rects.size()), rects.data());
    }
    return arr;
}

JNIEXPORT void JNICALL
Java_com_jobat_core_nativebridge_MuPdfNativeBridge_nativeCloseDocument(
        JNIEnv*, jobject, jlong handle) {
    NativeDocSession* s = nullptr;
    {
        std::lock_guard<std::mutex> lock(gRegistryMutex);
        auto it = gSessions.find(static_cast<int64_t>(handle));
        if (it != gSessions.end()) {
            s = it->second;
            gSessions.erase(it);
        }
    }
    if (!s) return;
#ifdef JOBAT_HAS_MUPDF
    {
        std::lock_guard<std::mutex> lock(s->mutex);
        if (s->doc) fz_drop_document(s->ctx, s->doc);
        if (s->ctx) fz_drop_context(s->ctx);
    }
#endif
    delete s;
}

} // extern "C"
