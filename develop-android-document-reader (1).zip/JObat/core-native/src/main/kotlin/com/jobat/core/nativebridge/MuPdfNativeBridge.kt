package com.jobat.core.nativebridge

import android.graphics.Bitmap
import android.graphics.RectF
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MuPdfNativeBridge {
    private val libraryLoaded: Boolean = runCatching {
        System.loadLibrary("jobat_mupdf_jni")
        true
    }.getOrDefault(false)

    val isMuPdfAvailable: Boolean
        get() = libraryLoaded && nativeIsMuPdfLinked()

    suspend fun open(path: String): Long = withContext(Dispatchers.IO) {
        if (!libraryLoaded) 0L else nativeOpenDocument(path)
    }

    fun needsPassword(handle: Long): Boolean =
        libraryLoaded && handle > 0L && nativeNeedsPassword(handle)

    suspend fun authenticate(handle: Long, password: String): Boolean = withContext(Dispatchers.IO) {
        libraryLoaded && handle > 0L && nativeAuthenticate(handle, password)
    }

    fun countPages(handle: Long): Int =
        if (libraryLoaded && handle > 0L) nativeCountPages(handle) else 0

    suspend fun renderPage(
        handle: Long,
        pageIndex: Int,
        target: Bitmap,
        scale: Float = 1f,
        autoCrop: Boolean = false,
        contrastBoost: Float = 1f
    ): Boolean = withContext(Dispatchers.IO) {
        if (!libraryLoaded || handle <= 0L) false
        else nativeRenderPage(handle, pageIndex, target, scale, autoCrop, contrastBoost)
    }

    suspend fun extractText(handle: Long, pageIndex: Int): String = withContext(Dispatchers.IO) {
        if (!libraryLoaded || handle <= 0L) "" else nativeExtractPageText(handle, pageIndex)
    }

    suspend fun searchPage(handle: Long, pageIndex: Int, query: String): List<RectF> =
        withContext(Dispatchers.IO) {
            if (!libraryLoaded || handle <= 0L || query.isBlank()) return@withContext emptyList()
            val raw = nativeSearchPage(handle, pageIndex, query)
            buildList(raw.size / 4) {
                var i = 0
                while (i + 3 < raw.size) {
                    add(RectF(raw[i], raw[i + 1], raw[i + 2], raw[i + 3]))
                    i += 4
                }
            }
        }

    fun close(handle: Long) {
        if (libraryLoaded && handle > 0L) nativeCloseDocument(handle)
    }

    private external fun nativeIsMuPdfLinked(): Boolean
    private external fun nativeOpenDocument(path: String): Long
    private external fun nativeNeedsPassword(handle: Long): Boolean
    private external fun nativeAuthenticate(handle: Long, password: String): Boolean
    private external fun nativeCountPages(handle: Long): Int
    private external fun nativeRenderPage(
        handle: Long,
        pageIndex: Int,
        bitmap: Bitmap,
        scale: Float,
        autoCrop: Boolean,
        contrastBoost: Float
    ): Boolean
    private external fun nativeExtractPageText(handle: Long, pageIndex: Int): String
    private external fun nativeSearchPage(handle: Long, pageIndex: Int, query: String): FloatArray
    private external fun nativeCloseDocument(handle: Long)
}
