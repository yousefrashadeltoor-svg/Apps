-keepclasseswithmembernames class com.jobat.core.nativebridge.MuPdfNativeBridge {
    native <methods>;
}
