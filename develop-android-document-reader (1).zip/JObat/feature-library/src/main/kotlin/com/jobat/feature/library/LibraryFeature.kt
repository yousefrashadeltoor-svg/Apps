package com.jobat.feature.library

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.jobat.data.LibraryIndexWorker
import com.jobat.designsystem.CircularGoldProgress
import com.jobat.designsystem.JobatTokens
import com.jobat.designsystem.JobatWordmark
import com.jobat.domain.DocumentItem
import com.jobat.domain.FormatCategory
import com.jobat.domain.LibraryRepository
import com.jobat.domain.LibrarySort
import com.jobat.domain.LibraryViewMode
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: LibraryRepository
) : ViewModel() {
    val searchQuery = MutableStateFlow("")
    val sortMode = MutableStateFlow(LibrarySort.LAST_READ)
    val viewMode = MutableStateFlow(LibraryViewMode.GRID)
    val categoryFilter = MutableStateFlow<FormatCategory?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val documents: StateFlow<List<DocumentItem>> = combine(
        searchQuery, sortMode, categoryFilter
    ) { q, sort, cat -> Triple(q, sort, cat) }
        .flatMapLatest { (q, sort, cat) ->
            if (q.isNotBlank()) repository.searchFts(q)
            else repository.observeLibrary(sort, cat, includeArchived = false, onlyTrashed = false)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun enqueueFolderScan(treeUri: Uri) {
        val req = OneTimeWorkRequestBuilder<LibraryIndexWorker>()
            .setInputData(workDataOf(LibraryIndexWorker.KEY_TREE_URI to treeUri.toString()))
            .build()
        WorkManager.getInstance(context).enqueue(req)
    }

    fun toggleFavorite(id: String) = viewModelScope.launch { repository.toggleFavorite(id) }
    fun moveToTrash(id: String) = viewModelScope.launch { repository.setTrashed(id, true) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    onOpenDocument: (DocumentItem, String?) -> Unit,
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val docs by viewModel.documents.collectAsStateWithLifecycle()
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val viewMode by viewModel.viewMode.collectAsStateWithLifecycle()
    val category by viewModel.categoryFilter.collectAsStateWithLifecycle()
    var passwordPromptDoc by remember { mutableStateOf<DocumentItem?>(null) }
    var previewDoc by remember { mutableStateOf<DocumentItem?>(null) }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) viewModel.enqueueFolderScan(uri)
    }

    val continueDoc = remember(docs) { docs.firstOrNull { it.progress in 0.01f..0.99f } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = JobatTokens.SpaceLg)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = JobatTokens.SpaceMd),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            JobatWordmark()
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    viewModel.viewMode.value = when (viewMode) {
                        LibraryViewMode.GRID -> LibraryViewMode.LIST
                        LibraryViewMode.LIST -> LibraryViewMode.COMPACT
                        LibraryViewMode.COMPACT -> LibraryViewMode.GRID
                    }
                }) { Text(viewMode.name) }
                FilledTonalIconButton(onClick = { folderPicker.launch(null) }) {
                    Icon(Icons.Default.Add, contentDescription = "Index SAF Folder")
                }
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.searchQuery.value = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            placeholder = { Text("ابحث في العناوين، المؤلفين، والمحتوى...") },
            shape = MaterialTheme.shapes.medium
        )

        Spacer(Modifier.height(JobatTokens.SpaceMd))

        if (continueDoc != null && query.isBlank()) {
            Surface(
                onClick = { onOpenDocument(continueDoc, null) },
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(JobatTokens.SpaceLg),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(JobatTokens.SpaceLg)
                ) {
                    CircularGoldProgress(progress = continueDoc.progress)
                    Column(modifier = Modifier.weight(1f)) {
                        Text("متابعة القراءة", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(continueDoc.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${continueDoc.currentPage}/${continueDoc.pageCount} • متبقي ~${continueDoc.estimateMinutesRemaining()} د",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(Modifier.height(JobatTokens.SpaceMd))
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(selected = category == null, onClick = { viewModel.categoryFilter.value = null }, label = { Text("الكل") })
            }
            items(FormatCategory.entries) { cat ->
                FilterChip(
                    selected = category == cat,
                    onClick = { viewModel.categoryFilter.value = if (category == cat) null else cat },
                    label = { Text(cat.name) }
                )
            }
        }

        Spacer(Modifier.height(JobatTokens.SpaceMd))

        if (viewMode == LibraryViewMode.GRID) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 148.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                items(docs, key = { it.id }) { doc ->
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.combinedClickable(
                            onClick = { if (doc.isPasswordProtected) passwordPromptDoc = doc else onOpenDocument(doc, null) },
                            onLongClick = { previewDoc = doc }
                        )
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(doc.format.name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text(doc.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(doc.author, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            LinearProgressIndicator(progress = { doc.progress }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                items(docs, key = { it.id }) { doc ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth().combinedClickable(
                            onClick = { if (doc.isPasswordProtected) passwordPromptDoc = doc else onOpenDocument(doc, null) },
                            onLongClick = { previewDoc = doc }
                        )
                    ) {
                        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(doc.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (viewMode == LibraryViewMode.LIST) {
                                    Text("${doc.author} • ${doc.format.name}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Text("${(doc.progress * 100).toInt()}%", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }

    passwordPromptDoc?.let { locked ->
        var pwd by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { passwordPromptDoc = null },
            title = { Text("مستند محمي بكلمة مرور") },
            text = {
                OutlinedTextField(
                    value = pwd,
                    onValueChange = { pwd = it },
                    visualTransformation = PasswordVisualTransformation(),
                    label = { Text("كلمة المرور") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    val target = locked; passwordPromptDoc = null
                    onOpenDocument(target, pwd)
                }) { Text("فتح") }
            },
            dismissButton = { TextButton(onClick = { passwordPromptDoc = null }) { Text("إلغاء") } }
        )
    }

    previewDoc?.let { target ->
        AlertDialog(
            onDismissRequest = { previewDoc = null },
            title = { Text(target.title) },
            text = { Text("${target.format.name} • ${target.pageCount} صفحة • ${(target.sizeBytes / 1024)} KB") },
            confirmButton = {
                TextButton(onClick = { viewModel.toggleFavorite(target.id); previewDoc = null }) {
                    Text(if (target.isFavorite) "إزالة من المفضلة" else "إضافة للمفضلة")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.moveToTrash(target.id); previewDoc = null }) { Text("نقل للسلة") }
            }
        )
    }
}
