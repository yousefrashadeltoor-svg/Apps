package com.jobat.feature.reader

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.jobat.core.engine.EngineSession
import com.jobat.core.engine.LibreraDocumentEngine
import com.jobat.core.engine.OpenDocumentResult
import com.jobat.core.engine.TtsReadAloudController
import com.jobat.domain.LibraryRepository
import com.jobat.domain.SearchHit
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

enum class ReaderPageTheme(val bg: Color, val fg: Color) {
    PAPER(Color(0xFFFAF8F3), Color(0xFF1D1C1A)),
    SEPIA(Color(0xFFF1E5CE), Color(0xFF332618)),
    IVORY(Color(0xFFF6F1E7), Color(0xFF22201C)),
    GRAPHITE(Color(0xFF1A1D24), Color(0xFFE6E2D8)),
    MIDNIGHT(Color(0xFF0D1017), Color(0xFFDCE0EA)),
    AMOLED(Color(0xFF000000), Color(0xFFEAE6DC))
}

enum class ReaderLayoutMode { VERTICAL, HORIZONTAL, TWO_PAGE, RTL_PAGER, REFLOW }

data class ReaderUiState(
    val title: String = "",
    val pageIndex: Int = 0,
    val pageCount: Int = 1,
    val currentText: String = "",
    val currentBitmap: Bitmap? = null,
    val layoutMode: ReaderLayoutMode = ReaderLayoutMode.HORIZONTAL,
    val pageTheme: ReaderPageTheme = ReaderPageTheme.GRAPHITE,
    val fontSizeSp: Float = 18f,
    val lineHeightMult: Float = 1.75f,
    val marginDp: Int = 20,
    val blueLightWarmth: Float = 0f,
    val autoCropMargins: Boolean = false,
    val contrastBoost: Float = 1f,
    val immersiveChromeHidden: Boolean = false,
    val bookmarks: Set<Int> = emptySet(),
    val searchHits: List<SearchHit> = emptyList(),
    val error: String? = null
)

@HiltViewModel
class ReaderViewModel @Inject constructor(
    private val engine: LibreraDocumentEngine,
    private val repository: LibraryRepository,
    val tts: TtsReadAloudController
) : ViewModel() {
    private var session: EngineSession? = null
    private var docId: String = ""
    private var openedAtMs: Long = System.currentTimeMillis()
    private val _state = MutableStateFlow(ReaderUiState())
    val state = _state.asStateFlow()

    fun open(id: String, uri: Uri, name: String, password: String? = null) {
        docId = id
        openedAtMs = System.currentTimeMillis()
        viewModelScope.launch {
            when (val res = engine.openDocument(uri, name, password)) {
                is OpenDocumentResult.Opened -> {
                    session?.close()
                    session = res.session
                    _state.value = _state.value.copy(
                        title = res.session.title,
                        pageCount = res.session.pageCount,
                        error = null
                    )
                    goToPage(0)
                }
                is OpenDocumentResult.PasswordRequired ->
                    _state.value = _state.value.copy(error = "PASSWORD_REQUIRED")
                is OpenDocumentResult.CorruptOrUnsupported ->
                    _state.value = _state.value.copy(error = res.reason)
            }
        }
    }

    fun goToPage(index: Int) {
        val s = session ?: return
        val clamped = index.coerceIn(0, (s.pageCount - 1).coerceAtLeast(0))
        viewModelScope.launch {
            val text = s.reflowChapters.getOrNull(clamped).orEmpty()
            val bmp = if (s.reflowChapters.isEmpty() && _state.value.layoutMode != ReaderLayoutMode.REFLOW) {
                engine.renderPageBitmap(
                    s, clamped, 1080, 1520, 1f,
                    _state.value.autoCropMargins, _state.value.contrastBoost
                )
            } else null
            _state.value = _state.value.copy(pageIndex = clamped, currentText = text, currentBitmap = bmp)
            if (docId.isNotBlank()) repository.updateReadingPosition(docId, clamped + 1, s.pageCount)
        }
    }

    fun updateStyle(transform: (ReaderUiState) -> ReaderUiState) {
        _state.value = transform(_state.value)
        goToPage(_state.value.pageIndex)
    }

    fun toggleBookmark() {
        val p = _state.value.pageIndex
        val next = _state.value.bookmarks.toMutableSet().apply { if (!add(p)) remove(p) }
        _state.value = _state.value.copy(bookmarks = next)
    }

    fun search(query: String) {
        val s = session ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(searchHits = engine.searchInSession(s, query))
        }
    }

    fun toggleReadAloud() {
        if (tts.state.value.isPlaying) tts.pause()
        else tts.startReading(_state.value.currentText.ifBlank { _state.value.title })
    }

    override fun onCleared() {
        val elapsedMin = ((System.currentTimeMillis() - openedAtMs) / 60_000L).toInt()
        if (elapsedMin > 0) {
            viewModelScope.launch {
                repository.recordReadingMinutes(LocalDate.now().toString(), elapsedMin, 1)
            }
        }
        tts.pause()
        session?.close()
        super.onCleared()
    }
}

@Composable
fun ReaderScreen(
    onBack: () -> Unit,
    onEditPdf: () -> Unit,
    viewModel: ReaderViewModel = hiltViewModel()
) {
    val ui by viewModel.state.collectAsStateWithLifecycle()
    val ttsState by viewModel.tts.state.collectAsStateWithLifecycle()
    var zoom by remember { mutableFloatStateOf(1f) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ui.pageTheme.bg)
            .pointerInput(Unit) {
                detectTransformGestures { _, _, zoomChange, _ ->
                    zoom = (zoom * zoomChange).coerceIn(1f, 4f)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { zoom = if (zoom > 1.1f) 1f else 2f },
                    onTap = { viewModel.updateStyle { s -> s.copy(immersiveChromeHidden = !s.immersiveChromeHidden) } }
                )
            }
    ) {
        if (ui.currentBitmap != null && ui.layoutMode != ReaderLayoutMode.REFLOW) {
            Image(
                bitmap = ui.currentBitmap!!.asImageBitmap(),
                contentDescription = ui.title,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(scaleX = zoom, scaleY = zoom)
            )
        } else {
            SelectionContainer {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = ui.marginDp.dp, vertical = 72.dp)
                ) {
                    Text(
                        text = ui.currentText,
                        color = ui.pageTheme.fg,
                        fontSize = ui.fontSizeSp.sp,
                        lineHeight = (ui.fontSizeSp * ui.lineHeightMult).sp,
                        fontFamily = FontFamily.Serif,
                        textAlign = TextAlign.Justify
                    )
                }
            }
        }

        // Optional Blue-Light Warmth Filter Overlay
        if (ui.blueLightWarmth > 0.01f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFFF9E3D).copy(alpha = ui.blueLightWarmth * 0.28f))
            )
        }

        AnimatedVisibility(visible = !ui.immersiveChromeHidden, modifier = Modifier.align(Alignment.TopCenter)) {
            Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                        Text(ui.title, modifier = Modifier.weight(1f), maxLines = 1, style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { searchOpen = !searchOpen }) {
                            Icon(Icons.Default.Search, contentDescription = "Search")
                        }
                        IconButton(onClick = viewModel::toggleReadAloud) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "TTS")
                        }
                        TextButton(onClick = onEditPdf) { Text("تحرير") }
                    }
                    if (searchOpen) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it; viewModel.search(it) },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                            singleLine = true,
                            placeholder = { Text("بحث داخل المستند (${ui.searchHits.size})") }
                        )
                    }
                }
            }
        }

        AnimatedVisibility(visible = !ui.immersiveChromeHidden, modifier = Modifier.align(Alignment.BottomCenter)) {
            Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (ttsState.isPlaying) {
                        Text(
                            text = ttsState.sentences.getOrNull(ttsState.activeSentenceIndex).orEmpty(),
                            maxLines = 1,
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Slider(
                        value = ui.pageIndex.toFloat(),
                        onValueChange = { viewModel.goToPage(it.toInt()) },
                        valueRange = 0f..(ui.pageCount - 1).coerceAtLeast(1).toFloat()
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ReaderPageTheme.entries) { t ->
                            FilterChip(
                                selected = ui.pageTheme == t,
                                onClick = { viewModel.updateStyle { s -> s.copy(pageTheme = t) } },
                                label = { Text(t.name) }
                            )
                        }
                    }
                }
            }
        }
    }
}
