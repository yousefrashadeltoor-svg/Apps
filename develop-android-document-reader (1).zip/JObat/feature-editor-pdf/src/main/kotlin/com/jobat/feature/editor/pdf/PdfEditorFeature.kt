package com.jobat.feature.editor.pdf

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream

enum class PdfTool { HIGHLIGHT, UNDERLINE, STRIKE, PEN, ERASER, RECT, CIRCLE, ARROW, LINE, TEXT, NOTE, STAMP, SIGNATURE }

data class PdfAnnotation(
    val id: String,
    val pageIndex: Int,
    val tool: PdfTool,
    val points: List<Offset>,
    val colorArgb: Int = 0xFFD4B26A.toInt(),
    val strokeWidth: Float = 4f,
    val text: String = ""
)

data class EditablePdfPage(
    val sourceIndex: Int,
    val rotationDeg: Int = 0,
    val isBlankInsert: Boolean = false
)

/** Generic unbounded Undo/Redo state history stack used across PDF, Text, and Image studios. */
class UnlimitedUndoStack<T>(initial: T) {
    private val past = ArrayDeque<T>()
    private val future = ArrayDeque<T>()
    var current: T = initial
        private set

    val canUndo: Boolean get() = past.isNotEmpty()
    val canRedo: Boolean get() = future.isNotEmpty()

    fun commit(next: T) {
        past.addLast(current)
        future.clear()
        current = next
    }

    fun undo(): T {
        if (past.isNotEmpty()) {
            future.addFirst(current)
            current = past.removeLast()
        }
        return current
    }

    fun redo(): T {
        if (future.isNotEmpty()) {
            past.addLast(current)
            current = future.removeFirst()
        }
        return current
    }
}

object PdfExportWriter {
    suspend fun writeEditedPdf(
        pages: List<EditablePdfPage>,
        renderSource: suspend (Int) -> Bitmap,
        annotations: List<PdfAnnotation>,
        watermark: String?,
        addPageNumbers: Boolean,
        output: OutputStream
    ) = withContext(Dispatchers.IO) {
        val doc = PdfDocument()
        try {
            pages.forEachIndexed { outIdx, spec ->
                val info = PdfDocument.PageInfo.Builder(1080, 1520, outIdx + 1).create()
                val page = doc.startPage(info)
                val canvas = page.canvas
                canvas.save()
                if (spec.rotationDeg != 0) {
                    canvas.rotate(spec.rotationDeg.toFloat(), 540f, 760f)
                }
                if (!spec.isBlankInsert) {
                    val bmp = renderSource(spec.sourceIndex)
                    canvas.drawBitmap(bmp, 0f, 0f, null)
                }
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                annotations.filter { it.pageIndex == outIdx }.forEach { ann ->
                    paint.color = ann.colorArgb
                    paint.strokeWidth = if (ann.tool == PdfTool.HIGHLIGHT) ann.strokeWidth * 5f else ann.strokeWidth
                    paint.alpha = if (ann.tool == PdfTool.HIGHLIGHT) 92 else 255
                    paint.style = if (ann.text.isNotEmpty()) Paint.Style.FILL else Paint.Style.STROKE
                    if (ann.text.isNotEmpty() && ann.points.isNotEmpty()) {
                        paint.textSize = 32f
                        canvas.drawText(ann.text, ann.points.first().x, ann.points.first().y, paint)
                    } else if (ann.points.size >= 2) {
                        val p = Path().apply {
                            moveTo(ann.points.first().x, ann.points.first().y)
                            ann.points.drop(1).forEach { lineTo(it.x, it.y) }
                        }
                        canvas.drawPath(p, paint)
                    }
                }
                if (!watermark.isNullOrBlank()) {
                    paint.apply { color = 0x33D4B26A; textSize = 68f; style = Paint.Style.FILL }
                    canvas.save()
                    canvas.rotate(-32f, 540f, 760f)
                    canvas.drawText(watermark, 240f, 760f, paint)
                    canvas.restore()
                }
                if (addPageNumbers) {
                    paint.apply { color = 0xFF444444.toInt(); textSize = 24f; style = Paint.Style.FILL }
                    canvas.drawText("${outIdx + 1} / ${pages.size}", 500f, 1480f, paint)
                }
                canvas.restore()
                doc.finishPage(page)
            }
            doc.writeTo(output)
        } finally {
            doc.close()
        }
    }
}

@Composable
fun PdfEditorScreen(
    pageIndex: Int = 0,
    onSaveAnnotations: (List<PdfAnnotation>) -> Unit,
    onBack: () -> Unit
) {
    val history = remember { UnlimitedUndoStack<List<PdfAnnotation>>(emptyList()) }
    var annotations by remember { mutableStateOf(history.current) }
    var selectedTool by remember { mutableStateOf(PdfTool.PEN) }
    var activePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    val strokeColor = Color(0xFFD4B26A)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(enabled = history.canUndo, onClick = { annotations = history.undo() }) { Text("تراجع") }
                TextButton(enabled = history.canRedo, onClick = { annotations = history.redo() }) { Text("إعادة") }
                Button(onClick = { onSaveAnnotations(annotations) }) { Text("حفظ") }
            }
        }

        Canvas(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color(0xFFFAF8F3))
                .pointerInput(selectedTool) {
                    detectDragGestures(
                        onDragStart = { start ->
                            if (selectedTool == PdfTool.ERASER) {
                                val next = annotations.filterNot { ann ->
                                    ann.points.any { (it - start).getDistance() < 36f }
                                }
                                history.commit(next); annotations = next
                            } else {
                                activePoints = listOf(start)
                            }
                        },
                        onDrag = { change, _ ->
                            if (selectedTool != PdfTool.ERASER) activePoints = activePoints + change.position
                        },
                        onDragEnd = {
                            if (activePoints.size >= 2) {
                                val ann = PdfAnnotation(
                                    id = System.nanoTime().toString(),
                                    pageIndex = pageIndex,
                                    tool = selectedTool,
                                    points = activePoints,
                                    colorArgb = strokeColor.toArgb()
                                )
                                val next = annotations + ann
                                history.commit(next); annotations = next
                            }
                            activePoints = emptyList()
                        }
                    )
                }
        ) {
            (annotations + listOfNotNull(
                activePoints.takeIf { it.size >= 2 }?.let { PdfAnnotation("live", pageIndex, selectedTool, it, strokeColor.toArgb()) }
            )).forEach { ann ->
                val col = Color(ann.colorArgb).copy(alpha = if (ann.tool == PdfTool.HIGHLIGHT) 0.36f else 1f)
                val w = if (ann.tool == PdfTool.HIGHLIGHT) 22f else ann.strokeWidth
                when (ann.tool) {
                    PdfTool.RECT -> {
                        val a = ann.points.first(); val b = ann.points.last()
                        drawRect(col, topLeft = Offset(minOf(a.x, b.x), minOf(a.y, b.y)), size = Size(kotlin.math.abs(b.x - a.x), kotlin.math.abs(b.y - a.y)), style = Stroke(w))
                    }
                    else -> {
                        for (i in 0 until ann.points.size - 1) {
                            drawLine(col, ann.points[i], ann.points[i + 1], strokeWidth = w, cap = StrokeCap.Round)
                        }
                    }
                }
            }
        }

        LazyRow(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(PdfTool.entries) { tool ->
                FilterChip(selected = selectedTool == tool, onClick = { selectedTool = tool }, label = { Text(tool.name) })
            }
        }
    }
}
