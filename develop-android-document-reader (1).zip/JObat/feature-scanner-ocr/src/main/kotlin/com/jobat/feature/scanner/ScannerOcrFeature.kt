package com.jobat.feature.scanner

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.pdf.PdfDocument
import android.service.quicksettings.TileService
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream
import java.net.URL
import javax.net.ssl.HttpsURLConnection

object DocumentScannerPipeline {
    private const val TESSDATA_FAST_BASE =
        "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main"

    /** Perspective homography warp using 4 user/auto-detected document quad corners. */
    suspend fun warpPerspective(
        source: Bitmap,
        cornersClockwise: List<PointF>,
        targetWidth: Int = 1240,
        targetHeight: Int = 1754
    ): Bitmap = withContext(Dispatchers.Default) {
        require(cornersClockwise.size == 4) { "Expected 4 corner points" }
        val src = floatArrayOf(
            cornersClockwise[0].x, cornersClockwise[0].y,
            cornersClockwise[1].x, cornersClockwise[1].y,
            cornersClockwise[2].x, cornersClockwise[2].y,
            cornersClockwise[3].x, cornersClockwise[3].y
        )
        val dst = floatArrayOf(
            0f, 0f,
            targetWidth.toFloat(), 0f,
            targetWidth.toFloat(), targetHeight.toFloat(),
            0f, targetHeight.toFloat()
        )
        val matrix = Matrix().apply { setPolyToPoly(src, 0, dst, 0, 4) }
        val output = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        Canvas(output).drawBitmap(source, matrix, Paint(Paint.FILTER_BITMAP_FLAG))
        output
    }

    fun isLanguageInstalled(context: Context, langCode: String): Boolean =
        File(File(context.filesDir, "tesseract/tessdata"), "$langCode.traineddata").exists()

    /** Strictly user-triggered HTTPS download of slim tessdata_fast model (~3.5MB) to keep APK < 25MB. */
    suspend fun downloadLanguagePackOnDemand(context: Context, langCode: String): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(context.filesDir, "tesseract/tessdata").apply { mkdirs() }
                val target = File(dir, "$langCode.traineddata")
                val conn = (URL("$TESSDATA_FAST_BASE/$langCode.traineddata").openConnection() as HttpsURLConnection).apply {
                    connectTimeout = 15_000
                    readTimeout = 30_000
                }
                conn.inputStream.use { input -> target.outputStream().use { out -> input.copyTo(out) } }
                target
            }
        }

    suspend fun recognizeOffline(context: Context, page: Bitmap, langCode: String): String =
        withContext(Dispatchers.Default) {
            val baseDir = File(context.filesDir, "tesseract").apply { mkdirs() }
            val tess = TessBaseAPI()
            try {
                if (!tess.init(baseDir.absolutePath, langCode)) return@withContext ""
                tess.setImage(page)
                tess.utF8Text.orEmpty().trim()
            } finally {
                tess.recycle()
            }
        }

    /** Assembles rectified scans + invisible selectable OCR text layer into a searchable PDF. */
    suspend fun exportSearchablePdf(
        pages: List<Pair<Bitmap, String>>,
        output: OutputStream
    ) = withContext(Dispatchers.IO) {
        val pdf = PdfDocument()
        val invisibleTextPaint = Paint().apply { alpha = 1; textSize = 20f }
        try {
            pages.forEachIndexed { idx, (bmp, ocrText) ->
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, idx + 1).create())
                page.canvas.drawBitmap(bmp, 0f, 0f, null)
                ocrText.lines().forEachIndexed { lineIdx, line ->
                    page.canvas.drawText(line, 40f, 60f + lineIdx * 26f, invisibleTextPaint)
                }
                pdf.finishPage(page)
            }
            pdf.writeTo(output)
        } finally {
            pdf.close()
        }
    }
}

class ScannerQuickTileService : TileService() {
    override fun onClick() {
        super.onClick()
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setPackage(packageName)
            putExtra("jobat_route", "scanner")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivityAndCollapse(intent)
    }
}
