package com.jobat.core.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.LruCache
import com.jobat.core.nativebridge.MuPdfNativeBridge
import com.jobat.domain.DocFormat
import com.jobat.domain.FormatCategory
import com.jobat.domain.OutlineNode
import com.jobat.domain.SearchHit
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.inject.Inject
import javax.inject.Singleton

sealed interface OpenDocumentResult {
    data class Opened(val session: EngineSession) : OpenDocumentResult
    data class PasswordRequired(val pendingHandle: Long, val format: DocFormat) : OpenDocumentResult
    data class CorruptOrUnsupported(val reason: String) : OpenDocumentResult
}

data class EngineSession(
    val uri: Uri,
    val format: DocFormat,
    val title: String,
    val author: String,
    val pageCount: Int,
    val nativeHandle: Long = 0L,
    val pdfRenderer: PdfRenderer? = null,
    val pfd: ParcelFileDescriptor? = null,
    val reflowChapters: List<String> = emptyList(),
    val outline: List<OutlineNode> = emptyList(),
    val archiveEntries: List<String> = emptyList()
) : AutoCloseable {
    override fun close() {
        runCatching { pdfRenderer?.close() }
        runCatching { pfd?.close() }
        if (nativeHandle > 0L) MuPdfNativeBridge.close(nativeHandle)
    }
}

@Singleton
class LibreraDocumentEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val maxCacheKb = (Runtime.getRuntime().maxMemory() / 1024L / 8L).toInt().coerceAtLeast(8192)
    private val pageCache = object : LruCache<String, Bitmap>(maxCacheKb) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    suspend fun openDocument(
        uri: Uri,
        displayName: String,
        password: String? = null
    ): OpenDocumentResult = withContext(Dispatchers.IO) {
        val format = DocFormat.fromFileName(displayName)
        try {
            when (format.category) {
                FormatCategory.PAGED -> openPaged(uri, displayName, format, password)
                FormatCategory.REFLOW_BOOK -> openReflowBook(uri, displayName, format)
                FormatCategory.OFFICE -> openOfficeDocument(uri, displayName, format)
                FormatCategory.TEXT_WEB -> openTextOrWeb(uri, displayName, format)
                FormatCategory.COMIC, FormatCategory.ARCHIVE -> openArchiveOrComic(uri, displayName, format)
                FormatCategory.IMAGE -> OpenDocumentResult.Opened(
                    EngineSession(uri, format, displayName.substringBeforeLast('.'), "", 1)
                )
            }
        } catch (sec: SecurityException) {
            OpenDocumentResult.PasswordRequired(0L, format)
        } catch (t: Throwable) {
            OpenDocumentResult.CorruptOrUnsupported(t.message ?: "Corrupted stream")
        }
    }

    private suspend fun openPaged(
        uri: Uri,
        name: String,
        format: DocFormat,
        password: String?
    ): OpenDocumentResult {
        val tempFile = copyUriToCache(uri, "paged_${name.hashCode()}.${format.primaryExt}")
        if (MuPdfNativeBridge.isMuPdfAvailable) {
            val handle = MuPdfNativeBridge.open(tempFile.absolutePath)
            if (handle == -1L) return OpenDocumentResult.CorruptOrUnsupported("Invalid ${format.name} header")
            if (handle > 0L) {
                if (MuPdfNativeBridge.needsPassword(handle)) {
                    if (password.isNullOrEmpty() || !MuPdfNativeBridge.authenticate(handle, password)) {
                        return OpenDocumentResult.PasswordRequired(handle, format)
                    }
                }
                val count = MuPdfNativeBridge.countPages(handle).coerceAtLeast(1)
                return OpenDocumentResult.Opened(
                    EngineSession(
                        uri = uri,
                        format = format,
                        title = name.substringBeforeLast('.'),
                        author = "",
                        pageCount = count,
                        nativeHandle = handle
                    )
                )
            }
        }
        // Platform PdfRenderer engine for PDF when running slim binary
        val pfd = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        return OpenDocumentResult.Opened(
            EngineSession(
                uri = uri,
                format = format,
                title = name.substringBeforeLast('.'),
                author = "",
                pageCount = renderer.pageCount.coerceAtLeast(1),
                pdfRenderer = renderer,
                pfd = pfd
            )
        )
    }

    private fun openReflowBook(uri: Uri, name: String, format: DocFormat): OpenDocumentResult {
        return when (format) {
            DocFormat.EPUB -> parseEpub(uri, name)
            DocFormat.FB2, DocFormat.FB2_ZIP -> parseFb2(uri, name, zipped = format == DocFormat.FB2_ZIP)
            DocFormat.MOBI, DocFormat.AZW, DocFormat.AZW3 -> parsePalmDocMobi(uri, name, format)
            else -> openTextOrWeb(uri, name, format)
        }
    }

    private fun parseEpub(uri: Uri, fallbackName: String): OpenDocumentResult {
        val entries = readZipEntries(uri, maxEntryBytes = 2 * 1024 * 1024)
        if (entries.isEmpty()) return OpenDocumentResult.CorruptOrUnsupported("Empty EPUB archive")
        val opfBytes = entries.entries.firstOrNull { it.key.endsWith(".opf", ignoreCase = true) }?.value
        var title = fallbackName.substringBeforeLast('.')
        var author = ""
        if (opfBytes != null) {
            val opfText = String(opfBytes, StandardCharsets.UTF_8)
            Regex("<dc:title[^>]*>(.*?)</dc:title>", RegexOption.DOT_MATCHES_ALL)
                .find(opfText)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }?.let { title = it }
            Regex("<dc:creator[^>]*>(.*?)</dc:creator>", RegexOption.DOT_MATCHES_ALL)
                .find(opfText)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }?.let { author = it }
        }
        val chapters = entries
            .filterKeys { it.endsWith(".xhtml", true) || it.endsWith(".html", true) || it.endsWith(".htm", true) }
            .toSortedMap()
            .values
            .map { stripHtmlToCleanParagraphs(String(it, StandardCharsets.UTF_8)) }
            .filter { it.isNotBlank() }
            .ifEmpty { return OpenDocumentResult.CorruptOrUnsupported("No readable spine items in EPUB") }

        val outline = chapters.mapIndexed { idx, ch ->
            OutlineNode(title = ch.lineSequence().firstOrNull()?.take(60) ?: "Chapter ${idx + 1}", page = idx, level = 0)
        }
        return OpenDocumentResult.Opened(
            EngineSession(uri, DocFormat.EPUB, title, author, chapters.size, reflowChapters = chapters, outline = outline)
        )
    }

    private fun parseFb2(uri: Uri, fallbackName: String, zipped: Boolean): OpenDocumentResult {
        val xmlBytes = if (zipped) {
            readZipEntries(uri, 8 * 1024 * 1024).values.firstOrNull()
                ?: return OpenDocumentResult.CorruptOrUnsupported("Corrupt FB2.ZIP")
        } else {
            context.contentResolver.openInputStream(uri)?.use(InputStream::readBytes)
                ?: return OpenDocumentResult.CorruptOrUnsupported("Unreadable FB2")
        }
        var title = fallbackName.substringBeforeLast('.')
        var author = ""
        val paragraphs = mutableListOf<String>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")
        var currentTag = ""
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> currentTag = parser.name
                XmlPullParser.TEXT -> {
                    val txt = parser.text?.trim().orEmpty()
                    if (txt.isNotEmpty()) {
                        when (currentTag) {
                            "book-title" -> title = txt
                            "first-name", "last-name" -> author = "$author $txt".trim()
                            "p", "subtitle" -> paragraphs.add(txt)
                        }
                    }
                }
            }
            parser.next()
        }
        val pages = paragraphs.chunked(14).map { it.joinToString("\n\n") }.ifEmpty { listOf(title) }
        return OpenDocumentResult.Opened(
            EngineSession(uri, if (zipped) DocFormat.FB2_ZIP else DocFormat.FB2, title, author, pages.size, reflowChapters = pages)
        )
    }

    private fun parsePalmDocMobi(uri: Uri, fallbackName: String, format: DocFormat): OpenDocumentResult {
        val bytes = context.contentResolver.openInputStream(uri)?.use(InputStream::readBytes)
            ?: return OpenDocumentResult.CorruptOrUnsupported("Unreadable MOBI/AZW")
        if (bytes.size < 78) return OpenDocumentResult.CorruptOrUnsupported("Invalid PalmDB header")
        val headerTitle = String(bytes, 0, 32, StandardCharsets.UTF_8).trim('\u0000', ' ')
            .ifBlank { fallbackName.substringBeforeLast('.') }
        val extracted = stripHtmlToCleanParagraphs(
            String(bytes, 78, bytes.size - 78, StandardCharsets.ISO_8859_1)
                .replace(Regex("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]"), " ")
        )
        val pages = extracted.chunked(1800).ifEmpty { listOf(headerTitle) }
        return OpenDocumentResult.Opened(
            EngineSession(uri, format, headerTitle, "", pages.size, reflowChapters = pages)
        )
    }

    private fun openOfficeDocument(uri: Uri, name: String, format: DocFormat): OpenDocumentResult {
        val pages: List<String> = when (format) {
            DocFormat.DOCX -> extractXmlTextFromZip(uri) { it == "word/document.xml" }
            DocFormat.ODT -> extractXmlTextFromZip(uri) { it == "content.xml" }
            DocFormat.XLSX -> extractXmlTextFromZip(uri) { it == "xl/sharedStrings.xml" || it.startsWith("xl/worksheets/sheet") }
            DocFormat.PPTX -> extractXmlTextFromZip(uri) { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }
            DocFormat.RTF -> {
                val raw = readUtf8(uri)
                val clean = raw.replace(Regex("\\\\[a-z]+\\d* ?|[{}]"), "").trim()
                clean.chunked(2000)
            }
            DocFormat.DOC, DocFormat.XLS, DocFormat.PPT -> {
                val bytes = context.contentResolver.openInputStream(uri)?.use(InputStream::readBytes) ?: ByteArray(0)
                Regex("[\\p{L}\\p{N}\\p{P}\\p{Zs}\\n]{6,}")
                    .findAll(String(bytes, StandardCharsets.UTF_8))
                    .map { it.value.trim() }
                    .joinToString("\n")
                    .chunked(2000)
            }
            else -> listOf(readUtf8(uri))
        }.ifEmpty { return OpenDocumentResult.CorruptOrUnsupported("No readable content in ${format.name}") }

        return OpenDocumentResult.Opened(
            EngineSession(uri, format, name.substringBeforeLast('.'), "", pages.size, reflowChapters = pages)
        )
    }

    private fun openTextOrWeb(uri: Uri, name: String, format: DocFormat): OpenDocumentResult {
        val raw = readUtf8(uri)
        val pages = raw.chunked(2400).ifEmpty { listOf("") }
        return OpenDocumentResult.Opened(
            EngineSession(uri, format, name.substringBeforeLast('.'), "", pages.size, reflowChapters = pages)
        )
    }

    private fun openArchiveOrComic(uri: Uri, name: String, format: DocFormat): OpenDocumentResult {
        val names = mutableListOf<String>()
        context.contentResolver.openInputStream(uri)?.use { stream ->
            ZipInputStream(stream).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) names.add(entry.name)
                    entry = zis.nextEntry
                }
            }
        }
        val sorted = names.sorted()
        if (sorted.isEmpty()) return OpenDocumentResult.CorruptOrUnsupported("Protected or non-standard archive")
        return OpenDocumentResult.Opened(
            EngineSession(uri, format, name.substringBeforeLast('.'), "", sorted.size, archiveEntries = sorted)
        )
    }

    suspend fun renderPageBitmap(
        session: EngineSession,
        pageIndex: Int,
        widthPx: Int,
        heightPx: Int,
        scale: Float = 1f,
        autoCrop: Boolean = false,
        contrastBoost: Float = 1f
    ): Bitmap = withContext(Dispatchers.IO) {
        val key = "${session.uri}_${pageIndex}_${widthPx}_${scale}_${autoCrop}_${contrastBoost}"
        pageCache.get(key)?.let { if (!it.isRecycled) return@withContext it }

        val targetW = (widthPx * scale).toInt().coerceIn(128, 4096)
        val targetH = (heightPx * scale).toInt().coerceIn(128, 4096)
        val bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawColor(Color.WHITE)

        when {
            session.nativeHandle > 0L -> {
                MuPdfNativeBridge.renderPage(session.nativeHandle, pageIndex, bmp, scale, autoCrop, contrastBoost)
            }
            session.pdfRenderer != null -> {
                synchronized(session.pdfRenderer) {
                    session.pdfRenderer.openPage(pageIndex.coerceIn(0, session.pageCount - 1)).use { page ->
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    }
                }
            }
            session.format.category == FormatCategory.IMAGE -> {
                return@withContext decodeImageUri(session.uri, targetW).also { pageCache.put(key, it) }
            }
        }
        pageCache.put(key, bmp)
        bmp
    }

    suspend fun searchInSession(session: EngineSession, query: String): List<SearchHit> =
        withContext(Dispatchers.Default) {
            if (query.isBlank()) return@withContext emptyList()
            val results = mutableListOf<SearchHit>()
            if (session.reflowChapters.isNotEmpty()) {
                session.reflowChapters.forEachIndexed { pageIdx, text ->
                    var pos = text.indexOf(query, ignoreCase = true)
                    while (pos >= 0 && results.size < 250) {
                        val start = (pos - 36).coerceAtLeast(0)
                        val end = (pos + query.length + 48).coerceAtMost(text.length)
                        results.add(SearchHit(pageIdx, text.substring(start, end).replace('\n', ' ')))
                        pos = text.indexOf(query, pos + query.length, ignoreCase = true)
                    }
                }
            } else if (session.nativeHandle > 0L) {
                for (p in 0 until session.pageCount) {
                    val rects = MuPdfNativeBridge.searchPage(session.nativeHandle, p, query)
                    if (rects.isNotEmpty()) {
                        val snippet = MuPdfNativeBridge.extractText(session.nativeHandle, p).take(120)
                        results.add(SearchHit(p, snippet))
                    }
                }
            }
            results
        }

    private fun decodeImageUri(uri: Uri, maxDim: Int): Bitmap {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val src = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                val ratio = maxOf(info.size.width, info.size.height).toFloat() / maxDim
                if (ratio > 1f) decoder.setTargetSampleSize(ratio.toInt().coerceAtLeast(1))
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: Bitmap.createBitmap(maxDim, maxDim, Bitmap.Config.ARGB_8888)
        }
    }

    private fun extractXmlTextFromZip(uri: Uri, predicate: (String) -> Boolean): List<String> {
        val entries = readZipEntries(uri, 4 * 1024 * 1024).filterKeys(predicate)
        return entries.values.map { bytes ->
            stripHtmlToCleanParagraphs(String(bytes, StandardCharsets.UTF_8))
        }.filter { it.isNotBlank() }
    }

    private fun readZipEntries(uri: Uri, maxEntryBytes: Int): Map<String, ByteArray> {
        val map = linkedMapOf<String, ByteArray>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val bytes = zis.readBytes()
                        if (bytes.size <= maxEntryBytes) map[entry.name] = bytes
                    }
                    entry = zis.nextEntry
                }
            }
        }
        return map
    }

    private fun readUtf8(uri: Uri): String =
        context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

    private fun stripHtmlToCleanParagraphs(html: String): String =
        html.replace(Regex("<(script|style)[^>]*>.*?</\\1>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), "")
            .replace(Regex("</(p|div|h[1-6]|li|tr|br)>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .lines()
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n\n")

    private fun copyUriToCache(uri: Uri, fileName: String): File {
        val dir = File(context.cacheDir, "engine_tmp").apply { mkdirs() }
        val out = File(dir, fileName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(out).use { output -> input.copyTo(output) }
        } ?: error("Cannot open URI stream")
        return out
    }

    fun purgeTempCache() {
        pageCache.evictAll()
        File(context.cacheDir, "engine_tmp").deleteRecursively()
    }
}

data class TtsPlaybackState(
    val isReady: Boolean = false,
    val isPlaying: Boolean = false,
    val sentences: List<String> = emptyList(),
    val activeSentenceIndex: Int = 0,
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.0f,
    val sleepMinutesRemaining: Int? = null
)

@Singleton
class TtsReadAloudController @Inject constructor(
    @ApplicationContext context: Context
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var sleepJob: Job? = null
    private val _state = MutableStateFlow(TtsPlaybackState())
    val state: StateFlow<TtsPlaybackState> = _state.asStateFlow()

    private var tts: TextToSpeech? = TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) {
            _state.value = _state.value.copy(isReady = true)
        }
    }?.apply {
        setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onError(utteranceId: String?) {
                _state.value = _state.value.copy(isPlaying = false)
            }
            override fun onDone(utteranceId: String?) {
                val next = _state.value.activeSentenceIndex + 1
                if (next < _state.value.sentences.size && _state.value.isPlaying) {
                    _state.value = _state.value.copy(activeSentenceIndex = next)
                    speakSentence(next)
                } else {
                    _state.value = _state.value.copy(isPlaying = false)
                }
            }
        })
    }

    fun startReading(text: String, locale: Locale = Locale.getDefault()) {
        val parts = text.split(Regex("(?<=[.!؟،\\n])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isEmpty()) return
        tts?.language = locale
        _state.value = _state.value.copy(sentences = parts, activeSentenceIndex = 0, isPlaying = true)
        speakSentence(0)
    }

    fun pause() {
        tts?.stop()
        _state.value = _state.value.copy(isPlaying = false)
    }

    fun resume() {
        if (_state.value.sentences.isEmpty()) return
        _state.value = _state.value.copy(isPlaying = true)
        speakSentence(_state.value.activeSentenceIndex)
    }

    fun setRateAndPitch(rate: Float, pitch: Float) {
        val r = rate.coerceIn(0.5f, 2.2f)
        val p = pitch.coerceIn(0.6f, 1.6f)
        tts?.setSpeechRate(r)
        tts?.setPitch(p)
        _state.value = _state.value.copy(speechRate = r, pitch = p)
    }

    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        _state.value = _state.value.copy(sleepMinutesRemaining = minutes)
        if (minutes != null && minutes > 0) {
            sleepJob = scope.launch {
                for (rem in minutes downTo 1) {
                    _state.value = _state.value.copy(sleepMinutesRemaining = rem)
                    delay(60_000L)
                }
                pause()
                _state.value = _state.value.copy(sleepMinutesRemaining = null)
            }
        }
    }

    private fun speakSentence(index: Int) {
        val sentence = _state.value.sentences.getOrNull(index) ?: return
        tts?.speak(sentence, TextToSpeech.QUEUE_FLUSH, null, "jobat_utt_$index")
    }

    fun shutdown() {
        sleepJob?.cancel()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
