# سياسة الخصوصية — Privacy Policy (`𝒥𝒪 bat` / `com.jobat.reader`)

**آخر تحديث / Last Updated:** 2026-01-15

## العربية
1. **العمل دون اتصال بالكامل (100% Offline):** يعمل تطبيق **𝒥𝒪 bat** محليًا بالكامل على جهازك. لا يجمع أي بيانات شخصية أو إحصائية، ولا يحتوي على إعلانات أو حزم تتبع (لا Firebase، لا Crashlytics، لا Analytics).
2. **الملفات والمستندات:** تُفتح الملفات عبر إطار الوصول للتخزين (Storage Access Framework) دون طلب صلاحية `MANAGE_EXTERNAL_STORAGE`. تبقى المستندات، التمييزات، التواقيع، والملاحظات داخل تخزين جهازك فقط.
3. **الخزنة المشفرة والبصمة:** تُشفَّر الملفات المضافة إلى الخزنة محليًا بخوارزمية `AES-256-GCM` عبر مفتاح مخزَّن في شريحة الأمان `Android Keystore`، وتُدار المصادقة الحيوية حصريًا عبر نظام Android (`BiometricPrompt`) دون وصول التطبيق لبياناتك الحيوية.
4. **الكاميرا وOCR:** تُستخدم صلاحية `CAMERA` فقط عند تشغيلك لماسح المستندات. أما الاتصال الاختياري بالشبكة (HTTPS فقط دون Cleartext) فلا يُستخدم إلا إذا طلبت يدويًا تنزيل حزمة لغة OCR (مثل العربية أو الإنجليزية) أو اخترت "بحث في الويب" لنص محدد.
5. **النسخ الاحتياطي:** يتم تصدير واستيراد النسخة الاحتياطية كملف واحد مشفر اختياريًا تختار مكانه بنفسك.

## English
1. **Zero Data Collection & Zero Telemetry:** **𝒥𝒪 bat** operates 100% offline. No analytics, ads, crash reporters, device identifiers, or reading habits are ever collected or transmitted.
2. **Scoped Storage First:** All books, PDFs, images, signatures, and annotations remain strictly on your device via Android Storage Access Framework (SAF).
3. **Biometric & Encrypted Vault:** Sensitive files placed in the Vault are encrypted with `AES256_GCM_HKDF_4KB` backed by `AndroidKeyStore`. Biometric verification is handled exclusively by the OS `BiometricPrompt`.
4. **Camera & Optional On-Demand OCR Packs:** `CAMERA` permission is requested only when entering the Document Scanner. Network access (strict HTTPS, `cleartextTrafficPermitted="false"`) is only invoked when you explicitly tap to download an offline Tesseract `.traineddata` pack or initiate a manual web lookup.
