# Changelog — 𝒥𝒪 bat (`com.jobat.reader`)

## [1.0.0] - 2026-01-15
### Added
- Initial stable release of **𝒥𝒪 bat** (`com.jobat.reader`) built on a de-tracked, modularized GPL-3.0 fork of Librera Reader + MuPDF NDK (`:core-native`, `:core-engine`).
- Complete **Obsidian & Champagne** Jetpack Compose Material 3 Design System (`:design-system`) synchronized via `tokens.json` with Dark, Light Ivory, AMOLED, Sepia, and Android 12+ Dynamic Color themes.
- Offline Library (`:feature-library`) with WorkManager SAF folder indexing, Room FTS4 full-text search, Grid/List/Compact modes, Collections, Tags, Favorites, Archive, Recycle Bin, and circular Continue Reading progress.
- Multi-format Reader (`:feature-reader`) supporting PDF, EPUB 2/3, MOBI, AZW/AZW3, FB2/FB2.ZIP, DJVU, XPS, CBZ/CBR/CB7, RTF, TXT, DOC/DOCX, ODT, XLS/XLSX, PPT/PPTX, MD, CSV, HTML/XHTML/MHT/XML, JPG/PNG/WEBP/GIF/BMP/HEIC/AVIF/SVG/TIFF, and ZIP/RAR/7z archives, with RTL, PDF Reflow, auto-crop margins, 6 reading themes, blue-light scheduler, offline dictionary hooks, and sentence-highlighted TTS with MediaStyle notification & sleep timer.
- PDF Studio (`:feature-editor-pdf`) with annotations, pressure ink, shapes, sticky notes, stamps, reusable vector/image signatures, AcroForms, unlimited Undo/Redo, and page rearrange/rotate/delete/insert/protect/watermark.
- Text & Code Editor (`:feature-editor-text`) with syntax highlighting, line numbers, Regex find/replace, and live Markdown/HTML/CSV preview.
- Non-destructive Image Editor (`:feature-editor-image`), CameraX Document Scanner + on-demand Tesseract OCR (`:feature-scanner-ocr`), and Document Tools (`:feature-tools`).
- Biometric App Lock, AES-256-GCM Encrypted Vault, Reading Statistics & Quote Cards (`:feature-stats`), Glance Widgets (`:widget`), Baseline Profiles (`:baselineprofile`), and 1:1 Web Preview (`preview-web/`).
