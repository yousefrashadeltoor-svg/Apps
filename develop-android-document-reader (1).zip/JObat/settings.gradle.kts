pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "JObat"

include(
    ":app",
    ":core-native",
    ":core-engine",
    ":design-system",
    ":domain",
    ":data",
    ":feature-library",
    ":feature-reader",
    ":feature-editor-pdf",
    ":feature-editor-text",
    ":feature-editor-image",
    ":feature-scanner-ocr",
    ":feature-tools",
    ":feature-settings",
    ":feature-stats",
    ":widget",
    ":baselineprofile"
)
