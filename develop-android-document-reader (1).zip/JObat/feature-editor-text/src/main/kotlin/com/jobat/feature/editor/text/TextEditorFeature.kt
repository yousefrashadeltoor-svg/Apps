package com.jobat.feature.editor.text

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

object SyntaxHighlighter {
    private val headingRegex = Regex("(?m)^#{1,6}\\s.*$")
    private val tagRegex = Regex("</?[a-zA-Z][a-zA-Z0-9:-]*[^>]*>")
    private val stringRegex = Regex("\"[^\"\\n]*\"|'[^'\\n]*'")
    private val codeRegex = Regex("`[^`]+`")

    fun highlight(source: String): AnnotatedString = buildAnnotatedString {
        append(source)
        headingRegex.findAll(source).forEach {
            addStyle(SpanStyle(color = Color(0xFFD4B26A), fontWeight = FontWeight.Bold), it.range.first, it.range.last + 1)
        }
        tagRegex.findAll(source).forEach {
            addStyle(SpanStyle(color = Color(0xFF7CA7D8)), it.range.first, it.range.last + 1)
        }
        stringRegex.findAll(source).forEach {
            addStyle(SpanStyle(color = Color(0xFF8CC49E)), it.range.first, it.range.last + 1)
        }
        codeRegex.findAll(source).forEach {
            addStyle(SpanStyle(color = Color(0xFFE2B872)), it.range.first, it.range.last + 1)
        }
    }

    fun replaceRegex(source: String, pattern: String, replacement: String, useRegex: Boolean): Result<String> = runCatching {
        if (pattern.isEmpty()) source
        else if (useRegex) Regex(pattern).replace(source, replacement)
        else source.replace(pattern, replacement)
    }
}

@Composable
fun TextCodeEditorScreen(
    initialContent: String,
    fileName: String,
    onAutoSave: (String) -> Unit,
    onBack: () -> Unit
) {
    var content by remember { mutableStateOf(initialContent) }
    var previewMode by remember { mutableStateOf(false) }
    var findPattern by remember { mutableStateOf("") }
    var replaceWith by remember { mutableStateOf("") }
    var useRegex by remember { mutableStateOf(true) }
    val undoStack = remember { ArrayDeque<String>() }
    val redoStack = remember { ArrayDeque<String>() }

    // Debounced auto-save every 1200ms after edits
    LaunchedEffect(content) {
        delay(1200L)
        onAutoSave(content)
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Text(fileName, style = MaterialTheme.typography.titleMedium)
            Row {
                TextButton(enabled = undoStack.isNotEmpty(), onClick = {
                    redoStack.addFirst(content); content = undoStack.removeLast()
                }) { Text("↶") }
                TextButton(enabled = redoStack.isNotEmpty(), onClick = {
                    undoStack.addLast(content); content = redoStack.removeFirst()
                }) { Text("↷") }
                FilterChip(selected = previewMode, onClick = { previewMode = !previewMode }, label = { Text("معاينة") })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(findPattern, { findPattern = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("Regex بحث") })
            OutlinedTextField(replaceWith, { replaceWith = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("استبدال") })
            Button(onClick = {
                SyntaxHighlighter.replaceRegex(content, findPattern, replaceWith, useRegex).onSuccess {
                    undoStack.addLast(content); content = it
                }
            }) { Text("تطبيق") }
        }

        val scroll = rememberScrollState()
        if (previewMode) {
            Text(
                text = SyntaxHighlighter.highlight(content),
                modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll),
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            Row(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll)) {
                val lineNumbers = remember(content) {
                    (1..content.count { it == '\n' } + 1).joinToString("\n")
                }
                Text(
                    text = lineNumbers,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(end = 12.dp)
                )
                BasicTextField(
                    value = content,
                    onValueChange = { undoStack.addLast(content); redoStack.clear(); content = it },
                    textStyle = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
