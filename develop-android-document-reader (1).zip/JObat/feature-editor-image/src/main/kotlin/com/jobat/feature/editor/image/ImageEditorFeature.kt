package com.jobat.feature.editor.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream

data class ImageEditSpec(
    val rotationDeg: Float = 0f,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
    val brightness: Float = 0f,       // -100..100
    val contrast: Float = 1f,         // 0.4..2.0
    val saturation: Float = 1f,       // 0..2.0
    val warmth: Float = 0f,           // -50..50
    val cropNormalized: RectF = RectF(0f, 0f, 1f, 1f),
    val quality: Int = 90
)

object ImageProcessor {
    suspend fun applyAndExport(
        source: Bitmap,
        spec: ImageEditSpec,
        format: String,
        output: OutputStream
    ) = withContext(Dispatchers.Default) {
        val cx = (spec.cropNormalized.left * source.width).toInt().coerceIn(0, source.width - 1)
        val cy = (spec.cropNormalized.top * source.height).toInt().coerceIn(0, source.height - 1)
        val cw = (spec.cropNormalized.width() * source.width).toInt().coerceIn(1, source.width - cx)
        val ch = (spec.cropNormalized.height() * source.height).toInt().coerceIn(1, source.height - cy)

        val transform = Matrix().apply {
            postScale(if (spec.flipHorizontal) -1f else 1f, if (spec.flipVertical) -1f else 1f)
            postRotate(spec.rotationDeg)
        }
        val cropped = Bitmap.createBitmap(source, cx, cy, cw, ch, transform, true)
        val result = Bitmap.createBitmap(cropped.width, cropped.height, Bitmap.Config.ARGB_8888)

        val cm = ColorMatrix().apply { setSaturation(spec.saturation) }
        val t = (1f - spec.contrast) * 128f + spec.brightness
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    spec.contrast, 0f, 0f, 0f, t + spec.warmth * 0.8f,
                    0f, spec.contrast, 0f, 0f, t,
                    0f, 0f, spec.contrast, 0f, t - spec.warmth * 0.8f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        Canvas(result).drawBitmap(cropped, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        })

        val compressFormat = when (format.lowercase()) {
            "png" -> Bitmap.CompressFormat.PNG
            "jpg", "jpeg" -> Bitmap.CompressFormat.JPEG
            else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                Bitmap.CompressFormat.WEBP_LOSSY else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
        }
        withContext(Dispatchers.IO) {
            result.compress(compressFormat, spec.quality.coerceIn(10, 100), output)
        }
    }
}
