package com.jobat.domain

import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable
import kotlin.math.roundToInt

enum class FormatCategory { PAGED, REFLOW_BOOK, OFFICE, TEXT_WEB, COMIC, IMAGE, ARCHIVE }

enum class DocFormat(val primaryExt: String, val extensions: Set<String>, val category: FormatCategory) {
    PDF("pdf", setOf("pdf"), FormatCategory.PAGED),
    DJVU("djvu", setOf("djvu", "djv"), FormatCategory.PAGED),
    XPS("xps", setOf("xps", "oxps"), FormatCategory.PAGED),
    EPUB("epub", setOf("epub", "epub3"), FormatCategory.REFLOW_BOOK),
    MOBI("mobi", setOf("mobi", "prc"), FormatCategory.REFLOW_BOOK),
    AZW("azw", setOf("azw"), FormatCategory.REFLOW_BOOK),
    AZW3("azw3", setOf("azw3", "kf8"), FormatCategory.REFLOW_BOOK),
    FB2("fb2", setOf("fb2"), FormatCategory.REFLOW_BOOK),
    FB2_ZIP("fb2.zip", setOf("fb2.zip", "fbz"), FormatCategory.REFLOW_BOOK),
    CBZ("cbz", setOf("cbz"), FormatCategory.COMIC),
    CBR("cbr", setOf("cbr"), FormatCategory.COMIC),
    CB7("cb7", setOf("cb7"), FormatCategory.COMIC),
    RTF("rtf", setOf("rtf"), FormatCategory.OFFICE),
    DOC("doc", setOf("doc"), FormatCategory.OFFICE),
    DOCX("docx", setOf("docx"), FormatCategory.OFFICE),
    ODT("odt", setOf("odt"), FormatCategory.OFFICE),
    XLS("xls", setOf("xls"), FormatCategory.OFFICE),
    XLSX("xlsx", setOf("xlsx"), FormatCategory.OFFICE),
    PPT("ppt", setOf("ppt"), FormatCategory.OFFICE),
    PPTX("pptx", setOf("pptx"), FormatCategory.OFFICE),
    TXT("txt", setOf("txt", "log"), FormatCategory.TEXT_WEB),
    MD("md", setOf("md", "markdown"), FormatCategory.TEXT_WEB),
    CSV("csv", setOf("csv", "tsv"), FormatCategory.TEXT_WEB),
    HTML("html", setOf("html", "htm"), FormatCategory.TEXT_WEB),
    XHTML("xhtml", setOf("xhtml"), FormatCategory.TEXT_WEB),
    MHT("mht", setOf("mht", "mhtml"), FormatCategory.TEXT_WEB),
    XML("xml", setOf("xml"), FormatCategory.TEXT_WEB),
    JPG("jpg", setOf("jpg", "jpeg"), FormatCategory.IMAGE),
    PNG("png", setOf("png"), FormatCategory.IMAGE),
    WEBP("webp", setOf("webp"), FormatCategory.IMAGE),
    GIF("gif", setOf("gif"), FormatCategory.IMAGE),
    BMP("bmp", setOf("bmp"), FormatCategory.IMAGE),
    HEIC("heic", setOf("heic", "heif"), FormatCategory.IMAGE),
    AVIF("avif", setOf("avif"), FormatCategory.IMAGE),
    SVG("svg", setOf("svg"), FormatCategory.IMAGE),
    TIFF("tiff", setOf("tif", "tiff"), FormatCategory.IMAGE),
    ZIP("zip", setOf("zip"), FormatCategory.ARCHIVE),
    RAR("rar", setOf("rar"), FormatCategory.ARCHIVE),
    SEVEN_Z("7z", setOf("7z"), FormatCategory.ARCHIVE);

    companion object {
        fun fromFileName(name: String): DocFormat {
            val lower = name.trim().lowercase()
            if (lower.endsWith(".fb2.zip")) return FB2_ZIP
            val ext = lower.substringAfterLast('.', "")
            return entries.firstOrNull { ext in it.extensions } ?: TXT
        }
    }
}

enum class LibraryViewMode { GRID, LIST, COMPACT }
enum class LibrarySort { LAST_READ, TITLE, DATE_ADDED, SIZE, PROGRESS }

@Serializable
data class DocumentItem(
    val id: String,
    val uriString: String,
    val title: String,
    val author: String,
    val format: DocFormat,
    val sizeBytes: Long,
    val pageCount: Int,
    val currentPage: Int,
    val addedAtEpochMs: Long,
    val lastReadEpochMs: Long,
    val coverCachePath: String? = null,
    val collectionId: String? = null,
    val tags: List<String> = emptyList(),
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val isTrashed: Boolean = false,
    val isVaultLocked: Boolean = false,
    val isPasswordProtected: Boolean = false
) {
    val progress: Float
        get() = if (pageCount <= 1) (if (lastReadEpochMs > 0L) 1f else 0f)
        else (currentPage.toFloat() / pageCount.toFloat()).coerceIn(0f, 1f)

    fun estimateMinutesRemaining(avgPagesPerMinute: Float = 0.85f): Int {
        val left = (pageCount - currentPage).coerceAtLeast(0)
        return (left / avgPagesPerMinute.coerceAtLeast(0.1f)).roundToInt()
    }
}

@Serializable
data class CollectionModel(val id: String, val name: String, val colorHex: String, val count: Int = 0)

@Serializable
data class OutlineNode(val title: String, val page: Int, val level: Int = 0)

@Serializable
data class SearchHit(val page: Int, val snippet: String)

@Serializable
data class QuoteHighlight(
    val id: String,
    val documentId: String,
    val documentTitle: String,
    val page: Int,
    val text: String,
    val note: String = "",
    val colorHex: String = "#D4B26A",
    val createdAtMs: Long
)

@Serializable
data class DailyReadingStat(val isoDate: String, val minutesRead: Int, val pagesRead: Int)

@Serializable
data class FullBackupPayload(
    val schemaVersion: Int = 1,
    val exportedAtMs: Long,
    val themeMode: String,
    val languageTag: String,
    val dailyGoalMinutes: Int,
    val documents: List<DocumentItem>,
    val collections: List<CollectionModel>,
    val highlights: List<QuoteHighlight>,
    val stats: List<DailyReadingStat>
)

interface LibraryRepository {
    fun observeLibrary(sort: LibrarySort, category: FormatCategory?, includeArchived: Boolean, onlyTrashed: Boolean): Flow<List<DocumentItem>>
    fun searchFts(query: String): Flow<List<DocumentItem>>
    suspend fun upsertDocument(doc: DocumentItem, indexedExcerpt: String = "")
    suspend fun updateReadingPosition(docId: String, page: Int, totalPages: Int)
    suspend fun toggleFavorite(docId: String)
    suspend fun setArchived(docId: String, archived: Boolean)
    suspend fun setTrashed(docId: String, trashed: Boolean)
    suspend fun purgeTrashed()
    fun observeHighlights(): Flow<List<QuoteHighlight>>
    suspend fun addHighlight(item: QuoteHighlight)
    fun observeStats(): Flow<List<DailyReadingStat>>
    suspend fun recordReadingMinutes(isoDate: String, minutes: Int, pages: Int)
    suspend fun exportBackupJson(): String
    suspend fun importBackupJson(rawJson: String): Result<Int>
}

class SortDocumentsUseCase {
    operator fun invoke(items: List<DocumentItem>, sort: LibrarySort): List<DocumentItem> = when (sort) {
        LibrarySort.LAST_READ -> items.sortedByDescending { it.lastReadEpochMs }
        LibrarySort.TITLE -> items.sortedBy { it.title.lowercase() }
        LibrarySort.DATE_ADDED -> items.sortedByDescending { it.addedAtEpochMs }
        LibrarySort.SIZE -> items.sortedByDescending { it.sizeBytes }
        LibrarySort.PROGRESS -> items.sortedByDescending { it.progress }
    }
}

class ComputeReadingStreakUseCase {
    operator fun invoke(stats: List<DailyReadingStat>): Int {
        var streak = 0
        for (day in stats.sortedByDescending { it.isoDate }) {
            if (day.minutesRead > 0) streak++ else break
        }
        return streak
    }
}
