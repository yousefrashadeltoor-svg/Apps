package com.jobat.designsystem

import android.os.Build
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class JobatThemeMode { DARK, LIGHT, AMOLED, SEPIA, DYNAMIC }

/** Generated & strictly synchronized with JObat/design-system/tokens.json */
object JobatTokens {
    // Obsidian Dark
    val ObsidianBg = Color(0xFF0B0C10)
    val GraphiteSurface = Color(0xFF15171C)
    val GraphiteElevated = Color(0xFF1E2128)
    val DarkTextPrimary = Color(0xFFF4F1EA)
    val DarkTextSecondary = Color(0xFF9EA3B0)

    // Champagne Gold Gradient
    val Champagne = Color(0xFFD4B26A)
    val ChampagneDeep = Color(0xFFB8914A)
    val ChampagneLightTheme = Color(0xFF9E7832)

    // Ivory Light
    val IvoryBg = Color(0xFFF6F1E7)
    val IvorySurface = Color(0xFFFFFDF9)
    val IvoryElevated = Color(0xFFECE5D7)
    val IvoryTextPrimary = Color(0xFF171614)
    val IvoryTextSecondary = Color(0xFF5E584E)

    // AMOLED
    val AmoledBg = Color(0xFF000000)
    val AmoledSurface = Color(0xFF0A0B0E)
    val AmoledElevated = Color(0xFF14161B)

    // Sepia
    val SepiaBg = Color(0xFFEFE4CE)
    val SepiaSurface = Color(0xFFF8F0DF)
    val SepiaElevated = Color(0xFFE4D5B8)
    val SepiaTextPrimary = Color(0xFF2B2116)
    val SepiaAccent = Color(0xFF96682A)

    // Spacing (4/8dp grid)
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 12.dp
    val SpaceLg = 16.dp
    val SpaceXl = 24.dp
    val SpaceXxl = 32.dp

    // Radii (12/16/24dp)
    val RadiusMd = 12.dp
    val RadiusLg = 16.dp
    val RadiusXl = 24.dp

    // Material 3 Emphasized Motion
    val EmphasizedEasing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    val EmphasizedDecelEasing = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1.0f)
    const val DurationFastMs = 160
    const val DurationMediumMs = 280
    const val DurationSlowMs = 420

    val ChampagneBrush = Brush.linearGradient(listOf(Champagne, ChampagneDeep))
}

@Immutable
data class JobatMotionConfig(val reduceMotion: Boolean = false) {
    fun <T> navSpring() = if (reduceMotion) snap<T>() else spring(
        dampingRatio = 0.78f,
        stiffness = Spring.StiffnessMediumLow
    )
    fun <T> standardTween() = if (reduceMotion) snap<T>() else tween(
        durationMillis = JobatTokens.DurationMediumMs,
        easing = JobatTokens.EmphasizedEasing
    )
}

val LocalJobatMotion = staticCompositionLocalOf { JobatMotionConfig(false) }

private val ObsidianColorScheme: ColorScheme = darkColorScheme(
    primary = JobatTokens.Champagne,
    onPrimary = JobatTokens.ObsidianBg,
    primaryContainer = Color(0xFF2A2418),
    onPrimaryContainer = JobatTokens.Champagne,
    secondary = JobatTokens.ChampagneDeep,
    background = JobatTokens.ObsidianBg,
    onBackground = JobatTokens.DarkTextPrimary,
    surface = JobatTokens.GraphiteSurface,
    onSurface = JobatTokens.DarkTextPrimary,
    surfaceVariant = JobatTokens.GraphiteElevated,
    onSurfaceVariant = JobatTokens.DarkTextSecondary,
    outline = Color(0x26D4B26A),
    error = Color(0xFFD96B6B)
)

private val IvoryColorScheme: ColorScheme = lightColorScheme(
    primary = JobatTokens.ChampagneLightTheme,
    onPrimary = JobatTokens.IvorySurface,
    primaryContainer = Color(0xFFF0E6D2),
    onPrimaryContainer = JobatTokens.ChampagneLightTheme,
    secondary = JobatTokens.ChampagneDeep,
    background = JobatTokens.IvoryBg,
    onBackground = JobatTokens.IvoryTextPrimary,
    surface = JobatTokens.IvorySurface,
    onSurface = JobatTokens.IvoryTextPrimary,
    surfaceVariant = JobatTokens.IvoryElevated,
    onSurfaceVariant = JobatTokens.IvoryTextSecondary,
    outline = Color(0x24181510),
    error = Color(0xFFB84242)
)

private val AmoledColorScheme: ColorScheme = ObsidianColorScheme.copy(
    background = JobatTokens.AmoledBg,
    surface = JobatTokens.AmoledSurface,
    surfaceVariant = JobatTokens.AmoledElevated,
    onPrimary = JobatTokens.AmoledBg
)

private val SepiaColorScheme: ColorScheme = IvoryColorScheme.copy(
    primary = JobatTokens.SepiaAccent,
    background = JobatTokens.SepiaBg,
    surface = JobatTokens.SepiaSurface,
    surfaceVariant = JobatTokens.SepiaElevated,
    onBackground = JobatTokens.SepiaTextPrimary,
    onSurface = JobatTokens.SepiaTextPrimary
)

val JobatTypography = Typography(
    displaySmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 30.sp, lineHeight = 36.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp)
)

val JobatShapes = Shapes(
    small = RoundedCornerShape(JobatTokens.RadiusMd),
    medium = RoundedCornerShape(JobatTokens.RadiusLg),
    large = RoundedCornerShape(JobatTokens.RadiusXl)
)

@Composable
fun JobatTheme(
    mode: JobatThemeMode = JobatThemeMode.DARK,
    reduceMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val scheme = when (mode) {
        JobatThemeMode.DARK -> ObsidianColorScheme
        JobatThemeMode.LIGHT -> IvoryColorScheme
        JobatThemeMode.AMOLED -> AmoledColorScheme
        JobatThemeMode.SEPIA -> SepiaColorScheme
        JobatThemeMode.DYNAMIC -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) dynamicDarkColorScheme(context)
            else ObsidianColorScheme
        }
    }
    CompositionLocalProvider(LocalJobatMotion provides JobatMotionConfig(reduceMotion)) {
        MaterialTheme(
            colorScheme = scheme,
            typography = JobatTypography,
            shapes = JobatShapes,
            content = content
        )
    }
}

@Composable
fun JobatWordmark(modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "𝒥𝒪",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontStyle = FontStyle.Italic,
                brush = JobatTokens.ChampagneBrush,
                letterSpacing = 0.5.sp
            )
        )
        Text(
            text = " bat",
            style = MaterialTheme.typography.headlineSmall.copy(
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Normal,
                letterSpacing = 1.2.sp
            )
        )
    }
}

data class JobatNavItem(val route: String, val label: String, val icon: ImageVector)

@Composable
fun JobatFloatingNavBar(
    items: List<JobatNavItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val motion = LocalJobatMotion.current
    val haptics = LocalHapticFeedback.current
    Surface(
        modifier = modifier
            .padding(horizontal = JobatTokens.SpaceLg, vertical = JobatTokens.SpaceMd)
            .fillMaxWidth()
            .height(64.dp),
        shape = RoundedCornerShape(JobatTokens.RadiusXl),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        shadowElevation = 12.dp
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp)) {
            val slotWidth = maxWidth / items.size.coerceAtLeast(1)
            val indicatorOffset by animateDpAsState(
                targetValue = slotWidth * selectedIndex,
                animationSpec = motion.navSpring(),
                label = "champagne_nav_indicator"
            )
            Box(
                modifier = Modifier
                    .offset(x = indicatorOffset)
                    .width(slotWidth)
                    .padding(vertical = 8.dp, horizontal = 4.dp)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.13f))
            )
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                items.forEachIndexed { idx, item ->
                    val active = idx == selectedIndex
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                role = Role.Tab
                            ) {
                                if (!active) {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onSelect(idx)
                                }
                            },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            modifier = Modifier.size(20.dp),
                            tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = item.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CircularGoldProgress(
    progress: Float,
    size: Dp = 52.dp,
    strokeWidth: Dp = 3.5.dp,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val track = primary.copy(alpha = 0.16f)
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
            drawArc(track, -90f, 360f, false, style = stroke)
            drawArc(primary, -90f, 360f * progress.coerceIn(0f, 1f), false, style = stroke)
        }
        Text(
            text = "${(progress.coerceIn(0f, 1f) * 100).toInt()}%",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = primary
        )
    }
}
