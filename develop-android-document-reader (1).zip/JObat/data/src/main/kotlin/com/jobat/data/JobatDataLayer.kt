package com.jobat.data

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.documentfile.provider.DocumentFile
import androidx.hilt.work.HiltWorker
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.jobat.core.engine.LibreraDocumentEngine
import com.jobat.core.engine.OpenDocumentResult
import com.jobat.domain.DailyReadingStat
import com.jobat.domain.DocFormat
import com.jobat.domain.DocumentItem
import com.jobat.domain.FormatCategory
import com.jobat.domain.FullBackupPayload
import com.jobat.domain.LibraryRepository
import com.jobat.domain.LibrarySort
import com.jobat.domain.QuoteHighlight
import com.jobat.domain.SortDocumentsUseCase
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

private val Context.jobatDataStore by preferencesDataStore(name = "jobat_preferences")

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val id: String,
    val uriString: String,
    val title: String,
    val author: String,
    val formatName: String,
    val sizeBytes: Long,
    val pageCount: Int,
    val currentPage: Int,
    val addedAtEpochMs: Long,
    val lastReadEpochMs: Long,
    val coverCachePath: String?,
    val collectionId: String?,
    val tagsCsv: String,
    val isFavorite: Boolean,
    val isArchived: Boolean,
    val isTrashed: Boolean,
    val isVaultLocked: Boolean,
    val isPasswordProtected: Boolean,
    val indexedContent: String
) {
    fun toDomain() = DocumentItem(
        id = id,
        uriString = uriString,
        title = title,
        author = author,
        format = runCatching { DocFormat.valueOf(formatName) }.getOrDefault(DocFormat.PDF),
        sizeBytes = sizeBytes,
        pageCount = pageCount,
        currentPage = currentPage,
        addedAtEpochMs = addedAtEpochMs,
        lastReadEpochMs = lastReadEpochMs,
        coverCachePath = coverCachePath,
        collectionId = collectionId,
        tags = tagsCsv.split(',').map { it.trim() }.filter { it.isNotEmpty() },
        isFavorite = isFavorite,
        isArchived = isArchived,
        isTrashed = isTrashed,
        isVaultLocked = isVaultLocked,
        isPasswordProtected = isPasswordProtected
    )
}

fun DocumentItem.toEntity(excerpt: String = "") = DocumentEntity(
    id = id,
    uriString = uriString,
    title = title,
    author = author,
    formatName = format.name,
    sizeBytes = sizeBytes,
    pageCount = pageCount,
    currentPage = currentPage,
    addedAtEpochMs = addedAtEpochMs,
    lastReadEpochMs = lastReadEpochMs,
    coverCachePath = coverCachePath,
    collectionId = collectionId,
    tagsCsv = tags.joinToString(","),
    isFavorite = isFavorite,
    isArchived = isArchived,
    isTrashed = isTrashed,
    isVaultLocked = isVaultLocked,
    isPasswordProtected = isPasswordProtected,
    indexedContent = excerpt
)

@Fts4(contentEntity = DocumentEntity::class)
@Entity(tableName = "documents_fts")
data class DocumentFtsEntity(
    @ColumnInfo(name = "title") val title: String,
    @ColumnInfo(name = "author") val author: String,
    @ColumnInfo(name = "tagsCsv") val tagsCsv: String,
    @ColumnInfo(name = "indexedContent") val indexedContent: String
)

@Entity(tableName = "highlights")
data class HighlightEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val documentTitle: String,
    val page: Int,
    val text: String,
    val note: String,
    val colorHex: String,
    val createdAtMs: Long
) {
    fun toDomain() = QuoteHighlight(id, documentId, documentTitle, page, text, note, colorHex, createdAtMs)
}

@Entity(tableName = "daily_stats")
data class DailyStatEntity(
    @PrimaryKey val isoDate: String,
    val minutesRead: Int,
    val pagesRead: Int
)

@Dao
interface JobatDao {
    @Query("SELECT * FROM documents WHERE isTrashed = :onlyTrashed AND (:includeArchived = 1 OR isArchived = 0)")
    fun observeDocs(includeArchived: Boolean, onlyTrashed: Boolean): Flow<List<DocumentEntity>>

    @Query("""
        SELECT documents.* FROM documents
        JOIN documents_fts ON documents.rowid = documents_fts.rowid
        WHERE documents_fts MATCH :ftsQuery AND documents.isTrashed = 0
    """)
    fun searchDocsFts(ftsQuery: String): Flow<List<DocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDoc(entity: DocumentEntity)

    @Query("UPDATE documents SET currentPage = :page, pageCount = :total, lastReadEpochMs = :now WHERE id = :id")
    suspend fun updateProgress(id: String, page: Int, total: Int, now: Long)

    @Query("UPDATE documents SET isFavorite = NOT isFavorite WHERE id = :id")
    suspend fun toggleFavorite(id: String)

    @Query("UPDATE documents SET isArchived = :archived WHERE id = :id")
    suspend fun setArchived(id: String, archived: Boolean)

    @Query("UPDATE documents SET isTrashed = :trashed WHERE id = :id")
    suspend fun setTrashed(id: String, trashed: Boolean)

    @Query("DELETE FROM documents WHERE isTrashed = 1")
    suspend fun purgeTrashed()

    @Query("SELECT * FROM highlights ORDER BY createdAtMs DESC")
    fun observeHighlights(): Flow<List<HighlightEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHighlight(entity: HighlightEntity)

    @Query("SELECT * FROM daily_stats ORDER BY isoDate DESC LIMIT 90")
    fun observeStats(): Flow<List<DailyStatEntity>>

    @Query("SELECT * FROM daily_stats WHERE isoDate = :date LIMIT 1")
    suspend fun getStat(date: String): DailyStatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStat(stat: DailyStatEntity)
}

@Database(
    entities = [DocumentEntity::class, DocumentFtsEntity::class, HighlightEntity::class, DailyStatEntity::class],
    version = 1,
    exportSchema = false
)
abstract class JobatDatabase : RoomDatabase() {
    abstract fun dao(): JobatDao
}

@Singleton
class JobatPreferencesStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val keyTheme = stringPreferencesKey("theme_mode")
    private val keyLang = stringPreferencesKey("language_tag")
    private val keyReduceMotion = booleanPreferencesKey("reduce_motion")
    private val keyBiometric = booleanPreferencesKey("biometric_lock")
    private val keyGoal = intPreferencesKey("daily_goal_min")
    private val keyOnboarded = booleanPreferencesKey("onboarding_done")

    val themeFlow: Flow<String> = context.jobatDataStore.data.map { it[keyTheme] ?: "DARK" }
    val langFlow: Flow<String> = context.jobatDataStore.data.map { it[keyLang] ?: "ar" }
    val reduceMotionFlow: Flow<Boolean> = context.jobatDataStore.data.map { it[keyReduceMotion] ?: false }
    val biometricFlow: Flow<Boolean> = context.jobatDataStore.data.map { it[keyBiometric] ?: false }
    val dailyGoalFlow: Flow<Int> = context.jobatDataStore.data.map { it[keyGoal] ?: 30 }
    val onboardedFlow: Flow<Boolean> = context.jobatDataStore.data.map { it[keyOnboarded] ?: false }

    suspend fun setTheme(mode: String) { context.jobatDataStore.edit { it[keyTheme] = mode } }
    suspend fun setLanguage(tag: String) { context.jobatDataStore.edit { it[keyLang] = tag } }
    suspend fun setReduceMotion(v: Boolean) { context.jobatDataStore.edit { it[keyReduceMotion] = v } }
    suspend fun setBiometric(v: Boolean) { context.jobatDataStore.edit { it[keyBiometric] = v } }
    suspend fun setDailyGoal(min: Int) { context.jobatDataStore.edit { it[keyGoal] = min.coerceIn(5, 300) } }
    suspend fun completeOnboarding() { context.jobatDataStore.edit { it[keyOnboarded] = true } }
}

/** AndroidKeyStore AES-256-GCM Encrypted Vault for sensitive documents. */
@Singleton
class VaultCryptoManager @Inject constructor(@ApplicationContext private val context: Context) {
    private val vaultDir by lazy { File(context.filesDir, "encrypted_vault").apply { mkdirs() } }
    private val masterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    suspend fun sealIntoVault(sourceUri: Uri, docId: String): File = withContext(Dispatchers.IO) {
        val dest = File(vaultDir, "$docId.jvault").also { if (it.exists()) it.delete() }
        val encFile = EncryptedFile.Builder(
            context, dest, masterKey, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            encFile.openFileOutput().use { out -> input.copyTo(out) }
        } ?: error("Cannot read source file for vault encryption")
        dest
    }

    suspend fun unsealBytes(docId: String): ByteArray = withContext(Dispatchers.IO) {
        val src = File(vaultDir, "$docId.jvault")
        val encFile = EncryptedFile.Builder(
            context, src, masterKey, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
        encFile.openFileInput().use { it.readBytes() }
    }
}

@Singleton
class LibraryRepositoryImpl @Inject constructor(
    private val dao: JobatDao,
    private val prefs: JobatPreferencesStore
) : LibraryRepository {
    private val sorter = SortDocumentsUseCase()
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    override fun observeLibrary(
        sort: LibrarySort,
        category: FormatCategory?,
        includeArchived: Boolean,
        onlyTrashed: Boolean
    ): Flow<List<DocumentItem>> = dao.observeDocs(includeArchived, onlyTrashed).map { rows ->
        val filtered = rows.map(DocumentEntity::toDomain)
            .filter { category == null || it.format.category == category }
        sorter(filtered, sort)
    }

    override fun searchFts(query: String): Flow<List<DocumentItem>> {
        val sanitized = query.trim().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+")).filter { it.isNotBlank() }.joinToString(" ") { "$it*" }
        return dao.searchDocsFts(sanitized).map { it.map(DocumentEntity::toDomain) }
    }

    override suspend fun upsertDocument(doc: DocumentItem, indexedExcerpt: String) {
        dao.upsertDoc(doc.toEntity(indexedExcerpt))
    }

    override suspend fun updateReadingPosition(docId: String, page: Int, totalPages: Int) {
        dao.updateProgress(docId, page, totalPages, System.currentTimeMillis())
    }

    override suspend fun toggleFavorite(docId: String) = dao.toggleFavorite(docId)
    override suspend fun setArchived(docId: String, archived: Boolean) = dao.setArchived(docId, archived)
    override suspend fun setTrashed(docId: String, trashed: Boolean) = dao.setTrashed(docId, trashed)
    override suspend fun purgeTrashed() = dao.purgeTrashed()

    override fun observeHighlights(): Flow<List<QuoteHighlight>> =
        dao.observeHighlights().map { list -> list.map(HighlightEntity::toDomain) }

    override suspend fun addHighlight(item: QuoteHighlight) {
        dao.upsertHighlight(
            HighlightEntity(item.id, item.documentId, item.documentTitle, item.page, item.text, item.note, item.colorHex, item.createdAtMs)
        )
    }

    override fun observeStats(): Flow<List<DailyReadingStat>> =
        dao.observeStats().map { list -> list.map { DailyReadingStat(it.isoDate, it.minutesRead, it.pagesRead) } }

    override suspend fun recordReadingMinutes(isoDate: String, minutes: Int, pages: Int) {
        val existing = dao.getStat(isoDate)
        dao.upsertStat(
            DailyStatEntity(
                isoDate = isoDate,
                minutesRead = (existing?.minutesRead ?: 0) + minutes,
                pagesRead = (existing?.pagesRead ?: 0) + pages
            )
        )
    }

    override suspend fun exportBackupJson(): String {
        val payload = FullBackupPayload(
            exportedAtMs = System.currentTimeMillis(),
            themeMode = prefs.themeFlow.first(),
            languageTag = prefs.langFlow.first(),
            dailyGoalMinutes = prefs.dailyGoalFlow.first(),
            documents = dao.observeDocs(includeArchived = true, onlyTrashed = false).first().map(DocumentEntity::toDomain),
            collections = emptyList(),
            highlights = observeHighlights().first(),
            stats = observeStats().first()
        )
        return json.encodeToString(payload)
    }

    override suspend fun importBackupJson(rawJson: String): Result<Int> = runCatching {
        val payload = json.decodeFromString<FullBackupPayload>(rawJson)
        prefs.setTheme(payload.themeMode)
        prefs.setLanguage(payload.languageTag)
        prefs.setDailyGoal(payload.dailyGoalMinutes)
        payload.documents.forEach { dao.upsertDoc(it.toEntity()) }
        payload.highlights.forEach { addHighlight(it) }
        payload.stats.forEach { dao.upsertStat(DailyStatEntity(it.isoDate, it.minutesRead, it.pagesRead)) }
        payload.documents.size + payload.highlights.size
    }
}

/** Background Scoped-Storage SAF directory indexer with metadata & FTS excerpt extraction. */
@HiltWorker
class LibraryIndexWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val engine: LibreraDocumentEngine,
    private val repository: LibraryRepository
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val treeUriStr = inputData.getString(KEY_TREE_URI) ?: return@withContext Result.failure()
        val root = DocumentFile.fromTreeUri(applicationContext, Uri.parse(treeUriStr))
            ?: return@withContext Result.failure()
        indexDirectory(root)
        Result.success()
    }

    private suspend fun indexDirectory(dir: DocumentFile) {
        for (file in dir.listFiles()) {
            if (file.isDirectory) {
                indexDirectory(file)
                continue
            }
            val name = file.name ?: continue
            val format = DocFormat.fromFileName(name)
            val openRes = engine.openDocument(file.uri, name)
            var title = name.substringBeforeLast('.')
            var author = ""
            var pages = 1
            var excerpt = ""
            var pwdProtected = false
            when (openRes) {
                is OpenDocumentResult.Opened -> openRes.session.use { s ->
                    title = s.title
                    author = s.author
                    pages = s.pageCount
                    excerpt = s.reflowChapters.firstOrNull()?.take(1500).orEmpty()
                }
                is OpenDocumentResult.PasswordRequired -> pwdProtected = true
                is OpenDocumentResult.CorruptOrUnsupported -> continue
            }
            repository.upsertDocument(
                doc = DocumentItem(
                    id = file.uri.toString().hashCode().toUInt().toString(16),
                    uriString = file.uri.toString(),
                    title = title,
                    author = author,
                    format = format,
                    sizeBytes = file.length(),
                    pageCount = pages,
                    currentPage = 0,
                    addedAtEpochMs = System.currentTimeMillis(),
                    lastReadEpochMs = file.lastModified(),
                    isPasswordProtected = pwdProtected
                ),
                indexedExcerpt = excerpt
            )
        }
    }

    companion object { const val KEY_TREE_URI = "tree_uri" }
}

@Module
@InstallIn(SingletonComponent::class)
abstract class DataModule {
    @Binds @Singleton
    abstract fun bindLibraryRepository(impl: LibraryRepositoryImpl): LibraryRepository

    companion object {
        @Provides @Singleton
        fun provideDatabase(@ApplicationContext context: Context): JobatDatabase =
            Room.databaseBuilder(context, JobatDatabase::class.java, "jobat_library.db")
                .fallbackToDestructiveMigration()
                .build()

        @Provides
        fun provideDao(db: JobatDatabase): JobatDao = db.dao()
    }
}
