package com.jobat.feature.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class OcrLanguageModel(val code: String, val displayName: String, val sizeMb: Float, val installed: Boolean)

class OfflineScannerOcrEngine(private val context: Context) {
    private val tessRoot = File(context.filesDir, "ocr").apply { File(this, "tessdata").mkdirs() }

    fun listModels(): List<OcrLanguageModel> {
        val dir = File(tessRoot, "tessdata")
        return listOf(
            OcrLanguageModel("ara", "العربية (Arabic)", 4.2f, File(dir, "ara.traineddata").exists()),
            OcrLanguageModel("eng", "English", 3.8f, File(dir, "eng.traineddata").exists()),
            OcrLanguageModel("fra", "Français", 3.5f, File(dir, "fra.traineddata").exists()),
            OcrLanguageModel("deu", "Deutsch", 3.6f, File(dir, "deu.traineddata").exists()),
        )
    }

    suspend fun perspectiveWarp(source: Bitmap, srcQuad: FloatArray, outWidth: Int, outHeight: Int): Bitmap =
        withContext(Dispatchers.Default) {
            val dstQuad = floatArrayOf(0f, 0f, outWidth.toFloat(), 0f, outWidth.toFloat(), outHeight.toFloat(), 0f, outHeight.toFloat())
            val matrix = Matrix().apply { setPolyToPoly(srcQuad, 0, dstQuad, 0, 4) }
            val out = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
            Canvas(out).drawBitmap(source, matrix, Paint(Paint.FILTER_BITMAP_FLAG))
            out
        }

    suspend fun recognizeText(bitmap: Bitmap, langCode: String): String = withContext(Dispatchers.Default) {
        val api = TessBaseAPI()
        try {
            if (!api.init(tessRoot.absolutePath, langCode)) return@withContext ""
            api.setImage(bitmap)
            api.utF8Text.orEmpty().trim()
        } finally {
            api.recycle()
        }
    }

    suspend fun buildSearchablePdf(pages: List<Pair<Bitmap, String>>, outputFile: File): File =
        withContext(Dispatchers.IO) {
            val pdf = PdfDocument()
            val hiddenTextPaint = Paint().apply { alpha = 0; textSize = 11f }
            pages.forEachIndexed { idx, (bmp, ocrText) ->
                val info = PdfDocument.PageInfo.Builder(bmp.width, bmp.height, idx + 1).create()
                val page = pdf.startPage(info)
                page.canvas.drawBitmap(bmp, 0f, 0f, null)
                ocrText.lines().forEachIndexed { lineIdx, line ->
                    page.canvas.drawText(line, 24f, 40f + lineIdx * 16f, hiddenTextPaint)
                }
                pdf.finishPage(page)
            }
            outputFile.outputStream().use { pdf.writeTo(it) }
            pdf.close()
            outputFile
        }
}
