package com.jobat.core.nativebridge

import android.graphics.Bitmap
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed interface NativeOpenResult {
    data class Ready(val handle: Long, val pageCount: Int) : NativeOpenResult
    data class PasswordRequired(val handle: Long) : NativeOpenResult
    data class CorruptedOrUnsupported(val reason: String) : NativeOpenResult
}

class NativeDocumentBridge {
    private val pageCache = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount / 1024
    }

    suspend fun openDocument(path: String, emFontSize: Float = 15f): NativeOpenResult =
        withContext(Dispatchers.IO) {
            val handle = nativeOpen(path, emFontSize)
            when {
                handle < 0L -> NativeOpenResult.CorruptedOrUnsupported("Failed to decode file ($handle)")
                nativeNeedsPassword(handle) -> NativeOpenResult.PasswordRequired(handle)
                else -> NativeOpenResult.Ready(handle, nativeGetPageCount(handle))
            }
        }

    suspend fun unlockWithPassword(handle: Long, password: String): NativeOpenResult =
        withContext(Dispatchers.IO) {
            if (nativeAuthenticate(handle, password)) {
                NativeOpenResult.Ready(handle, nativeGetPageCount(handle))
            } else {
                NativeOpenResult.PasswordRequired(handle)
            }
        }

    suspend fun renderPageCached(
        handle: Long,
        pageIndex: Int,
        widthPx: Int,
        heightPx: Int,
        zoom: Float = 1f,
        invertNight: Boolean = false,
        autoCrop: Boolean = false,
    ): Bitmap = withContext(Dispatchers.Default) {
        val key = "$handle:$pageIndex:${widthPx}x$heightPx:$zoom:$invertNight:$autoCrop"
        pageCache.get(key)?.takeIf { !it.isRecycled }?.let { return@withContext it }
        val bmp = Bitmap.createBitmap(widthPx.coerceAtLeast(1), heightPx.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        nativeRenderPage(handle, pageIndex, bmp, zoom, invertNight, autoCrop)
        pageCache.put(key, bmp)
        bmp
    }

    suspend fun saveDocument(handle: Long, outputPath: String, incremental: Boolean): Boolean =
        withContext(Dispatchers.IO) {
            pageCache.evictAll()
            nativeSaveAnnotations(handle, outputPath, incremental)
        }

    fun close(handle: Long) {
        pageCache.evictAll()
        nativeClose(handle)
    }

    private external fun nativeOpen(path: String, emFontSize: Float): Long
    private external fun nativeNeedsPassword(handle: Long): Boolean
    private external fun nativeAuthenticate(handle: Long, password: String): Boolean
    private external fun nativeGetPageCount(handle: Long): Int
    private external fun nativeRenderPage(
        handle: Long,
        pageIndex: Int,
        bitmap: Bitmap,
        zoom: Float,
        invertNight: Boolean,
        autoCrop: Boolean,
    ): Boolean
    private external fun nativeSaveAnnotations(handle: Long, outputPath: String, incremental: Boolean): Boolean
    private external fun nativeClose(handle: Long)

    companion object {
        init {
            System.loadLibrary("jobat_mupdf")
        }
    }
}
