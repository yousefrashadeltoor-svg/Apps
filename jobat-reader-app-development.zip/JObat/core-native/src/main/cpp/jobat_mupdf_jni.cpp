#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#ifdef HAVE_MUPDF_FITZ
extern "C" {
#include "mupdf/fitz.h"
#include "mupdf/pdf.h"
}
#endif

namespace {
constexpr const char* kTag = "JobatNative";

struct NativeAnnotation {
    int pageIndex;
    int type; // 0=Highlight, 1=Underline, 2=Strike, 3=Ink, 4=Rect, 5=Note, 6=Signature, 7=Stamp
    uint32_t argbColor;
    float strokeWidth;
    std::vector<float> points;
    std::string payload;
};

struct DocumentSession {
    int64_t handle = 0;
    std::string path;
    int pageCount = 1;
    bool needsPassword = false;
    bool authenticated = true;
    std::vector<int> pageOrder;
    std::vector<int> pageRotations;
    std::vector<NativeAnnotation> annotations;
#ifdef HAVE_MUPDF_FITZ
    fz_context* ctx = nullptr;
    fz_document* doc = nullptr;
#endif
};

std::mutex gMutex;
int64_t gNextHandle = 1000;
std::unordered_map<int64_t, DocumentSession> gSessions;
} // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_jobat_core_nativebridge_NativeDocumentBridge_nativeOpen(
        JNIEnv* env, jobject, jstring jPath, jfloat emFontSize) {
    const char* rawPath = env->GetStringUTFChars(jPath, nullptr);
    std::string path(rawPath ? rawPath : "");
    env->ReleaseStringUTFChars(jPath, rawPath);

    std::lock_guard<std::mutex> lock(gMutex);
    DocumentSession session;
    session.handle = ++gNextHandle;
    session.path = path;

#ifdef HAVE_MUPDF_FITZ
    session.ctx = fz_new_context(nullptr, nullptr, 128 << 20);
    if (!session.ctx) return -1L;
    fz_try(session.ctx) {
        fz_register_document_handlers(session.ctx);
        fz_set_user_css(session.ctx, "body { line-height: 1.55; }");
        session.doc = fz_open_document(session.ctx, path.c_str());
        fz_layout_document(session.ctx, session.doc, 420.0f, 680.0f, emFontSize);
        session.needsPassword = fz_needs_password(session.ctx, session.doc) != 0;
        session.authenticated = !session.needsPassword;
        session.pageCount = session.authenticated ? fz_count_pages(session.ctx, session.doc) : 0;
    } fz_catch(session.ctx) {
        __android_log_print(ANDROID_LOG_ERROR, kTag, "Open failed: %s", fz_caught_message(session.ctx));
        fz_drop_context(session.ctx);
        return -2L;
    }
#else
    (void)emFontSize;
    session.pageCount = path.empty() ? 0 : 1;
    if (session.pageCount == 0) return -2L;
#endif

    session.pageOrder.resize(static_cast<size_t>(session.pageCount));
    session.pageRotations.assign(static_cast<size_t>(session.pageCount), 0);
    for (int i = 0; i < session.pageCount; ++i) session.pageOrder[static_cast<size_t>(i)] = i;

    const int64_t handle = session.handle;
    gSessions.emplace(handle, std::move(session));
    return static_cast<jlong>(handle);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativebridge_NativeDocumentBridge_nativeNeedsPassword(
        JNIEnv*, jobject, jlong handle) {
    std::lock_guard<std::mutex> lock(gMutex);
    auto it = gSessions.find(handle);
    return (it != gSessions.end() && it->second.needsPassword && !it->second.authenticated) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativebridge_NativeDocumentBridge_nativeAuthenticate(
        JNIEnv* env, jobject, jlong handle, jstring jPassword) {
    const char* pwd = env->GetStringUTFChars(jPassword, nullptr);
    std::string password(pwd ? pwd : "");
    env->ReleaseStringUTFChars(jPassword, pwd);

    std::lock_guard<std::mutex> lock(gMutex);
    auto it = gSessions.find(handle);
    if (it == gSessions.end()) return JNI_FALSE;
    auto& s = it->second;

#ifdef HAVE_MUPDF_FITZ
    int ok = 0;
    fz_try(s.ctx) {
        ok = fz_authenticate_password(s.ctx, s.doc, password.c_str());
        if (ok) {
            s.authenticated = true;
            s.pageCount = fz_count_pages(s.ctx, s.doc);
            s.pageOrder.resize(static_cast<size_t>(s.pageCount));
            s.pageRotations.assign(static_cast<size_t>(s.pageCount), 0);
            for (int i = 0; i < s.pageCount; ++i) s.pageOrder[static_cast<size_t>(i)] = i;
        }
    } fz_catch(s.ctx) {
        return JNI_FALSE;
    }
    return ok ? JNI_TRUE : JNI_FALSE;
#else
    s.authenticated = !password.empty();
    return s.authenticated ? JNI_TRUE : JNI_FALSE;
#endif
}

extern "C" JNIEXPORT jint JNICALL
Java_com_jobat_core_nativebridge_NativeDocumentBridge_nativeGetPageCount(
        JNIEnv*, jobject, jlong handle) {
    std::lock_guard<std::mutex> lock(gMutex);
    auto it = gSessions.find(handle);
    return it == gSessions.end() ? 0 : static_cast<jint>(it->second.pageOrder.size());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativebridge_NativeDocumentBridge_nativeRenderPage(
        JNIEnv* env, jobject, jlong handle, jint pageIndex, jobject bitmap,
        jfloat zoom, jboolean invertNight, jboolean autoCrop) {
    AndroidBitmapInfo info{};
    void* pixels = nullptr;
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return JNI_FALSE;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS) return JNI_FALSE;

    std::lock_guard<std::mutex> lock(gMutex);
    auto it = gSessions.find(handle);
    if (it == gSessions.end() || pageIndex < 0 ||
        static_cast<size_t>(pageIndex) >= it->second.pageOrder.size()) {
        AndroidBitmap_unlockPixels(env, bitmap);
        return JNI_FALSE;
    }

#ifdef HAVE_MUPDF_FITZ
    auto& s = it->second;
    const int srcPage = s.pageOrder[static_cast<size_t>(pageIndex)];
    const int rot = s.pageRotations[static_cast<size_t>(pageIndex)];
    fz_try(s.ctx) {
        fz_page* page = fz_load_page(s.ctx, s.doc, srcPage);
        fz_matrix ctm = fz_scale(zoom, zoom);
        ctm = fz_post_rotate(ctm, static_cast<float>(rot));
        fz_pixmap* pix = fz_new_pixmap_with_data(
                s.ctx, fz_device_rgb(s.ctx), static_cast<int>(info.width),
                static_cast<int>(info.height), nullptr, 1, static_cast<int>(info.stride),
                static_cast<unsigned char*>(pixels));
        fz_clear_pixmap_with_value(s.ctx, pix, 255);
        fz_device* dev = fz_new_draw_device(s.ctx, ctm, pix);
        fz_run_page(s.ctx, page, dev, fz_identity, nullptr);
        fz_close_device(s.ctx, dev);
        fz_drop_device(s.ctx, dev);
        if (invertNight) fz_invert_pixmap_luminance(s.ctx, pix);
        (void)autoCrop;
        fz_drop_pixmap(s.ctx, pix);
        fz_drop_page(s.ctx, page);
    } fz_catch(s.ctx) {
        AndroidBitmap_unlockPixels(env, bitmap);
        return JNI_FALSE;
    }
#else
    (void)zoom;
    (void)autoCrop;
    const uint32_t fill = invertNight ? 0xFF0B0C10u : 0xFFFAF9F5u;
    auto* row = static_cast<uint8_t*>(pixels);
    for (uint32_t y = 0; y < info.height; ++y) {
        auto* px = reinterpret_cast<uint32_t*>(row + y * info.stride);
        for (uint32_t x = 0; x < info.width; ++x) px[x] = fill;
    }
#endif

    AndroidBitmap_unlockPixels(env, bitmap);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_jobat_core_nativebridge_NativeDocumentBridge_nativeSaveAnnotations(
        JNIEnv* env, jobject, jlong handle, jstring jOutputPath, jboolean incremental) {
    const char* out = env->GetStringUTFChars(jOutputPath, nullptr);
    std::string outputPath(out ? out : "");
    env->ReleaseStringUTFChars(jOutputPath, out);

    std::lock_guard<std::mutex> lock(gMutex);
    auto it = gSessions.find(handle);
    if (it == gSessions.end() || outputPath.empty()) return JNI_FALSE;

#ifdef HAVE_MUPDF_FITZ
    auto& s = it->second;
    pdf_document* pdf = pdf_specifics(s.ctx, s.doc);
    if (!pdf) return JNI_FALSE;
    fz_try(s.ctx) {
        pdf_write_options opts = pdf_default_write_options;
        opts.do_incremental = incremental ? 1 : 0;
        opts.do_compress = 1;
        opts.do_garbage = incremental ? 0 : 2;
        pdf_save_document(s.ctx, pdf, outputPath.c_str(), &opts);
    } fz_catch(s.ctx) {
        return JNI_FALSE;
    }
#else
    (void)incremental;
#endif
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_jobat_core_nativebridge_NativeDocumentBridge_nativeClose(
        JNIEnv*, jobject, jlong handle) {
    std::lock_guard<std::mutex> lock(gMutex);
    auto it = gSessions.find(handle);
    if (it == gSessions.end()) return;
#ifdef HAVE_MUPDF_FITZ
    if (it->second.doc) fz_drop_document(it->second.ctx, it->second.doc);
    if (it->second.ctx) fz_drop_context(it->second.ctx);
#endif
    gSessions.erase(it);
}
