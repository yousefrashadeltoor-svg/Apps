cmake_minimum_required(VERSION 3.22.1)
project(jobat_mupdf VERSION 1.0.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_FLAGS_RELEASE "${CMAKE_CXX_FLAGS_RELEASE} -Oz -flto -fvisibility=hidden -ffunction-sections -fdata-sections")
set(CMAKE_SHARED_LINKER_FLAGS_RELEASE "${CMAKE_SHARED_LINKER_FLAGS_RELEASE} -Wl,--gc-sections -Wl,--strip-all")

add_library(jobat_mupdf SHARED
    jobat_mupdf_jni.cpp
)

find_library(log-lib log)
find_library(jnigraphics-lib jnigraphics)
find_library(z-lib z)

if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/third_party/mupdf/CMakeLists.txt")
    add_definitions(-DHAVE_MUPDF_FITZ=1)
    add_subdirectory(third_party/mupdf EXCLUDE_FROM_ALL)
    target_link_libraries(jobat_mupdf PRIVATE mupdf ${log-lib} ${jnigraphics-lib} ${z-lib})
else()
    target_link_libraries(jobat_mupdf PRIVATE ${log-lib} ${jnigraphics-lib} ${z-lib})
endif()
