package com.jobat.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jobat.designsystem.theme.JobatAppTheme

@Composable
fun SettingsScreen(
    currentTheme: JobatAppTheme,
    languageCode: String,
    reduceMotion: Boolean,
    biometricEnabled: Boolean,
    onThemeChange: (JobatAppTheme) -> Unit,
    onLanguageChange: (String) -> Unit,
    onReduceMotionChange: (Boolean) -> Unit,
    onBiometricChange: (Boolean) -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("𝒥𝒪 bat Settings", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            JobatAppTheme.entries.forEach { t ->
                FilterChip(selected = currentTheme == t, onClick = { onThemeChange(t) }, label = { Text(t.name) })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = languageCode == "ar", onClick = { onLanguageChange("ar") }, label = { Text("العربية (RTL)") })
            FilterChip(selected = languageCode == "en", onClick = { onLanguageChange("en") }, label = { Text("English (LTR)") })
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Reduce Motion")
            Switch(checked = reduceMotion, onCheckedChange = onReduceMotionChange)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Biometric App & Vault Lock")
            Switch(checked = biometricEnabled, onCheckedChange = onBiometricChange)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onExportBackup) { Text("Export Backup") }
            OutlinedButton(onClick = onImportBackup) { Text("Restore Backup") }
        }

        HorizontalDivider()
        Text("About & Open-Source Licenses (GPL-3.0)", style = MaterialTheme.typography.titleMedium)
        Text(
            "𝒥𝒪 bat (com.jobat.reader) v1.0.0 — Distributed under GNU GPL-3.0-or-later.\n" +
                "Core reading engine forked from Librera Reader (GPL-3.0) with Artifex MuPDF (AGPL-3.0/GPL-3.0), " +
                "DjVuLibre (GPL-2.0+), Tesseract OCR (Apache-2.0), AndroidX Jetpack Compose, Room, DataStore, " +
                "WorkManager, CameraX, Coil & Apache Commons Compress (Apache-2.0). 100% Offline • Zero Ads • Zero Tracking.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
