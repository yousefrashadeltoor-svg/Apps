package com.jobat.feature.tools

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class DocumentToolsEngine {

    suspend fun mergePdfs(inputs: List<File>, output: File, watermark: String? = null, numberPages: Boolean = false): File =
        withContext(Dispatchers.IO) {
            val outPdf = PdfDocument()
            var globalPage = 1
            inputs.forEach { file ->
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        for (i in 0 until renderer.pageCount) {
                            renderer.openPage(i).use { src ->
                                val bmp = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
                                src.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                val page = outPdf.startPage(PdfDocument.PageInfo.Builder(src.width, src.height, globalPage).create())
                                page.canvas.drawBitmap(bmp, 0f, 0f, null)
                                watermark?.takeIf { it.isNotBlank() }?.let { wm ->
                                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                        color = Color.argb(48, 180, 145, 74)
                                        textSize = 42f
                                    }
                                    page.canvas.save()
                                    page.canvas.rotate(-32f, src.width / 2f, src.height / 2f)
                                    page.canvas.drawText(wm, src.width * 0.2f, src.height * 0.5f, paint)
                                    page.canvas.restore()
                                }
                                if (numberPages) {
                                    val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 14f }
                                    page.canvas.drawText("$globalPage", src.width - 42f, src.height - 24f, numPaint)
                                }
                                outPdf.finishPage(page)
                                bmp.recycle()
                                globalPage++
                            }
                        }
                    }
                }
            }
            output.outputStream().use { outPdf.writeTo(it) }
            outPdf.close()
            output
        }

    suspend fun splitPdf(input: File, pageRange: IntRange, output: File): File = withContext(Dispatchers.IO) {
        val outPdf = PdfDocument()
        ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                var outIdx = 1
                for (i in pageRange) {
                    if (i !in 0 until renderer.pageCount) continue
                    renderer.openPage(i).use { src ->
                        val bmp = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
                        src.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        val page = outPdf.startPage(PdfDocument.PageInfo.Builder(src.width, src.height, outIdx++).create())
                        page.canvas.drawBitmap(bmp, 0f, 0f, null)
                        outPdf.finishPage(page)
                        bmp.recycle()
                    }
                }
            }
        }
        output.outputStream().use { outPdf.writeTo(it) }
        outPdf.close()
        output
    }

    suspend fun imagesToPdf(bitmaps: List<Bitmap>, output: File): File = withContext(Dispatchers.IO) {
        val pdf = PdfDocument()
        bitmaps.forEachIndexed { idx, bmp ->
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, idx + 1).create())
            page.canvas.drawBitmap(bmp, 0f, 0f, null)
            pdf.finishPage(page)
        }
        output.outputStream().use { pdf.writeTo(it) }
        pdf.close()
        output
    }
}
