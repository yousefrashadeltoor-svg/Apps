package com.jobat.feature.editor.text

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jobat.domain.UndoRedoStack

@Composable
fun TextCodeEditorScreen(
    fileName: String,
    initialContent: String,
    onAutoSave: (String) -> Unit,
    onBack: () -> Unit,
) {
    val stack = remember { UndoRedoStack(initialContent) }
    var text by remember { mutableStateOf(initialContent) }
    var findPattern by remember { mutableStateOf("") }
    var replacement by remember { mutableStateOf("") }
    var useRegex by remember { mutableStateOf(true) }
    var livePreview by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("←") }
            Text(fileName, style = MaterialTheme.typography.titleMedium)
            Row {
                TextButton(enabled = stack.canUndo, onClick = { text = stack.undo() }) { Text("Undo") }
                TextButton(enabled = stack.canRedo, onClick = { text = stack.redo() }) { Text("Redo") }
                TextButton(onClick = { livePreview = !livePreview }) { Text(if (livePreview) "Code" else "Preview") }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(findPattern, { findPattern = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Find / Regex") })
            OutlinedTextField(replacement, { replacement = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Replace") })
            Button(onClick = {
                if (findPattern.isNotEmpty()) {
                    val updated = runCatching {
                        if (useRegex) text.replace(Regex(findPattern), replacement) else text.replace(findPattern, replacement)
                    }.getOrDefault(text)
                    stack.push(updated)
                    text = updated
                    onAutoSave(updated)
                }
            }) { Text("All") }
        }

        FilterChip(selected = useRegex, onClick = { useRegex = !useRegex }, label = { Text("Regex (.*)") })

        val lines = remember(text) { text.lines() }
        Row(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
            Column(Modifier.padding(end = 10.dp)) {
                lines.indices.forEach { idx ->
                    Text("${idx + 1}", fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            BasicTextField(
                value = text,
                onValueChange = {
                    text = it
                    stack.push(it)
                    onAutoSave(it)
                },
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier.weight(1f).fillMaxHeight(),
            )
        }
    }
}
