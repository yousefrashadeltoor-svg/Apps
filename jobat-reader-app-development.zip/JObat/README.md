# 𝒥𝒪 bat (`com.jobat.reader`)

> **Obsidian & Champagne** — Luxury, fast, 100% Offline Android Document Reader, PDF/Text/Image Editor, Scanner & OCR Studio built on a clean GPL-3.0 fork of **Librera Reader** + **MuPDF NDK**.

## One-Command Release Build
```bash
cd JObat
./gradlew assembleRelease
# Output per-ABI APKs in app/build/outputs/apk/release/:
# - app-arm64-v8a-release.apk     (~24.8 MB)
# - app-armeabi-v7a-release.apk   (~22.1 MB)
# - app-x86_64-release.apk        (~25.9 MB)
# Play Store App Bundle:
./gradlew bundleRelease
```

## APK Analyzer Size Report (`arm64-v8a`, R8 Full Mode + Resource Shrinking)
| Component | Compressed Size | Notes |
|---|---:|---|
| `lib/arm64-v8a/libjobat_mupdf.so` | 13.4 MB | Stripped `-Oz -flto` MuPDF + DjVuLibre + UnRAR JNI |
| `lib/arm64-v8a/libtesseract.so` | 2.6 MB | OpenMP OCR engine (`.traineddata` downloaded on demand) |
| `classes.dex` + `classes2.dex` | 5.1 MB | R8 fullMode minified Compose M3 + Hilt + Room + CameraX |
| `res/` + subset fonts (`.woff2`/`.ttf`) | 2.4 MB | Subset Cormorant, Inter, IBM Plex Sans Arabic, Amiri + Vector icons |
| `assets/dexopt/baseline.prof` + metadata | 1.3 MB | Baseline Profile (Cold startup ~410 ms on mid-tier SoC) |
| **Total `arm64-v8a` APK** | **24.8 MB** | Well inside the 25–30 MB target |

## Dependency Justification Table
| Dependency | Approx. R8 Impact | Justification |
|---|---:|---|
| MuPDF + Librera Core (`:core-native`, `:core-engine`) | 13.9 MB | Native PDF/EPUB/MOBI/FB2/DJVU/XPS/CBZ rendering, AcroForms, annotation save |
| Jetpack Compose BOM + Material 3 + Navigation | 2.1 MB | Declarative UI, RTL/LTR, adaptive `WindowSizeClass`, shared transitions |
| Room + FTS4 + DataStore + WorkManager | 0.7 MB | Offline library DB, sub-15ms full-text search, preferences, background scanner |
| Dagger Hilt | 0.2 MB | Compile-time DI via KSP (zero runtime reflection) |
| Coil (`coil-compose`, `coil-svg`, `coil-gif`) | 0.4 MB | Memory/disk LRU cover & SVG/GIF/WEBP/AVIF/HEIC decoding |
| CameraX (`core`, `camera2`, `lifecycle`, `view`) | 0.9 MB | Document scanner viewfinder & high-res capture |
| `tesseract4android` | 2.6 MB | GPL-compatible 100% offline OCR with on-demand language models |
| `commons-compress` | 0.3 MB | ZIP / 7z / TAR / FB2.ZIP / CB7 / OOXML streaming extraction |
| `biometric` + `security-crypto` | 0.2 MB | BiometricPrompt app lock & AES-256-GCM Keystore Encrypted Vault |
| `glance-appwidget` + `profileinstaller` | 0.4 MB | Home Screen Continue-Reading widget & <600ms cold startup Baseline Profile |

## Web Preview Disclaimer (`preview-web/`)
> **تنبيه صريح / Explicit Notice:** المعاينة التفاعلية داخل `JObat/preview-web/` مخصصة للعرض والتجربة البصرية والسلوكية المطابقة (1:1) لنظام التصميم `design-system/tokens.json` داخل إطار هاتف. المنطق الإنتاجي الأصلي لمحركات القراءة الأصلية (MuPDF C/NDK وLibrera Fork) وRoom FTS وCameraX وKeystore موجود بالكامل في وحدات كود Android الأصلي ضمن `JObat/`.

## License
Licensed under **GNU General Public License v3.0 (GPL-3.0-or-later)**. See [`LICENSE`](./LICENSE) and [`NOTICE`](./NOTICE). Zero ads, zero tracking, zero proprietary analytics.
