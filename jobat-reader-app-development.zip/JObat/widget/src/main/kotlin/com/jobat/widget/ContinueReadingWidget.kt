package com.jobat.widget

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Column
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider

class ContinueReadingWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val prefs = context.getSharedPreferences("jobat_widget", Context.MODE_PRIVATE)
        val title = prefs.getString("last_title", "𝒥𝒪 bat — Continue Reading") ?: "𝒥𝒪 bat"
        val progress = prefs.getInt("last_progress", 0)

        provideContent {
            Column(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .background(Color(0xFF0B0C10))
                    .padding(16.dp),
            ) {
                Text(
                    text = "𝒥𝒪 bat",
                    style = TextStyle(color = ColorProvider(Color(0xFFD4B26A)), fontSize = 16.sp, fontWeight = FontWeight.Bold),
                )
                Spacer(GlanceModifier.height(8.dp))
                Text(
                    text = title,
                    style = TextStyle(color = ColorProvider(Color(0xFFF4F0E8)), fontSize = 14.sp, fontWeight = FontWeight.Medium),
                )
                Spacer(GlanceModifier.height(4.dp))
                Text(
                    text = "$progress% completed",
                    style = TextStyle(color = ColorProvider(Color(0xFF9FA4B0)), fontSize = 12.sp),
                )
            }
        }
    }
}

class ContinueReadingWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ContinueReadingWidget()
}
