# Changelog — 𝒥𝒪 bat

## [1.0.0] — 2026-01-01
### Added
- Clean multi-module Android architecture (`:core-native`, `:core-engine`, `:design-system`, `:domain`, `:data`, `:feature-*`, `:widget`, `:baselineprofile`, `:app`).
- **Obsidian & Champagne** Design System generated from unified `design-system/tokens.json` with Dark, Light, AMOLED, Sepia, and Dynamic Material You themes.
- Full-format Librera + MuPDF NDK engine: PDF, EPUB 2/3, MOBI, AZW/AZW3, FB2/FB2.ZIP, DJVU, XPS, CBZ/CBR/CB7, RTF, TXT, DOC/DOCX, ODT, XLS/XLSX, PPT/PPTX, MD, CSV, HTML/XHTML/MHT/XML, JPG/PNG/WEBP/GIF/BMP/HEIC/AVIF/SVG/TIFF, ZIP/RAR/7z.
- Library with WorkManager folder indexer, Room FTS4 instant search, collections, tags, favorites, archive, trash, cover cache, and Continue Reading widget.
- Studio PDF editor (annotations, ink, shapes, notes, stamps, saved signatures, AcroForms, unlimited Undo/Redo, page manager, merge/split/compress/protect/watermark).
- Syntax-highlighted Text/Code editor with Regex find/replace & live Markdown/HTML/CSV preview.
- Hardware-accelerated Image Editor, CameraX perspective scanner, and on-demand Tesseract Offline OCR.
- BiometricPrompt App Lock & AES-256-GCM Encrypted Vault, Reading Analytics, Quotes Exporter, Glance Widgets, Quick Settings Tile, and encrypted Backup/Restore.
- 1:1 Interactive Web Preview (`preview-web/`) synchronized to `design-system/tokens.json`.

### Removed
- Stripped 100% of upstream ads, Firebase, Crashlytics, telemetry, and third-party branding.
