package com.jobat.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.room.*
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import androidx.work.*
import com.jobat.core.engine.SupportedFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

@Entity(tableName = "documents", indices = [Index("extension"), Index("lastReadEpochMs")])
data class DocumentEntity(
    @PrimaryKey val id: String,
    val uri: String,
    val title: String,
    val author: String,
    val extension: String,
    val sizeBytes: Long,
    val pageCount: Int,
    val currentPage: Int,
    val lastReadEpochMs: Long,
    val addedEpochMs: Long,
    val coverCachePath: String?,
    val indexedExcerpt: String,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val isTrashed: Boolean = false,
    val isVaultLocked: Boolean = false,
    val isPasswordProtected: Boolean = false,
    val collectionsCsv: String = "",
    val tagsCsv: String = "",
)

@Fts4(contentEntity = DocumentEntity::class)
@Entity(tableName = "documents_fts")
data class DocumentFtsEntity(
    val title: String,
    val author: String,
    val indexedExcerpt: String,
    val tagsCsv: String,
)

@Entity(tableName = "excerpts")
data class ExcerptEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val documentTitle: String,
    val pageNumber: Int,
    val text: String,
    val note: String?,
    val colorHex: String,
    val createdAtEpochMs: Long,
)

@Entity(tableName = "reading_stats")
data class ReadingStatEntity(
    @PrimaryKey val epochDay: Long,
    val minutesRead: Int,
    val pagesRead: Int,
)

@Dao
interface JobatDao {
    @Query("SELECT * FROM documents WHERE isTrashed = 0 AND isArchived = 0 AND isVaultLocked = 0 ORDER BY lastReadEpochMs DESC")
    fun observeActiveDocuments(): Flow<List<DocumentEntity>>

    @Query("""
        SELECT d.* FROM documents d
        JOIN documents_fts fts ON d.rowid = fts.rowid
        WHERE documents_fts MATCH :ftsQuery AND d.isTrashed = 0 AND d.isVaultLocked = 0
    """)
    fun searchFullText(ftsQuery: String): Flow<List<DocumentEntity>>

    @Upsert
    suspend fun upsertDocuments(items: List<DocumentEntity>)

    @Query("UPDATE documents SET currentPage = :page, lastReadEpochMs = :now WHERE id = :id")
    suspend fun updateProgress(id: String, page: Int, now: Long)

    @Query("UPDATE documents SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: String, fav: Boolean)

    @Query("UPDATE documents SET isTrashed = :trashed WHERE id = :id")
    suspend fun setTrashed(id: String, trashed: Boolean)

    @Query("UPDATE documents SET isVaultLocked = :locked WHERE id = :id")
    suspend fun setVaultLocked(id: String, locked: Boolean)

    @Query("SELECT * FROM excerpts ORDER BY createdAtEpochMs DESC")
    fun observeExcerpts(): Flow<List<ExcerptEntity>>

    @Upsert
    suspend fun upsertExcerpt(item: ExcerptEntity)

    @Query("SELECT * FROM reading_stats ORDER BY epochDay DESC LIMIT 30")
    fun observeStats(): Flow<List<ReadingStatEntity>>

    @Upsert
    suspend fun upsertStat(stat: ReadingStatEntity)

    @Query("SELECT * FROM documents")
    suspend fun snapshotDocuments(): List<DocumentEntity>

    @Query("SELECT * FROM excerpts")
    suspend fun snapshotExcerpts(): List<ExcerptEntity>
}

@Database(
    entities = [DocumentEntity::class, DocumentFtsEntity::class, ExcerptEntity::class, ReadingStatEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class JobatDatabase : RoomDatabase() {
    abstract fun dao(): JobatDao
}

class EncryptedVaultManager(private val context: Context) {
    private val vaultDir = File(context.filesDir, "secure_vault").apply { mkdirs() }

    private fun masterKey(): MasterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .setUserAuthenticationRequired(false)
        .build()

    suspend fun sealIntoVault(id: String, plainBytes: ByteArray): File = withContext(Dispatchers.IO) {
        val target = File(vaultDir, "$id.jvault")
        if (target.exists()) target.delete()
        val encrypted = EncryptedFile.Builder(
            context, target, masterKey(), EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
        encrypted.openFileOutput().use { it.write(plainBytes) }
        target
    }

    suspend fun unsealFromVault(id: String): ByteArray = withContext(Dispatchers.IO) {
        val target = File(vaultDir, "$id.jvault")
        val encrypted = EncryptedFile.Builder(
            context, target, masterKey(), EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
        encrypted.openFileInput().use { it.readBytes() }
    }

    fun purgeTempCache() {
        File(context.cacheDir, "vault_session").deleteRecursively()
    }
}

@Serializable
data class JobatBackupPayload(
    val schemaVersion: Int = 1,
    val exportedAtEpochMs: Long,
    val theme: String,
    val language: String,
    val progressByUri: Map<String, Int>,
    val favorites: List<String>,
    val excerptsCount: Int,
)

object BackupRestoreManager {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    fun encode(payload: JobatBackupPayload): String = json.encodeToString(payload)
    fun decode(raw: String): JobatBackupPayload = json.decodeFromString(raw)
}

class LibraryScanWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val treeUriStr = inputData.getString("tree_uri") ?: return@withContext Result.success()
        val root = DocumentFile.fromTreeUri(applicationContext, Uri.parse(treeUriStr))
            ?: return@withContext Result.retry()
        val db = Room.databaseBuilder(applicationContext, JobatDatabase::class.java, "jobat.db").build()
        val discovered = mutableListOf<DocumentEntity>()
        root.listFiles().forEach { file ->
            val name = file.name ?: return@forEach
            val fmt = SupportedFormat.fromFileName(name) ?: return@forEach
            discovered += DocumentEntity(
                id = UUID.nameUUIDFromBytes(file.uri.toString().toByteArray()).toString(),
                uri = file.uri.toString(),
                title = name.substringBeforeLast('.'),
                author = "",
                extension = fmt.ext,
                sizeBytes = file.length(),
                pageCount = 1,
                currentPage = 0,
                lastReadEpochMs = 0L,
                addedEpochMs = System.currentTimeMillis(),
                coverCachePath = null,
                indexedExcerpt = name,
            )
        }
        if (discovered.isNotEmpty()) db.dao().upsertDocuments(discovered)
        db.close()
        Result.success()
    }

    companion object {
        fun schedulePeriodic(context: Context, treeUri: String) {
            val req = PeriodicWorkRequestBuilder<LibraryScanWorker>(6, TimeUnit.HOURS)
                .setInputData(workDataOf("tree_uri" to treeUri))
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "jobat_library_scan", ExistingPeriodicWorkPolicy.UPDATE, req
            )
        }
    }
}
