# سياسة الخصوصية — 𝒥𝒪 bat (`com.jobat.reader`)

**آخر تحديث:** 2026-01-01

1. **العمل الكامل دون اتصال (100% Offline):** يعمل تطبيق **𝒥𝒪 bat** محليًا بالكامل على جهازك. لا يجمع التطبيق أو يخزن أو يرسل أي مستندات أو صور أو ملاحظات أو بيانات شخصية إلى أي خادم خارجي.
2. **صفر إعلانات وصفر تتبع:** لا يحتوي التطبيق على Firebase أو Crashlytics أو AdMob أو أي حزم تحليلات أو تتبع.
3. **الأذونات بالحد الأدنى:**
   - **الوصول للملفات (Storage Access Framework):** يقتصر على الملفات والمجلدات التي تمنحها أنت صراحةً.
   - **الكاميرا (`CAMERA`):** تُستخدم حصريًا عند فتح ماسح المستندات محليًا.
   - **البصمة/الوجه (`USE_BIOMETRIC`):** تُستخدم عبر نظام Android BiometricPrompt لفتح الخزنة المشفرة (Android Keystore AES-256-GCM) ولا يطّلع التطبيق على بياناتك الحيوية.
   - **الشبكة الاختيارية:** تُستخدم فقط عند طلبك الصريح لتنزيل ملف لغة OCR (`.traineddata`) عبر HTTPS (Cleartext ممنوع).
4. **أمان الملفات المؤقتة:** تُمسح الملفات المؤقتة وذاكرة المعاينة تلقائيًا عند إغلاق الجلسة أو قفل الخزنة.

---

# Privacy Policy — 𝒥𝒪 bat (`com.jobat.reader`)

1. **100% Offline by Design:** All reading, indexing, PDF/text/image editing, document scanning, and OCR occur exclusively on-device.
2. **Zero Ads, Zero Telemetry:** All analytics, crash reporters, and ad libraries are permanently absent.
3. **Minimal Scoped Permissions:** Uses Android Storage Access Framework (no broad `MANAGE_EXTERNAL_STORAGE`), optional `CAMERA` for scanning, and system `BiometricPrompt` + Android Keystore `EncryptedFile` for the Vault.
4. **Optional On-Demand Downloads:** Network is invoked solely on explicit user action to download Tesseract `.traineddata` OCR models over TLS 1.3 (`usesCleartextTraffic="false"`).
