package com.jobat.feature.editor.pdf

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.jobat.domain.UndoRedoStack

enum class PdfTool { HIGHLIGHT, UNDERLINE, STRIKE, PEN, ERASER, RECT, CIRCLE, ARROW, TEXT, NOTE, STAMP, SIGNATURE }

data class PdfStroke(
    val tool: PdfTool,
    val color: Color,
    val widthPx: Float,
    val points: List<Offset>,
    val label: String? = null,
)

@Composable
fun PdfEditorScreen(
    documentTitle: String,
    onSave: (strokes: List<PdfStroke>, saveAsCopy: Boolean) -> Unit,
    onBack: () -> Unit,
) {
    val stack = remember { UndoRedoStack<List<PdfStroke>>(emptyList()) }
    var strokes by remember { mutableStateOf(stack.current) }
    var activeTool by remember { mutableStateOf(PdfTool.HIGHLIGHT) }
    var activeColor by remember { mutableStateOf(Color(0xFFD4B26A)) }
    var activePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("←") }
            Text(documentTitle, style = MaterialTheme.typography.titleMedium)
            Row {
                TextButton(enabled = stack.canUndo, onClick = { strokes = stack.undo() }) { Text("Undo") }
                TextButton(enabled = stack.canRedo, onClick = { strokes = stack.redo() }) { Text("Redo") }
                Button(onClick = { onSave(strokes, false) }) { Text("Save") }
            }
        }

        Canvas(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color(0xFFFAF9F5))
                .pointerInput(activeTool, activeColor) {
                    detectDragGestures(
                        onDragStart = { start -> activePoints = listOf(start) },
                        onDrag = { change, _ -> activePoints = activePoints + change.position },
                        onDragEnd = {
                            if (activeTool == PdfTool.ERASER) {
                                val next = strokes.dropLast(1)
                                stack.push(next)
                                strokes = next
                            } else if (activePoints.size > 1) {
                                val stroke = PdfStroke(
                                    tool = activeTool,
                                    color = if (activeTool == PdfTool.HIGHLIGHT) activeColor.copy(alpha = 0.36f) else activeColor,
                                    widthPx = if (activeTool == PdfTool.HIGHLIGHT) 26f else 5f,
                                    points = activePoints,
                                )
                                val next = strokes + stroke
                                stack.push(next)
                                strokes = next
                            }
                            activePoints = emptyList()
                        },
                    )
                },
        ) {
            (strokes + listOfNotNull(
                activePoints.takeIf { it.size > 1 }?.let { PdfStroke(activeTool, activeColor, 5f, it) }
            )).forEach { s ->
                val path = Path().apply {
                    moveTo(s.points.first().x, s.points.first().y)
                    s.points.drop(1).forEach { lineTo(it.x, it.y) }
                }
                drawPath(path, s.color, style = Stroke(width = s.widthPx, cap = StrokeCap.Round))
            }
        }

        LazyRow(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(PdfTool.entries) { tool ->
                FilterChip(
                    selected = activeTool == tool,
                    onClick = { activeTool = tool },
                    label = { Text(tool.name) },
                )
            }
        }
    }
}
