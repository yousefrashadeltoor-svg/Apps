package com.jobat.feature.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import com.jobat.domain.DailyReadingStat

@Composable
fun StatsScreen(
    dailyGoalMinutes: Int,
    streakDays: Int,
    weeklyStats: List<DailyReadingStat>,
) {
    val todayMinutes = weeklyStats.firstOrNull()?.minutesRead ?: 0
    val barColor = MaterialTheme.colorScheme.primary

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp)) {
        Text("Reading Analytics", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            CircularProgressIndicator(
                progress = { (todayMinutes.toFloat() / dailyGoalMinutes.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.size(78.dp),
                strokeWidth = 6.dp,
            )
            Column {
                Text("$todayMinutes / $dailyGoalMinutes min today", style = MaterialTheme.typography.titleMedium)
                Text("$streakDays-day streak", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(24.dp))
        Canvas(Modifier.fillMaxWidth().height(160.dp)) {
            val maxMin = (weeklyStats.maxOfOrNull { it.minutesRead } ?: 60).coerceAtLeast(1)
            val count = weeklyStats.size.coerceAtLeast(1)
            val slot = size.width / count
            weeklyStats.forEachIndexed { idx, stat ->
                val h = (stat.minutesRead.toFloat() / maxMin) * size.height
                drawRoundRect(
                    color = barColor,
                    topLeft = Offset(idx * slot + slot * 0.2f, size.height - h),
                    size = Size(slot * 0.6f, h),
                    cornerRadius = CornerRadius(12f, 12f),
                )
            }
        }
    }
}
