package com.jobat.feature.editor.image

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

@Composable
fun ImageEditorScreen(
    source: Bitmap,
    onExport: (rotation: Float, flipX: Boolean, brightness: Float, contrast: Float, saturation: Float, quality: Int) -> Unit,
    onBack: () -> Unit,
) {
    var rotation by remember { mutableFloatStateOf(0f) }
    var flipX by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var quality by remember { mutableIntStateOf(92) }

    val matrix = remember(brightness, contrast, saturation) {
        val sat = ColorMatrix().apply { setToSaturation(saturation) }
        val bc = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, brightness * 255f,
                0f, contrast, 0f, 0f, brightness * 255f,
                0f, 0f, contrast, 0f, brightness * 255f,
                0f, 0f, 0f, 1f, 0f,
            )
        )
        sat.timesAssign(bc)
        sat
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onBack) { Text("←") }
            Row {
                TextButton(onClick = { rotation = (rotation + 90f) % 360f }) { Text("↻ 90°") }
                TextButton(onClick = { flipX = !flipX }) { Text("⇄") }
                Button(onClick = { onExport(rotation, flipX, brightness, contrast, saturation, quality) }) {
                    Text("Export $quality%")
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Image(
                bitmap = source.asImageBitmap(),
                contentDescription = null,
                colorFilter = ColorFilter.colorMatrix(matrix),
                modifier = Modifier.graphicsLayer(rotationZ = rotation, scaleX = if (flipX) -1f else 1f),
            )
        }
        Text("Brightness"); Slider(brightness, { brightness = it }, valueRange = -0.4f..0.4f)
        Text("Contrast"); Slider(contrast, { contrast = it }, valueRange = 0.5f..1.8f)
        Text("Saturation"); Slider(saturation, { saturation = it }, valueRange = 0f..2f)
        Text("Export Quality ($quality%)"); Slider(quality.toFloat(), { quality = it.toInt() }, valueRange = 20f..100f)
    }
}
