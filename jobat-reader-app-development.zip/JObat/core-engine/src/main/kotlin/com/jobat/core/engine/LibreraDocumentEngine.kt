package com.jobat.core.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jobat.core.nativebridge.NativeDocumentBridge
import com.jobat.core.nativebridge.NativeOpenResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.util.Locale
import java.util.zip.ZipFile

enum class FormatFamily { DOCUMENT, EBOOK, COMIC, OFFICE, WEB_CODE, IMAGE, ARCHIVE }

enum class SupportedFormat(val ext: String, val family: FormatFamily, val mime: String) {
    PDF("pdf", FormatFamily.DOCUMENT, "application/pdf"),
    XPS("xps", FormatFamily.DOCUMENT, "application/vnd.ms-xpsdocument"),
    DJVU("djvu", FormatFamily.DOCUMENT, "image/vnd.djvu"),
    EPUB("epub", FormatFamily.EBOOK, "application/epub+zip"),
    MOBI("mobi", FormatFamily.EBOOK, "application/x-mobipocket-ebook"),
    AZW("azw", FormatFamily.EBOOK, "application/vnd.amazon.ebook"),
    AZW3("azw3", FormatFamily.EBOOK, "application/vnd.amazon.mobi8-ebook"),
    FB2("fb2", FormatFamily.EBOOK, "application/x-fictionbook+xml"),
    FB2_ZIP("fb2.zip", FormatFamily.EBOOK, "application/x-zip-compressed-fb2"),
    RTF("rtf", FormatFamily.DOCUMENT, "application/rtf"),
    CBZ("cbz", FormatFamily.COMIC, "application/vnd.comicbook+zip"),
    CBR("cbr", FormatFamily.COMIC, "application/vnd.comicbook-rar"),
    CB7("cb7", FormatFamily.COMIC, "application/x-cb7"),
    DOC("doc", FormatFamily.OFFICE, "application/msword"),
    DOCX("docx", FormatFamily.OFFICE, "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    ODT("odt", FormatFamily.OFFICE, "application/vnd.oasis.opendocument.text"),
    XLS("xls", FormatFamily.OFFICE, "application/vnd.ms-excel"),
    XLSX("xlsx", FormatFamily.OFFICE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    PPT("ppt", FormatFamily.OFFICE, "application/vnd.ms-powerpoint"),
    PPTX("pptx", FormatFamily.OFFICE, "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    TXT("txt", FormatFamily.WEB_CODE, "text/plain"),
    MD("md", FormatFamily.WEB_CODE, "text/markdown"),
    CSV("csv", FormatFamily.WEB_CODE, "text/csv"),
    HTML("html", FormatFamily.WEB_CODE, "text/html"),
    XHTML("xhtml", FormatFamily.WEB_CODE, "application/xhtml+xml"),
    MHT("mht", FormatFamily.WEB_CODE, "multipart/related"),
    XML("xml", FormatFamily.WEB_CODE, "application/xml"),
    JPG("jpg", FormatFamily.IMAGE, "image/jpeg"),
    JPEG("jpeg", FormatFamily.IMAGE, "image/jpeg"),
    PNG("png", FormatFamily.IMAGE, "image/png"),
    WEBP("webp", FormatFamily.IMAGE, "image/webp"),
    GIF("gif", FormatFamily.IMAGE, "image/gif"),
    BMP("bmp", FormatFamily.IMAGE, "image/bmp"),
    HEIC("heic", FormatFamily.IMAGE, "image/heic"),
    HEIF("heif", FormatFamily.IMAGE, "image/heif"),
    AVIF("avif", FormatFamily.IMAGE, "image/avif"),
    SVG("svg", FormatFamily.IMAGE, "image/svg+xml"),
    TIFF("tiff", FormatFamily.IMAGE, "image/tiff"),
    ZIP("zip", FormatFamily.ARCHIVE, "application/zip"),
    RAR("rar", FormatFamily.ARCHIVE, "application/vnd.rar"),
    SEVEN_Z("7z", FormatFamily.ARCHIVE, "application/x-7z-compressed");

    companion object {
        fun fromFileName(name: String): SupportedFormat? {
            val lower = name.lowercase(Locale.ROOT)
            if (lower.endsWith(".fb2.zip")) return FB2_ZIP
            val ext = lower.substringAfterLast('.', "")
            return entries.firstOrNull { it.ext == ext }
        }
    }
}

data class ArchiveEntryItem(val path: String, val sizeBytes: Long, val isDirectory: Boolean, val format: SupportedFormat?)

class LibreraDocumentEngine(private val nativeBridge: NativeDocumentBridge) {

    suspend fun open(file: File, emFontSize: Float = 15f): NativeOpenResult = withContext(Dispatchers.IO) {
        val format = SupportedFormat.fromFileName(file.name)
            ?: return@withContext NativeOpenResult.CorruptedOrUnsupported("Unsupported extension: ${file.extension}")
        if (!file.exists() || file.length() == 0L) {
            return@withContext NativeOpenResult.CorruptedOrUnsupported("Empty or unreadable file")
        }
        when (format.family) {
            FormatFamily.OFFICE -> {
                val htmlCache = convertOfficeToPaginatedHtml(file, format)
                nativeBridge.openDocument(htmlCache.absolutePath, emFontSize)
            }
            else -> nativeBridge.openDocument(file.absolutePath, emFontSize)
        }
    }

    suspend fun listArchiveEntries(file: File): List<ArchiveEntryItem> = withContext(Dispatchers.IO) {
        when (SupportedFormat.fromFileName(file.name)) {
            SupportedFormat.ZIP, SupportedFormat.CBZ, SupportedFormat.FB2_ZIP -> {
                ZipFile(file).use { zip ->
                    zip.entries().asSequence().map { e ->
                        ArchiveEntryItem(e.name, e.size.coerceAtLeast(0L), e.isDirectory, SupportedFormat.fromFileName(e.name))
                    }.toList()
                }
            }
            SupportedFormat.SEVEN_Z, SupportedFormat.CB7 -> {
                SevenZFile.builder().setFile(file).get().use { sz ->
                    sz.entries.map { e ->
                        ArchiveEntryItem(e.name, e.size.coerceAtLeast(0L), e.isDirectory, SupportedFormat.fromFileName(e.name))
                    }
                }
            }
            else -> emptyList()
        }
    }

    private fun convertOfficeToPaginatedHtml(source: File, format: SupportedFormat): File {
        val outFile = File(source.parentFile, ".jobat_${source.nameWithoutExtension}.xhtml")
        val extracted = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><html xmlns=\"http://www.w3.org/1999/xhtml\"><body>")
            if (format == SupportedFormat.DOCX || format == SupportedFormat.ODT || format == SupportedFormat.XLSX || format == SupportedFormat.PPTX) {
                ZipFile(source).use { zip ->
                    val targetEntry = when (format) {
                        SupportedFormat.DOCX -> zip.getEntry("word/document.xml")
                        SupportedFormat.ODT -> zip.getEntry("content.xml")
                        SupportedFormat.XLSX -> zip.getEntry("xl/sharedStrings.xml")
                        else -> zip.getEntry("ppt/slides/slide1.xml")
                    }
                    val xml = targetEntry?.let { zip.getInputStream(it).bufferedReader().readText() }.orEmpty()
                    val plain = xml.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()
                    plain.chunked(480).forEach { chunk -> append("<p>").append(chunk).append("</p>") }
                }
            } else {
                append("<p>").append(source.readText(Charsets.UTF_8).take(250_000)).append("</p>")
            }
            append("</body></html>")
        }
        outFile.writeText(extracted, Charsets.UTF_8)
        return outFile
    }
}

data class TtsState(
    val isPlaying: Boolean = false,
    val currentSentenceIndex: Int = 0,
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.0f,
    val sleepRemainingMinutes: Int? = null,
)

class TtsReadAloudController(context: Context, private val scope: CoroutineScope) {
    private val _state = MutableStateFlow(TtsState())
    val state: StateFlow<TtsState> = _state.asStateFlow()
    private var sentences: List<String> = emptyList()
    private var sleepJob: Job? = null

    private val tts = TextToSpeech(context.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) attachProgressListener()
    }

    private fun attachProgressListener() {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onError(utteranceId: String?) { _state.value = _state.value.copy(isPlaying = false) }
            override fun onDone(utteranceId: String?) {
                val next = _state.value.currentSentenceIndex + 1
                if (next < sentences.size && _state.value.isPlaying) speakSentence(next)
                else _state.value = _state.value.copy(isPlaying = false)
            }
        })
    }

    fun start(pageSentences: List<String>, locale: Locale, startIndex: Int = 0) {
        sentences = pageSentences
        tts.language = locale
        _state.value = _state.value.copy(isPlaying = true, currentSentenceIndex = startIndex)
        speakSentence(startIndex)
    }

    private fun speakSentence(index: Int) {
        if (index !in sentences.indices) return
        _state.value = _state.value.copy(currentSentenceIndex = index)
        tts.setSpeechRate(_state.value.speechRate)
        tts.setPitch(_state.value.pitch)
        tts.speak(sentences[index], TextToSpeech.QUEUE_FLUSH, null, "jobat_utt_$index")
    }

    fun setRateAndPitch(rate: Float, pitch: Float) {
        _state.value = _state.value.copy(speechRate = rate.coerceIn(0.5f, 2.2f), pitch = pitch.coerceIn(0.6f, 1.6f))
        if (_state.value.isPlaying) speakSentence(_state.value.currentSentenceIndex)
    }

    fun scheduleSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        _state.value = _state.value.copy(sleepRemainingMinutes = minutes)
        if (minutes != null && minutes > 0) {
            sleepJob = scope.launch {
                repeat(minutes) { left ->
                    _state.value = _state.value.copy(sleepRemainingMinutes = minutes - left)
                    delay(60_000L)
                }
                stop()
            }
        }
    }

    fun stop() {
        tts.stop()
        sleepJob?.cancel()
        _state.value = _state.value.copy(isPlaying = false, sleepRemainingMinutes = null)
    }

    fun release() {
        stop()
        tts.shutdown()
    }
}
