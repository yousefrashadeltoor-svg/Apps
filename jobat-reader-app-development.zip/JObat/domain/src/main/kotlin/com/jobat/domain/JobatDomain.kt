package com.jobat.domain

import kotlinx.coroutines.flow.Flow

enum class SortField { TITLE, DATE_ADDED, FILE_SIZE, LAST_READ, PROGRESS }
enum class LibraryViewMode { GRID, LIST, COMPACT }
enum class ReaderMode { VERTICAL_SCROLL, HORIZONTAL_PAGED, TWO_PAGE, CONTINUOUS, PAGE_CURL }
enum class ReaderTheme { PAPER, SEPIA, IVORY, GRAPHITE, MIDNIGHT, AMOLED, CUSTOM }

data class LibraryDocument(
    val id: String,
    val uri: String,
    val title: String,
    val author: String,
    val extension: String,
    val sizeBytes: Long,
    val pageCount: Int,
    val currentPage: Int,
    val lastReadEpochMs: Long,
    val addedEpochMs: Long,
    val coverCachePath: String?,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val isTrashed: Boolean = false,
    val isVaultLocked: Boolean = false,
    val isPasswordProtected: Boolean = false,
    val collections: List<String> = emptyList(),
    val tags: List<String> = emptyList(),
) {
    val progressFraction: Float
        get() = if (pageCount <= 0) 0f else (currentPage.toFloat() / pageCount.toFloat()).coerceIn(0f, 1f)

    val estimatedRemainingMinutes: Int
        get() = ((pageCount - currentPage).coerceAtLeast(0) * 1.4f).toInt()
}

data class ExcerptQuote(
    val id: String,
    val documentId: String,
    val documentTitle: String,
    val pageNumber: Int,
    val text: String,
    val note: String?,
    val colorHex: String,
    val createdAtEpochMs: Long,
)

data class DailyReadingStat(
    val epochDay: Long,
    val minutesRead: Int,
    val pagesRead: Int,
)

class UndoRedoStack<T>(initial: T) {
    private val history = ArrayDeque<T>().apply { addLast(initial) }
    private val redoBuffer = ArrayDeque<T>()

    val current: T get() = history.last()
    val canUndo: Boolean get() = history.size > 1
    val canRedo: Boolean get() = redoBuffer.isNotEmpty()

    fun push(state: T) {
        history.addLast(state)
        redoBuffer.clear()
    }

    fun undo(): T {
        if (canUndo) redoBuffer.addLast(history.removeLast())
        return current
    }

    fun redo(): T {
        if (canRedo) history.addLast(redoBuffer.removeLast())
        return current
    }
}

interface LibraryRepository {
    fun observeLibrary(sort: SortField, extensionFilter: String?): Flow<List<LibraryDocument>>
    fun searchFullText(query: String): Flow<List<LibraryDocument>>
    fun observeExcerpts(): Flow<List<ExcerptQuote>>
    fun observeReadingStats(): Flow<List<DailyReadingStat>>
    suspend fun updateProgress(documentId: String, page: Int, deltaMinutes: Int)
    suspend fun toggleFavorite(documentId: String, favorite: Boolean)
    suspend fun moveToTrash(documentId: String, trashed: Boolean)
    suspend fun moveToVault(documentId: String, locked: Boolean)
    suspend fun saveExcerpt(excerpt: ExcerptQuote)
}
