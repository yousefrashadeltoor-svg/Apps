package com.jobat.designsystem.theme

import android.os.Build
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class JobatAppTheme { DARK, LIGHT, AMOLED, SEPIA, DYNAMIC }

object JobatTokens {
    // Generated 1:1 from design-system/tokens.json
    val Obsidian = Color(0xFF0B0C10)
    val Graphite = Color(0xFF15171C)
    val GraphiteElevated = Color(0xFF1E2128)
    val ChampagneStart = Color(0xFFD4B26A)
    val ChampagneEnd = Color(0xFFB8914A)
    val Ivory = Color(0xFFF6F1E7)
    val IvorySurface = Color(0xFFFFFDF8)
    val SepiaBg = Color(0xFFEFE4CE)
    val SepiaSurface = Color(0xFFF7EEDC)

    val ChampagneGradient = Brush.linearGradient(listOf(ChampagneStart, ChampagneEnd))

    val RadiusSm: Dp = 8.dp
    val RadiusMd: Dp = 12.dp
    val RadiusLg: Dp = 16.dp
    val RadiusXl: Dp = 24.dp

    val SpaceXxs: Dp = 4.dp
    val SpaceXs: Dp = 8.dp
    val SpaceSm: Dp = 12.dp
    val SpaceMd: Dp = 16.dp
    val SpaceLg: Dp = 20.dp
    val SpaceXl: Dp = 24.dp

    val EmphasizedEasing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    val EmphasizedDecel = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1.0f)
}

private val ObsidianDarkScheme = darkColorScheme(
    primary = JobatTokens.ChampagneStart,
    onPrimary = JobatTokens.Obsidian,
    secondary = JobatTokens.ChampagneEnd,
    background = JobatTokens.Obsidian,
    onBackground = Color(0xFFF4F0E8),
    surface = JobatTokens.Graphite,
    onSurface = Color(0xFFF4F0E8),
    surfaceVariant = JobatTokens.GraphiteElevated,
    onSurfaceVariant = Color(0xFF9FA4B0),
    outline = Color(0x14FFFFFF),
    error = Color(0xFFD96B6B),
)

private val IvoryLightScheme = lightColorScheme(
    primary = Color(0xFF9E7631),
    onPrimary = JobatTokens.IvorySurface,
    secondary = Color(0xFF7E5B1E),
    background = JobatTokens.Ivory,
    onBackground = Color(0xFF171614),
    surface = JobatTokens.IvorySurface,
    onSurface = Color(0xFF171614),
    surfaceVariant = Color(0xFFEDE6D8),
    onSurfaceVariant = Color(0xFF5C564B),
    outline = Color(0x17181510),
    error = Color(0xFFB84242),
)

private val AmoledScheme = ObsidianDarkScheme.copy(
    background = Color.Black,
    surface = Color(0xFF0A0B0E),
    surfaceVariant = Color(0xFF14161B),
)

private val SepiaScheme = IvoryLightScheme.copy(
    primary = Color(0xFF8F6224),
    background = JobatTokens.SepiaBg,
    onBackground = Color(0xFF2E2316),
    surface = JobatTokens.SepiaSurface,
    onSurface = Color(0xFF2E2316),
    surfaceVariant = Color(0xFFE5D6BA),
    onSurfaceVariant = Color(0xFF6A563E),
)

val JobatTypography = Typography(
    displaySmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 30.sp, lineHeight = 36.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
)

val JobatShapes = Shapes(
    small = RoundedCornerShape(JobatTokens.RadiusSm),
    medium = RoundedCornerShape(JobatTokens.RadiusMd),
    large = RoundedCornerShape(JobatTokens.RadiusLg),
    extraLarge = RoundedCornerShape(JobatTokens.RadiusXl),
)

val LocalReduceMotion = staticCompositionLocalOf { false }

@Composable
fun JobatTheme(
    appTheme: JobatAppTheme = JobatAppTheme.DARK,
    reduceMotion: Boolean = false,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val scheme = when (appTheme) {
        JobatAppTheme.DARK -> ObsidianDarkScheme
        JobatAppTheme.LIGHT -> IvoryLightScheme
        JobatAppTheme.AMOLED -> AmoledScheme
        JobatAppTheme.SEPIA -> SepiaScheme
        JobatAppTheme.DYNAMIC -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            dynamicDarkColorScheme(context)
        } else ObsidianDarkScheme
    }
    CompositionLocalProvider(LocalReduceMotion provides reduceMotion) {
        MaterialTheme(
            colorScheme = scheme,
            typography = JobatTypography,
            shapes = JobatShapes,
            content = content,
        )
    }
}

@Composable
fun FloatingGlassBottomBar(
    labels: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val reduceMotion = LocalReduceMotion.current
    BoxWithConstraints(
        modifier = modifier
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(JobatTokens.RadiusXl))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(JobatTokens.RadiusXl))
            .padding(horizontal = 6.dp),
    ) {
        val slotWidth = maxWidth / labels.size.coerceAtLeast(1)
        val indicatorOffset by animateDpAsState(
            targetValue = slotWidth * selectedIndex,
            animationSpec = if (reduceMotion) spring(stiffness = Spring.StiffnessHigh)
            else spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow),
            label = "goldNavIndicator",
        )
        Box(
            Modifier
                .offset(x = indicatorOffset + (slotWidth - 36.dp) / 2, y = 6.dp)
                .size(width = 36.dp, height = 3.dp)
                .clip(CircleShape)
                .background(JobatTokens.ChampagneGradient),
        )
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            labels.forEachIndexed { idx, label ->
                val active = idx == selectedIndex
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onSelect(idx) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
