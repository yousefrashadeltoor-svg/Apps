package com.jobat.feature.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jobat.designsystem.theme.JobatTokens
import com.jobat.domain.LibraryDocument
import com.jobat.domain.LibraryViewMode
import com.jobat.domain.SortField

@Composable
fun LibraryScreen(
    documents: List<LibraryDocument>,
    viewMode: LibraryViewMode,
    selectedFilter: String?,
    searchQuery: String,
    sortField: SortField,
    onSearchChange: (String) -> Unit,
    onFilterSelect: (String?) -> Unit,
    onViewModeChange: (LibraryViewMode) -> Unit,
    onSortChange: (SortField) -> Unit,
    onOpenDocument: (LibraryDocument) -> Unit,
    onPickSafFile: () -> Unit,
) {
    val filters = listOf(null, "pdf", "epub", "djvu", "cbz", "md", "jpg", "zip")
    val continueDoc = remember(documents) {
        documents.filter { it.currentPage in 1 until it.pageCount }.maxByOrNull { it.lastReadEpochMs }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = JobatTokens.SpaceMd),
    ) {
        Spacer(Modifier.height(JobatTokens.SpaceMd))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("𝒥𝒪 bat", style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.primary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    val next = LibraryViewMode.entries[(viewMode.ordinal + 1) % LibraryViewMode.entries.size]
                    onViewModeChange(next)
                }) { Text(viewMode.name) }
                TextButton(onClick = {
                    val next = SortField.entries[(sortField.ordinal + 1) % SortField.entries.size]
                    onSortChange(next)
                }) { Text(sortField.name) }
                Button(onClick = onPickSafFile) { Text("+") }
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            singleLine = true,
            shape = RoundedCornerShape(JobatTokens.RadiusLg),
            placeholder = { Text("FTS Search — title, author, content…") },
        )

        continueDoc?.let { doc ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(JobatTokens.RadiusLg))
                    .clickable { onOpenDocument(doc) },
                color = MaterialTheme.colorScheme.surface,
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            progress = { doc.progressFraction },
                            modifier = Modifier.size(52.dp),
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 3.5.dp,
                        )
                        Text("${(doc.progressFraction * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(doc.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${doc.author} • ${doc.estimatedRemainingMinutes} min left", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            items(filters) { ext ->
                FilterChip(
                    selected = selectedFilter == ext,
                    onClick = { onFilterSelect(ext) },
                    label = { Text(ext?.uppercase() ?: "ALL") },
                )
            }
        }

        if (viewMode == LibraryViewMode.GRID) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 148.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 96.dp),
            ) {
                items(documents, key = { it.id }) { doc ->
                    Surface(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(JobatTokens.RadiusLg)).clickable { onOpenDocument(doc) },
                        color = MaterialTheme.colorScheme.surface,
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(doc.extension.uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(10.dp))
                            Text(doc.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(doc.author, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(progress = { doc.progressFraction }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 96.dp)) {
                items(documents, key = { it.id }) { doc ->
                    Surface(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(JobatTokens.RadiusMd)).clickable { onOpenDocument(doc) },
                        color = MaterialTheme.colorScheme.surface,
                    ) {
                        Row(Modifier.padding(if (viewMode == LibraryViewMode.COMPACT) 10.dp else 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(doc.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (viewMode == LibraryViewMode.LIST) {
                                    Text("${doc.author} • ${doc.extension.uppercase()}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Text("${(doc.progressFraction * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}
