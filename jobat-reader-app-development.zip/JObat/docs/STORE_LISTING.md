# وصف المتجر والمعمارية — 𝒥𝒪 bat (`com.jobat.reader`)

## الوصف العربي (Google Play / F-Droid)
**العنوان:** 𝒥𝒪 bat — قارئ ومحرر مستندات فاخر دون إنترنت  
**الوصف القصير:** قارئ PDF/EPUB/DJVU ومحرر PDF ونصوص وصور وماسح OCR فخم، سريع، بلا إعلانات أو تتبع.  
**الوصف الكامل:**  
تطبيق **𝒥𝒪 bat** يجمع القراءة الهادئة وأدوات التحرير الاحترافية في تجربة فخمة بهوية *Obsidian & Champagne* تعمل 100% دون اتصال بالإنترنت:
- **36+ صيغة فعلية:** PDF, EPUB 2/3, MOBI, AZW3, FB2, DJVU, XPS, CBZ/CBR/CB7, DOCX/ODT/XLSX/PPTX, MD, HTML, XML, CSV, الصور عالية الدقة، وأرشيفات ZIP/RAR/7z.
- **استوديو PDF متكامل:** تمييز، قلم ضغط، أشكال، أختام، توقيع محفوظ، تعبئة نماذج AcroForms، دمج/تقسيم/ضغط/حماية، وUndo/Redo غير محدود.
- **ماسح CameraX وOCR دون اتصال:** كشف حواف وتصحيح منظور مع إنشاء PDF قابل للبحث وتنزيل لغات عند الطلب.
- **خصوصية مطلقة (GPL-3.0):** خزنة مشفرة AES-256-GCM ببصمة الإصبع، صفر إعلانات، صفر تتبع.

## English Store Listing
**Title:** 𝒥𝒪 bat — Offline Document Reader & PDF Studio  
**Short Description:** Luxury offline PDF/EPUB/DJVU reader, PDF/code/image editor, CameraX scanner & OCR. Zero ads.  
**Proposed Play Store Screenshots (8 Frames):**
1. Obsidian Dark Library — Continue Reading circular progress ring & curated covers.
2. Full-Format Reader — Arabic RTL typography, Sepia/AMOLED themes & synchronized TTS bar.
3. PDF Annotation Studio — Champagne highlighter, freehand ink, stamps & saved signature.
4. Page Manager & Tools — Reorder, merge, split, compress, watermark & password protection.
5. CameraX Document Scanner — 4-point perspective crop & offline Arabic/English OCR.
6. Code & Markdown Editor — Syntax highlighting, Regex find/replace & live split preview.
7. Biometric Encrypted Vault & Reading Analytics — Streak, 7-day chart & daily goal ring.
8. Adaptive Tablet / Foldable Split-Screen & Ivory Light theme showcase.
