# Build & Architecture Guide — 𝒥𝒪 bat (`com.jobat.reader`)

## Prerequisites
- JDK 17 (Temurin recommended)
- Android SDK Platform 35, Build-Tools 35.0.0
- Android NDK `27.2.12479018` + CMake `3.22.1`
- Optional vendored MuPDF source at `core-native/src/main/cpp/third_party/mupdf` (automatically enables `-DHAVE_MUPDF_FITZ=1`)

## Build & Test Commands
```bash
cd JObat

# 1. Run domain, format-registry & UndoRedo unit tests
./gradlew testDebugUnitTest

# 2. Generate startup Baseline Profile (optional, connected device API 28+)
./gradlew :baselineprofile:pixel6Api34BenchmarkAndroidTest

# 3. Build optimized, R8-shrunk, per-ABI Release APKs
cp keystore.properties.example keystore.properties   # Fill with your release keystore
./gradlew assembleRelease

# 4. Build Google Play App Bundle (.aab)
./gradlew bundleRelease
```

## Clean Architecture Layering
1. **`:core-native`** — C++20 JNI over MuPDF `fz_context`/`pdf_document` + bounded `LruCache<String, Bitmap>`.
2. **`:core-engine`** — Clean GPL-3.0 Librera-based format dispatcher (36+ formats), streaming ZIP/7z/OOXML handler, and `TtsReadAloudController`.
3. **`:design-system`** — Material 3 Obsidian & Champagne tokens mapped 1:1 from `design-system/tokens.json` (Dark, Light, AMOLED, Sepia, Dynamic).
4. **`:domain`** — Pure Kotlin models, repository contracts, and unlimited `UndoRedoStack<T>`.
5. **`:data`** — Room + `@Fts4` full-text index, DataStore preferences, `WorkManager` background folder scanner, `EncryptedFile` AES-256-GCM Keystore Vault, and `BackupRestoreManager`.
6. **`:feature-*`, `:widget`, `:baselineprofile`, `:app`** — Isolated Jetpack Compose feature modules, Glance widget, Quick Settings scanner tile, and Scoped Storage host activity.
