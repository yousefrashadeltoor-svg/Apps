package com.jobat.feature.reader

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.jobat.core.engine.TtsState
import com.jobat.domain.LibraryDocument
import com.jobat.domain.ReaderMode
import com.jobat.domain.ReaderTheme
import kotlinx.coroutines.launch

@Composable
fun ReaderScreen(
    document: LibraryDocument,
    initialPage: Int,
    readerMode: ReaderMode,
    readerTheme: ReaderTheme,
    blueLightIntensity: Float,
    ttsState: TtsState,
    renderPage: suspend (pageIndex: Int, zoom: Float, invert: Boolean) -> Bitmap?,
    onPageChanged: (Int) -> Unit,
    onToggleBookmark: (Int) -> Unit,
    onOpenPdfEditor: () -> Unit,
    onToggleTts: () -> Unit,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var chromeVisible by remember { mutableStateOf(true) }
    var zoom by remember { mutableFloatStateOf(1f) }
    val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { document.pageCount.coerceAtLeast(1) })
    val invert = readerTheme in setOf(ReaderTheme.GRAPHITE, ReaderTheme.MIDNIGHT, ReaderTheme.AMOLED)

    LaunchedEffect(pagerState.currentPage) { onPageChanged(pagerState.currentPage) }

    val bgColor = when (readerTheme) {
        ReaderTheme.PAPER -> Color(0xFFFAF9F5)
        ReaderTheme.SEPIA -> Color(0xFFF2E6CE)
        ReaderTheme.IVORY -> Color(0xFFF6F1E7)
        ReaderTheme.GRAPHITE -> Color(0xFF181A20)
        ReaderTheme.MIDNIGHT -> Color(0xFF0D111A)
        ReaderTheme.AMOLED -> Color.Black
        ReaderTheme.CUSTOM -> Color(0xFF14161B)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .pointerInput(Unit) {
                detectTransformGestures { _, _, zoomChange, _ ->
                    zoom = (zoom * zoomChange).coerceIn(0.75f, 3.5f)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { chromeVisible = !chromeVisible },
                    onDoubleTap = { zoom = if (zoom > 1.2f) 1f else 2f },
                )
            },
    ) {
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            val bitmap by produceState<Bitmap?>(initialValue = null, page, zoom, invert) {
                value = renderPage(page, zoom, invert)
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                bitmap?.let { bmp ->
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Page ${page + 1}",
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(scaleX = zoom, scaleY = zoom),
                    )
                } ?: CircularProgressIndicator()
            }
        }

        if (blueLightIntensity > 0f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xFFFF9E3D).copy(alpha = (blueLightIntensity * 0.28f).coerceAtMost(0.32f))),
            )
        }

        AnimatedVisibility(visible = chromeVisible, modifier = Modifier.align(Alignment.TopCenter)) {
            Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = onBack) { Text("←") }
                    Text(document.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onToggleBookmark(pagerState.currentPage) }) { Text("★") }
                    TextButton(onClick = onToggleTts) { Text(if (ttsState.isPlaying) "❚❚ TTS" else "▶ TTS") }
                    if (document.extension == "pdf") {
                        TextButton(onClick = onOpenPdfEditor) { Text("Edit") }
                    }
                }
            }
        }

        AnimatedVisibility(visible = chromeVisible, modifier = Modifier.align(Alignment.BottomCenter)) {
            Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${pagerState.currentPage + 1} / ${document.pageCount}", style = MaterialTheme.typography.labelMedium)
                        Text("${readerMode.name} • ${(zoom * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
                    }
                    Slider(
                        value = pagerState.currentPage.toFloat(),
                        onValueChange = { scope.launch { pagerState.scrollToPage(it.toInt()) } },
                        valueRange = 0f..(document.pageCount - 1).coerceAtLeast(1).toFloat(),
                    )
                }
            }
        }
    }
}
