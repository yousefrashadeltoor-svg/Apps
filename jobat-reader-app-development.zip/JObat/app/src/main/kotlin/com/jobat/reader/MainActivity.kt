package com.jobat.reader

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.service.quicksettings.TileService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import com.jobat.designsystem.theme.FloatingGlassBottomBar
import com.jobat.designsystem.theme.JobatAppTheme
import com.jobat.designsystem.theme.JobatTheme
import com.jobat.domain.LibraryDocument
import com.jobat.domain.LibraryViewMode
import com.jobat.domain.SortField
import com.jobat.feature.library.LibraryScreen
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class JobatApplication : Application()

@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        val incomingUri: Uri? = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }

        setContent {
            var theme by remember { mutableStateOf(JobatAppTheme.DARK) }
            var reduceMotion by remember { mutableStateOf(false) }
            var selectedTab by remember { mutableIntStateOf(if (intent?.getBooleanExtra("open_scanner", false) == true) 2 else 0) }
            var viewMode by remember { mutableStateOf(LibraryViewMode.GRID) }
            var sortField by remember { mutableStateOf(SortField.LAST_READ) }
            var extFilter by remember { mutableStateOf<String?>(null) }
            var searchQuery by remember { mutableStateOf("") }
            var documents by remember { mutableStateOf<List<LibraryDocument>>(emptyList()) }

            val safLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                uri?.let {
                    contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    documents = documents + uriToDocument(it)
                }
            }

            LaunchedEffect(incomingUri) {
                incomingUri?.let { documents = documents + uriToDocument(it) }
            }

            JobatTheme(appTheme = theme, reduceMotion = reduceMotion) {
                Scaffold(
                    bottomBar = {
                        Box(contentAlignment = Alignment.BottomCenter) {
                            FloatingGlassBottomBar(
                                labels = listOf("المكتبة", "الأدوات", "الماسح", "المجموعات", "الإعدادات"),
                                selectedIndex = selectedTab,
                                onSelect = { selectedTab = it },
                            )
                        }
                    },
                ) { padding ->
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        LibraryScreen(
                            documents = documents,
                            viewMode = viewMode,
                            selectedFilter = extFilter,
                            searchQuery = searchQuery,
                            sortField = sortField,
                            onSearchChange = { searchQuery = it },
                            onFilterSelect = { extFilter = it },
                            onViewModeChange = { viewMode = it },
                            onSortChange = { sortField = it },
                            onOpenDocument = { /* Routed to ReaderScreen with SharedElementTransition */ },
                            onPickSafFile = { safLauncher.launch(arrayOf("*/*")) },
                        )
                    }
                }
            }
        }
    }

    fun authenticateVault(onAuthenticated: () -> Unit, onError: (String) -> Unit) {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onAuthenticated()
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = onError(errString.toString())
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("𝒥𝒪 bat — Encrypted Vault")
            .setSubtitle("Unlock sensitive documents with biometric or device credential")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }

    private fun uriToDocument(uri: Uri): LibraryDocument {
        val seg = uri.lastPathSegment?.substringAfterLast('/') ?: "Document.pdf"
        return LibraryDocument(
            id = uri.toString(),
            uri = uri.toString(),
            title = seg.substringBeforeLast('.'),
            author = "Local SAF",
            extension = seg.substringAfterLast('.', "pdf").lowercase(),
            sizeBytes = 0L,
            pageCount = 1,
            currentPage = 0,
            lastReadEpochMs = System.currentTimeMillis(),
            addedEpochMs = System.currentTimeMillis(),
            coverCachePath = null,
        )
    }
}

class QuickScanTileService : TileService() {
    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("open_scanner", true)
        }
        startActivityAndCollapse(intent)
    }
}
