package com.jobat.reader

import com.jobat.core.engine.SupportedFormat
import com.jobat.domain.LibraryDocument
import com.jobat.domain.UndoRedoStack
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainAndEditorTest {

    @Test
    fun undoRedoStack_supportsUnlimitedHistoryAndBranchReset() {
        val stack = UndoRedoStack("v0")
        assertFalse(stack.canUndo)
        (1..250).forEach { stack.push("v$it") }
        assertEquals("v250", stack.current)
        assertEquals("v249", stack.undo())
        assertEquals("v248", stack.undo())
        assertTrue(stack.canRedo)
        assertEquals("v249", stack.redo())
        stack.push("branch")
        assertFalse(stack.canRedo)
        assertEquals("branch", stack.current)
    }

    @Test
    fun formatRegistry_recognizesAllCoreAndCompoundExtensions() {
        val sampleFiles = listOf(
            "book.pdf", "novel.epub", "classic.mobi", "kindle.azw3", "story.fb2.zip",
            "manuscript.djvu", "spec.xps", "comic.cbz", "manga.cbr", "issue.cb7",
            "report.docx", "sheet.xlsx", "deck.pptx", "notes.md", "data.csv",
            "page.xhtml", "photo.avif", "scan.tiff", "vector.svg", "bundle.7z"
        )
        sampleFiles.forEach { fileName ->
            assertNotNull("Expected $fileName to be recognized", SupportedFormat.fromFileName(fileName))
        }
    }

    @Test
    fun libraryDocument_computesProgressAndRemainingTimeAccurately() {
        val doc = LibraryDocument(
            id = "1", uri = "content://doc/1", title = "Muqaddimah", author = "Ibn Khaldun",
            extension = "pdf", sizeBytes = 4_200_000L, pageCount = 200, currentPage = 150,
            lastReadEpochMs = 1000L, addedEpochMs = 500L, coverCachePath = null,
        )
        assertEquals(0.75f, doc.progressFraction, 0.001f)
        assertEquals(70, doc.estimatedRemainingMinutes)
    }
}
