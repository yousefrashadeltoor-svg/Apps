-optimizationpasses 5
-keepclasseswithmembernames class * { native <methods>; }
-keep class com.jobat.core.nativebridge.** { *; }
-keep class com.googlecode.tesseract.android.** { *; }
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @kotlinx.serialization.Serializable class com.jobat.** { *; }
-dontwarn java.awt.**
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
}
