export type AppTheme = 'dark' | 'light' | 'amoled' | 'sepia' | 'dynamic';
export type Lang = 'ar' | 'en';
export type MainTab = 'library' | 'tools' | 'scanner' | 'collections' | 'settings';
export type ViewMode = 'grid' | 'list' | 'compact';
export type SortBy = 'lastRead' | 'title' | 'dateAdded' | 'size' | 'progress';
export type ReaderMode = 'vertical' | 'paged' | 'twoPage' | 'continuous' | 'curl';
export type ReaderThemeId = 'paper' | 'sepia' | 'ivory' | 'graphite' | 'midnight' | 'amoled' | 'custom';
export type FormatCategory = 'all' | 'pdf' | 'ebook' | 'comic_djvu' | 'office_code' | 'image' | 'archive';

export interface TocEntry {
  titleAr: string;
  titleEn: string;
  page: number;
}

export interface ArchiveInnerFile {
  name: string;
  ext: string;
  sizeKb: number;
  content: string;
}

export interface PdfAnnotation {
  id: string;
  page: number;
  tool: 'highlight' | 'underline' | 'strike' | 'pen' | 'rect' | 'circle' | 'arrow' | 'line' | 'text' | 'note' | 'stamp' | 'signature';
  color: string;
  strokeWidth: number;
  points: { x: number; y: number }[];
  text?: string;
  signatureDataUrl?: string;
}

export interface DocPageSpec {
  id: string;
  headingAr: string;
  headingEn: string;
  paragraphsAr: string[];
  paragraphsEn: string[];
  rotation?: number;
  isBlank?: boolean;
  imageUrl?: string;
}

export interface DocItem {
  id: string;
  titleAr: string;
  titleEn: string;
  authorAr: string;
  authorEn: string;
  ext: string;
  category: Exclude<FormatCategory, 'all'>;
  sizeBytes: number;
  pageCount: number;
  currentPage: number;
  lastReadMs: number;
  addedMs: number;
  coverStyle: {
    bgFrom: string;
    bgTo: string;
    accent: string;
    pattern: 'arch' | 'geometric' | 'minimal' | 'manuscript' | 'code' | 'photo';
    imageUrl?: string;
  };
  favorite: boolean;
  archived: boolean;
  trashed: boolean;
  vaultLocked: boolean;
  password?: string;
  watermark?: string;
  numberedPages?: boolean;
  collections: string[];
  tags: string[];
  bookmarks: number[];
  toc: TocEntry[];
  pages: DocPageSpec[];
  rawCode?: string;
  archiveEntries?: ArchiveInnerFile[];
  annotations?: PdfAnnotation[];
  formFields?: Record<string, string>;
}

export interface QuoteItem {
  id: string;
  docId: string;
  docTitle: string;
  author: string;
  page: number;
  text: string;
  note: string;
  color: string;
  createdAt: number;
}

export interface DailyStat {
  dayAr: string;
  dayEn: string;
  minutes: number;
  pages: number;
}

export interface ReaderSettings {
  mode: ReaderMode;
  theme: ReaderThemeId;
  customBg: string;
  customFg: string;
  fontFamily: 'amiri' | 'plex' | 'kufi' | 'cormorant' | 'inter';
  fontSize: number;
  lineHeight: number;
  marginPx: number;
  align: 'justify' | 'start';
  hyphenation: boolean;
  blueLight: number;
  blueLightScheduled: boolean;
  autoCrop: boolean;
  contrastBoost: boolean;
  reflowPdf: boolean;
  rotationLocked: boolean;
  rtlOverride: boolean | null;
}

export type ActiveOverlay =
  | null
  | { type: 'reader'; docId: string }
  | { type: 'pdfEditor'; docId: string; initialTab?: 'annotate' | 'pages' | 'forms' }
  | { type: 'textEditor'; docId: string }
  | { type: 'imageEditor'; docId: string }
  | { type: 'stats' }
  | { type: 'onboarding' }
  | { type: 'licenses' }
  | { type: 'codeInspector' };
