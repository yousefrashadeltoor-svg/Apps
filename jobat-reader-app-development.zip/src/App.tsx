import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  Wrench,
  ScanLine,
  FolderHeart,
  Settings,
  Smartphone,
  Tablet,
  Sparkles,
  Code2,
  WifiOff,
  BatteryFull,
  Play,
} from 'lucide-react';
import {
  ActiveOverlay,
  AppTheme,
  ArchiveInnerFile,
  DailyStat,
  DocItem,
  Lang,
  MainTab,
  QuoteItem,
  ReaderSettings,
} from './types';
import {
  DEFAULT_READER_SETTINGS,
  INITIAL_COLLECTIONS,
  INITIAL_DOCUMENTS,
  INITIAL_QUOTES,
  INITIAL_STATS,
} from './data/sampleData';
import { OnboardingScreen, SplashScreen } from './components/SplashAndOnboarding';
import { LibraryScreen } from './components/LibraryScreen';
import { ReaderScreen } from './components/ReaderScreen';
import { PdfEditorScreen } from './components/PdfEditorScreen';
import { TextEditorScreen } from './components/TextEditorScreen';
import { ImageEditorScreen } from './components/ImageEditorScreen';
import { ScannerOcrScreen } from './components/ScannerOcrScreen';
import { ToolsScreen } from './components/ToolsScreen';
import { CollectionsVaultScreen } from './components/CollectionsVaultScreen';
import { LicensesOverlay, SettingsScreen, StatsOverlay } from './components/SettingsStatsScreen';
import { ProjectInspectorModal } from './components/ProjectInspectorModal';

const STORAGE_KEY = 'jobat_studio_state_v1';

function loadSaved<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return parsed[key] !== undefined ? parsed[key] : fallback;
  } catch {
    return fallback;
  }
}

export function App() {
  const [theme, setTheme] = useState<AppTheme>(() => loadSaved('theme', 'dark'));
  const [lang, setLang] = useState<Lang>(() => loadSaved('lang', 'ar'));
  const [reduceMotion, setReduceMotion] = useState<boolean>(() => loadSaved('reduceMotion', false));
  const [haptics, setHaptics] = useState<boolean>(() => loadSaved('haptics', true));
  const [biometricLock, setBiometricLock] = useState<boolean>(() => loadSaved('biometricLock', true));
  const [tabletMode, setTabletMode] = useState(false);

  const [tab, setTab] = useState<MainTab>('library');
  const [overlay, setOverlay] = useState<ActiveOverlay>(null);
  const [showSplash, setShowSplash] = useState(true);
  const [dragActive, setDragActive] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [clock, setClock] = useState('09:41');

  const [docs, setDocs] = useState<DocItem[]>(() => loadSaved('docs', INITIAL_DOCUMENTS));
  const [collections, setCollections] = useState<string[]>(() => loadSaved('collections', INITIAL_COLLECTIONS));
  const [quotes, setQuotes] = useState<QuoteItem[]>(() => loadSaved('quotes', INITIAL_QUOTES));
  const [stats, setStats] = useState<DailyStat[]>(() => loadSaved('stats', INITIAL_STATS));
  const [dailyGoal, setDailyGoal] = useState<number>(() => loadSaved('dailyGoal', 45));
  const [savedSignatures, setSavedSignatures] = useState<string[]>(() => loadSaved('savedSignatures', []));
  const [readerSettings, setReaderSettings] = useState<ReaderSettings>(() =>
    loadSaved('readerSettings', DEFAULT_READER_SETTINGS)
  );

  const isAr = lang === 'ar';

  // Sync HTML dir/lang & persist to localStorage
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = isAr ? 'rtl' : 'ltr';
  }, [lang, isAr]);

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          theme,
          lang,
          reduceMotion,
          haptics,
          biometricLock,
          docs,
          collections,
          quotes,
          stats,
          dailyGoal,
          savedSignatures,
          readerSettings,
        })
      );
    } catch {
      // Ignore storage quota overflow for large data URLs
    }
  }, [theme, lang, reduceMotion, haptics, biometricLock, docs, collections, quotes, stats, dailyGoal, savedSignatures, readerSettings]);

  // Smooth Splash auto-dismiss
  useEffect(() => {
    if (!showSplash) return;
    const t = window.setTimeout(() => setShowSplash(false), reduceMotion ? 320 : 1250);
    return () => window.clearTimeout(t);
  }, [showSplash, reduceMotion]);

  // Live Status Bar Clock
  useEffect(() => {
    const tick = () => {
      const d = new Date();
      setClock(`${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`);
    };
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);

  const buzz = useCallback(() => {
    if (haptics && typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(8);
      } catch {
        // Silent fallback
      }
    }
  }, [haptics]);

  const notify = useCallback(
    (msg: string) => {
      buzz();
      setToast(msg);
    },
    [buzz]
  );

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 2700);
    return () => window.clearTimeout(id);
  }, [toast]);

  const updateDoc = useCallback((id: string, patch: Partial<DocItem>) => {
    setDocs((prev) => prev.map((d) => (d.id === id ? { ...d, ...patch } : d)));
  }, []);

  const addDoc = useCallback((newDoc: DocItem) => {
    setDocs((prev) => [newDoc, ...prev]);
  }, []);

  const openEditorForDoc = useCallback((doc: DocItem, pdfTab?: 'annotate' | 'pages' | 'forms') => {
    if (doc.category === 'image') {
      setOverlay({ type: 'imageEditor', docId: doc.id });
    } else if (['txt', 'md', 'html', 'xhtml', 'xml', 'csv', 'mht'].includes(doc.ext)) {
      setOverlay({ type: 'textEditor', docId: doc.id });
    } else {
      setOverlay({ type: 'pdfEditor', docId: doc.id, initialTab: pdfTab ?? 'annotate' });
    }
  }, []);

  // Real SAF / Drag-and-Drop File Importer with Corrupted/Empty file error protection
  const handleImportFile = useCallback(
    (file: File) => {
      if (file.size === 0) {
        notify(isAr ? `تعذّر فتح "${file.name}" — الملف فارغ أو تالف` : `Cannot open "${file.name}" — empty or corrupted file`);
        return;
      }
      const ext = file.name.split('.').pop()?.toLowerCase() ?? 'txt';
      const baseTitle = file.name.replace(/\.[^.]+$/, '');
      const id = `saf-${Date.now()}`;

      if (['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg', 'avif', 'heic', 'tiff'].includes(ext)) {
        const reader = new FileReader();
        reader.onload = () => {
          const url = typeof reader.result === 'string' ? reader.result : '/images/sample-photo.jpg';
          const created: DocItem = {
            id,
            titleAr: file.name,
            titleEn: file.name,
            authorAr: 'استيراد محلي (SAF)',
            authorEn: 'Local SAF Import',
            ext,
            category: 'image',
            sizeBytes: file.size,
            pageCount: 1,
            currentPage: 1,
            lastReadMs: Date.now(),
            addedMs: Date.now(),
            coverStyle: { bgFrom: '#17171B', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'photo', imageUrl: url },
            favorite: false,
            archived: false,
            trashed: false,
            vaultLocked: false,
            collections: [],
            tags: ['مستورد'],
            bookmarks: [],
            toc: [],
            pages: [{ id: `${id}-p1`, headingAr: baseTitle, headingEn: baseTitle, paragraphsAr: [], paragraphsEn: [], imageUrl: url }],
          };
          addDoc(created);
          setOverlay({ type: 'imageEditor', docId: id });
          notify(isAr ? `فُتحت الصورة "${file.name}" بنجاح` : `Opened "${file.name}" in Image Studio`);
        };
        reader.readAsDataURL(file);
        return;
      }

      if (['txt', 'md', 'html', 'xhtml', 'xml', 'csv', 'mht', 'rtf'].includes(ext)) {
        const reader = new FileReader();
        reader.onload = () => {
          const raw = typeof reader.result === 'string' ? reader.result : '';
          const paras = raw.split(/\n\s*\n/).filter(Boolean).slice(0, 12);
          const created: DocItem = {
            id,
            titleAr: file.name,
            titleEn: file.name,
            authorAr: 'استيراد محلي (SAF)',
            authorEn: 'Local SAF Import',
            ext,
            category: 'office_code',
            sizeBytes: file.size,
            pageCount: 1,
            currentPage: 1,
            lastReadMs: Date.now(),
            addedMs: Date.now(),
            coverStyle: { bgFrom: '#161A22', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'code' },
            favorite: false,
            archived: false,
            trashed: false,
            vaultLocked: false,
            collections: [],
            tags: ['مستورد'],
            bookmarks: [],
            toc: [],
            rawCode: raw,
            pages: [
              {
                id: `${id}-p1`,
                headingAr: baseTitle,
                headingEn: baseTitle,
                paragraphsAr: paras.length ? paras : [raw.slice(0, 600)],
                paragraphsEn: paras.length ? paras : [raw.slice(0, 600)],
              },
            ],
          };
          addDoc(created);
          setOverlay({ type: 'textEditor', docId: id });
          notify(isAr ? `فُتح "${file.name}" في محرر النصوص والكود` : `Opened "${file.name}" in Code Editor`);
        };
        reader.readAsText(file);
        return;
      }

      // Binary documents (PDF, EPUB, MOBI, DJVU, CBZ, DOCX, ZIP, etc.)
      const cat =
        ext === 'pdf' || ext === 'xps'
          ? 'pdf'
          : ['epub', 'mobi', 'azw', 'azw3', 'fb2'].includes(ext)
          ? 'ebook'
          : ['djvu', 'cbz', 'cbr', 'cb7'].includes(ext)
          ? 'comic_djvu'
          : ['zip', 'rar', '7z'].includes(ext)
          ? 'archive'
          : 'office_code';

      const created: DocItem = {
        id,
        titleAr: baseTitle,
        titleEn: baseTitle,
        authorAr: 'ملف محلي (SAF)',
        authorEn: 'Scoped Storage Document',
        ext,
        category: cat,
        sizeBytes: file.size,
        pageCount: 1,
        currentPage: 1,
        lastReadMs: Date.now(),
        addedMs: Date.now(),
        coverStyle: { bgFrom: '#1D1A15', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'manuscript' },
        favorite: false,
        archived: false,
        trashed: false,
        vaultLocked: false,
        collections: [],
        tags: [ext.toUpperCase()],
        bookmarks: [],
        toc: [],
        pages: [
          {
            id: `${id}-p1`,
            headingAr: baseTitle,
            headingEn: baseTitle,
            paragraphsAr: [
              `تم استيراد الملف "${file.name}" (${ext.toUpperCase()}) عبر إطار الوصول للتخزين الآمن Storage Access Framework.`,
              'في تطبيق Android الأصلي يتولى محرك Librera + MuPDF C/NDK فك ترميز الصفحات وعرضها بدقة كاملة مع دعم التحرير والحفظ المباشر.',
            ],
            paragraphsEn: [
              `Imported "${file.name}" (${ext.toUpperCase()}) via Android Storage Access Framework.`,
              'On Android, the native Librera + MuPDF C/NDK bridge renders all pages at full vector resolution with direct annotation support.',
            ],
          },
        ],
      };
      addDoc(created);
      setOverlay({ type: 'reader', docId: id });
      notify(isAr ? `أُضيف "${file.name}" إلى مكتبتك` : `Added "${file.name}" to your Library`);
    },
    [addDoc, isAr, notify]
  );

  const openArchiveInnerInEditor = useCallback(
    (entry: ArchiveInnerFile) => {
      const id = `arch-inner-${Date.now()}`;
      const created: DocItem = {
        id,
        titleAr: entry.name,
        titleEn: entry.name,
        authorAr: 'مستخرج من الأرشيف',
        authorEn: 'Extracted from Archive',
        ext: entry.ext,
        category: 'office_code',
        sizeBytes: entry.sizeKb * 1024,
        pageCount: 1,
        currentPage: 1,
        lastReadMs: Date.now(),
        addedMs: Date.now(),
        coverStyle: { bgFrom: '#161A20', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'code' },
        favorite: false,
        archived: false,
        trashed: false,
        vaultLocked: false,
        collections: [],
        tags: ['أرشيف'],
        bookmarks: [],
        toc: [],
        rawCode: entry.content,
        pages: [{ id: `${id}-p1`, headingAr: entry.name, headingEn: entry.name, paragraphsAr: [entry.content], paragraphsEn: [entry.content] }],
      };
      addDoc(created);
      setOverlay({ type: 'textEditor', docId: id });
    },
    [addDoc]
  );

  const recordReading = useCallback((pagesDelta: number) => {
    setStats((prev) =>
      prev.map((s, idx) =>
        idx === prev.length - 1 ? { ...s, pages: s.pages + pagesDelta, minutes: s.minutes + 2 } : s
      )
    );
  }, []);

  const exportBackup = () => {
    const payload = {
      app: 'com.jobat.reader',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      theme,
      lang,
      reduceMotion,
      dailyGoal,
      readerSettings,
      collections,
      quotes,
      stats,
      docs,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `jobat-backup-${new Date().toISOString().slice(0, 10)}.jobat.json`;
    a.click();
    URL.revokeObjectURL(url);
    notify(isAr ? 'تم تصدير النسخة الاحتياطية الكاملة بنجاح' : 'Exported complete single-file backup');
  };

  const importBackup = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result));
        if (data.app !== 'com.jobat.reader') throw new Error('Invalid');
        if (data.theme) setTheme(data.theme);
        if (data.lang) setLang(data.lang);
        if (Array.isArray(data.collections)) setCollections(data.collections);
        if (Array.isArray(data.quotes)) setQuotes(data.quotes);
        if (Array.isArray(data.docs)) setDocs(data.docs);
        if (data.dailyGoal) setDailyGoal(data.dailyGoal);
        notify(isAr ? 'تمت استعادة الإعدادات والمكتبة والملاحظات بنجاح' : 'Restored settings, progress & excerpts');
      } catch {
        notify(isAr ? 'ملف النسخة الاحتياطية غير صالح' : 'Invalid JObat backup file');
      }
    };
    reader.readAsText(file);
  };

  const navItems: { id: MainTab; icon: React.FC<{ size?: number; strokeWidth?: number }>; ar: string; en: string }[] = [
    { id: 'library', icon: BookOpen, ar: 'المكتبة', en: 'Library' },
    { id: 'tools', icon: Wrench, ar: 'الأدوات', en: 'Tools' },
    { id: 'scanner', icon: ScanLine, ar: 'الماسح', en: 'Scan' },
    { id: 'collections', icon: FolderHeart, ar: 'المجموعات', en: 'Shelves' },
    { id: 'settings', icon: Settings, ar: 'الإعدادات', en: 'Settings' },
  ];

  const activeNavIdx = navItems.findIndex((n) => n.id === tab);
  const overlayDoc = useMemo(() => {
    if (!overlay || !('docId' in overlay)) return null;
    return docs.find((d) => d.id === overlay.docId) ?? null;
  }, [overlay, docs]);

  const continueDoc = useMemo(
    () => docs.filter((d) => !d.trashed && !d.vaultLocked && !d.password).sort((a, b) => b.lastReadMs - a.lastReadMs)[0],
    [docs]
  );

  return (
    <div
      data-reduce-motion={reduceMotion ? 'true' : 'false'}
      className="min-h-screen w-full flex flex-col items-center justify-center sm:py-5 sm:px-4 select-none"
      style={{
        background:
          'radial-gradient(ellipse at 50% 0%, rgba(212, 178, 106, 0.08) 0%, #090A0E 48%, #050608 100%)',
      }}
    >
      {/* Quiet External Studio Control Bar (Desktop/Tablet) */}
      <div
        dir="ltr"
        className="hidden sm:flex items-center gap-2 mb-3.5 px-3 py-1.5 rounded-full text-[11px] bg-[#12141A]/90 border border-white/8 backdrop-blur-xl shadow-lg"
      >
        {/* Theme Dots */}
        <div className="flex items-center gap-1.5 pr-2 border-r border-white/10">
          {(
            [
              { id: 'dark', bg: '#0B0C10', ring: '#D4B26A', tip: 'Obsidian Dark' },
              { id: 'light', bg: '#F6F1E7', ring: '#9E7631', tip: 'Ivory Light' },
              { id: 'amoled', bg: '#000000', ring: '#D4B26A', tip: 'AMOLED Black' },
              { id: 'sepia', bg: '#EFE4CE', ring: '#8F6224', tip: 'Warm Sepia' },
              { id: 'dynamic', bg: '#161C22', ring: '#8EBCDA', tip: 'Dynamic Color' },
            ] as { id: AppTheme; bg: string; ring: string; tip: string }[]
          ).map((t) => (
            <button
              key={t.id}
              title={t.tip}
              onClick={() => setTheme(t.id)}
              className="w-4 h-4 rounded-full transition-transform cursor-pointer"
              style={{
                background: t.bg,
                border: `1.5px solid ${t.ring}`,
                transform: theme === t.id ? 'scale(1.25)' : 'scale(1)',
                boxShadow: theme === t.id ? `0 0 0 2px rgba(212,178,106,0.35)` : undefined,
              }}
            />
          ))}
        </div>

        {/* Language & RTL/LTR */}
        <button
          onClick={() => setLang((l) => (l === 'ar' ? 'en' : 'ar'))}
          className="px-2.5 py-1 rounded-full text-[#E8E2D5] hover:bg-white/8 font-medium cursor-pointer"
        >
          {lang === 'ar' ? 'AR · RTL' : 'EN · LTR'}
        </button>

        {/* WindowSizeClass Phone / Tablet */}
        <button
          onClick={() => setTabletMode((v) => !v)}
          title="Toggle Phone / Tablet WindowSizeClass"
          className="px-2.5 py-1 rounded-full text-[#9FA4B0] hover:text-[#F4F0E8] inline-flex items-center gap-1 cursor-pointer"
        >
          {tabletMode ? <Tablet size={12} className="text-[#D4B26A]" /> : <Smartphone size={12} className="text-[#D4B26A]" />}
          <span>{tabletMode ? 'Tablet' : 'Phone'}</span>
        </button>

        {/* Reduce Motion */}
        <button
          onClick={() => setReduceMotion((m) => !m)}
          className={`px-2.5 py-1 rounded-full inline-flex items-center gap-1 cursor-pointer ${
            reduceMotion ? 'bg-[#D4B26A]/20 text-[#D4B26A]' : 'text-[#9FA4B0] hover:text-[#F4F0E8]'
          }`}
        >
          <Sparkles size={11} />
          <span>{reduceMotion ? 'Reduced' : 'Motion'}</span>
        </button>

        {/* Onboarding & Splash Replay */}
        <button
          onClick={() => setOverlay({ type: 'onboarding' })}
          className="px-2.5 py-1 rounded-full text-[#9FA4B0] hover:text-[#F4F0E8] inline-flex items-center gap-1 cursor-pointer"
        >
          <Play size={10} />
          <span>Onboarding</span>
        </button>

        {/* Android Project JObat/ Blueprint */}
        <button
          onClick={() => setOverlay({ type: 'codeInspector' })}
          className="px-3 py-1 rounded-full bg-[#D4B26A]/15 text-[#D4B26A] border border-[#D4B26A]/35 font-medium inline-flex items-center gap-1.5 cursor-pointer hover:bg-[#D4B26A]/25 transition-colors"
        >
          <Code2 size={12} />
          <span>JObat/ APK</span>
        </button>
      </div>

      {/* Flagship Android Phone / Tablet Bezel Frame */}
      <div
        data-theme={theme}
        dir={isAr ? 'rtl' : 'ltr'}
        onDragOver={(e) => {
          e.preventDefault();
          setDragActive(true);
        }}
        onDragLeave={() => setDragActive(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragActive(false);
          const f = e.dataTransfer.files?.[0];
          if (f) handleImportFile(f);
        }}
        className={`jb-app relative flex flex-col overflow-hidden transition-all duration-300 w-full h-[100dvh] sm:rounded-[44px] ${
          tabletMode ? 'sm:w-[860px] sm:h-[760px]' : 'sm:w-[392px] sm:h-[812px]'
        }`}
        style={{
          boxShadow:
            '0 0 0 2px rgba(212, 178, 106, 0.22), 0 0 0 9px #14161B, 0 0 0 10.5px rgba(255,255,255,0.09), 0 34px 90px rgba(0, 0, 0, 0.78)',
        }}
      >
        {/* Android Edge-to-Edge Status Bar */}
        <div
          dir="ltr"
          className="relative z-20 h-9 px-6 flex items-center justify-between text-[11px] font-medium shrink-0 select-none"
          style={{ color: 'var(--jb-text-secondary)' }}
        >
          <span className="tabular-nums font-semibold" style={{ color: 'var(--jb-text)' }}>
            {clock}
          </span>
          {/* Subtle Camera Punch-Hole */}
          <div className="hidden sm:block w-3 h-3 rounded-full bg-[#050608] ring-1 ring-white/10" />
          <div className="flex items-center gap-1.5">
            <span className="text-[9px] tracking-wider uppercase font-semibold" style={{ color: 'var(--jb-accent)' }}>
              OFFLINE
            </span>
            <WifiOff size={11} style={{ color: 'var(--jb-accent)' }} />
            <BatteryFull size={13} />
          </div>
        </div>

        {/* Drag-and-Drop Overlay */}
        {dragActive && (
          <div
            className="absolute inset-3 z-50 rounded-[34px] flex flex-col items-center justify-center gap-2 backdrop-blur-md"
            style={{ background: 'rgba(11,12,16,0.82)', border: '2px dashed var(--jb-accent)' }}
          >
            <p className="text-[15px] font-semibold text-[#D4B26A]">
              {isAr ? 'أفلت الملف لفتحه فورًا في 𝒥𝒪 bat' : 'Drop file to open directly in 𝒥𝒪 bat'}
            </p>
            <p className="text-[11px] text-[#9FA4B0]">PDF · EPUB · MD · HTML · CSV · XML · JPG · PNG · WEBP · SVG · ZIP</p>
          </div>
        )}

        {/* Main Screen Viewport */}
        <main className="relative flex-1 overflow-hidden">
          {tab === 'library' && (
            <LibraryScreen
              lang={lang}
              docs={docs}
              collections={collections}
              tabletMode={tabletMode}
              onOpenDoc={(d) => {
                buzz();
                updateDoc(d.id, { lastReadMs: Date.now() });
                setOverlay({ type: 'reader', docId: d.id });
              }}
              onEditDoc={(d) => openEditorForDoc(d)}
              onUpdateDoc={updateDoc}
              onImportFile={handleImportFile}
              onOpenStats={() => setOverlay({ type: 'stats' })}
              onNotify={notify}
            />
          )}

          {tab === 'tools' && (
            <ToolsScreen
              lang={lang}
              docs={docs}
              quotes={quotes}
              onLaunchPdfEditor={(d, t) => openEditorForDoc(d, t)}
              onLaunchTextEditor={(d) => setOverlay({ type: 'textEditor', docId: d.id })}
              onLaunchImageEditor={(d) => setOverlay({ type: 'imageEditor', docId: d.id })}
              onOpenArchive={(d) => setOverlay({ type: 'reader', docId: d.id })}
              onAddDoc={addDoc}
              onUpdateDoc={updateDoc}
              onNotify={notify}
            />
          )}

          {tab === 'scanner' && (
            <ScannerOcrScreen
              lang={lang}
              onCreateScannedPdf={(title, count, ocrText, imageUrl) => {
                const id = `scan-${Date.now()}`;
                addDoc({
                  id,
                  titleAr: title,
                  titleEn: title,
                  authorAr: 'ماسح JObat + OCR',
                  authorEn: 'JObat CameraX + OCR',
                  ext: 'pdf',
                  category: 'pdf',
                  sizeBytes: count * 540_000,
                  pageCount: count,
                  currentPage: 1,
                  lastReadMs: Date.now(),
                  addedMs: Date.now(),
                  coverStyle: { bgFrom: '#1B1915', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'photo', imageUrl },
                  favorite: false,
                  archived: false,
                  trashed: false,
                  vaultLocked: false,
                  collections: ['عقود وأعمال'],
                  tags: ['OCR', 'مسح'],
                  bookmarks: [],
                  toc: [],
                  pages: Array.from({ length: count }, (_, idx) => ({
                    id: `${id}-p${idx}`,
                    headingAr: `${title} — صفحة ${idx + 1}`,
                    headingEn: `${title} — Page ${idx + 1}`,
                    paragraphsAr: ocrText.split('\n\n'),
                    paragraphsEn: ocrText.split('\n\n'),
                    imageUrl: idx === 0 ? imageUrl : undefined,
                  })),
                });
                notify(isAr ? 'حُفظ ملف PDF الممسوح في المكتبة' : 'Saved scanned PDF into Library');
                setTab('library');
              }}
              onNotify={notify}
            />
          )}

          {tab === 'collections' && (
            <CollectionsVaultScreen
              lang={lang}
              docs={docs}
              collections={collections}
              onCreateCollection={(name) => {
                if (!collections.includes(name)) {
                  setCollections((prev) => [...prev, name]);
                  notify(isAr ? `أُنشئت مجموعة "${name}"` : `Created collection "${name}"`);
                }
              }}
              onOpenDoc={(d) => setOverlay({ type: 'reader', docId: d.id })}
              onUpdateDoc={updateDoc}
              onDeleteForever={(id) => setDocs((prev) => prev.filter((d) => d.id !== id))}
              onNotify={notify}
            />
          )}

          {tab === 'settings' && (
            <SettingsScreen
              lang={lang}
              theme={theme}
              reduceMotion={reduceMotion}
              haptics={haptics}
              biometricLock={biometricLock}
              continueDoc={continueDoc}
              onThemeChange={setTheme}
              onLangChange={setLang}
              onReduceMotionChange={setReduceMotion}
              onHapticsChange={setHaptics}
              onBiometricChange={setBiometricLock}
              onExportBackup={exportBackup}
              onImportBackup={importBackup}
              onOpenStats={() => setOverlay({ type: 'stats' })}
              onOpenLicenses={() => setOverlay({ type: 'licenses' })}
              onReplayOnboarding={() => setOverlay({ type: 'onboarding' })}
              onOpenCodeInspector={() => setOverlay({ type: 'codeInspector' })}
              onOpenScanner={() => setTab('scanner')}
              onOpenDoc={(d) => setOverlay({ type: 'reader', docId: d.id })}
            />
          )}

          {/* Floating Frosted Glass Bottom Navigation with Animated Champagne Indicator */}
          {!overlay && (
            <nav
              aria-label="Primary navigation"
              className="absolute inset-x-3.5 bottom-3 z-20 h-[62px] rounded-[24px] jb-glass px-1.5 flex items-center"
              style={{
                border: '1px solid var(--jb-border-strong)',
                boxShadow: '0 14px 36px rgba(0, 0, 0, 0.42)',
              }}
            >
              {navItems.map((item, idx) => {
                const Icon = item.icon;
                const active = idx === activeNavIdx;
                const isCenterScan = item.id === 'scanner';
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      buzz();
                      setTab(item.id);
                    }}
                    className="relative flex-1 h-full flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all"
                    style={{
                      color: active ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                    }}
                  >
                    {/* Animated Champagne Gold Top Pill Indicator */}
                    <span
                      className="absolute top-1.5 h-[2.5px] rounded-full transition-all"
                      style={{
                        width: active ? 24 : 0,
                        opacity: active ? 1 : 0,
                        background: 'var(--jb-champagne-grad)',
                      }}
                    />
                    {isCenterScan ? (
                      <div
                        className="w-9 h-9 rounded-2xl flex items-center justify-center transition-transform"
                        style={{
                          background: active ? 'var(--jb-champagne-grad)' : 'var(--jb-accent-soft)',
                          color: active ? 'var(--jb-accent-on)' : 'var(--jb-accent)',
                          border: active ? 'none' : '1px solid var(--jb-border-strong)',
                        }}
                      >
                        <Icon size={17} strokeWidth={1.9} />
                      </div>
                    ) : (
                      <>
                        <Icon size={17} strokeWidth={active ? 2 : 1.6} />
                        <span className="text-[9.5px] font-medium leading-none mt-0.5">
                          {isAr ? item.ar : item.en}
                        </span>
                      </>
                    )}
                  </button>
                );
              })}
            </nav>
          )}

          {/* Full-Screen Overlays inside Phone */}
          {overlay?.type === 'reader' && overlayDoc && (
            <ReaderScreen
              lang={lang}
              doc={overlayDoc}
              settings={readerSettings}
              onUpdateSettings={(patch) => setReaderSettings((prev) => ({ ...prev, ...patch }))}
              onUpdateDoc={updateDoc}
              onAddQuote={(q) =>
                setQuotes((prev) => [{ ...q, id: `q-${Date.now()}`, createdAt: Date.now() }, ...prev])
              }
              onOpenEditor={(d) => openEditorForDoc(d)}
              onOpenArchiveFileInEditor={openArchiveInnerInEditor}
              onRecordReading={recordReading}
              onClose={() => setOverlay(null)}
              onNotify={notify}
            />
          )}

          {overlay?.type === 'pdfEditor' && overlayDoc && (
            <PdfEditorScreen
              lang={lang}
              doc={overlayDoc}
              initialTab={overlay.initialTab}
              savedSignatures={savedSignatures}
              onSaveSignature={(sig) => setSavedSignatures((prev) => [sig, ...prev].slice(0, 4))}
              onUpdateDoc={updateDoc}
              onCreateDocCopy={addDoc}
              onClose={() => setOverlay(null)}
              onNotify={notify}
            />
          )}

          {overlay?.type === 'textEditor' && overlayDoc && (
            <TextEditorScreen
              lang={lang}
              doc={overlayDoc}
              onUpdateDoc={updateDoc}
              onConvertToPdf={(title, content) => {
                const clean = title.replace(/\.\w+$/, '');
                addDoc({
                  ...overlayDoc,
                  id: `txtpdf-${Date.now()}`,
                  titleAr: `${clean}.pdf`,
                  titleEn: `${clean}.pdf`,
                  ext: 'pdf',
                  category: 'pdf',
                  pageCount: 1,
                  currentPage: 1,
                  addedMs: Date.now(),
                  pages: [
                    {
                      id: `tp-${Date.now()}`,
                      headingAr: clean,
                      headingEn: clean,
                      paragraphsAr: content.split('\n\n').filter(Boolean),
                      paragraphsEn: content.split('\n\n').filter(Boolean),
                    },
                  ],
                });
                notify(isAr ? 'تم التحويل إلى PDF وأُضيف للمكتبة' : 'Converted to PDF & saved to Library');
              }}
              onClose={() => setOverlay(null)}
              onNotify={notify}
            />
          )}

          {overlay?.type === 'imageEditor' && overlayDoc && (
            <ImageEditorScreen
              lang={lang}
              doc={overlayDoc}
              onSaveEditedImage={(docId, dataUrl, sizeBytes) => {
                const target = docs.find((d) => d.id === docId);
                if (!target) return;
                updateDoc(docId, {
                  sizeBytes,
                  coverStyle: { ...target.coverStyle, imageUrl: dataUrl },
                  pages: target.pages.map((p, idx) => (idx === 0 ? { ...p, imageUrl: dataUrl } : p)),
                });
              }}
              onClose={() => setOverlay(null)}
              onNotify={notify}
            />
          )}

          {overlay?.type === 'stats' && (
            <StatsOverlay
              lang={lang}
              stats={stats}
              dailyGoal={dailyGoal}
              docsCount={docs.filter((d) => !d.trashed).length}
              quotesCount={quotes.length}
              onGoalChange={setDailyGoal}
              onClose={() => setOverlay(null)}
            />
          )}

          {overlay?.type === 'licenses' && (
            <LicensesOverlay lang={lang} onClose={() => setOverlay(null)} />
          )}

          {overlay?.type === 'onboarding' && (
            <OnboardingScreen
              lang={lang}
              onComplete={(perms) => {
                setBiometricLock(perms.biometric);
                setOverlay(null);
                notify(isAr ? 'تم حفظ الأذونات المحددة (Scoped Storage)' : 'Saved scoped permission preferences');
              }}
            />
          )}

          {showSplash && <SplashScreen lang={lang} onFinish={() => setShowSplash(false)} />}

          {/* Custom Obsidian & Champagne Snackbar */}
          {toast && (
            <div
              role="status"
              className="pointer-events-none absolute inset-x-5 bottom-21 z-50 px-3.5 py-2.5 rounded-2xl text-[11.5px] font-medium text-center shadow-2xl jb-anim-in"
              style={{
                background: 'var(--jb-surface-elevated)',
                color: 'var(--jb-text)',
                border: '1px solid var(--jb-border-strong)',
              }}
            >
              {toast}
            </div>
          )}
        </main>

        {/* Android Gesture Navigation Pill */}
        <div className="h-4 flex items-center justify-center shrink-0">
          <button
            onClick={() => {
              if (overlay && overlay.type !== 'codeInspector') setOverlay(null);
              else setTab('library');
            }}
            aria-label="Home gesture bar"
            className="w-28 h-1 rounded-full opacity-45 hover:opacity-90 transition-opacity cursor-pointer"
            style={{ background: 'var(--jb-text-secondary)' }}
          />
        </div>
      </div>

      {/* Android Codebase & APK Analyzer Inspector Modal */}
      {overlay?.type === 'codeInspector' && (
        <ProjectInspectorModal
          lang={lang}
          onClose={() => setOverlay(null)}
          onNotify={notify}
        />
      )}
    </div>
  );
}

export default App;
