import { DailyStat, DocItem, QuoteItem, ReaderSettings } from '../types';

const now = Date.now();
const hr = 3_600_000;

export const DEFAULT_READER_SETTINGS: ReaderSettings = {
  mode: 'paged',
  theme: 'ivory',
  customBg: '#12151C',
  customFg: '#E8E2D5',
  fontFamily: 'amiri',
  fontSize: 18,
  lineHeight: 1.85,
  marginPx: 22,
  align: 'justify',
  hyphenation: true,
  blueLight: 0,
  blueLightScheduled: false,
  autoCrop: false,
  contrastBoost: false,
  reflowPdf: false,
  rotationLocked: false,
  rtlOverride: null,
};

export const INITIAL_COLLECTIONS: string[] = [
  'الفكر والعمارة',
  'مراجع هندسية',
  'أدب وتراث',
  'عقود وأعمال',
];

export const INITIAL_DOCUMENTS: DocItem[] = [
  {
    id: 'doc-muqaddimah',
    titleAr: 'المقدمة — في طبيعة العمران البشري',
    titleEn: 'The Muqaddimah — On Human Civilization',
    authorAr: 'عبد الرحمن بن خلدون',
    authorEn: 'Ibn Khaldun',
    ext: 'pdf',
    category: 'pdf',
    sizeBytes: 6_480_000,
    pageCount: 5,
    currentPage: 3,
    lastReadMs: now - hr * 1.2,
    addedMs: now - hr * 120,
    coverStyle: { bgFrom: '#171513', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'manuscript' },
    favorite: true,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['أدب وتراث', 'الفكر والعمارة'],
    tags: ['تراث', 'فلسفة', 'عمران'],
    bookmarks: [1, 3],
    toc: [
      { titleAr: 'الفصل الأول: في العمران البشري على الجملة', titleEn: 'Chapter I: Human Civilization in General', page: 1 },
      { titleAr: 'الفصل الثاني: في أثر الإقليم والهواء في الأخلاق', titleEn: 'Chapter II: Geography, Climate & Character', page: 2 },
      { titleAr: 'الفصل الثالث: في الدول والملك والعصبية', titleEn: 'Chapter III: Dynasties, Sovereignty & Cohesion', page: 3 },
      { titleAr: 'الفصل الرابع: في البلدان والأمصار والعمارة', titleEn: 'Chapter IV: Cities, Architecture & Urban Craft', page: 4 },
      { titleAr: 'الفصل الخامس: في الصنائع والعلوم والكتابة', titleEn: 'Chapter V: Arts, Sciences & Calligraphy', page: 5 },
    ],
    pages: [
      {
        id: 'muq-1',
        headingAr: 'الفصل الأول: في العمران البشري على الجملة',
        headingEn: 'Chapter I: Human Civilization in General',
        paragraphsAr: [
          'اعلم أن فن التاريخ فن عزيز المذهب، جم الفوائد، شريف الغاية؛ إذ هو يوقفنا على أحوال الماضين من الأمم في أخلاقهم، والأنبياء في سيرهم، والملوك في دولهم وسياستهم.',
          'والاجتماع الإنساني ضروري، ويعبّر الحكماء عن هذا بقولهم: الإنسان مدني بالطبع، أي لا بد له من الاجتماع الذي هو المدينة في اصطلاحهم، وهو معنى العمران.',
          'فإذا حصل الاجتماع للبشر وتم عمران العالم بهم، فلا بد من وازع يدفع بعضهم عن بعض، وتقوم به موازين العدل واستقرار الصنائع والعلوم.',
        ],
        paragraphsEn: [
          'History is a discipline of noble purpose and abundant wisdom; it acquaints us with the conditions of past nations as reflected in their character, governance, and enduring crafts.',
          'Human social organization is necessary. Philosophers express this truth by saying that humankind is civic by nature—requiring the shared order of the polis, which is the essence of civilization.',
          'Once communities gather and cultivate the earth, measured governance and craft become the twin pillars that sustain scholarship, architecture, and prosperity.',
        ],
      },
      {
        id: 'muq-2',
        headingAr: 'الفصل الثاني: في أثر الإقليم والهواء في الأخلاق',
        headingEn: 'Chapter II: Geography, Climate & Character',
        paragraphsAr: [
          'إن الأقاليم المعتدلة في أوساط المعمور كانت مخصوصة بالاعتدال في المساكن والملابس والأقوات والصنائع، يتخذون البيوت المنجّدة بالحجارة المنمّقة على جهة الصناعة.',
          'ويتناغون في استجادة الآلات والمواعين، وتزدهر بينهم علوم الهندسة والحساب والفلك، لاعتدال المزاج وصفاء الذهن واتصال الحواضر بعضها ببعض.',
        ],
        paragraphsEn: [
          'Temperate regions prosper through harmony in dwelling, craft, and nourishment. Their inhabitants build finely dressed stone houses proportioned with geometric grace.',
          'Among them flourish mathematics, astronomy, and refined bookmaking, sustained by steady trade routes and continuous dialogue among libraries.',
        ],
      },
      {
        id: 'muq-3',
        headingAr: 'الفصل الثالث: في الدول والملك والعصبية',
        headingEn: 'Chapter III: Dynasties, Sovereignty & Cohesion',
        paragraphsAr: [
          'إن الظلم مؤذن بخراب العمران؛ لأن العدوان على أموال الناس يذهب بآمالهم في تحصيلها واكتسابها، فإذا ذهبت آمالهم انقبضت أيديهم عن السعي في العمارة.',
          'وأما العدل فهو الميزان المنصوب بين الخليقة، به تعمر الأمصار، وتغزر الجبايات بالرفق، وتتسع الأسواق، ويأمن الصانع والكاتب والتاجر على ثمرة عمله.',
          'ولهذا كانت الدول في أوائل عهدها أقرب إلى البساطة والرفق والهمّة العالية، فتنهض المعالم الكبرى وتُدوَّن الدواوين وتُحفظ الكتب.',
        ],
        paragraphsEn: [
          'Injustice heralds the ruin of civilization; when people lose confidence in the fruits of their labor, enterprise withers and bustling markets fall silent.',
          'Justice is the balance established among humankind: through gentleness and fair law, cities blossom, crafts multiply, and scholars enjoy the serenity to write.',
          'In their formative era, great states prize simplicity, discipline, and magnanimity—raising timeless monuments and endowing public houses of wisdom.',
        ],
      },
      {
        id: 'muq-4',
        headingAr: 'الفصل الرابع: في البلدان والأمصار والعمارة',
        headingEn: 'Chapter IV: Cities, Architecture & Urban Craft',
        paragraphsAr: [
          'يُراعى في اختطاط المدن دفع المضار وجلب المنافع: طيب الهواء، وسعة المياه العذبة، وقرب المراعي والمحاجر، وحصانة الموضع مع سهولة المسالك.',
          'وصناعة البناء أول صنائع العمران الحضري وأقدمها، تتدرج من الكنّ البسيط إلى القباب والمآذن والأروقة الموزونة بنسب الضوء والظل.',
        ],
        paragraphsEn: [
          'In founding cities, wise planners unite wholesome air, pure running water, accessible stone quarries, and gracious thoroughfares open to trade.',
          'Architecture is the earliest and grandest of urban arts, ascending from humble shelter to proportioned courtyards, domes, and arcades sculpted by light and shadow.',
        ],
      },
      {
        id: 'muq-5',
        headingAr: 'الفصل الخامس: في الصنائع والعلوم والكتابة',
        headingEn: 'Chapter V: Arts, Sciences & Calligraphy',
        paragraphsAr: [
          'الخط والكتابة من عداد الصنائع الإنسانية، وهي رسوم وأشكال حرفية تدل على الكلمات المسموعة الدالة على ما في النفس، وبها تنتقل العلوم من جيل إلى جيل.',
          'وإنما تجود صناعة الخط والوراقة وتذهيب المصاحف والكتب حيث يرسخ العمران وتسمو الذائقة في الإتقان والتناسب دون تكلّف.',
        ],
        paragraphsEn: [
          'Calligraphy and bookcraft rank among the noblest human arts—visible forms preserving spoken thought across centuries and distant lands.',
          'Letterforms, paper-making, and subtle gold illumination reach perfection where quiet precision, proportion, and restraint are cherished above ornament.',
        ],
      },
    ],
    annotations: [],
    formFields: {
      reviewer: 'م. طارق المنصور',
      edition: 'طبعة دار القلم المحققة — 2026',
      catalogNo: 'JB-ARC-0142',
      verified: 'نعم — نسخة مطابقة للأصل',
    },
  },
  {
    id: 'doc-architecture-epub',
    titleAr: 'جماليات الظل والضوء في العمارة الهادئة',
    titleEn: 'Poetics of Shadow & Light in Quiet Architecture',
    authorAr: 'د. ليلى الحسن',
    authorEn: 'Dr. Layla Al-Hassan',
    ext: 'epub',
    category: 'ebook',
    sizeBytes: 2_340_000,
    pageCount: 4,
    currentPage: 2,
    lastReadMs: now - hr * 5,
    addedMs: now - hr * 96,
    coverStyle: { bgFrom: '#1E2128', bgTo: '#0E1015', accent: '#C8A55C', pattern: 'arch' },
    favorite: true,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['الفكر والعمارة'],
    tags: ['عمارة', 'تصميم', 'فلسفة'],
    bookmarks: [2],
    toc: [
      { titleAr: 'مدخل: صمت الحجر ودفء النور', titleEn: 'Prelude: Silent Stone & Warm Light', page: 1 },
      { titleAr: 'الفناء الداخلي وهندسة السكينة', titleEn: 'The Courtyard & Geometry of Stillness', page: 2 },
      { titleAr: 'المواد النبيلة: البازلت والذهب المطفي', titleEn: 'Noble Materials: Obsidian & Brushed Brass', page: 3 },
      { titleAr: 'خاتمة: الفخامة في الاقتصاد البصري', titleEn: 'Epilogue: Luxury in Visual Restraint', page: 4 },
    ],
    pages: [
      {
        id: 'arch-1',
        headingAr: 'مدخل: صمت الحجر ودفء النور',
        headingEn: 'Prelude: Silent Stone & Warm Light',
        paragraphsAr: [
          'لا تُقاس فخامة الفراغ المعماري بكثرة زخارفه، بل بقدرته على احتضان الضوء وترويضه على أسطح الحجر الداكن والخشب المعتّق.',
          'حين يدخل شعاع الشمس المائل عبر المشربية أو الشق العلوي، يتحول الجدار الصامت إلى ساعة ضوئية حيّة تمنح القارئ والساكن طمأنينة عميقة.',
        ],
        paragraphsEn: [
          'True architectural luxury is never measured by excess ornament, but by how a room receives daylight across honed dark stone and warm linen plaster.',
          'When a slender beam of afternoon sun grazes a quiet wall, the surface becomes a living sundial—inviting contemplation, focus, and unhurried reading.',
        ],
      },
      {
        id: 'arch-2',
        headingAr: 'الفناء الداخلي وهندسة السكينة',
        headingEn: 'The Courtyard & Geometry of Stillness',
        paragraphsAr: [
          'يعمل الفناء الداخلي كرئة مناخية وبصرية معًا؛ فهو يعزل ضجيج المدينة ويمنح البيت سماءه الخاصة وإيقاعه الهادئ.',
          'وبنفس الفلسفة تُصمَّم واجهات القراءة الرفيعة: هوامش متوازنة، تباين مريح للعين، وأدوات تحضر عند الحاجة وتختفي بلطف في لحظة التركيز.',
        ],
        paragraphsEn: [
          'An interior courtyard acts as both thermal sanctuary and visual pause—filtering urban noise while framing a private square of sky.',
          'Great reading interfaces obey the very same law: generous margins, calibrated contrast, and tools that glide away the moment deep reading begins.',
        ],
      },
      {
        id: 'arch-3',
        headingAr: 'المواد النبيلة: البازلت والذهب المطفي',
        headingEn: 'Noble Materials: Obsidian & Brushed Brass',
        paragraphsAr: [
          'يجتمع حجر الأوبسيديان الأسود مع لمسات النحاس الشامباني المطفي في ثنائية خالدة: عمقٌ يمتص التشتت، وبريقٌ خافت يرشد العين إلى الجوهر.',
        ],
        paragraphsEn: [
          'Honed obsidian stone paired with muted champagne brass forms a timeless duet: quiet depth that absorbs distraction, and a gentle gleam that guides the eye.',
        ],
      },
      {
        id: 'arch-4',
        headingAr: 'خاتمة: الفخامة في الاقتصاد البصري',
        headingEn: 'Epilogue: Luxury in Visual Restraint',
        paragraphsAr: [
          'كل تفصيل يبقى في التصميم النهائي يجب أن يبرر وجوده بالوظيفة والجمال معًا؛ فالأناقة الحقيقية هي ما يتبقى بعد إزالة كل ما هو زائد.',
        ],
        paragraphsEn: [
          'Every element allowed to remain must earn its place through both utility and grace. Elegance is what endures when everything superfluous is removed.',
        ],
      },
    ],
  },
  {
    id: 'doc-optics-djvu',
    titleAr: 'كتاب المناظر — مخطوطة البصريات والانكسار',
    titleEn: 'Book of Optics — Treatise on Vision & Refraction',
    authorAr: 'الحسن بن الهيثم',
    authorEn: 'Ibn al-Haytham (Alhazen)',
    ext: 'djvu',
    category: 'comic_djvu',
    sizeBytes: 9_120_000,
    pageCount: 3,
    currentPage: 1,
    lastReadMs: now - hr * 18,
    addedMs: now - hr * 210,
    coverStyle: { bgFrom: '#231C14', bgTo: '#110E0A', accent: '#D4B26A', pattern: 'geometric' },
    favorite: false,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['أدب وتراث', 'مراجع هندسية'],
    tags: ['تراث', 'بصريات', 'مخطوطات'],
    bookmarks: [],
    toc: [
      { titleAr: 'المقالة الأولى: في كيفية الإبصار بالجملة', titleEn: 'Book I: On the Manner of Vision', page: 1 },
      { titleAr: 'المقالة الثانية: في الخزانة المظلمة (القمرة)', titleEn: 'Book II: The Camera Obscura Experiment', page: 2 },
      { titleAr: 'المقالة الثالثة: في الانعكاس عن المرايا', titleEn: 'Book III: Reflection from Curved Mirrors', page: 3 },
    ],
    pages: [
      {
        id: 'opt-1',
        headingAr: 'المقالة الأولى: في كيفية الإبصار بالجملة',
        headingEn: 'Book I: On the Manner of Vision',
        paragraphsAr: [
          'نجعل مبدأ البحث استقراء الموجودات وتصفّح أحوال المبصرات وتمييز خواص الجزئيات، ونبتدئ في البحث مع خصمنا بأن نجعل أنفسنا خصمًا لكل ما ننظر فيه.',
          'إن الإبصار إنما يكون بأشعة الضوء الصادرة من الأجسام المضيئة أو المنعكسة عن الأجسام المستضيئة إلى البصر على خطوط مستقيمة.',
        ],
        paragraphsEn: [
          'We begin our inquiry by observing phenomena, testing hypotheses by experiment, and making ourselves impartial critics of every claim we examine.',
          'Vision occurs through rays of light emitted or reflected from visible objects entering the eye along rectilinear paths.',
        ],
      },
      {
        id: 'opt-2',
        headingAr: 'المقالة الثانية: في الخزانة المظلمة (القمرة)',
        headingEn: 'Book II: The Camera Obscura Experiment',
        paragraphsAr: [
          'إذا قابلت عدة سُرُج متفرقة ثقبًا ضيقًا ينفذ إلى بيت مظلم، ظهر مقابل الثقب على الحائط خيال كل سراج على حدة دون أن تختلط الأضواء في الهواء.',
        ],
        paragraphsEn: [
          'When several lamps stand opposite a fine aperture leading into a darkened chamber, each casts its distinct inverted image upon the wall without mingling in transit.',
        ],
      },
      {
        id: 'opt-3',
        headingAr: 'المقالة الثالثة: في الانعكاس عن المرايا',
        headingEn: 'Book III: Reflection from Curved Mirrors',
        paragraphsAr: [
          'زاوية السقوط تساوي زاوية الانعكاس في جميع السطوح الصقيلة المستوية والكرية والأسطوانية، ويقع الشعاعان والعمود في مستوى واحد.',
        ],
        paragraphsEn: [
          'The angle of incidence equals the angle of reflection across planar, spherical, and cylindrical surfaces, all lying within a single normal plane.',
        ],
      },
    ],
  },
  {
    id: 'doc-md-notes',
    titleAr: 'معمارية JObat — ملاحظات النواة والأداء.md',
    titleEn: 'JObat Architecture — NDK & Compose Notes.md',
    authorAr: 'فريق الهندسة',
    authorEn: 'Core Engineering',
    ext: 'md',
    category: 'office_code',
    sizeBytes: 48_600,
    pageCount: 2,
    currentPage: 1,
    lastReadMs: now - hr * 3,
    addedMs: now - hr * 48,
    coverStyle: { bgFrom: '#141820', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'code' },
    favorite: true,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['مراجع هندسية'],
    tags: ['برمجة', 'أندرويد', 'NDK'],
    bookmarks: [],
    toc: [{ titleAr: 'نظرة عامة على النواة', titleEn: 'Core Overview', page: 1 }],
    rawCode: `# 𝒥𝒪 bat — Obsidian & Champagne Architecture

## 1. Core Engine Isolation (GPL-3.0)
- **:core-native** — C++20 JNI bridge over MuPDF \`fz_context\` & DjVuLibre (\`-Oz -flto\`).
- **:core-engine** — Clean fork of Librera Reader handling 36+ formats, archive streaming & TTS.
- **:design-system** — Generated 1:1 from \`tokens.json\` (Dark, Light, AMOLED, Sepia, Dynamic).

## 2. Performance Targets
- Cold startup: **410 ms** with \`BaselineProfile\` (target < 600 ms).
- Release APK (\`arm64-v8a\`): **24.8 MB** with R8 fullMode + ABI splits.
- Memory ceiling: 24 MB \`LruCache\` tile pool for 4,000-page PDFs.

\`\`\`kotlin
val result = libreraEngine.open(file = pdfFile, emFontSize = 15f)
when (result) {
    is NativeOpenResult.Ready -> renderTiles(result.handle, result.pageCount)
    is NativeOpenResult.PasswordRequired -> promptUnlockDialog(result.handle)
    is NativeOpenResult.CorruptedOrUnsupported -> showDiagnosticBanner(result.reason)
}
\`\`\`

## 3. Privacy Guarantee
Zero Firebase, zero Crashlytics, zero AdMob, \`usesCleartextTraffic="false"\`, and hardware-backed **AES-256-GCM** Encrypted Vault.
`,
    pages: [
      {
        id: 'md-1',
        headingAr: 'معمارية JObat — النواة والأداء',
        headingEn: 'JObat Architecture — NDK & Performance',
        paragraphsAr: [
          'يفصل التطبيق نواة القراءة الأصلية المبنية على Librera Reader وMuPDF C++20 داخل وحدتي :core-native و:core-engine مع ذاكرة تخزين مؤقت LruCache ذكية للملفات الضخمة.',
          'حجم الحزمة النهائية لمعمارية arm64-v8a يبلغ 24.8 ميجابايت فقط مع زمن إقلاع بارد 410 مللي ثانية بفضل Baseline Profiles.',
        ],
        paragraphsEn: [
          'JObat isolates the Librera Reader + MuPDF C++20 rendering core into :core-native and :core-engine with a bounded 24 MB LruCache tile pool.',
          'Final arm64-v8a release APK measures 24.8 MB with a 410 ms cold start powered by Baseline Profiles.',
        ],
      },
      {
        id: 'md-2',
        headingAr: 'ضمان الخصوصية والترخيص GPL-3.0',
        headingEn: 'Privacy Guarantee & GPL-3.0 Compliance',
        paragraphsAr: [
          'صفر إعلانات، صفر تتبع، عمل كامل دون إنترنت، وخزنة مشفرة بمعيار AES-256-GCM عبر Android Keystore.',
        ],
        paragraphsEn: [
          'Zero ads, zero telemetry, 100% offline execution, and hardware-backed AES-256-GCM Keystore Encrypted Vault.',
        ],
      },
    ],
  },
  {
    id: 'doc-csv-catalog',
    titleAr: 'فهرس المخطوطات والطبعات النادرة.csv',
    titleEn: 'Rare_Manuscripts_Catalog.csv',
    authorAr: 'أرشيف الدار',
    authorEn: 'Curatorial Archive',
    ext: 'csv',
    category: 'office_code',
    sizeBytes: 18_400,
    pageCount: 1,
    currentPage: 1,
    lastReadMs: now - hr * 30,
    addedMs: now - hr * 140,
    coverStyle: { bgFrom: '#181C19', bgTo: '#0B0D0C', accent: '#8FB99E', pattern: 'code' },
    favorite: false,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['أدب وتراث'],
    tags: ['فهرسة', 'بيانات'],
    bookmarks: [],
    toc: [],
    rawCode: `ID,Title,Author,Year,Format,Folios,City
MS-001,Al-Muqaddimah,Ibn Khaldun,1377,PDF,312,Tunis
MS-002,Kitab al-Manazir,Ibn al-Haytham,1021,DJVU,248,Cairo
MS-003,Al-Qanun fi al-Tibb,Ibn Sina,1025,EPUB,410,Isfahan
MS-004,Rihlat Ibn Battuta,Ibn Battuta,1355,FB2,286,Tangier
MS-005,Hayy ibn Yaqzan,Ibn Tufayl,1169,MOBI,144,Granada
MS-006,Al-Jabr wal-Muqabala,Al-Khwarizmi,820,PDF,128,Baghdad`,
    pages: [
      {
        id: 'csv-1',
        headingAr: 'فهرس المخطوطات والطبعات النادرة',
        headingEn: 'Rare Manuscripts Catalog (CSV)',
        paragraphsAr: ['جدول مفهرس يضم 6 مخطوطات كلاسيكية من تونس والقاهرة وأصفهان وطنجة وغرناطة وبغداد. افتح محرر النصوص لمعاينة الجدول وتعديله.'],
        paragraphsEn: ['Indexed dataset of 6 classical manuscripts across Tunis, Cairo, Isfahan, Tangier, Granada, and Baghdad. Open in Text Editor for live table view.'],
      },
    ],
  },
  {
    id: 'doc-html-specimen',
    titleAr: 'قالب الطباعة الذهبية.html',
    titleEn: 'Obsidian_Type_Specimen.html',
    authorAr: 'استوديو التصميم',
    authorEn: 'Design Systems Lab',
    ext: 'html',
    category: 'office_code',
    sizeBytes: 14_200,
    pageCount: 1,
    currentPage: 1,
    lastReadMs: now - hr * 42,
    addedMs: now - hr * 160,
    coverStyle: { bgFrom: '#1C1820', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'minimal' },
    favorite: false,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['مراجع هندسية'],
    tags: ['برمجة', 'تصميم'],
    bookmarks: [],
    toc: [],
    rawCode: `<section style="font-family: Georgia, serif; background: #0B0C10; color: #F4F0E8; padding: 24px; border-radius: 16px; border: 1px solid rgba(212,178,106,0.3);">
  <p style="color: #D4B26A; letter-spacing: 0.18em; font-size: 11px; text-transform: uppercase; margin: 0 0 8px;">Obsidian &amp; Champagne</p>
  <h1 style="font-size: 26px; margin: 0 0 12px; font-weight: 600;">𝒥𝒪 bat Type Specimen</h1>
  <p style="color: #9FA4B0; line-height: 1.7; font-size: 14px; margin: 0;">
    Quiet luxury rests in balanced measure, crisp optical margins, and zero visual clutter.
  </p>
</section>`,
    pages: [
      {
        id: 'html-1',
        headingAr: 'قالب الطباعة الذهبية (HTML)',
        headingEn: 'Obsidian Type Specimen (HTML)',
        paragraphsAr: ['ملف واجهة HTML قابل للعرض المباشر والتحرير الفوري مع تلوين الكود والمعاينة الحية.'],
        paragraphsEn: ['Formatted HTML specimen document supporting both formatted reading and live syntax-highlighted code editing.'],
      },
    ],
  },
  {
    id: 'doc-photo-manuscript',
    titleAr: 'مخطوطة الأوبسيديان والقهوة الصباحية.jpg',
    titleEn: 'Obsidian_Manuscript_Still_Life.jpg',
    authorAr: 'عدسة الاستوديو',
    authorEn: 'Atelier Photography',
    ext: 'jpg',
    category: 'image',
    sizeBytes: 3_840_000,
    pageCount: 1,
    currentPage: 1,
    lastReadMs: now - hr * 8,
    addedMs: now - hr * 72,
    coverStyle: {
      bgFrom: '#1A1612',
      bgTo: '#0B0C10',
      accent: '#D4B26A',
      pattern: 'photo',
      imageUrl: '/images/sample-photo.jpg',
    },
    favorite: true,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['الفكر والعمارة'],
    tags: ['تصوير', 'تراث'],
    bookmarks: [],
    toc: [],
    pages: [
      {
        id: 'img-1',
        headingAr: 'مخطوطة الأوبسيديان والقهوة الصباحية',
        headingEn: 'Obsidian Manuscript Still Life',
        paragraphsAr: [],
        paragraphsEn: [],
        imageUrl: '/images/sample-photo.jpg',
      },
    ],
  },
  {
    id: 'doc-locked-contract',
    titleAr: 'عقد التصميم المعماري — محمي بكلمة مرور',
    titleEn: 'Architectural Retainer Agreement (Locked)',
    authorAr: 'مكتب دار الأفق',
    authorEn: 'Dar Al-Ufuq Studio',
    ext: 'pdf',
    category: 'pdf',
    sizeBytes: 1_920_000,
    pageCount: 2,
    currentPage: 1,
    lastReadMs: now - hr * 26,
    addedMs: now - hr * 100,
    coverStyle: { bgFrom: '#211B13', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'minimal' },
    favorite: false,
    archived: false,
    trashed: false,
    vaultLocked: false,
    password: '1234',
    collections: ['عقود وأعمال'],
    tags: ['عقود', 'عمارة'],
    bookmarks: [],
    toc: [
      { titleAr: 'البند الأول: نطاق العمل والتسليمات', titleEn: 'Article 1: Scope & Deliverables', page: 1 },
      { titleAr: 'البند الثاني: السرية وحقوق الملكية', titleEn: 'Article 2: Confidentiality & IP', page: 2 },
    ],
    pages: [
      {
        id: 'con-1',
        headingAr: 'البند الأول: نطاق العمل والتسليمات المعمارية',
        headingEn: 'Article 1: Architectural Scope & Deliverables',
        paragraphsAr: [
          'يلتزم الطرف الثاني بإعداد المخططات التنفيذية الكاملة لجناح المكتبة الخاصة وقاعة المخطوطات وفق معايير الإضاءة المتحفية والعزل الصوتي.',
          'يمكنك فتح هذا العقد في محرر PDF لإضافة توقيعك المحفوظ وختم الاعتماد وتعبئة حقول النموذج (AcroForms).',
        ],
        paragraphsEn: [
          'The Studio shall deliver complete architectural drawings for the Private Library Pavilion, incorporating museum-grade lighting and acoustic isolation.',
          'Open this contract in the PDF Editor to place your reusable signature, official approval stamp, and complete AcroForm fields.',
        ],
      },
      {
        id: 'con-2',
        headingAr: 'البند الثاني: السرية وحقوق الملكية الفكرية',
        headingEn: 'Article 2: Confidentiality & Intellectual Property',
        paragraphsAr: [
          'تُحفظ جميع المخططات وجداول المواد بسرية تامة بين الطرفين ولا يجوز تداولها إلا بموافقة خطية موقّعة.',
        ],
        paragraphsEn: [
          'All drawings, material schedules, and specifications remain strictly confidential between both signatories.',
        ],
      },
    ],
    formFields: {
      reviewer: 'د. سامي الكيلاني',
      edition: 'العقد التنفيذي رقم 2026/09',
      catalogNo: 'CTR-9920',
      verified: 'بانتظار التوقيع النهائي',
    },
  },
  {
    id: 'doc-archive-bundle',
    titleAr: 'حزمة أبحاث الخط العربي والطباعة.zip',
    titleEn: 'Arabic_Typography_Research_Pack.zip',
    authorAr: 'مجمع الحرف',
    authorEn: 'Type Foundry Archive',
    ext: 'zip',
    category: 'archive',
    sizeBytes: 12_450_000,
    pageCount: 3,
    currentPage: 1,
    lastReadMs: now - hr * 55,
    addedMs: now - hr * 240,
    coverStyle: { bgFrom: '#1A1D24', bgTo: '#0B0C10', accent: '#B8914A', pattern: 'geometric' },
    favorite: false,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['مراجع هندسية'],
    tags: ['تراث', 'تصميم'],
    bookmarks: [],
    toc: [],
    archiveEntries: [
      {
        name: '01-naskh-proportions.md',
        ext: 'md',
        sizeKb: 24,
        content: '# نسب خط النسخ الكلاسيكي\n\nيُبنى حرف الألف على ميزان النقطة المربعة بقلم القصب، وتتفرع منه دوائر النون والسين بانسجام هندسي بديع.',
      },
      {
        name: '02-kufi-grid-spec.xml',
        ext: 'xml',
        sizeKb: 16,
        content: '<?xml version="1.0" encoding="UTF-8"?>\n<typeface family="JobatKufi" weight="500" rtl="true">\n  <metrics capHeight="720" xHeight="510" baselineGrid="8" />\n</typeface>',
      },
      {
        name: '03-colophon-notes.txt',
        ext: 'txt',
        sizeKb: 9,
        content: 'Colophon — Extracted seamlessly in memory by JObat ArchiveBrowserEngine (ZIP / RAR / 7z / FB2.ZIP) with zero temporary disk leaks.',
      },
    ],
    pages: [
      {
        id: 'zip-1',
        headingAr: 'أرشيف داخلي: حزمة أبحاث الخط العربي',
        headingEn: 'Archive Package: Arabic Typography Research',
        paragraphsAr: ['يحتوي هذا الأرشيف على 3 ملفات قابلة للفتح المباشر دون فك ضغط خارجي.'],
        paragraphsEn: ['Contains 3 inner documents browseable and openable directly inside JObat.'],
      },
    ],
  },
  {
    id: 'doc-cbz-atlas',
    titleAr: 'أطلس المدن الأندلسية المصوّر',
    titleEn: 'Illustrated Atlas of Andalusian Courtyards',
    authorAr: 'كريم بنجلون',
    authorEn: 'Karim Benjelloun',
    ext: 'cbz',
    category: 'comic_djvu',
    sizeBytes: 15_800_000,
    pageCount: 3,
    currentPage: 1,
    lastReadMs: now - hr * 64,
    addedMs: now - hr * 300,
    coverStyle: { bgFrom: '#1F1916', bgTo: '#0B0C10', accent: '#D4B26A', pattern: 'arch' },
    favorite: false,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['الفكر والعمارة'],
    tags: ['عمارة', 'تصوير'],
    bookmarks: [],
    toc: [
      { titleAr: 'لوحة ١: بهو السباع — غرناطة', titleEn: 'Plate I: Court of the Lions — Granada', page: 1 },
      { titleAr: 'لوحة ٢: عقود قرطبة المزدوجة', titleEn: 'Plate II: Double Arches of Cordoba', page: 2 },
      { titleAr: 'لوحة ٣: حدائق العريف المائية', titleEn: 'Plate III: Water Gardens of Generalife', page: 3 },
    ],
    pages: [
      {
        id: 'cbz-1',
        headingAr: 'لوحة ١: بهو السباع — غرناطة',
        headingEn: 'Plate I: Court of the Lions — Granada',
        paragraphsAr: ['مائة وأربعة وعشرون عمودًا من الرخام الأبيض تحمل عقودًا مخرّمة تحاكي النسب الموسيقية والهندسية الدقيقة (١ : √٢).'],
        paragraphsEn: ['One hundred and twenty-four slender white marble columns support filigree arcades proportioned on the classical 1 : √2 harmonic ratio.'],
        imageUrl: '/images/sample-photo.jpg',
      },
      {
        id: 'cbz-2',
        headingAr: 'لوحة ٢: عقود قرطبة المزدوجة',
        headingEn: 'Plate II: Double Arches of Cordoba',
        paragraphsAr: ['ابتكار إنشائي فريد يضاعف ارتفاع السقف ويسمح بتخلل الضوء الهادئ عبر غابة من الأعمدة الرشيقة.'],
        paragraphsEn: ['A structural triumph doubling ceiling height while diffusing serene daylight across a rhythmic forest of stone columns.'],
      },
      {
        id: 'cbz-3',
        headingAr: 'لوحة ٣: حدائق العريف المائية',
        headingEn: 'Plate III: Water Gardens of Generalife',
        paragraphsAr: ['تعمل القنوات المائية كمرآة تعكس السماء والأروقة وتلطّف حرارة الصيف بهمس الماء المتصل.'],
        paragraphsEn: ['Slender water channels mirror sky and colonnade alike, cooling summer air with an unbroken whisper of water.'],
      },
    ],
  },
  {
    id: 'doc-mobi-hayy',
    titleAr: 'حي بن يقظان — رسالة فلسفية',
    titleEn: 'Hayy ibn Yaqzan — A Philosophical Tale',
    authorAr: 'أبو بكر بن طفيل',
    authorEn: 'Ibn Tufayl',
    ext: 'mobi',
    category: 'ebook',
    sizeBytes: 1_180_000,
    pageCount: 3,
    currentPage: 3,
    lastReadMs: now - hr * 80,
    addedMs: now - hr * 360,
    coverStyle: { bgFrom: '#161A1E', bgTo: '#0B0C10', accent: '#C4A25E', pattern: 'manuscript' },
    favorite: false,
    archived: false,
    trashed: false,
    vaultLocked: false,
    collections: ['أدب وتراث'],
    tags: ['فلسفة', 'تراث'],
    bookmarks: [1],
    toc: [{ titleAr: 'التأمل الأول في نظام الكون', titleEn: 'First Contemplation of the Cosmos', page: 1 }],
    pages: [
      {
        id: 'hayy-1',
        headingAr: 'التأمل الأول في نظام الكون',
        headingEn: 'First Contemplation of the Cosmos',
        paragraphsAr: ['تأمّل حيّ في الكائنات من حوله فوجدها على كثرة تنوعها تترابط في نظام واحد بديع لا خلل فيه ولا اضطراب.'],
        paragraphsEn: ['Observing island life in solitude, Hayy perceived beneath manifold forms a single harmonious order governed by cause and wisdom.'],
      },
      {
        id: 'hayy-2',
        headingAr: 'من الحس والتجربة إلى البرهان العقلي',
        headingEn: 'From Observation to Rational Insight',
        paragraphsAr: ['تدرّج عقله من مشاهدة الجزئيات المحسوسة إلى استنباط القوانين الكلية دون معلم سوى الفطرة الصافية والتأمل الصبور.'],
        paragraphsEn: ['Step by step, unaided reason ascended from careful sensory observation to universal principles of nature and ethics.'],
      },
      {
        id: 'hayy-3',
        headingAr: 'لقاء أبسال واتفاق الحكمة',
        headingEn: 'Meeting Absal & Harmony of Truth',
        paragraphsAr: ['فلما التقى بأبسال أدركا أن الحقيقة التي تُدرك بالبصيرة الصادقة توافق الحكمة النبيلة في جوهرها وغايتها.'],
        paragraphsEn: ['When Absal arrived, both discovered that contemplative inquiry and noble ethics converge upon the very same luminous truth.'],
      },
    ],
  },
  {
    id: 'doc-vault-secret',
    titleAr: 'سجل الملكية الفكرية والمفاتيح الخاصة (سري)',
    titleEn: 'Private IP Ledger & Board Minutes (AES-256)',
    authorAr: 'الخزنة المشفرة',
    authorEn: 'Encrypted Keystore Vault',
    ext: 'pdf',
    category: 'pdf',
    sizeBytes: 890_000,
    pageCount: 2,
    currentPage: 1,
    lastReadMs: now - hr * 12,
    addedMs: now - hr * 50,
    coverStyle: { bgFrom: '#1D1710', bgTo: '#09090C', accent: '#D4B26A', pattern: 'minimal' },
    favorite: false,
    archived: false,
    trashed: false,
    vaultLocked: true,
    collections: ['عقود وأعمال'],
    tags: ['عقود', 'سري'],
    bookmarks: [],
    toc: [],
    pages: [
      {
        id: 'vlt-1',
        headingAr: 'وثيقة مشفرة بمعيار AES-256-GCM (Android Keystore)',
        headingEn: 'AES-256-GCM Sealed Document (Android Keystore)',
        paragraphsAr: [
          'هذه الوثيقة محفوظة داخل الخزنة المشفرة لتطبيق 𝒥𝒪 bat باستخدام EncryptedFile ومفتاح عتادي في شريحة الأمان.',
          'عند إغلاق الخزنة أو مغادرة التطبيق، تُمسح الذاكرة المؤقتة فورًا ولا يظهر الملف في البحث العام أو التطبيقات الخارجية.',
        ],
        paragraphsEn: [
          'This confidential dossier is encrypted at rest via AndroidX Security EncryptedFile (AES256_GCM_HKDF_4KB) backed by Android Keystore.',
          'Upon locking the Vault or backgrounding JObat, all decrypted buffers are immediately zeroed and excluded from public FTS results.',
        ],
      },
      {
        id: 'vlt-2',
        headingAr: 'ملحق براءات التصميم وتوقيعات الاعتماد',
        headingEn: 'Annex: Design Registrations & Signatures',
        paragraphsAr: ['رقم الإيداع المرجعي: JB-VAULT-2026-8841 — جميع البيانات محفوظة محليًا على الجهاز بنسبة 100%.'],
        paragraphsEn: ['Registration Reference: JB-VAULT-2026-8841 — Stored 100% offline on device with zero cloud exposure.'],
      },
    ],
  },
];

export const INITIAL_QUOTES: QuoteItem[] = [
  {
    id: 'q-1',
    docId: 'doc-muqaddimah',
    docTitle: 'المقدمة — في طبيعة العمران البشري',
    author: 'ابن خلدون',
    page: 3,
    text: 'وأما العدل فهو الميزان المنصوب بين الخليقة، به تعمر الأمصار، ويأمن الصانع والكاتب على ثمرة عمله.',
    note: 'قاعدة تأسيسية في فلسفة العمران والاقتصاد.',
    color: '#D4B26A',
    createdAt: now - hr * 6,
  },
  {
    id: 'q-2',
    docId: 'doc-architecture-epub',
    docTitle: 'Poetics of Shadow & Light in Quiet Architecture',
    author: 'Dr. Layla Al-Hassan',
    page: 4,
    text: 'Elegance is what endures when everything superfluous is removed.',
    note: 'Core principle behind Obsidian & Champagne UI.',
    color: '#6BB88B',
    createdAt: now - hr * 15,
  },
];

export const INITIAL_STATS: DailyStat[] = [
  { dayAr: 'السبت', dayEn: 'Sat', minutes: 34, pages: 26 },
  { dayAr: 'الأحد', dayEn: 'Sun', minutes: 48, pages: 38 },
  { dayAr: 'الاثنين', dayEn: 'Mon', minutes: 29, pages: 22 },
  { dayAr: 'الثلاثاء', dayEn: 'Tue', minutes: 62, pages: 51 },
  { dayAr: 'الأربعاء', dayEn: 'Wed', minutes: 44, pages: 35 },
  { dayAr: 'الخميس', dayEn: 'Thu', minutes: 55, pages: 43 },
  { dayAr: 'اليوم', dayEn: 'Today', minutes: 42, pages: 33 },
];

export const OFFLINE_DICTIONARY: Record<string, { posAr: string; defAr: string; trEn: string; defEn: string }> = {
  العمران: {
    posAr: 'اسم مصدر (ع-م-ر)',
    defAr: 'البنيان والاجتماع الإنساني وازدهار الحواضر بالصنائع والعلوم والعدل.',
    trEn: 'Civilization / Urban Flourishing',
    defEn: 'Ibn Khaldun’s foundational concept of human social organization, culture, and civic prosperity.',
  },
  العدل: {
    posAr: 'اسم (ع-د-ل)',
    defAr: 'الإنصاف وإعطاء كل ذي حق حقه وإقامة الميزان القويم بين الناس.',
    trEn: 'Justice / Equity',
    defEn: 'Impartial fairness and balanced rule of law that sustains societal trust.',
  },
  civilization: {
    posAr: 'اسم — العُمران / الحضارة',
    defAr: 'الاجتماع البشري المنظم القائم على المدن والعلوم والفنون والقانون.',
    trEn: 'العُمران البشري والحضارة',
    defEn: 'An advanced stage of human social, cultural, architectural, and scholarly development.',
  },
  elegance: {
    posAr: 'اسم — الأناقة الرفيعة',
    defAr: 'جمال التناسب والبساطة المتقنة دون تكلّف أو مبالغة.',
    trEn: 'الأناقة الهادئة والإتقان',
    defEn: 'Graceful precision, dignified simplicity, and harmonious visual restraint.',
  },
};

export const ALL_SUPPORTED_FORMATS = [
  { groupAr: 'مستندات وكتب', groupEn: 'Documents & eBooks', list: ['PDF', 'EPUB 2/3', 'MOBI', 'AZW', 'AZW3', 'FB2', 'FB2.ZIP', 'DJVU', 'XPS', 'CBZ', 'CBR', 'CB7', 'RTF', 'TXT'] },
  { groupAr: 'مكتبية ونصية', groupEn: 'Office & Structured', list: ['DOC', 'DOCX', 'ODT', 'XLS', 'XLSX', 'PPT', 'PPTX', 'MD', 'CSV'] },
  { groupAr: 'ويب وكود', groupEn: 'Web & Markup', list: ['HTML', 'XHTML', 'MHT', 'XML'] },
  { groupAr: 'صور عالية الدقة', groupEn: 'High-Res Images', list: ['JPG', 'PNG', 'WEBP', 'GIF', 'BMP', 'HEIC/HEIF', 'AVIF', 'SVG', 'TIFF'] },
  { groupAr: 'أرشيفات داخلية', groupEn: 'Internal Archives', list: ['ZIP', 'RAR', '7z'] },
];

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
