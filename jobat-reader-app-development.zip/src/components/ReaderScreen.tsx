import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  Search,
  Volume2,
  Type,
  List,
  PenTool,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  Square,
  Moon,
  Lock,
  Unlock,
  Copy,
  BookMarked,
  Languages,
  Highlighter,
  X,
  FolderArchive,
  FileCode2,
  Maximize2,
} from 'lucide-react';
import { ArchiveInnerFile, DocItem, Lang, QuoteItem, ReaderMode, ReaderSettings, ReaderThemeId } from '../types';
import { OFFLINE_DICTIONARY } from '../data/sampleData';

interface ReaderScreenProps {
  lang: Lang;
  doc: DocItem;
  settings: ReaderSettings;
  onUpdateSettings: (patch: Partial<ReaderSettings>) => void;
  onUpdateDoc: (id: string, patch: Partial<DocItem>) => void;
  onAddQuote: (q: Omit<QuoteItem, 'id' | 'createdAt'>) => void;
  onOpenEditor: (doc: DocItem) => void;
  onOpenArchiveFileInEditor: (entry: ArchiveInnerFile) => void;
  onRecordReading: (pagesDelta: number) => void;
  onClose: () => void;
  onNotify: (msg: string) => void;
}

const READER_PALETTES: Record<Exclude<ReaderThemeId, 'custom'>, { bg: string; fg: string; muted: string; accent: string; label: string }> = {
  paper: { bg: '#FAF9F5', fg: '#1B1B19', muted: '#6E6C66', accent: '#9E7631', label: 'Paper' },
  sepia: { bg: '#F2E6CE', fg: '#322517', muted: '#755F44', accent: '#8F6224', label: 'Sepia' },
  ivory: { bg: '#F6F1E7', fg: '#201E1A', muted: '#6A6357', accent: '#9E7631', label: 'Ivory' },
  graphite: { bg: '#181A20', fg: '#E4E0D8', muted: '#8E93A0', accent: '#D4B26A', label: 'Graphite' },
  midnight: { bg: '#0D111A', fg: '#D8DFE9', muted: '#7C889B', accent: '#D4B26A', label: 'Midnight' },
  amoled: { bg: '#000000', fg: '#DCD8D0', muted: '#787878', accent: '#D4B26A', label: 'AMOLED' },
};

const FONT_MAP: Record<ReaderSettings['fontFamily'], { css: string; label: string }> = {
  amiri: { css: "'Amiri', Georgia, serif", label: 'Amiri أميري' },
  plex: { css: "'IBM Plex Sans Arabic', 'Inter', sans-serif", label: 'IBM Plex' },
  kufi: { css: "'Noto Kufi Arabic', 'Inter', sans-serif", label: 'Noto Kufi كوفي' },
  cormorant: { css: "'Cormorant Garamond', 'Amiri', serif", label: 'Cormorant' },
  inter: { css: "'Inter', 'IBM Plex Sans Arabic', sans-serif", label: 'Inter Sans' },
};

export const ReaderScreen: React.FC<ReaderScreenProps> = ({
  lang,
  doc,
  settings,
  onUpdateSettings,
  onUpdateDoc,
  onAddQuote,
  onOpenEditor,
  onOpenArchiveFileInEditor,
  onRecordReading,
  onClose,
  onNotify,
}) => {
  const isAr = lang === 'ar';
  const effectiveRtl = settings.rtlOverride ?? isAr;
  const totalPages = Math.max(1, doc.pages.length);
  const [page, setPage] = useState(() => Math.min(Math.max(1, doc.currentPage || 1), totalPages));
  const [chrome, setChrome] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [sheet, setSheet] = useState<null | 'style' | 'toc' | 'search' | 'tts'>(null);
  const [tocTab, setTocTab] = useState<'toc' | 'bookmarks' | 'jump'>('toc');
  const [jumpVal, setJumpVal] = useState(String(page));
  const [scrubPreview, setScrubPreview] = useState<number | null>(null);

  // In-document search
  const [searchTerm, setSearchTerm] = useState('');
  const [matchCursor, setMatchCursor] = useState(0);

  // Text selection & dictionary
  const [selectedText, setSelectedText] = useState('');
  const [dictView, setDictView] = useState<null | 'dict' | 'translate'>(null);

  // TTS controller
  const [ttsPlaying, setTtsPlaying] = useState(false);
  const [ttsIdx, setTtsIdx] = useState(0);
  const [ttsRate, setTtsRate] = useState(1.0);
  const [ttsPitch, setTtsPitch] = useState(1.0);
  const [sleepMin, setSleepMin] = useState<number | null>(null);
  const ttsTimerRef = useRef<number | null>(null);

  // Archive preview inner item
  const [previewEntry, setPreviewEntry] = useState<ArchiveInnerFile | null>(null);

  const palette =
    settings.theme === 'custom'
      ? { bg: settings.customBg, fg: settings.customFg, muted: '#8E93A0', accent: '#D4B26A' }
      : READER_PALETTES[settings.theme];

  const currentPageSpec = doc.pages[page - 1] ?? doc.pages[0];
  const sentences = useMemo(() => {
    if (!currentPageSpec) return [];
    return effectiveRtl ? currentPageSpec.paragraphsAr : currentPageSpec.paragraphsEn;
  }, [currentPageSpec, effectiveRtl]);

  const isBookmarked = doc.bookmarks.includes(page);

  const goToPage = (next: number) => {
    const clamped = Math.min(Math.max(1, next), totalPages);
    if (clamped !== page) {
      setPage(clamped);
      setTtsIdx(0);
      onUpdateDoc(doc.id, { currentPage: clamped, lastReadMs: Date.now() });
      onRecordReading(1);
    }
  };

  // Search matches across all pages
  const searchMatches = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return [];
    const res: { page: number; excerpt: string }[] = [];
    doc.pages.forEach((p, idx) => {
      const lines = effectiveRtl ? [p.headingAr, ...p.paragraphsAr] : [p.headingEn, ...p.paragraphsEn];
      lines.forEach((line) => {
        if (line.toLowerCase().includes(q)) {
          res.push({ page: idx + 1, excerpt: line });
        }
      });
    });
    return res;
  }, [doc.pages, searchTerm, effectiveRtl]);

  // TTS Playback with real Web Speech API + synchronized timer fallback
  useEffect(() => {
    if (!ttsPlaying || sentences.length === 0) {
      if (ttsTimerRef.current) window.clearTimeout(ttsTimerRef.current);
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      return;
    }

    const text = sentences[ttsIdx] ?? sentences[0];
    let finished = false;
    const advance = () => {
      if (finished) return;
      finished = true;
      if (ttsIdx + 1 < sentences.length) {
        setTtsIdx((i) => i + 1);
      } else if (page < totalPages) {
        goToPage(page + 1);
      } else {
        setTtsPlaying(false);
      }
    };

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance(text);
        utt.lang = effectiveRtl ? 'ar-SA' : 'en-US';
        utt.rate = ttsRate;
        utt.pitch = ttsPitch;
        utt.onend = advance;
        utt.onerror = () => {
          ttsTimerRef.current = window.setTimeout(advance, Math.max(1800, (text.length * 48) / ttsRate));
        };
        window.speechSynthesis.speak(utt);
      } catch {
        // Fallback timer below
      }
    }
    ttsTimerRef.current = window.setTimeout(advance, Math.max(3200, (text.length * 62) / ttsRate));

    return () => {
      finished = true;
      if (ttsTimerRef.current) window.clearTimeout(ttsTimerRef.current);
    };
  }, [ttsPlaying, ttsIdx, page, ttsRate, ttsPitch, effectiveRtl]);

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const captureSelection = () => {
    const sel = window.getSelection()?.toString().trim() ?? '';
    if (sel.length >= 2) {
      setSelectedText(sel.slice(0, 280));
      setDictView(null);
    }
  };

  const renderHighlighted = (text: string) => {
    const q = searchTerm.trim();
    if (!q) return text;
    const idx = text.toLowerCase().indexOf(q.toLowerCase());
    if (idx === -1) return text;
    return (
      <>
        {text.slice(0, idx)}
        <mark
          className="px-1 rounded"
          style={{ background: 'rgba(212, 178, 106, 0.42)', color: palette.fg }}
        >
          {text.slice(idx, idx + q.length)}
        </mark>
        {text.slice(idx + q.length)}
      </>
    );
  };

  const saveHighlight = (color: string) => {
    if (!selectedText) return;
    onAddQuote({
      docId: doc.id,
      docTitle: isAr ? doc.titleAr : doc.titleEn,
      author: isAr ? doc.authorAr : doc.authorEn,
      page,
      text: selectedText,
      note: '',
      color,
    });
    setSelectedText('');
    window.getSelection()?.removeAllRanges();
    onNotify(isAr ? 'تم حفظ المقتطف في صفحة الاقتباسات' : 'Saved highlight to Excerpts');
  };

  const dictLookup = useMemo(() => {
    const word = selectedText.trim().split(/\s+/)[0]?.replace(/[،.؛:!?"'()]/g, '').toLowerCase() ?? '';
    const exact =
      OFFLINE_DICTIONARY[word] ??
      Object.entries(OFFLINE_DICTIONARY).find(([k]) => word.includes(k.toLowerCase()))?.[1];
    if (exact) return exact;
    return {
      posAr: isAr ? 'معجم JObat المحلي (Offline)' : 'JObat Offline Lexicon',
      defAr: `«${selectedText.slice(0, 48)}» — عبارة مقتبسة من سياق «${doc.titleAr}» (ص ${page})، محفوظة في الفهرس الدلالي المحلي.`,
      trEn: effectiveRtl
        ? `Contextual translation (p.${page}): "${(currentPageSpec?.paragraphsEn[0] ?? selectedText).slice(0, 110)}…"`
        : `الترجمة السياقية (ص ${page}): «${(currentPageSpec?.paragraphsAr[0] ?? selectedText).slice(0, 110)}…»`,
      defEn: `"${selectedText.slice(0, 48)}" — Indexed literary expression from "${doc.titleEn}" (page ${page}).`,
    };
  }, [selectedText, doc, page, isAr, effectiveRtl, currentPageSpec]);

  const toggleBookmark = () => {
    const next = isBookmarked ? doc.bookmarks.filter((b) => b !== page) : [...doc.bookmarks, page].sort((a, b) => a - b);
    onUpdateDoc(doc.id, { bookmarks: next });
    onNotify(isBookmarked ? (isAr ? 'أُزيلت العلامة المرجعية' : 'Bookmark removed') : isAr ? `أُضيفت علامة مرجعية لصفحة ${page}` : `Bookmarked page ${page}`);
  };

  const pagesToShow =
    settings.mode === 'vertical' || settings.mode === 'continuous'
      ? doc.pages.map((p, i) => ({ spec: p, num: i + 1 }))
      : settings.mode === 'twoPage'
      ? doc.pages.slice(page - 1, page + 1).map((p, i) => ({ spec: p, num: page + i }))
      : [{ spec: currentPageSpec, num: page }];

  return (
    <div
      className="absolute inset-0 z-30 flex flex-col overflow-hidden select-text"
      style={{
        background: palette.bg,
        color: palette.fg,
        filter: settings.contrastBoost ? 'contrast(1.14)' : undefined,
      }}
    >
      {/* Blue Light Filter Overlay */}
      {(settings.blueLight > 0 || settings.blueLightScheduled) && (
        <div
          className="pointer-events-none absolute inset-0 z-20"
          style={{
            background: `rgba(255, 148, 42, ${Math.min(0.32, (Math.max(settings.blueLight, settings.blueLightScheduled ? 35 : 0) / 100) * 0.32)})`,
            mixBlendMode: 'multiply',
          }}
        />
      )}

      {/* Top Sliding Chrome Bar */}
      <div
        className="relative z-30 jb-glass px-3 py-2 flex items-center justify-between gap-1 transition-all"
        style={{
          borderBottom: '1px solid var(--jb-border)',
          color: 'var(--jb-text)',
          transform: chrome ? 'translateY(0)' : 'translateY(-110%)',
          opacity: chrome ? 1 : 0,
          pointerEvents: chrome ? 'auto' : 'none',
        }}
      >
        <button
          onClick={onClose}
          className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer"
          style={{ background: 'var(--jb-surface)' }}
          aria-label="Back"
        >
          {isAr ? <ArrowRight size={16} /> : <ArrowLeft size={16} />}
        </button>

        <div className="flex-1 min-w-0 px-1.5">
          <p className="text-[12px] font-semibold truncate">{isAr ? doc.titleAr : doc.titleEn}</p>
          <p className="text-[10px] truncate" style={{ color: 'var(--jb-text-secondary)' }}>
            {doc.ext.toUpperCase()} • {settings.reflowPdf ? 'Reflow • ' : ''}
            {Math.round(zoom * 100)}%
          </p>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={toggleBookmark}
            title={isAr ? 'علامة مرجعية' : 'Bookmark'}
            className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: isBookmarked ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
          >
            <Bookmark size={15} fill={isBookmarked ? 'currentColor' : 'none'} />
          </button>
          <button
            onClick={() => setSheet(sheet === 'search' ? null : 'search')}
            title={isAr ? 'بحث في المستند' : 'Search in Document'}
            className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: sheet === 'search' ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
          >
            <Search size={15} />
          </button>
          <button
            onClick={() => setSheet(sheet === 'tts' ? null : 'tts')}
            title="TTS"
            className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: ttsPlaying || sheet === 'tts' ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
          >
            <Volume2 size={15} />
          </button>
          <button
            onClick={() => setSheet(sheet === 'style' ? null : 'style')}
            title={isAr ? 'الخط والثيم' : 'Typography & Theme'}
            className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: sheet === 'style' ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
          >
            <Type size={15} />
          </button>
          <button
            onClick={() => onOpenEditor(doc)}
            title={isAr ? 'تحرير' : 'Edit'}
            className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer"
            style={{ background: 'var(--jb-accent-soft)', color: 'var(--jb-accent)' }}
          >
            <PenTool size={14} />
          </button>
        </div>
      </div>

      {/* Inline Search Bar */}
      {sheet === 'search' && (
        <div
          className="relative z-30 px-3 py-2 flex items-center gap-2 jb-glass"
          style={{ borderBottom: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
        >
          <input
            autoFocus
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setMatchCursor(0);
            }}
            placeholder={isAr ? 'ابحث داخل صفحات الكتاب…' : 'Find inside document…'}
            className="flex-1 h-8 px-3 rounded-lg text-[12px] outline-none"
            style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border-strong)', color: 'var(--jb-text)' }}
          />
          <span className="text-[11px] tabular-nums" style={{ color: 'var(--jb-accent)' }}>
            {searchMatches.length ? `${matchCursor + 1}/${searchMatches.length}` : '0'}
          </span>
          <button
            disabled={!searchMatches.length}
            onClick={() => {
              const next = (matchCursor + 1) % searchMatches.length;
              setMatchCursor(next);
              goToPage(searchMatches[next].page);
            }}
            className="px-2 h-8 rounded-lg text-[11px] cursor-pointer disabled:opacity-40"
            style={{ background: 'var(--jb-surface)' }}
          >
            {isAr ? 'التالي' : 'Next'}
          </button>
          <button onClick={() => setSheet(null)} className="p-1 cursor-pointer">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Persistent TTS Notification Bar */}
      {(ttsPlaying || sheet === 'tts') && (
        <div
          className="relative z-30 px-3.5 py-2.5 jb-glass flex flex-col gap-2"
          style={{ borderBottom: '1px solid var(--jb-border-strong)', color: 'var(--jb-text)' }}
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setTtsPlaying((p) => !p)}
                className="jb-gold-btn w-8 h-8 rounded-full flex items-center justify-center cursor-pointer"
              >
                {ttsPlaying ? <Pause size={14} /> : <Play size={14} />}
              </button>
              <button
                onClick={() => {
                  setTtsPlaying(false);
                  setTtsIdx(0);
                }}
                className="w-7 h-7 rounded-full flex items-center justify-center cursor-pointer"
                style={{ background: 'var(--jb-surface)' }}
              >
                <Square size={11} />
              </button>
              <span className="text-[11px] font-medium px-1">
                {isAr ? `قارئ صوتي • جملة ${ttsIdx + 1}/${Math.max(1, sentences.length)}` : `TTS • Sentence ${ttsIdx + 1}/${Math.max(1, sentences.length)}`}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setTtsRate((r) => (r >= 2 ? 0.75 : Number((r + 0.25).toFixed(2))))}
                className="px-2 py-0.5 rounded-md text-[10.5px] font-semibold cursor-pointer"
                style={{ background: 'var(--jb-accent-soft)', color: 'var(--jb-accent)' }}
              >
                {ttsRate}x
              </button>
              <button
                onClick={() => setTtsPitch((p) => (p >= 1.3 ? 0.8 : Number((p + 0.2).toFixed(1))))}
                className="px-2 py-0.5 rounded-md text-[10.5px] cursor-pointer"
                style={{ background: 'var(--jb-surface)', color: 'var(--jb-text-secondary)' }}
              >
                {isAr ? `نبرة ${ttsPitch}` : `Pitch ${ttsPitch}`}
              </button>
              <button
                onClick={() => {
                  const next = sleepMin === null ? 15 : sleepMin === 15 ? 30 : sleepMin === 30 ? 60 : null;
                  setSleepMin(next);
                  onNotify(next ? (isAr ? `مؤقت النوم: ${next} دقيقة` : `Sleep timer set: ${next} min`) : isAr ? 'أُلغي مؤقت النوم' : 'Sleep timer off');
                }}
                className="px-2 py-0.5 rounded-md text-[10.5px] inline-flex items-center gap-1 cursor-pointer"
                style={{
                  background: sleepMin ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                  color: sleepMin ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                }}
              >
                <Moon size={10} />
                <span>{sleepMin ? `${sleepMin}m` : isAr ? 'نوم' : 'Sleep'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Reading Surface */}
      <div
        dir={effectiveRtl ? 'rtl' : 'ltr'}
        onMouseUp={captureSelection}
        onTouchEnd={captureSelection}
        onDoubleClick={() => setZoom((z) => (z > 1.15 ? 1 : 1.45))}
        className="flex-1 overflow-y-auto jb-scroll relative"
        style={{
          paddingLeft: settings.autoCrop ? 10 : settings.marginPx,
          paddingRight: settings.autoCrop ? 10 : settings.marginPx,
          paddingTop: 18,
          paddingBottom: 92,
        }}
      >
        {/* Archive Inner File Browser if ZIP/RAR/7z */}
        {doc.archiveEntries && doc.archiveEntries.length > 0 ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-2" style={{ borderBottom: `1px solid ${palette.muted}33` }}>
              <FolderArchive size={18} style={{ color: palette.accent }} />
              <h2 className="text-[16px] font-semibold">
                {isAr ? 'متصفح الأرشيف الداخلي (ZIP / RAR / 7z)' : 'Internal Archive Browser (ZIP / RAR / 7z)'}
              </h2>
            </div>
            {doc.archiveEntries.map((entry) => (
              <div
                key={entry.name}
                className="p-3 rounded-2xl flex items-center justify-between gap-2"
                style={{ border: `1px solid ${palette.muted}33` }}
              >
                <button
                  onClick={() => setPreviewEntry(entry)}
                  className="flex items-center gap-2.5 text-start flex-1 cursor-pointer"
                >
                  <FileCode2 size={17} style={{ color: palette.accent }} />
                  <div>
                    <p className="text-[13px] font-medium">{entry.name}</p>
                    <p className="text-[10.5px]" style={{ color: palette.muted }}>
                      {entry.ext.toUpperCase()} • {entry.sizeKb} KB
                    </p>
                  </div>
                </button>
                <button
                  onClick={() => onOpenArchiveFileInEditor(entry)}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer"
                  style={{ background: `${palette.accent}22`, color: palette.accent }}
                >
                  {isAr ? 'تحرير' : 'Edit'}
                </button>
              </div>
            ))}
            {previewEntry && (
              <div className="mt-3 p-4 rounded-2xl jb-mono text-[12px] whitespace-pre-wrap leading-relaxed" dir="auto" style={{ border: `1px solid ${palette.accent}55` }}>
                <div className="text-[10.5px] font-semibold mb-2" style={{ color: palette.accent }}>
                  {previewEntry.name}
                </div>
                {previewEntry.content}
              </div>
            )}
          </div>
        ) : (
          <div
            key={settings.mode === 'curl' ? `curl-${page}` : 'surface'}
            className={`${settings.mode === 'curl' ? 'jb-curl-in' : ''} ${
              settings.mode === 'twoPage' ? 'grid grid-cols-2 gap-4' : 'space-y-8'
            }`}
            style={{
              fontFamily: FONT_MAP[settings.fontFamily].css,
              fontSize: `${Math.round(settings.fontSize * (settings.reflowPdf ? 1.12 : 1) * zoom)}px`,
              lineHeight: settings.lineHeight,
              textAlign: settings.align,
              hyphens: settings.hyphenation ? 'auto' : 'none',
            }}
          >
            {pagesToShow.map(({ spec, num }) => (
              <article
                key={spec.id}
                className="relative"
                style={{
                  transform: spec.rotation ? `rotate(${spec.rotation}deg)` : undefined,
                  borderBottom:
                    settings.mode === 'vertical' ? `1px dashed ${palette.muted}40` : undefined,
                  paddingBottom: settings.mode === 'vertical' ? 24 : 0,
                }}
              >
                {/* Running Header */}
                <div
                  onClick={() => setChrome((c) => !c)}
                  className="flex items-center justify-between text-[10.5px] mb-4 cursor-pointer select-none"
                  style={{ color: palette.muted, fontFamily: 'var(--jb-font-sans)' }}
                >
                  <span className="truncate max-w-[72%]">{isAr ? doc.authorAr : doc.authorEn}</span>
                  <span className="tabular-nums">
                    {doc.numberedPages ? `#${num}` : `${num} / ${totalPages}`}
                  </span>
                </div>

                {/* Watermark if present */}
                {doc.watermark && (
                  <div
                    className="pointer-events-none absolute inset-0 flex items-center justify-center -rotate-24 text-[26px] font-bold tracking-widest opacity-12 select-none"
                    style={{ color: palette.accent }}
                  >
                    {doc.watermark}
                  </div>
                )}

                {spec.imageUrl && (
                  <div className="mb-4 rounded-2xl overflow-hidden shadow-md">
                    <img
                      src={spec.imageUrl}
                      alt={isAr ? spec.headingAr : spec.headingEn}
                      className="w-full h-auto object-contain transition-transform"
                      style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}
                    />
                  </div>
                )}

                {!spec.isBlank && (effectiveRtl ? spec.headingAr : spec.headingEn) && (
                  <h1
                    className="font-bold mb-4 leading-snug"
                    style={{
                      fontSize: '1.22em',
                      color: palette.fg,
                    }}
                  >
                    {renderHighlighted(effectiveRtl ? spec.headingAr : spec.headingEn)}
                  </h1>
                )}

                <div className="space-y-4">
                  {(effectiveRtl ? spec.paragraphsAr : spec.paragraphsEn).map((para, pIdx) => {
                    const activeTts = ttsPlaying && num === page && pIdx === ttsIdx;
                    return (
                      <p
                        key={pIdx}
                        onClick={(e) => {
                          if (e.detail === 1 && !window.getSelection()?.toString()) {
                            // Allow quick quote/dictionary action via Alt-click, otherwise toggle focus chrome gently
                            if (e.shiftKey) setSelectedText(para);
                          }
                        }}
                        className="transition-colors rounded-lg"
                        style={
                          activeTts
                            ? {
                                background: `${palette.accent}24`,
                                boxShadow: `inset 3px 0 0 ${palette.accent}`,
                                padding: '6px 10px',
                              }
                            : undefined
                        }
                      >
                        {renderHighlighted(para)}
                      </p>
                    );
                  })}
                </div>

                {/* Quick select-quote hint button for effortless testing */}
                {!spec.isBlank && (effectiveRtl ? spec.paragraphsAr : spec.paragraphsEn).length > 0 && (
                  <div className="mt-6 flex items-center justify-between text-[11px]" style={{ fontFamily: 'var(--jb-font-sans)', color: palette.muted }}>
                    <button
                      onClick={() => setSelectedText((effectiveRtl ? spec.paragraphsAr[0] : spec.paragraphsEn[0]) ?? '')}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full cursor-pointer opacity-75 hover:opacity-100 transition-opacity"
                      style={{ border: `1px solid ${palette.muted}44` }}
                    >
                      <Highlighter size={11} style={{ color: palette.accent }} />
                      <span>{isAr ? 'تحديد مقتطف / قاموس' : 'Highlight / Dictionary'}</span>
                    </button>
                    <button
                      onClick={() => setChrome((c) => !c)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full cursor-pointer opacity-75 hover:opacity-100"
                      style={{ border: `1px solid ${palette.muted}44` }}
                    >
                      <Maximize2 size={11} />
                      <span>{chrome ? (isAr ? 'وضع التركيز' : 'Focus Mode') : isAr ? 'إظهار الأدوات' : 'Show Bars'}</span>
                    </button>
                  </div>
                )}
              </article>
            ))}
          </div>
        )}
      </div>

      {/* Text Selection Floating Action Card (Highlight, Dictionary, Translate, Copy) */}
      {selectedText && (
        <div
          className="absolute inset-x-3 bottom-24 z-40 rounded-2xl p-3.5 shadow-2xl jb-sheet-in"
          style={{
            background: 'var(--jb-surface-elevated)',
            border: '1px solid var(--jb-border-strong)',
            color: 'var(--jb-text)',
          }}
        >
          <div className="flex items-start justify-between gap-2 mb-2.5">
            <p className="text-[11.5px] line-clamp-2 italic" style={{ color: 'var(--jb-text-secondary)' }}>
              “{selectedText}”
            </p>
            <button onClick={() => setSelectedText('')} className="p-0.5 cursor-pointer" style={{ color: 'var(--jb-text-tertiary)' }}>
              <X size={14} />
            </button>
          </div>
          <div className="flex items-center justify-between gap-1.5 flex-wrap">
            <div className="flex items-center gap-1.5">
              {['#D4B26A', '#6BB88B', '#6B9FD9', '#D96B6B'].map((c) => (
                <button
                  key={c}
                  onClick={() => saveHighlight(c)}
                  title={isAr ? 'حفظ تمييز' : 'Highlight'}
                  className="w-6 h-6 rounded-full cursor-pointer hover:scale-110 transition-transform"
                  style={{ background: c, border: '2px solid var(--jb-bg)' }}
                />
              ))}
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setDictView(dictView === 'dict' ? null : 'dict')}
                className="px-2.5 py-1.5 rounded-lg text-[11px] inline-flex items-center gap-1 cursor-pointer"
                style={{ background: dictView === 'dict' ? 'var(--jb-accent-soft)' : 'var(--jb-surface)', color: 'var(--jb-text)' }}
              >
                <BookMarked size={12} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'قاموس' : 'Dict'}</span>
              </button>
              <button
                onClick={() => setDictView(dictView === 'translate' ? null : 'translate')}
                className="px-2.5 py-1.5 rounded-lg text-[11px] inline-flex items-center gap-1 cursor-pointer"
                style={{ background: dictView === 'translate' ? 'var(--jb-accent-soft)' : 'var(--jb-surface)', color: 'var(--jb-text)' }}
              >
                <Languages size={12} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'ترجمة' : 'Translate'}</span>
              </button>
              <button
                onClick={() => {
                  navigator.clipboard?.writeText(selectedText);
                  onNotify(isAr ? 'نُسخ النص إلى الحافظة' : 'Copied to clipboard');
                  setSelectedText('');
                }}
                className="px-2.5 py-1.5 rounded-lg text-[11px] inline-flex items-center gap-1 cursor-pointer"
                style={{ background: 'var(--jb-surface)', color: 'var(--jb-text)' }}
              >
                <Copy size={12} />
              </button>
            </div>
          </div>

          {dictView && (
            <div className="mt-2.5 p-2.5 rounded-xl text-[11.5px] leading-relaxed" style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)' }}>
              {dictView === 'dict' ? (
                <>
                  <div className="text-[10px] font-semibold mb-0.5" style={{ color: 'var(--jb-accent)' }}>
                    {dictLookup.posAr}
                  </div>
                  <p>{isAr ? dictLookup.defAr : dictLookup.defEn}</p>
                </>
              ) : (
                <>
                  <div className="text-[10px] font-semibold mb-0.5" style={{ color: 'var(--jb-accent)' }}>
                    {isAr ? 'ترجمة فورية محلية (Offline)' : 'Offline Instant Translation'}
                  </div>
                  <p>{dictLookup.trEn}</p>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* Bottom Interactive Scrubber & Page Controls */}
      <div
        className="absolute inset-x-0 bottom-0 z-30 jb-glass px-4 py-3 transition-all"
        style={{
          borderTop: '1px solid var(--jb-border)',
          color: 'var(--jb-text)',
          transform: chrome ? 'translateY(0)' : 'translateY(110%)',
          opacity: chrome ? 1 : 0,
          pointerEvents: chrome ? 'auto' : 'none',
        }}
      >
        {scrubPreview !== null && (
          <div
            className="mb-2 px-3 py-1.5 rounded-xl text-[11px] text-center truncate"
            style={{ background: 'var(--jb-surface-elevated)', border: '1px solid var(--jb-border-strong)', color: 'var(--jb-accent)' }}
          >
            {isAr ? `معاينة ص ${scrubPreview}: ` : `Preview p.${scrubPreview}: `}
            {isAr ? doc.pages[scrubPreview - 1]?.headingAr : doc.pages[scrubPreview - 1]?.headingEn}
          </div>
        )}

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => goToPage(page - 1)}
            disabled={page <= 1}
            className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer"
            style={{ background: 'var(--jb-surface)' }}
          >
            {effectiveRtl ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
          </button>

          <input
            type="range"
            min={1}
            max={totalPages}
            value={page}
            onChange={(e) => {
              const v = Number(e.target.value);
              setScrubPreview(v);
              goToPage(v);
            }}
            onMouseUp={() => setScrubPreview(null)}
            onTouchEnd={() => setScrubPreview(null)}
            className="flex-1 jb-range"
          />

          <button
            onClick={() => goToPage(page + 1)}
            disabled={page >= totalPages}
            className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer"
            style={{ background: 'var(--jb-surface)' }}
          >
            {effectiveRtl ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
          </button>
        </div>

        <div className="mt-2 flex items-center justify-between text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
          <button
            onClick={() => {
              setJumpVal(String(page));
              setSheet('toc');
            }}
            className="inline-flex items-center gap-1.5 hover:opacity-100 cursor-pointer"
            style={{ color: 'var(--jb-accent)' }}
          >
            <List size={13} />
            <span>{isAr ? 'الفهرس والعلامات' : 'TOC & Marks'}</span>
          </button>

          <span className="tabular-nums font-medium">
            {page} / {totalPages} ({Math.round((page / totalPages) * 100)}%)
          </span>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setZoom((z) => Math.max(0.7, Number((z - 0.1).toFixed(2))))}
              className="w-6 h-6 rounded flex items-center justify-center cursor-pointer"
              style={{ background: 'var(--jb-surface)' }}
            >
              <ZoomOut size={12} />
            </button>
            <button
              onClick={() => setZoom((z) => Math.min(2.2, Number((z + 0.1).toFixed(2))))}
              className="w-6 h-6 rounded flex items-center justify-center cursor-pointer"
              style={{ background: 'var(--jb-surface)' }}
            >
              <ZoomIn size={12} />
            </button>
          </div>
        </div>
      </div>

      {/* Typography, Reading Mode & Reader Themes Sheet */}
      {sheet === 'style' && (
        <div onClick={() => setSheet(null)} className="absolute inset-0 z-40 bg-black/55 flex items-end">
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-h-[80%] overflow-y-auto jb-scroll rounded-t-3xl p-5 space-y-4 jb-sheet-in"
            style={{ background: 'var(--jb-surface-elevated)', borderTop: '1px solid var(--jb-border-strong)', color: 'var(--jb-text)' }}
          >
            <div className="flex items-center justify-between">
              <h4 className="text-[14px] font-semibold">{isAr ? 'ثيمات القراءة والخطوط' : 'Reading Themes & Typography'}</h4>
              <button onClick={() => setSheet(null)} className="p-1 cursor-pointer">
                <X size={15} />
              </button>
            </div>

            {/* 7 Reading Themes */}
            <div>
              <p className="text-[11px] mb-2" style={{ color: 'var(--jb-text-secondary)' }}>
                {isAr ? 'ثيم الصفحة' : 'Page Theme'}
              </p>
              <div className="flex items-center gap-2 overflow-x-auto jb-no-scrollbar pb-1">
                {(Object.keys(READER_PALETTES) as Exclude<ReaderThemeId, 'custom'>[]).map((id) => {
                  const p = READER_PALETTES[id];
                  const active = settings.theme === id;
                  return (
                    <button
                      key={id}
                      onClick={() => onUpdateSettings({ theme: id })}
                      className="px-3 py-2 rounded-xl text-[11px] font-medium shrink-0 cursor-pointer"
                      style={{
                        background: p.bg,
                        color: p.fg,
                        border: active ? '2px solid var(--jb-accent)' : '1px solid rgba(128,128,128,0.3)',
                      }}
                    >
                      {p.label}
                    </button>
                  );
                })}
                <button
                  onClick={() => onUpdateSettings({ theme: 'custom' })}
                  className="px-3 py-2 rounded-xl text-[11px] font-medium shrink-0 cursor-pointer"
                  style={{
                    background: settings.customBg,
                    color: settings.customFg,
                    border: settings.theme === 'custom' ? '2px solid var(--jb-accent)' : '1px solid rgba(128,128,128,0.3)',
                  }}
                >
                  {isAr ? 'مخصص' : 'Custom'}
                </button>
              </div>
              {settings.theme === 'custom' && (
                <div className="mt-2 flex items-center gap-3 text-[11px]">
                  <label className="flex items-center gap-1.5">
                    <span>BG</span>
                    <input type="color" value={settings.customBg} onChange={(e) => onUpdateSettings({ customBg: e.target.value })} />
                  </label>
                  <label className="flex items-center gap-1.5">
                    <span>Text</span>
                    <input type="color" value={settings.customFg} onChange={(e) => onUpdateSettings({ customFg: e.target.value })} />
                  </label>
                </div>
              )}
            </div>

            {/* Blue Light Filter + Night Schedule */}
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1.5">
                <span style={{ color: 'var(--jb-text-secondary)' }}>
                  {isAr ? `فلتر الضوء الأزرق (${settings.blueLight}%)` : `Blue-Light Warmth (${settings.blueLight}%)`}
                </span>
                <button
                  onClick={() => onUpdateSettings({ blueLightScheduled: !settings.blueLightScheduled })}
                  className="px-2 py-0.5 rounded text-[10px] cursor-pointer"
                  style={{
                    background: settings.blueLightScheduled ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                    color: settings.blueLightScheduled ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                  }}
                >
                  {isAr ? 'جدولة ليلية ٢٢:٠٠' : 'Schedule 22:00'}
                </button>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={settings.blueLight}
                onChange={(e) => onUpdateSettings({ blueLight: Number(e.target.value) })}
                className="w-full jb-range"
              />
            </div>

            {/* Reading Modes */}
            <div>
              <p className="text-[11px] mb-2" style={{ color: 'var(--jb-text-secondary)' }}>
                {isAr ? 'وضع التصفح' : 'Page Mode'}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    { id: 'paged', ar: 'صفحات أفقية', en: 'Paged' },
                    { id: 'vertical', ar: 'تمرير عمودي', en: 'Vertical' },
                    { id: 'twoPage', ar: 'صفحتان', en: 'Two-Page' },
                    { id: 'curl', ar: 'تقليب Curl', en: 'Page Curl' },
                  ] as { id: ReaderMode; ar: string; en: string }[]
                ).map((m) => (
                  <button
                    key={m.id}
                    onClick={() => onUpdateSettings({ mode: m.id })}
                    className="px-2.5 py-1.5 rounded-xl text-[11px] cursor-pointer"
                    style={{
                      background: settings.mode === m.id ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                      color: settings.mode === m.id ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                      border: `1px solid ${settings.mode === m.id ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                    }}
                  >
                    {isAr ? m.ar : m.en}
                  </button>
                ))}
              </div>
            </div>

            {/* Font Family */}
            <div>
              <p className="text-[11px] mb-2" style={{ color: 'var(--jb-text-secondary)' }}>
                {isAr ? 'الخط العربي واللاتيني' : 'Typeface'}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {(Object.keys(FONT_MAP) as ReaderSettings['fontFamily'][]).map((fid) => (
                  <button
                    key={fid}
                    onClick={() => onUpdateSettings({ fontFamily: fid })}
                    className="px-2.5 py-1.5 rounded-xl text-[11px] cursor-pointer"
                    style={{
                      fontFamily: FONT_MAP[fid].css,
                      background: settings.fontFamily === fid ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                      color: settings.fontFamily === fid ? 'var(--jb-accent)' : 'var(--jb-text)',
                      border: `1px solid ${settings.fontFamily === fid ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                    }}
                  >
                    {FONT_MAP[fid].label}
                  </button>
                ))}
              </div>
            </div>

            {/* Size, Line Height, Margins */}
            <div className="grid grid-cols-3 gap-3 text-[11px]">
              <div>
                <span style={{ color: 'var(--jb-text-secondary)' }}>{isAr ? 'الحجم' : 'Size'}: {settings.fontSize}</span>
                <input
                  type="range"
                  min={14}
                  max={28}
                  value={settings.fontSize}
                  onChange={(e) => onUpdateSettings({ fontSize: Number(e.target.value) })}
                  className="w-full jb-range mt-1"
                />
              </div>
              <div>
                <span style={{ color: 'var(--jb-text-secondary)' }}>{isAr ? 'التباعد' : 'Line'}: {settings.lineHeight}</span>
                <input
                  type="range"
                  min={1.4}
                  max={2.3}
                  step={0.1}
                  value={settings.lineHeight}
                  onChange={(e) => onUpdateSettings({ lineHeight: Number(e.target.value) })}
                  className="w-full jb-range mt-1"
                />
              </div>
              <div>
                <span style={{ color: 'var(--jb-text-secondary)' }}>{isAr ? 'الهامش' : 'Margin'}: {settings.marginPx}</span>
                <input
                  type="range"
                  min={10}
                  max={38}
                  value={settings.marginPx}
                  onChange={(e) => onUpdateSettings({ marginPx: Number(e.target.value) })}
                  className="w-full jb-range mt-1"
                />
              </div>
            </div>

            {/* Advanced PDF & Engine Toggles */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[
                { active: settings.autoCrop, label: isAr ? 'قص الهوامش' : 'Auto-Crop', toggle: () => onUpdateSettings({ autoCrop: !settings.autoCrop }) },
                { active: settings.contrastBoost, label: isAr ? 'تحسين التباين' : 'Contrast+', toggle: () => onUpdateSettings({ contrastBoost: !settings.contrastBoost }) },
                { active: settings.reflowPdf, label: 'PDF Reflow', toggle: () => onUpdateSettings({ reflowPdf: !settings.reflowPdf }) },
                { active: effectiveRtl, label: effectiveRtl ? 'RTL ←' : 'LTR →', toggle: () => onUpdateSettings({ rtlOverride: !effectiveRtl }) },
                {
                  active: settings.rotationLocked,
                  label: isAr ? 'قفل التدوير' : 'Lock Rotate',
                  toggle: () => onUpdateSettings({ rotationLocked: !settings.rotationLocked }),
                  icon: settings.rotationLocked ? Lock : Unlock,
                },
              ].map((chip) => (
                <button
                  key={chip.label}
                  onClick={chip.toggle}
                  className="px-2.5 py-1.5 rounded-xl text-[11px] inline-flex items-center gap-1 cursor-pointer"
                  style={{
                    background: chip.active ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                    color: chip.active ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                    border: `1px solid ${chip.active ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                  }}
                >
                  <span>{chip.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TOC / Bookmarks / Jump to Page Sheet */}
      {sheet === 'toc' && (
        <div onClick={() => setSheet(null)} className="absolute inset-0 z-40 bg-black/55 flex items-end">
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-h-[75%] overflow-y-auto jb-scroll rounded-t-3xl p-5 jb-sheet-in"
            style={{ background: 'var(--jb-surface-elevated)', borderTop: '1px solid var(--jb-border-strong)', color: 'var(--jb-text)' }}
          >
            <div className="flex items-center gap-1.5 mb-4">
              {(
                [
                  { id: 'toc', ar: 'الفهرس', en: 'Contents' },
                  { id: 'bookmarks', ar: `العلامات (${doc.bookmarks.length})`, en: `Bookmarks (${doc.bookmarks.length})` },
                  { id: 'jump', ar: 'قفزة لصفحة', en: 'Jump to Page' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setTocTab(tab.id)}
                  className="flex-1 py-2 rounded-xl text-[11.5px] font-medium cursor-pointer"
                  style={{
                    background: tocTab === tab.id ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                    color: tocTab === tab.id ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                  }}
                >
                  {isAr ? tab.ar : tab.en}
                </button>
              ))}
            </div>

            {tocTab === 'toc' && (
              <div className="space-y-1.5">
                {(doc.toc.length ? doc.toc : doc.pages.map((p, i) => ({ titleAr: p.headingAr || `صفحة ${i + 1}`, titleEn: p.headingEn || `Page ${i + 1}`, page: i + 1 }))).map(
                  (entry) => (
                    <button
                      key={`${entry.page}-${entry.titleEn}`}
                      onClick={() => {
                        goToPage(entry.page);
                        setSheet(null);
                      }}
                      className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-[12px] text-start cursor-pointer"
                      style={{
                        background: entry.page === page ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                        color: entry.page === page ? 'var(--jb-accent)' : 'var(--jb-text)',
                      }}
                    >
                      <span className="truncate">{isAr ? entry.titleAr : entry.titleEn}</span>
                      <span className="text-[11px] tabular-nums shrink-0 ms-2">{entry.page}</span>
                    </button>
                  )
                )}
              </div>
            )}

            {tocTab === 'bookmarks' && (
              <div className="space-y-1.5">
                {doc.bookmarks.length === 0 ? (
                  <p className="text-[12px] text-center py-6" style={{ color: 'var(--jb-text-secondary)' }}>
                    {isAr ? 'لا توجد علامات مرجعية بعد.' : 'No bookmarks saved yet.'}
                  </p>
                ) : (
                  doc.bookmarks.map((bm) => (
                    <button
                      key={bm}
                      onClick={() => {
                        goToPage(bm);
                        setSheet(null);
                      }}
                      className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-[12px] cursor-pointer"
                      style={{ background: 'var(--jb-surface)' }}
                    >
                      <span>{isAr ? `صفحة ${bm} — ${doc.pages[bm - 1]?.headingAr ?? ''}` : `Page ${bm} — ${doc.pages[bm - 1]?.headingEn ?? ''}`}</span>
                      <Bookmark size={13} fill="var(--jb-accent)" style={{ color: 'var(--jb-accent)' }} />
                    </button>
                  ))
                )}
              </div>
            )}

            {tocTab === 'jump' && (
              <div className="flex items-center gap-2 py-2">
                <input
                  type="number"
                  min={1}
                  max={totalPages}
                  value={jumpVal}
                  onChange={(e) => setJumpVal(e.target.value)}
                  className="flex-1 h-10 px-3 rounded-xl text-[13px] outline-none"
                  style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border-strong)', color: 'var(--jb-text)' }}
                />
                <button
                  onClick={() => {
                    goToPage(Number(jumpVal) || 1);
                    setSheet(null);
                  }}
                  className="jb-gold-btn px-4 h-10 rounded-xl text-[12px] font-semibold cursor-pointer"
                >
                  {isAr ? `انتقال (1–${totalPages})` : `Go (1–${totalPages})`}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
