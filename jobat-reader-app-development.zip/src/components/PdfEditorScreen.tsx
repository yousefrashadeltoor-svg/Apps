import React, { useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Undo2,
  Redo2,
  Save,
  CopyPlus,
  Highlighter,
  PenTool,
  Eraser,
  Square,
  Circle,
  MoveUpRight,
  Minus,
  Type,
  StickyNote,
  Stamp,
  Feather,
  RotateCw,
  Trash2,
  FilePlus2,
  ChevronLeft,
  ChevronRight,
  Lock,
  Hash,
  Droplets,
  X,
  Underline,
  Strikethrough,
  FileOutput,
} from 'lucide-react';
import { DocItem, DocPageSpec, Lang, PdfAnnotation } from '../types';

interface PdfEditorScreenProps {
  lang: Lang;
  doc: DocItem;
  initialTab?: 'annotate' | 'pages' | 'forms';
  savedSignatures: string[];
  onSaveSignature: (dataUrl: string) => void;
  onUpdateDoc: (id: string, patch: Partial<DocItem>) => void;
  onCreateDocCopy: (newDoc: DocItem) => void;
  onClose: () => void;
  onNotify: (msg: string) => void;
}

type ToolId = PdfAnnotation['tool'] | 'eraser';

const COLORS = ['#D4B26A', '#D9534F', '#4EA677', '#4B86C8', '#181818'];
const STAMPS = [
  { ar: 'مُعتمَد', en: 'APPROVED' },
  { ar: 'سرّي للغاية', en: 'CONFIDENTIAL' },
  { ar: 'مُسوَّدة', en: 'DRAFT' },
];

export const PdfEditorScreen: React.FC<PdfEditorScreenProps> = ({
  lang,
  doc,
  initialTab = 'annotate',
  savedSignatures,
  onSaveSignature,
  onUpdateDoc,
  onCreateDocCopy,
  onClose,
  onNotify,
}) => {
  const isAr = lang === 'ar';
  const [tab, setTab] = useState<'annotate' | 'pages' | 'forms'>(initialTab);
  const [pageIdx, setPageIdx] = useState(0);

  // Unlimited Undo/Redo for annotations
  const [history, setHistory] = useState<PdfAnnotation[][]>([doc.annotations ?? []]);
  const [histPtr, setHistPtr] = useState(0);
  const annotations = history[histPtr] ?? [];

  const [pages, setPages] = useState<DocPageSpec[]>(doc.pages);
  const [watermark, setWatermark] = useState(doc.watermark ?? '');
  const [numberedPages, setNumberedPages] = useState(Boolean(doc.numberedPages));
  const [password, setPassword] = useState(doc.password ?? '');
  const [formFields, setFormFields] = useState<Record<string, string>>(
    doc.formFields ?? {
      reviewer: '',
      edition: '',
      catalogNo: 'JB-2026',
      verified: '',
    }
  );

  const [tool, setTool] = useState<ToolId>('highlight');
  const [color, setColor] = useState('#D4B26A');
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [stampIdx, setStampIdx] = useState(0);
  const [draftPts, setDraftPts] = useState<{ x: number; y: number }[]>([]);
  const [activeNote, setActiveNote] = useState<PdfAnnotation | null>(null);
  const [promptPos, setPromptPos] = useState<null | { x: number; y: number; kind: 'text' | 'note' }>(null);
  const [promptText, setPromptText] = useState('');

  // Reusable Signature Pad Modal
  const [showSigModal, setShowSigModal] = useState(false);
  const [selectedSig, setSelectedSig] = useState<string | null>(savedSignatures[0] ?? null);
  const sigCanvasRef = useRef<HTMLCanvasElement>(null);
  const sigDrawing = useRef(false);
  const sheetRef = useRef<HTMLDivElement>(null);

  const pushAnnotations = (next: PdfAnnotation[]) => {
    const sliced = history.slice(0, histPtr + 1);
    sliced.push(next);
    setHistory(sliced);
    setHistPtr(sliced.length - 1);
  };

  const canUndo = histPtr > 0;
  const canRedo = histPtr < history.length - 1;
  const undo = () => canUndo && setHistPtr((p) => p - 1);
  const redo = () => canRedo && setHistPtr((p) => p + 1);

  const getRelPoint = (e: React.PointerEvent): { x: number; y: number } => {
    const rect = sheetRef.current?.getBoundingClientRect();
    if (!rect) return { x: 50, y: 50 };
    return {
      x: Number((((e.clientX - rect.left) / rect.width) * 100).toFixed(2)),
      y: Number((((e.clientY - rect.top) / rect.height) * 100).toFixed(2)),
    };
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    const pt = getRelPoint(e);
    if (tool === 'eraser') {
      const pageAnns = annotations.filter((a) => a.page === pageIdx + 1);
      const hit = pageAnns.find((a) =>
        a.points.some((p) => Math.hypot(p.x - pt.x, p.y - pt.y) < 8)
      );
      if (hit) {
        pushAnnotations(annotations.filter((a) => a.id !== hit.id));
      }
      return;
    }
    if (tool === 'text' || tool === 'note') {
      setPromptPos({ x: pt.x, y: pt.y, kind: tool });
      setPromptText('');
      return;
    }
    if (tool === 'stamp') {
      const label = isAr ? STAMPS[stampIdx].ar : STAMPS[stampIdx].en;
      setStampIdx((i) => (i + 1) % STAMPS.length);
      pushAnnotations([
        ...annotations,
        {
          id: `ann-${Date.now()}`,
          page: pageIdx + 1,
          tool: 'stamp',
          color,
          strokeWidth: 2,
          points: [pt],
          text: label,
        },
      ]);
      return;
    }
    if (tool === 'signature') {
      if (!selectedSig) {
        setShowSigModal(true);
        return;
      }
      pushAnnotations([
        ...annotations,
        {
          id: `ann-${Date.now()}`,
          page: pageIdx + 1,
          tool: 'signature',
          color,
          strokeWidth: 2,
          points: [pt],
          signatureDataUrl: selectedSig,
        },
      ]);
      onNotify(isAr ? 'تم إدراج التوقيع المحفوظ' : 'Placed saved signature');
      return;
    }
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setDraftPts([pt]);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!draftPts.length) return;
    const pt = getRelPoint(e);
    if (tool === 'pen' || tool === 'highlight') {
      setDraftPts((prev) => [...prev, pt]);
    } else {
      setDraftPts((prev) => [prev[0], pt]);
    }
  };

  const handlePointerUp = () => {
    if (draftPts.length >= 2 && tool !== 'eraser') {
      pushAnnotations([
        ...annotations,
        {
          id: `ann-${Date.now()}`,
          page: pageIdx + 1,
          tool,
          color,
          strokeWidth: tool === 'highlight' ? 14 : strokeWidth,
          points: draftPts,
        },
      ]);
    }
    setDraftPts([]);
  };

  const saveDocument = (asCopy: boolean) => {
    const patch: Partial<DocItem> = {
      annotations,
      pages,
      pageCount: pages.length,
      watermark: watermark.trim() || undefined,
      numberedPages,
      password: password.trim() || undefined,
      formFields,
      lastReadMs: Date.now(),
    };
    if (asCopy) {
      const copy: DocItem = {
        ...doc,
        ...patch,
        id: `doc-copy-${Date.now()}`,
        titleAr: `${doc.titleAr} (نسخة محررة)`,
        titleEn: `${doc.titleEn} (Annotated Copy)`,
        addedMs: Date.now(),
      };
      onCreateDocCopy(copy);
      onNotify(isAr ? 'تم حفظ نسخة PDF جديدة في المكتبة' : 'Saved new annotated PDF copy to Library');
    } else {
      onUpdateDoc(doc.id, patch);
      onNotify(isAr ? 'تم حفظ التعديلات داخل ملف PDF بنجاح' : 'Saved all edits into PDF successfully');
    }
  };

  const startSigStroke = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const c = sigCanvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const r = c.getBoundingClientRect();
    sigDrawing.current = true;
    ctx.strokeStyle = '#1B1B19';
    ctx.lineWidth = 2.6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(((e.clientX - r.left) / r.width) * c.width, ((e.clientY - r.top) / r.height) * c.height);
  };

  const moveSigStroke = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!sigDrawing.current) return;
    const c = sigCanvasRef.current;
    const ctx = c?.getContext('2d');
    if (!c || !ctx) return;
    const r = c.getBoundingClientRect();
    ctx.lineTo(((e.clientX - r.left) / r.width) * c.width, ((e.clientY - r.top) / r.height) * c.height);
    ctx.stroke();
  };

  const clearSigCanvas = () => {
    const c = sigCanvasRef.current;
    c?.getContext('2d')?.clearRect(0, 0, c.width, c.height);
  };

  const commitSig = () => {
    const c = sigCanvasRef.current;
    if (!c) return;
    const url = c.toDataURL('image/png');
    onSaveSignature(url);
    setSelectedSig(url);
    setTool('signature');
    setShowSigModal(false);
    onNotify(isAr ? 'حُفظ التوقيع — انقر على الصفحة لوضعه' : 'Signature saved — tap anywhere on page to place');
  };

  const curPage = pages[pageIdx] ?? pages[0];
  const visibleAnns = annotations.filter((a) => a.page === pageIdx + 1);

  const renderShape = (a: PdfAnnotation, key: string) => {
    const p0 = a.points[0];
    const p1 = a.points[a.points.length - 1] ?? p0;
    if (!p0) return null;
    if (a.tool === 'pen' || a.tool === 'highlight') {
      const d = a.points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
      return (
        <path
          key={key}
          d={d}
          fill="none"
          stroke={a.color}
          strokeWidth={a.tool === 'highlight' ? 4.2 : a.strokeWidth * 0.35}
          strokeOpacity={a.tool === 'highlight' ? 0.36 : 0.95}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      );
    }
    if (a.tool === 'underline' || a.tool === 'strike' || a.tool === 'line') {
      return (
        <line
          key={key}
          x1={p0.x}
          y1={p0.y}
          x2={p1.x}
          y2={a.tool === 'underline' || a.tool === 'strike' ? p0.y : p1.y}
          stroke={a.color}
          strokeWidth={a.tool === 'strike' ? 0.8 : 0.9}
          strokeDasharray={a.tool === 'underline' ? undefined : undefined}
        />
      );
    }
    if (a.tool === 'arrow') {
      const angle = Math.atan2(p1.y - p0.y, p1.x - p0.x);
      const len = 2.8;
      const ax1 = p1.x - len * Math.cos(angle - 0.5);
      const ay1 = p1.y - len * Math.sin(angle - 0.5);
      const ax2 = p1.x - len * Math.cos(angle + 0.5);
      const ay2 = p1.y - len * Math.sin(angle + 0.5);
      return (
        <g key={key} stroke={a.color} strokeWidth={0.9} strokeLinecap="round">
          <line x1={p0.x} y1={p0.y} x2={p1.x} y2={p1.y} />
          <line x1={p1.x} y1={p1.y} x2={ax1} y2={ay1} />
          <line x1={p1.x} y1={p1.y} x2={ax2} y2={ay2} />
        </g>
      );
    }
    if (a.tool === 'rect') {
      return (
        <rect
          key={key}
          x={Math.min(p0.x, p1.x)}
          y={Math.min(p0.y, p1.y)}
          width={Math.abs(p1.x - p0.x)}
          height={Math.abs(p1.y - p0.y)}
          fill="none"
          stroke={a.color}
          strokeWidth={0.9}
          rx={0.8}
        />
      );
    }
    if (a.tool === 'circle') {
      return (
        <ellipse
          key={key}
          cx={(p0.x + p1.x) / 2}
          cy={(p0.y + p1.y) / 2}
          rx={Math.abs(p1.x - p0.x) / 2}
          ry={Math.abs(p1.y - p0.y) / 2}
          fill="none"
          stroke={a.color}
          strokeWidth={0.9}
        />
      );
    }
    return null;
  };

  const tools: { id: ToolId; icon: React.FC<{ size?: number }>; label: string }[] = [
    { id: 'highlight', icon: Highlighter, label: isAr ? 'تمييز' : 'Highlight' },
    { id: 'underline', icon: Underline, label: isAr ? 'تسطير' : 'Underline' },
    { id: 'strike', icon: Strikethrough, label: isAr ? 'شطب' : 'Strike' },
    { id: 'pen', icon: PenTool, label: isAr ? 'قلم' : 'Ink' },
    { id: 'eraser', icon: Eraser, label: isAr ? 'ممحاة' : 'Eraser' },
    { id: 'rect', icon: Square, label: isAr ? 'مستطيل' : 'Box' },
    { id: 'circle', icon: Circle, label: isAr ? 'دائرة' : 'Circle' },
    { id: 'arrow', icon: MoveUpRight, label: isAr ? 'سهم' : 'Arrow' },
    { id: 'line', icon: Minus, label: isAr ? 'خط' : 'Line' },
    { id: 'text', icon: Type, label: isAr ? 'نص' : 'Text' },
    { id: 'note', icon: StickyNote, label: isAr ? 'ملاحظة' : 'Note' },
    { id: 'stamp', icon: Stamp, label: isAr ? 'ختم' : 'Stamp' },
    { id: 'signature', icon: Feather, label: isAr ? 'توقيع' : 'Sign' },
  ];

  return (
    <div className="absolute inset-0 z-30 flex flex-col" style={{ background: 'var(--jb-bg)', color: 'var(--jb-text)' }}>
      {/* Top Bar */}
      <div className="px-3 py-2.5 flex items-center justify-between gap-1.5" style={{ background: 'var(--jb-surface)', borderBottom: '1px solid var(--jb-border)' }}>
        <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
          {isAr ? <ArrowRight size={15} /> : <ArrowLeft size={15} />}
        </button>

        <div className="flex items-center gap-1 rounded-xl p-0.5" style={{ background: 'var(--jb-bg)' }}>
          {(
            [
              { id: 'annotate', ar: 'تعليق', en: 'Annotate' },
              { id: 'pages', ar: 'الصفحات', en: 'Pages' },
              { id: 'forms', ar: 'نماذج', en: 'Forms' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="px-2.5 py-1 rounded-lg text-[10.5px] font-medium cursor-pointer"
              style={{
                background: tab === t.id ? 'var(--jb-accent-soft)' : 'transparent',
                color: tab === t.id ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
              }}
            >
              {isAr ? t.ar : t.en}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1">
          <button disabled={!canUndo} onClick={undo} title="Undo" className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
            <Undo2 size={13} />
          </button>
          <button disabled={!canRedo} onClick={redo} title="Redo" className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
            <Redo2 size={13} />
          </button>
          <button onClick={() => saveDocument(true)} title={isAr ? 'حفظ نسخة جديدة' : 'Save Copy'} className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-accent)' }}>
            <CopyPlus size={13} />
          </button>
          <button onClick={() => saveDocument(false)} className="jb-gold-btn h-7 px-2.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer">
            <Save size={12} />
            <span>{isAr ? 'حفظ' : 'Save'}</span>
          </button>
        </div>
      </div>

      {/* TAB 1: ANNOTATE */}
      {tab === 'annotate' && (
        <>
          <div className="flex-1 overflow-y-auto jb-scroll p-3.5 flex flex-col items-center">
            {/* Interactive Paper Canvas */}
            <div
              ref={sheetRef}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              className="relative w-full min-h-[430px] rounded-xl p-5 shadow-xl select-none touch-none overflow-hidden cursor-crosshair"
              style={{
                background: '#FAF8F2',
                color: '#1C1B18',
                transform: curPage?.rotation ? `rotate(${curPage.rotation}deg)` : undefined,
              }}
            >
              {watermark && (
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center -rotate-24 text-[26px] font-bold tracking-widest opacity-15 text-[#9E7631]">
                  {watermark}
                </div>
              )}

              {!curPage?.isBlank ? (
                <div className="pointer-events-none space-y-3" style={{ fontFamily: "'Amiri', Georgia, serif" }}>
                  <div className="flex justify-between text-[10px] text-[#7D776B]" style={{ fontFamily: 'var(--jb-font-sans)' }}>
                    <span>{isAr ? doc.titleAr : doc.titleEn}</span>
                    <span>{numberedPages ? `#${pageIdx + 1}` : `p.${pageIdx + 1}/${pages.length}`}</span>
                  </div>
                  <h3 className="text-[17px] font-bold text-[#171614]">
                    {isAr ? curPage?.headingAr : curPage?.headingEn}
                  </h3>
                  {(isAr ? curPage?.paragraphsAr : curPage?.paragraphsEn)?.map((p, idx) => (
                    <p key={idx} className="text-[14px] leading-[1.85] text-[#282622]">
                      {p}
                    </p>
                  ))}
                </div>
              ) : (
                <div className="pointer-events-none h-full flex items-center justify-center text-xs text-[#9E978B] pt-24">
                  {isAr ? 'صفحة فارغة جاهزة للرسم والكتابة' : 'Blank sheet ready for ink & notes'}
                </div>
              )}

              {/* Vector Annotation Layer */}
              <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 w-full h-full">
                {visibleAnns.map((a) => renderShape(a, a.id))}
                {draftPts.length >= 2 &&
                  tool !== 'eraser' &&
                  renderShape(
                    { id: 'draft', page: pageIdx + 1, tool, color, strokeWidth, points: draftPts },
                    'draft'
                  )}
              </svg>

              {/* HTML Annotation Pins: Text, Sticky Notes, Stamps, Saved Signatures */}
              {visibleAnns.map((a) => {
                const pt = a.points[0];
                if (!pt) return null;
                if (a.tool === 'text') {
                  return (
                    <div
                      key={a.id}
                      style={{ left: `${pt.x}%`, top: `${pt.y}%`, color: a.color }}
                      className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 text-[12px] font-semibold px-1.5 py-0.5 rounded bg-white/75"
                    >
                      {a.text}
                    </div>
                  );
                }
                if (a.tool === 'note') {
                  return (
                    <button
                      key={a.id}
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        setActiveNote(a);
                      }}
                      style={{ left: `${pt.x}%`, top: `${pt.y}%`, background: a.color }}
                      className="absolute -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-lg shadow-md flex items-center justify-center text-[#0B0C10] cursor-pointer"
                    >
                      <StickyNote size={13} />
                    </button>
                  );
                }
                if (a.tool === 'stamp') {
                  return (
                    <div
                      key={a.id}
                      style={{ left: `${pt.x}%`, top: `${pt.y}%`, borderColor: a.color, color: a.color }}
                      className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 -rotate-12 border-2 px-2.5 py-0.5 rounded text-[11px] font-bold tracking-wider uppercase bg-white/60"
                    >
                      {a.text}
                    </div>
                  );
                }
                if (a.tool === 'signature' && a.signatureDataUrl) {
                  return (
                    <img
                      key={a.id}
                      src={a.signatureDataUrl}
                      alt="Signature"
                      style={{ left: `${pt.x}%`, top: `${pt.y}%` }}
                      className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 w-28 h-12 object-contain"
                    />
                  );
                }
                return null;
              })}
            </div>

            {/* Page Switcher */}
            <div className="mt-2.5 flex items-center gap-3 text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
              <button disabled={pageIdx <= 0} onClick={() => setPageIdx((p) => p - 1)} className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer" style={{ background: 'var(--jb-surface)' }}>
                {isAr ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
              </button>
              <span className="tabular-nums">
                {isAr ? `صفحة ${pageIdx + 1} من ${pages.length}` : `Page ${pageIdx + 1} of ${pages.length}`} • {visibleAnns.length} {isAr ? 'عنصر' : 'marks'}
              </span>
              <button disabled={pageIdx >= pages.length - 1} onClick={() => setPageIdx((p) => p + 1)} className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer" style={{ background: 'var(--jb-surface)' }}>
                {isAr ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
              </button>
            </div>
          </div>

          {/* Bottom Tool Dock */}
          <div className="px-3 py-2.5 space-y-2" style={{ background: 'var(--jb-surface)', borderTop: '1px solid var(--jb-border)' }}>
            {/* Color + Stroke Width + Draw Signature */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                {COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => setColor(c)}
                    className="w-5 h-5 rounded-full cursor-pointer transition-transform"
                    style={{
                      background: c,
                      transform: color === c ? 'scale(1.2)' : 'scale(1)',
                      boxShadow: color === c ? '0 0 0 2px var(--jb-bg), 0 0 0 3.5px var(--jb-accent)' : undefined,
                    }}
                  />
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min={1}
                  max={8}
                  value={strokeWidth}
                  onChange={(e) => setStrokeWidth(Number(e.target.value))}
                  className="w-16 jb-range"
                />
                <button
                  onClick={() => setShowSigModal(true)}
                  className="px-2 py-1 rounded-lg text-[10.5px] font-medium cursor-pointer"
                  style={{ background: 'var(--jb-accent-soft)', color: 'var(--jb-accent)' }}
                >
                  {isAr ? 'رسم توقيع' : 'New Sign'}
                </button>
              </div>
            </div>

            {/* Scrollable Tool Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto jb-no-scrollbar pb-0.5">
              {tools.map((t) => {
                const Icon = t.icon;
                const active = tool === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => setTool(t.id)}
                    className="px-2.5 py-1.5 rounded-xl text-[10.5px] inline-flex items-center gap-1 shrink-0 cursor-pointer transition-colors"
                    style={{
                      background: active ? 'var(--jb-accent-soft)' : 'var(--jb-surface-elevated)',
                      color: active ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                      border: `1px solid ${active ? 'var(--jb-border-strong)' : 'transparent'}`,
                    }}
                  >
                    <Icon size={12} />
                    <span>{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}

      {/* TAB 2: PAGE MANAGER */}
      {tab === 'pages' && (
        <div className="flex-1 overflow-y-auto jb-scroll p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-[13px] font-semibold">
              {isAr ? `إدارة الصفحات (${pages.length})` : `Page Manager (${pages.length})`}
            </h4>
            <button
              onClick={() => {
                setPages((prev) => [
                  ...prev,
                  {
                    id: `blank-${Date.now()}`,
                    headingAr: `صفحة مضافة ${prev.length + 1}`,
                    headingEn: `Inserted Page ${prev.length + 1}`,
                    paragraphsAr: [],
                    paragraphsEn: [],
                    isBlank: true,
                  },
                ]);
                onNotify(isAr ? 'أُدرجت صفحة فارغة جديدة' : 'Inserted new blank page');
              }}
              className="jb-gold-btn px-3 py-1.5 rounded-xl text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer"
            >
              <FilePlus2 size={13} />
              <span>{isAr ? 'إدراج صفحة' : 'Insert Blank'}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {pages.map((p, idx) => (
              <div
                key={p.id}
                className="p-2.5 rounded-2xl flex flex-col justify-between gap-2"
                style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
              >
                <div
                  className="aspect-[3/4] rounded-xl p-2.5 bg-[#FAF8F2] text-[#1D1B18] overflow-hidden flex flex-col justify-between"
                  style={{ transform: `rotate(${p.rotation ?? 0}deg)` }}
                >
                  <span className="text-[9px] font-bold text-[#9E7631]">#{idx + 1}</span>
                  <p className="text-[10px] font-semibold line-clamp-3">
                    {p.isBlank ? (isAr ? 'صفحة فارغة' : 'Blank Page') : isAr ? p.headingAr : p.headingEn}
                  </p>
                  <span className="text-[8px] text-[#7D776B]">{p.rotation ?? 0}°</span>
                </div>
                <div className="flex items-center justify-between">
                  <button
                    title="Rotate 90°"
                    onClick={() =>
                      setPages((prev) =>
                        prev.map((item, i) => (i === idx ? { ...item, rotation: ((item.rotation ?? 0) + 90) % 360 } : item))
                      )
                    }
                    className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer"
                    style={{ background: 'var(--jb-surface-elevated)' }}
                  >
                    <RotateCw size={12} />
                  </button>
                  <button
                    title="Move Up/Left"
                    disabled={idx === 0}
                    onClick={() =>
                      setPages((prev) => {
                        const copy = [...prev];
                        [copy[idx - 1], copy[idx]] = [copy[idx], copy[idx - 1]];
                        return copy;
                      })
                    }
                    className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer"
                    style={{ background: 'var(--jb-surface-elevated)' }}
                  >
                    <ChevronLeft size={12} />
                  </button>
                  <button
                    title="Extract page to Library"
                    onClick={() => {
                      onCreateDocCopy({
                        ...doc,
                        id: `extract-${Date.now()}`,
                        titleAr: `${doc.titleAr} — ص ${idx + 1}`,
                        titleEn: `${doc.titleEn} — p.${idx + 1}`,
                        pages: [p],
                        pageCount: 1,
                        currentPage: 1,
                        addedMs: Date.now(),
                      });
                      onNotify(isAr ? `استُخرجت صفحة ${idx + 1} كملف مستقل` : `Extracted page ${idx + 1} to Library`);
                    }}
                    className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer"
                    style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-accent)' }}
                  >
                    <FileOutput size={12} />
                  </button>
                  <button
                    title="Delete page"
                    disabled={pages.length <= 1}
                    onClick={() => {
                      setPages((prev) => prev.filter((_, i) => i !== idx));
                      setPageIdx(0);
                    }}
                    className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer"
                    style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-danger)' }}
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Watermark, Page Numbers, Password Protection */}
          <div className="p-3.5 rounded-2xl space-y-3" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
            <div>
              <label className="text-[11px] flex items-center gap-1.5 mb-1" style={{ color: 'var(--jb-text-secondary)' }}>
                <Droplets size={12} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'العلامة المائية' : 'Watermark Text'}</span>
              </label>
              <input
                value={watermark}
                onChange={(e) => setWatermark(e.target.value)}
                placeholder={isAr ? 'مثال: نسخة أصلية — JObat' : 'e.g. CONFIDENTIAL — JObat'}
                className="w-full h-9 px-3 rounded-xl text-[12px] outline-none"
                style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
              />
            </div>

            <div>
              <label className="text-[11px] flex items-center gap-1.5 mb-1" style={{ color: 'var(--jb-text-secondary)' }}>
                <Lock size={12} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'حماية / إزالة كلمة المرور' : 'Set / Remove PDF Password'}</span>
              </label>
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={isAr ? 'اتركه فارغًا لإزالة القفل' : 'Leave empty to keep unlocked'}
                className="w-full h-9 px-3 rounded-xl text-[12px] outline-none"
                style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
              />
            </div>

            <button
              onClick={() => setNumberedPages((v) => !v)}
              className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-[12px] cursor-pointer"
              style={{
                background: numberedPages ? 'var(--jb-accent-soft)' : 'var(--jb-bg)',
                color: numberedPages ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
              }}
            >
              <span className="inline-flex items-center gap-1.5">
                <Hash size={13} />
                {isAr ? 'ترقيم تلقائي للصفحات' : 'Automatic Page Numbering'}
              </span>
              <span>{numberedPages ? 'ON' : 'OFF'}</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: ACROFORMS */}
      {tab === 'forms' && (
        <div className="flex-1 overflow-y-auto jb-scroll p-4 space-y-3">
          <div className="p-4 rounded-2xl space-y-3" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
            <h4 className="text-[13.5px] font-semibold" style={{ color: 'var(--jb-accent)' }}>
              {isAr ? 'تعبئة حقول نموذج PDF (AcroForms)' : 'Interactive PDF AcroForm Fields'}
            </h4>
            {[
              { key: 'reviewer', ar: 'الاسم الكامل / الموقّع', en: 'Signatory / Reviewer Name' },
              { key: 'edition', ar: 'عنوان الطبعة أو العقد', en: 'Edition / Contract Reference' },
              { key: 'catalogNo', ar: 'الرقم المرجعي', en: 'Catalog / Filing Number' },
              { key: 'verified', ar: 'حالة الاعتماد والملاحظات', en: 'Verification Status & Notes' },
            ].map((f) => (
              <div key={f.key}>
                <label className="block text-[11px] mb-1" style={{ color: 'var(--jb-text-secondary)' }}>
                  {isAr ? f.ar : f.en}
                </label>
                <input
                  value={formFields[f.key] ?? ''}
                  onChange={(e) => setFormFields((prev) => ({ ...prev, [f.key]: e.target.value }))}
                  className="w-full h-9 px-3 rounded-xl text-[12px] outline-none"
                  style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border-strong)', color: 'var(--jb-text)' }}
                />
              </div>
            ))}
            <button onClick={() => saveDocument(false)} className="jb-gold-btn w-full py-2.5 rounded-xl text-[12px] font-semibold cursor-pointer">
              {isAr ? 'حفظ حقول النموذج داخل الملف' : 'Save Form Fields into PDF'}
            </button>
          </div>
        </div>
      )}

      {/* Prompt for Free Text or Sticky Note */}
      {promptPos && (
        <div onClick={() => setPromptPos(null)} className="absolute inset-0 z-40 bg-black/60 flex items-center justify-center p-5">
          <div onClick={(e) => e.stopPropagation()} className="w-full rounded-2xl p-4 space-y-3" style={{ background: 'var(--jb-surface-elevated)', border: '1px solid var(--jb-border-strong)' }}>
            <h4 className="text-[13px] font-semibold">
              {promptPos.kind === 'note' ? (isAr ? 'ملاحظة لاصقة جديدة' : 'New Sticky Note') : isAr ? 'إدراج نص حر' : 'Insert Free Text'}
            </h4>
            <input
              autoFocus
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder={isAr ? 'اكتب هنا…' : 'Type text…'}
              className="w-full h-9 px-3 rounded-xl text-[12px] outline-none"
              style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => setPromptPos(null)} className="px-3 py-1.5 text-[11.5px] cursor-pointer">
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  if (promptText.trim()) {
                    pushAnnotations([
                      ...annotations,
                      {
                        id: `ann-${Date.now()}`,
                        page: pageIdx + 1,
                        tool: promptPos.kind,
                        color,
                        strokeWidth: 2,
                        points: [{ x: promptPos.x, y: promptPos.y }],
                        text: promptText.trim(),
                      },
                    ]);
                  }
                  setPromptPos(null);
                }}
                className="jb-gold-btn px-3.5 py-1.5 rounded-xl text-[11.5px] font-semibold cursor-pointer"
              >
                {isAr ? 'إدراج' : 'Place'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sticky Note Reader Popover */}
      {activeNote && (
        <div onClick={() => setActiveNote(null)} className="absolute inset-0 z-40 bg-black/50 flex items-center justify-center p-6">
          <div onClick={(e) => e.stopPropagation()} className="w-full rounded-2xl p-4 space-y-2" style={{ background: 'var(--jb-surface-elevated)', border: '1px solid var(--jb-border-strong)' }}>
            <div className="flex justify-between items-center">
              <span className="text-[11px] font-semibold" style={{ color: 'var(--jb-accent)' }}>
                {isAr ? 'ملاحظة لاصقة' : 'Sticky Note'}
              </span>
              <button onClick={() => setActiveNote(null)} className="cursor-pointer"><X size={14} /></button>
            </div>
            <p className="text-[12.5px] leading-relaxed">{activeNote.text}</p>
          </div>
        </div>
      )}

      {/* Reusable Signature Pad Modal */}
      {showSigModal && (
        <div onClick={() => setShowSigModal(false)} className="absolute inset-0 z-40 bg-black/65 flex items-center justify-center p-4">
          <div onClick={(e) => e.stopPropagation()} className="w-full rounded-3xl p-4 space-y-3 jb-anim-in" style={{ background: 'var(--jb-surface-elevated)', border: '1px solid var(--jb-border-strong)' }}>
            <div className="flex items-center justify-between">
              <h4 className="text-[13.5px] font-semibold">{isAr ? 'التوقيع الإلكتروني المحفوظ' : 'Reusable Signature Vault'}</h4>
              <button onClick={() => setShowSigModal(false)} className="cursor-pointer"><X size={15} /></button>
            </div>
            <canvas
              ref={sigCanvasRef}
              width={320}
              height={130}
              onPointerDown={startSigStroke}
              onPointerMove={moveSigStroke}
              onPointerUp={() => { sigDrawing.current = false; }}
              onPointerLeave={() => { sigDrawing.current = false; }}
              className="w-full h-32 rounded-2xl bg-[#FAF8F2] touch-none cursor-crosshair border border-[#D4B26A]/40"
            />
            {savedSignatures.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto">
                {savedSignatures.map((sig, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setSelectedSig(sig);
                      setTool('signature');
                      setShowSigModal(false);
                    }}
                    className="h-10 px-2 rounded-lg bg-[#FAF8F2] border border-[#D4B26A] shrink-0 cursor-pointer"
                  >
                    <img src={sig} alt="Saved sig" className="h-8 object-contain" />
                  </button>
                ))}
              </div>
            )}
            <div className="flex justify-between">
              <button onClick={clearSigCanvas} className="px-3 py-1.5 rounded-xl text-[11.5px] cursor-pointer" style={{ background: 'var(--jb-surface)' }}>
                {isAr ? 'مسح' : 'Clear'}
              </button>
              <button onClick={commitSig} className="jb-gold-btn px-4 py-1.5 rounded-xl text-[11.5px] font-semibold cursor-pointer">
                {isAr ? 'حفظ واستخدام التوقيع' : 'Save & Use Signature'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
