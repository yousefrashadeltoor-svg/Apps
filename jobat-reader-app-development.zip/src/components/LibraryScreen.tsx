import React, { useMemo, useRef, useState } from 'react';
import {
  Search,
  X,
  LayoutGrid,
  List,
  AlignJustify,
  ArrowUpDown,
  FolderPlus,
  RefreshCw,
  BarChart3,
  MoreVertical,
  Heart,
  PenTool,
  Shield,
  Archive,
  Trash2,
  FolderHeart,
  Lock,
  BookOpen,
  Clock,
  Tag,
  Check,
  Sparkles,
} from 'lucide-react';
import { DocItem, FormatCategory, Lang, SortBy, ViewMode } from '../types';
import { formatBytes } from '../data/sampleData';
import { BookCover, CircularProgress, JobatWordmark } from './BrandVisuals';

interface LibraryScreenProps {
  lang: Lang;
  docs: DocItem[];
  collections: string[];
  tabletMode?: boolean;
  onOpenDoc: (doc: DocItem) => void;
  onEditDoc: (doc: DocItem) => void;
  onUpdateDoc: (id: string, patch: Partial<DocItem>) => void;
  onImportFile: (file: File) => void;
  onOpenStats: () => void;
  onNotify: (msg: string) => void;
}

export const LibraryScreen: React.FC<LibraryScreenProps> = ({
  lang,
  docs,
  collections,
  tabletMode = false,
  onOpenDoc,
  onEditDoc,
  onUpdateDoc,
  onImportFile,
  onOpenStats,
  onNotify,
}) => {
  const isAr = lang === 'ar';
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<FormatCategory>('all');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [sortBy, setSortBy] = useState<SortBy>('lastRead');
  const [sortAsc, setSortAsc] = useState(false);
  const [showSortSheet, setShowSortSheet] = useState(false);
  const [menuDocId, setMenuDocId] = useState<string | null>(null);
  const [newTagText, setNewTagText] = useState('');
  const [scanning, setScanning] = useState(false);
  const [scrollTop, setScrollTop] = useState(0);
  const [pwdPromptDoc, setPwdPromptDoc] = useState<DocItem | null>(null);
  const [pwdInput, setPwdInput] = useState('');
  const [pwdError, setPwdError] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const activeDocs = useMemo(
    () => docs.filter((d) => !d.trashed && !d.archived && !d.vaultLocked),
    [docs]
  );

  const continueDoc = useMemo(() => {
    const inProgress = activeDocs.filter((d) => d.pageCount > 1 && d.currentPage >= 1 && d.currentPage < d.pageCount && !d.password);
    return [...inProgress].sort((a, b) => b.lastReadMs - a.lastReadMs)[0] ?? activeDocs[0];
  }, [activeDocs]);

  // Room FTS4 simulation: searches title, author, extension, tags, collections, full page text & rawCode
  const { filtered, snippets } = useMemo(() => {
    const q = query.trim().toLowerCase();
    const snipMap: Record<string, string> = {};

    const list = activeDocs.filter((d) => {
      if (category !== 'all' && d.category !== category) return false;
      if (!q) return true;
      const metaHit =
        d.titleAr.toLowerCase().includes(q) ||
        d.titleEn.toLowerCase().includes(q) ||
        d.authorAr.toLowerCase().includes(q) ||
        d.authorEn.toLowerCase().includes(q) ||
        d.ext.toLowerCase().includes(q) ||
        d.tags.some((t) => t.toLowerCase().includes(q)) ||
        d.collections.some((c) => c.toLowerCase().includes(q));

      let contentSnippet = '';
      for (const p of d.pages) {
        const pool = [...p.paragraphsAr, ...p.paragraphsEn, p.headingAr, p.headingEn];
        const found = pool.find((line) => line.toLowerCase().includes(q));
        if (found) {
          contentSnippet = found;
          break;
        }
      }
      if (!contentSnippet && d.rawCode?.toLowerCase().includes(q)) {
        contentSnippet = d.rawCode.split('\n').find((l) => l.toLowerCase().includes(q)) ?? '';
      }
      if (contentSnippet) snipMap[d.id] = contentSnippet.slice(0, 95);
      return metaHit || Boolean(contentSnippet);
    });

    const dir = sortAsc ? 1 : -1;
    list.sort((a, b) => {
      switch (sortBy) {
        case 'title': {
          const ta = isAr ? a.titleAr : a.titleEn;
          const tb = isAr ? b.titleAr : b.titleEn;
          return ta.localeCompare(tb, isAr ? 'ar' : 'en') * (sortAsc ? 1 : -1);
        }
        case 'dateAdded':
          return (a.addedMs - b.addedMs) * dir;
        case 'size':
          return (a.sizeBytes - b.sizeBytes) * dir;
        case 'progress':
          return (a.currentPage / Math.max(1, a.pageCount) - b.currentPage / Math.max(1, b.pageCount)) * dir;
        case 'lastRead':
        default:
          return (a.lastReadMs - b.lastReadMs) * dir;
      }
    });

    return { filtered: list, snippets: snipMap };
  }, [activeDocs, category, query, sortBy, sortAsc, isAr]);

  const menuDoc = useMemo(() => docs.find((d) => d.id === menuDocId) ?? null, [docs, menuDocId]);

  const handleDocTap = (doc: DocItem) => {
    if (doc.password) {
      setPwdPromptDoc(doc);
      setPwdInput('');
      setPwdError(false);
      return;
    }
    onOpenDoc(doc);
  };

  const triggerScan = () => {
    if (scanning) return;
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      onNotify(
        isAr
          ? `تمت الفهرسة (WorkManager) • ${activeDocs.length} ملفًا مفهرسًا في FTS`
          : `WorkManager scan complete • ${activeDocs.length} files indexed in FTS`
      );
    }, 850);
  };

  const categories: { id: FormatCategory; ar: string; en: string }[] = [
    { id: 'all', ar: 'الكل', en: 'All' },
    { id: 'pdf', ar: 'PDF', en: 'PDF' },
    { id: 'ebook', ar: 'EPUB · MOBI', en: 'EPUB · MOBI' },
    { id: 'comic_djvu', ar: 'DJVU · CBZ', en: 'DJVU · CBZ' },
    { id: 'office_code', ar: 'نصوص وكود', en: 'Docs & Code' },
    { id: 'image', ar: 'صور', en: 'Images' },
    { id: 'archive', ar: 'أرشيف', en: 'Archives' },
  ];

  const sortOptions: { id: SortBy; ar: string; en: string }[] = [
    { id: 'lastRead', ar: 'آخر قراءة', en: 'Last Read' },
    { id: 'title', ar: 'الاسم أبجديًا', en: 'Title' },
    { id: 'dateAdded', ar: 'تاريخ الإضافة', en: 'Date Added' },
    { id: 'size', ar: 'حجم الملف', en: 'File Size' },
    { id: 'progress', ar: 'نسبة التقدم', en: 'Reading Progress' },
  ];

  const cycleViewMode = () => {
    setViewMode((v) => (v === 'grid' ? 'list' : v === 'list' ? 'compact' : 'grid'));
  };

  return (
    <div className="relative h-full flex flex-col">
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        accept=".pdf,.epub,.mobi,.azw3,.fb2,.djvu,.cbz,.txt,.md,.html,.xhtml,.xml,.csv,.docx,.odt,.jpg,.jpeg,.png,.webp,.gif,.svg,.zip"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onImportFile(f);
          e.currentTarget.value = '';
        }}
      />

      {/* Scrollable Body with Subtle Header Parallax */}
      <div
        onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
        className="flex-1 overflow-y-auto jb-scroll px-4 pb-28 pt-2"
      >
        {/* Brand Header */}
        <header
          className="flex items-center justify-between py-2"
          style={{
            transform: `translateY(${Math.min(scrollTop * 0.14, 10)}px)`,
            opacity: Math.max(0.78, 1 - scrollTop / 360),
          }}
        >
          <JobatWordmark size="md" />
          <div className="flex items-center gap-1.5">
            <button
              onClick={onOpenStats}
              title={isAr ? 'إحصائيات القراءة' : 'Reading Analytics'}
              className="w-9 h-9 rounded-xl flex items-center justify-center transition-colors cursor-pointer"
              style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)', color: 'var(--jb-text-secondary)' }}
            >
              <BarChart3 size={16} strokeWidth={1.7} />
            </button>
            <button
              onClick={triggerScan}
              title={isAr ? 'تحديث وفهرسة المجلدات' : 'Rescan Folders'}
              className="w-9 h-9 rounded-xl flex items-center justify-center transition-colors cursor-pointer"
              style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)', color: 'var(--jb-text-secondary)' }}
            >
              <RefreshCw size={15} strokeWidth={1.7} className={scanning ? 'animate-spin' : ''} style={scanning ? { color: 'var(--jb-accent)' } : undefined} />
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              title={isAr ? 'فتح ملف (SAF)' : 'Open File (SAF)'}
              className="jb-gold-btn h-9 px-3 rounded-xl flex items-center gap-1.5 text-[11.5px] font-semibold cursor-pointer active:scale-95 transition-transform"
            >
              <FolderPlus size={14} strokeWidth={2} />
              <span>{isAr ? 'فتح' : 'Open'}</span>
            </button>
          </div>
        </header>

        {scanning && (
          <div className="h-1 w-full rounded-full overflow-hidden mb-2" style={{ background: 'var(--jb-surface)' }}>
            <div className="h-full w-full jb-shimmer" />
          </div>
        )}

        {/* Instant Room FTS Search */}
        <div
          className="mt-2 flex items-center gap-2.5 px-3.5 h-11 rounded-2xl transition-colors"
          style={{
            background: 'var(--jb-surface)',
            border: `1px solid ${query ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
          }}
        >
          <Search size={15} style={{ color: query ? 'var(--jb-accent)' : 'var(--jb-text-tertiary)' }} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={isAr ? 'بحث فوري في الكتب، المؤلفين، والمحتوى…' : 'Instant search titles, authors & full text…'}
            className="flex-1 bg-transparent text-[12.5px] outline-none placeholder:opacity-60"
            style={{ color: 'var(--jb-text)' }}
          />
          {query && (
            <button onClick={() => setQuery('')} className="p-1 cursor-pointer" style={{ color: 'var(--jb-text-secondary)' }}>
              <X size={14} />
            </button>
          )}
        </div>

        {/* Continue Reading Hero Card */}
        {continueDoc && !query && category === 'all' && (
          <div
            onClick={() => handleDocTap(continueDoc)}
            className="mt-3.5 p-3.5 rounded-[20px] flex items-center gap-3.5 cursor-pointer group transition-all relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, var(--jb-surface-elevated) 0%, var(--jb-surface) 100%)',
              border: '1px solid var(--jb-border-strong)',
              boxShadow: '0 8px 26px rgba(0,0,0,0.22)',
            }}
          >
            <BookCover doc={continueDoc} lang={lang} compact className="w-12 h-16 rounded-xl shrink-0 shadow-md" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 text-[10px] font-semibold tracking-wider uppercase" style={{ color: 'var(--jb-accent)' }}>
                <Sparkles size={10} />
                <span>{isAr ? 'متابعة القراءة' : 'Continue Reading'}</span>
              </div>
              <h3 className="text-[13.5px] font-semibold truncate mt-0.5" style={{ color: 'var(--jb-text)' }}>
                {isAr ? continueDoc.titleAr : continueDoc.titleEn}
              </h3>
              <p className="text-[11px] truncate" style={{ color: 'var(--jb-text-secondary)' }}>
                {isAr ? continueDoc.authorAr : continueDoc.authorEn}
              </p>
              <div className="flex items-center gap-2 mt-1 text-[10.5px]" style={{ color: 'var(--jb-text-tertiary)' }}>
                <span>
                  {isAr
                    ? `صفحة ${continueDoc.currentPage} من ${continueDoc.pageCount}`
                    : `Page ${continueDoc.currentPage} of ${continueDoc.pageCount}`}
                </span>
                <span>•</span>
                <span className="inline-flex items-center gap-1">
                  <Clock size={10} />
                  {isAr
                    ? `${Math.max(2, (continueDoc.pageCount - continueDoc.currentPage) * 6)} د متبقية`
                    : `${Math.max(2, (continueDoc.pageCount - continueDoc.currentPage) * 6)}m left`}
                </span>
              </div>
            </div>
            <CircularProgress value={continueDoc.currentPage / Math.max(1, continueDoc.pageCount)} size={50} stroke={3} />
          </div>
        )}

        {/* Filter Chips */}
        <div className="mt-3.5 flex items-center gap-1.5 overflow-x-auto jb-no-scrollbar pb-1">
          {categories.map((cat) => {
            const active = category === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className="px-3 py-1.5 rounded-full text-[11px] font-medium whitespace-nowrap transition-all cursor-pointer shrink-0"
                style={{
                  background: active ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                  color: active ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                  border: `1px solid ${active ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                }}
              >
                {isAr ? cat.ar : cat.en}
              </button>
            );
          })}
        </div>

        {/* Section Toolbar: Count + Sort + ViewMode */}
        <div className="mt-3 mb-2.5 flex items-center justify-between">
          <span className="text-[11.5px] font-medium" style={{ color: 'var(--jb-text-secondary)' }}>
            {isAr ? `${filtered.length} مستندًا` : `${filtered.length} documents`}
          </span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowSortSheet(true)}
              className="h-7 px-2.5 rounded-lg inline-flex items-center gap-1 text-[11px] cursor-pointer"
              style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)', color: 'var(--jb-text-secondary)' }}
            >
              <ArrowUpDown size={12} style={{ color: 'var(--jb-accent)' }} />
              <span>{sortOptions.find((s) => s.id === sortBy)?.[isAr ? 'ar' : 'en']}</span>
            </button>
            <button
              onClick={cycleViewMode}
              title={viewMode}
              className="h-7 w-7 rounded-lg inline-flex items-center justify-center cursor-pointer"
              style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)', color: 'var(--jb-text-secondary)' }}
            >
              {viewMode === 'grid' ? <LayoutGrid size={13} /> : viewMode === 'list' ? <List size={13} /> : <AlignJustify size={13} />}
            </button>
          </div>
        </div>

        {/* Empty State */}
        {filtered.length === 0 ? (
          <div className="py-14 flex flex-col items-center text-center gap-3 jb-anim-in">
            <div
              className="w-16 h-16 rounded-3xl flex items-center justify-center"
              style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border-strong)' }}
            >
              <BookOpen size={26} style={{ color: 'var(--jb-accent)' }} strokeWidth={1.4} />
            </div>
            <p className="text-[14px] font-medium" style={{ color: 'var(--jb-text)' }}>
              {isAr ? 'لا توجد مستندات مطابقة' : 'No matching documents'}
            </p>
            <p className="text-[11.5px] max-w-[220px]" style={{ color: 'var(--jb-text-secondary)' }}>
              {isAr ? 'جرّب تعديل كلمة البحث أو افتح ملفًا جديدًا من جهازك.' : 'Try adjusting your search filter or import a file from your device.'}
            </p>
          </div>
        ) : viewMode === 'grid' ? (
          <div className={`grid ${tabletMode ? 'grid-cols-4' : 'grid-cols-2'} gap-3 jb-anim-in`}>
            {filtered.map((doc) => {
              const pct = Math.round((doc.currentPage / Math.max(1, doc.pageCount)) * 100);
              return (
                <div
                  key={doc.id}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setMenuDocId(doc.id);
                  }}
                  className="group rounded-2xl p-2 flex flex-col transition-all"
                  style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
                >
                  <div onClick={() => handleDocTap(doc)} className="cursor-pointer">
                    <BookCover doc={doc} lang={lang} className="w-full aspect-[3/4] rounded-xl shadow-sm group-hover:scale-[1.01] transition-transform" />
                  </div>
                  <div className="pt-2 px-0.5 flex items-center justify-between gap-1">
                    <div onClick={() => handleDocTap(doc)} className="min-w-0 flex-1 cursor-pointer">
                      <p className="text-[11.5px] font-medium truncate" style={{ color: 'var(--jb-text)' }}>
                        {isAr ? doc.titleAr : doc.titleEn}
                      </p>
                      <div className="flex items-center gap-1.5 text-[10px]" style={{ color: 'var(--jb-text-tertiary)' }}>
                        <span>{formatBytes(doc.sizeBytes)}</span>
                        <span>•</span>
                        <span style={{ color: 'var(--jb-accent)' }}>{doc.password ? (isAr ? 'محمي' : 'Locked') : `${pct}%`}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => setMenuDocId(doc.id)}
                      aria-label="Document actions"
                      className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0 cursor-pointer"
                      style={{ color: 'var(--jb-text-secondary)' }}
                    >
                      <MoreVertical size={13} />
                    </button>
                  </div>
                  {query && snippets[doc.id] && (
                    <p
                      className="mt-1.5 px-2 py-1 rounded-lg text-[10px] line-clamp-2"
                      style={{ background: 'var(--jb-accent-soft)', color: 'var(--jb-text-secondary)' }}
                    >
                      “{snippets[doc.id]}…”
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col gap-2 jb-anim-in">
            {filtered.map((doc) => {
              const pct = Math.round((doc.currentPage / Math.max(1, doc.pageCount)) * 100);
              const isCompact = viewMode === 'compact';
              return (
                <div
                  key={doc.id}
                  className={`rounded-2xl ${isCompact ? 'px-3 py-2' : 'p-2.5'} flex items-center gap-3 transition-colors`}
                  style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
                >
                  <div onClick={() => handleDocTap(doc)} className="cursor-pointer shrink-0">
                    <BookCover
                      doc={doc}
                      lang={lang}
                      compact
                      className={isCompact ? 'w-8 h-9 rounded-lg' : 'w-11 h-14 rounded-xl'}
                    />
                  </div>
                  <div onClick={() => handleDocTap(doc)} className="flex-1 min-w-0 cursor-pointer">
                    <div className="flex items-center gap-1.5">
                      <p className="text-[12.5px] font-medium truncate" style={{ color: 'var(--jb-text)' }}>
                        {isAr ? doc.titleAr : doc.titleEn}
                      </p>
                      {doc.password && <Lock size={11} style={{ color: 'var(--jb-accent)' }} />}
                    </div>
                    {!isCompact && (
                      <p className="text-[11px] truncate" style={{ color: 'var(--jb-text-secondary)' }}>
                        {isAr ? doc.authorAr : doc.authorEn} • {doc.ext.toUpperCase()} • {formatBytes(doc.sizeBytes)}
                      </p>
                    )}
                    {query && snippets[doc.id] && (
                      <p className="text-[10px] mt-1 line-clamp-1" style={{ color: 'var(--jb-accent)' }}>
                        FTS: “{snippets[doc.id]}…”
                      </p>
                    )}
                    {!isCompact && (
                      <div className="mt-1.5 h-1 w-full rounded-full overflow-hidden" style={{ background: 'var(--jb-border)' }}>
                        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: 'var(--jb-accent)' }} />
                      </div>
                    )}
                  </div>
                  <span className="text-[10.5px] font-medium tabular-nums shrink-0" style={{ color: 'var(--jb-accent)' }}>
                    {pct}%
                  </span>
                  <button
                    onClick={() => setMenuDocId(doc.id)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 cursor-pointer"
                    style={{ color: 'var(--jb-text-secondary)' }}
                  >
                    <MoreVertical size={14} />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Sort Bottom Sheet */}
      {showSortSheet && (
        <div
          onClick={() => setShowSortSheet(false)}
          className="absolute inset-0 z-30 bg-black/55 flex items-end"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-3xl p-5 jb-sheet-in"
            style={{ background: 'var(--jb-surface-elevated)', borderTop: '1px solid var(--jb-border-strong)' }}
          >
            <div className="w-10 h-1 rounded-full mx-auto mb-4" style={{ background: 'var(--jb-border-strong)' }} />
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-[14px] font-semibold">{isAr ? 'ترتيب المكتبة' : 'Sort Library'}</h4>
              <button
                onClick={() => setSortAsc((v) => !v)}
                className="text-[11px] px-2.5 py-1 rounded-lg cursor-pointer"
                style={{ background: 'var(--jb-accent-soft)', color: 'var(--jb-accent)' }}
              >
                {sortAsc ? (isAr ? 'تصاعدي ↑' : 'Ascending ↑') : isAr ? 'تنازلي ↓' : 'Descending ↓'}
              </button>
            </div>
            <div className="flex flex-col gap-1">
              {sortOptions.map((opt) => {
                const active = sortBy === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => {
                      setSortBy(opt.id);
                      setShowSortSheet(false);
                    }}
                    className="flex items-center justify-between px-3.5 py-2.5 rounded-xl text-[12.5px] cursor-pointer"
                    style={{
                      background: active ? 'var(--jb-accent-soft)' : 'transparent',
                      color: active ? 'var(--jb-accent)' : 'var(--jb-text)',
                    }}
                  >
                    <span>{isAr ? opt.ar : opt.en}</span>
                    {active && <Check size={15} />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Password Unlock Modal */}
      {pwdPromptDoc && (
        <div
          onClick={() => setPwdPromptDoc(null)}
          className="absolute inset-0 z-40 bg-black/65 flex items-center justify-center p-5"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-3xl p-5 jb-anim-in"
            style={{ background: 'var(--jb-surface-elevated)', border: '1px solid var(--jb-border-strong)' }}
          >
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'var(--jb-accent-soft)' }}>
                <Lock size={17} style={{ color: 'var(--jb-accent)' }} />
              </div>
              <div>
                <h4 className="text-[14px] font-semibold">{isAr ? 'مستند محمي بكلمة مرور' : 'Password-Protected PDF'}</h4>
                <p className="text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
                  {isAr ? 'كلمة المرور التجريبية: 1234' : 'Demo password: 1234'}
                </p>
              </div>
            </div>
            <input
              type="password"
              autoFocus
              value={pwdInput}
              onChange={(e) => {
                setPwdInput(e.target.value);
                setPwdError(false);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  if (pwdInput === pwdPromptDoc.password) {
                    const target = pwdPromptDoc;
                    setPwdPromptDoc(null);
                    onOpenDoc(target);
                  } else setPwdError(true);
                }
              }}
              placeholder={isAr ? 'أدخل كلمة المرور…' : 'Enter document password…'}
              className="mt-2 w-full h-10 px-3.5 rounded-xl text-[13px] outline-none"
              style={{
                background: 'var(--jb-bg)',
                border: `1px solid ${pwdError ? 'var(--jb-danger)' : 'var(--jb-border-strong)'}`,
                color: 'var(--jb-text)',
              }}
            />
            {pwdError && (
              <p className="text-[11px] mt-1.5" style={{ color: 'var(--jb-danger)' }}>
                {isAr ? 'كلمة المرور غير صحيحة، حاول مرة أخرى.' : 'Incorrect password. Please try again.'}
              </p>
            )}
            <div className="flex justify-end gap-2 mt-4">
              <button
                onClick={() => setPwdPromptDoc(null)}
                className="px-3.5 py-2 rounded-xl text-[12px] cursor-pointer"
                style={{ color: 'var(--jb-text-secondary)' }}
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  if (pwdInput === pwdPromptDoc.password) {
                    const target = pwdPromptDoc;
                    setPwdPromptDoc(null);
                    onOpenDoc(target);
                  } else setPwdError(true);
                }}
                className="jb-gold-btn px-4 py-2 rounded-xl text-[12px] font-semibold cursor-pointer"
              >
                {isAr ? 'فتح المستند' : 'Unlock'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Document Context Bottom Sheet */}
      {menuDoc && (
        <div onClick={() => setMenuDocId(null)} className="absolute inset-0 z-30 bg-black/60 flex items-end">
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full rounded-t-3xl p-5 max-h-[82%] overflow-y-auto jb-scroll jb-sheet-in"
            style={{ background: 'var(--jb-surface-elevated)', borderTop: '1px solid var(--jb-border-strong)' }}
          >
            <div className="w-10 h-1 rounded-full mx-auto mb-3.5" style={{ background: 'var(--jb-border-strong)' }} />
            <div className="flex items-center gap-3 pb-3 mb-3" style={{ borderBottom: '1px solid var(--jb-border)' }}>
              <BookCover doc={menuDoc} lang={lang} compact className="w-10 h-13 rounded-lg" />
              <div className="min-w-0 flex-1">
                <h4 className="text-[13.5px] font-semibold truncate">{isAr ? menuDoc.titleAr : menuDoc.titleEn}</h4>
                <p className="text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
                  {menuDoc.ext.toUpperCase()} • {formatBytes(menuDoc.sizeBytes)} • {menuDoc.pageCount} {isAr ? 'ص' : 'p'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setMenuDocId(null);
                  handleDocTap(menuDoc);
                }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-[12px] cursor-pointer"
                style={{ background: 'var(--jb-surface)', color: 'var(--jb-text)' }}
              >
                <BookOpen size={14} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'قراءة الآن' : 'Read Now'}</span>
              </button>
              <button
                onClick={() => {
                  setMenuDocId(null);
                  onEditDoc(menuDoc);
                }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-[12px] cursor-pointer"
                style={{ background: 'var(--jb-surface)', color: 'var(--jb-text)' }}
              >
                <PenTool size={14} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'تحرير متقدم' : 'Open Editor'}</span>
              </button>
              <button
                onClick={() => {
                  onUpdateDoc(menuDoc.id, { favorite: !menuDoc.favorite });
                  onNotify(menuDoc.favorite ? (isAr ? 'أُزيل من المفضلة' : 'Removed from Favorites') : isAr ? 'أُضيف إلى المفضلة' : 'Added to Favorites');
                }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-[12px] cursor-pointer"
                style={{ background: 'var(--jb-surface)', color: 'var(--jb-text)' }}
              >
                <Heart size={14} fill={menuDoc.favorite ? 'var(--jb-accent)' : 'none'} style={{ color: 'var(--jb-accent)' }} />
                <span>{menuDoc.favorite ? (isAr ? 'في المفضلة' : 'Favorited') : isAr ? 'إضافة للمفضلة' : 'Favorite'}</span>
              </button>
              <button
                onClick={() => {
                  onUpdateDoc(menuDoc.id, { vaultLocked: true });
                  setMenuDocId(null);
                  onNotify(isAr ? 'نُقل إلى الخزنة المشفرة AES-256' : 'Sealed in AES-256 Encrypted Vault');
                }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-[12px] cursor-pointer"
                style={{ background: 'var(--jb-surface)', color: 'var(--jb-text)' }}
              >
                <Shield size={14} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'نقل للخزنة' : 'Lock in Vault'}</span>
              </button>
              <button
                onClick={() => {
                  onUpdateDoc(menuDoc.id, { archived: true });
                  setMenuDocId(null);
                  onNotify(isAr ? 'نُقل إلى الأرشيف' : 'Moved to Archive');
                }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-[12px] cursor-pointer"
                style={{ background: 'var(--jb-surface)', color: 'var(--jb-text)' }}
              >
                <Archive size={14} style={{ color: 'var(--jb-text-secondary)' }} />
                <span>{isAr ? 'أرشفة' : 'Archive'}</span>
              </button>
              <button
                onClick={() => {
                  onUpdateDoc(menuDoc.id, { trashed: true });
                  setMenuDocId(null);
                  onNotify(isAr ? 'نُقل إلى سلة المحذوفات' : 'Moved to Trash');
                }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-[12px] cursor-pointer"
                style={{ background: 'var(--jb-surface)', color: 'var(--jb-danger)' }}
              >
                <Trash2 size={14} />
                <span>{isAr ? 'حذف للسلة' : 'Move to Trash'}</span>
              </button>
            </div>

            {/* Collections toggle */}
            <div className="mt-3.5">
              <div className="flex items-center gap-1.5 text-[11px] font-medium mb-2" style={{ color: 'var(--jb-text-secondary)' }}>
                <FolderHeart size={12} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'المجموعات' : 'Collections'}</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {collections.map((col) => {
                  const inCol = menuDoc.collections.includes(col);
                  return (
                    <button
                      key={col}
                      onClick={() => {
                        const next = inCol ? menuDoc.collections.filter((c) => c !== col) : [...menuDoc.collections, col];
                        onUpdateDoc(menuDoc.id, { collections: next });
                      }}
                      className="px-2.5 py-1 rounded-full text-[11px] cursor-pointer"
                      style={{
                        background: inCol ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                        color: inCol ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                        border: `1px solid ${inCol ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                      }}
                    >
                      {inCol ? '✓ ' : '+ '}
                      {col}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Tags editor */}
            <div className="mt-3">
              <div className="flex items-center gap-1.5 text-[11px] font-medium mb-1.5" style={{ color: 'var(--jb-text-secondary)' }}>
                <Tag size={12} style={{ color: 'var(--jb-accent)' }} />
                <span>{isAr ? 'الوسوم' : 'Tags'}</span>
              </div>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {menuDoc.tags.map((t) => (
                  <button
                    key={t}
                    onClick={() => onUpdateDoc(menuDoc.id, { tags: menuDoc.tags.filter((x) => x !== t) })}
                    className="px-2 py-0.5 rounded-md text-[10.5px] cursor-pointer"
                    style={{ background: 'var(--jb-surface)', color: 'var(--jb-text-secondary)' }}
                  >
                    #{t} ×
                  </button>
                ))}
              </div>
              <div className="flex gap-1.5">
                <input
                  value={newTagText}
                  onChange={(e) => setNewTagText(e.target.value)}
                  placeholder={isAr ? 'أضف وسمًا جديدًا…' : 'Add tag…'}
                  className="flex-1 h-8 px-2.5 rounded-lg text-[11.5px] outline-none"
                  style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
                />
                <button
                  onClick={() => {
                    const clean = newTagText.trim().replace(/^#/, '');
                    if (clean && !menuDoc.tags.includes(clean)) {
                      onUpdateDoc(menuDoc.id, { tags: [...menuDoc.tags, clean] });
                      setNewTagText('');
                    }
                  }}
                  className="jb-gold-btn px-3 h-8 rounded-lg text-[11px] font-semibold cursor-pointer"
                >
                  {isAr ? 'إضافة' : 'Add'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
