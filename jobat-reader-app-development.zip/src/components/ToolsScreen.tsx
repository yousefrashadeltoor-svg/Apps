import React, { useState } from 'react';
import {
  PenTool,
  FileCode2,
  Image as ImageIcon,
  Merge,
  Scissors,
  Minimize2,
  Lock,
  RefreshCw,
  Quote,
  FolderArchive,
  Layers,
  Download,
  Printer,
  X,
  Check,
  FileCheck2,
} from 'lucide-react';
import { DocItem, Lang, QuoteItem } from '../types';
import { ALL_SUPPORTED_FORMATS, formatBytes } from '../data/sampleData';

interface ToolsScreenProps {
  lang: Lang;
  docs: DocItem[];
  quotes: QuoteItem[];
  onLaunchPdfEditor: (doc: DocItem, tab?: 'annotate' | 'pages' | 'forms') => void;
  onLaunchTextEditor: (doc: DocItem) => void;
  onLaunchImageEditor: (doc: DocItem) => void;
  onOpenArchive: (doc: DocItem) => void;
  onAddDoc: (doc: DocItem) => void;
  onUpdateDoc: (id: string, patch: Partial<DocItem>) => void;
  onNotify: (msg: string) => void;
}

type ToolModal = null | 'merge' | 'split' | 'compress' | 'protect' | 'convert' | 'quotes' | 'formats';

export const ToolsScreen: React.FC<ToolsScreenProps> = ({
  lang,
  docs,
  quotes,
  onLaunchPdfEditor,
  onLaunchTextEditor,
  onLaunchImageEditor,
  onOpenArchive,
  onAddDoc,
  onUpdateDoc,
  onNotify,
}) => {
  const isAr = lang === 'ar';
  const activeDocs = docs.filter((d) => !d.trashed && !d.vaultLocked);
  const pdfDocs = activeDocs.filter((d) => d.ext === 'pdf' || d.ext === 'epub' || d.ext === 'djvu');
  const codeDocs = activeDocs.filter((d) => ['md', 'txt', 'html', 'xml', 'csv'].includes(d.ext));
  const imgDocs = activeDocs.filter((d) => d.category === 'image');
  const archiveDoc = activeDocs.find((d) => d.category === 'archive');

  const [modal, setModal] = useState<ToolModal>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>(pdfDocs.slice(0, 2).map((d) => d.id));
  const [targetId, setTargetId] = useState<string>(pdfDocs[0]?.id ?? '');
  const [splitFrom, setSplitFrom] = useState(1);
  const [splitTo, setSplitTo] = useState(2);
  const [compressLevel, setCompressLevel] = useState<0.75 | 0.52 | 0.35>(0.52);
  const [pwdValue, setPwdValue] = useState('');
  const [quoteCard, setQuoteCard] = useState<QuoteItem | null>(quotes[0] ?? null);

  const runMerge = () => {
    const chosen = activeDocs.filter((d) => selectedIds.includes(d.id));
    if (chosen.length < 2) return;
    const mergedPages = chosen.flatMap((d) => d.pages);
    const totalSize = chosen.reduce((acc, d) => acc + d.sizeBytes, 0);
    const created: DocItem = {
      ...chosen[0],
      id: `merged-${Date.now()}`,
      titleAr: `ملف مدمج (${chosen.length} مستندات)`,
      titleEn: `Merged Document (${chosen.length} files)`,
      ext: 'pdf',
      category: 'pdf',
      pages: mergedPages,
      pageCount: mergedPages.length,
      currentPage: 1,
      sizeBytes: Math.round(totalSize * 0.92),
      password: undefined,
      addedMs: Date.now(),
      lastReadMs: Date.now(),
    };
    onAddDoc(created);
    setModal(null);
    onNotify(isAr ? `تم دمج ${chosen.length} ملفات (${mergedPages.length} صفحة) في المكتبة` : `Merged ${chosen.length} PDFs (${mergedPages.length} pages) into Library`);
  };

  const runSplit = () => {
    const src = activeDocs.find((d) => d.id === targetId) ?? pdfDocs[0];
    if (!src) return;
    const start = Math.max(1, Math.min(splitFrom, src.pages.length));
    const end = Math.max(start, Math.min(splitTo, src.pages.length));
    const slice = src.pages.slice(start - 1, end);
    onAddDoc({
      ...src,
      id: `split-${Date.now()}`,
      titleAr: `${src.titleAr} (ص ${start}–${end})`,
      titleEn: `${src.titleEn} (p.${start}–${end})`,
      ext: 'pdf',
      category: 'pdf',
      pages: slice,
      pageCount: slice.length,
      currentPage: 1,
      sizeBytes: Math.round((src.sizeBytes * slice.length) / Math.max(1, src.pages.length)),
      password: undefined,
      addedMs: Date.now(),
      lastReadMs: Date.now(),
    });
    setModal(null);
    onNotify(isAr ? `تم تقسيم الصفحات ${start}–${end} في ملف جديد` : `Split pages ${start}–${end} into a new PDF`);
  };

  const runCompress = () => {
    const src = activeDocs.find((d) => d.id === targetId) ?? pdfDocs[0];
    if (!src) return;
    const newBytes = Math.max(12_000, Math.round(src.sizeBytes * compressLevel));
    const savedPct = Math.round((1 - compressLevel) * 100);
    onUpdateDoc(src.id, { sizeBytes: newBytes });
    setModal(null);
    onNotify(
      isAr
        ? `تم ضغط الملف بنسبة ${savedPct}% ← الحجم الجديد ${formatBytes(newBytes)}`
        : `Compressed by ${savedPct}% → new size ${formatBytes(newBytes)}`
    );
  };

  const runProtect = () => {
    const src = activeDocs.find((d) => d.id === targetId) ?? pdfDocs[0];
    if (!src) return;
    const clean = pwdValue.trim();
    onUpdateDoc(src.id, { password: clean || undefined });
    setModal(null);
    onNotify(
      clean
        ? isAr
          ? 'تم تشفير المستند بكلمة مرور بنجاح'
          : 'Password protection applied'
        : isAr
        ? 'تمت إزالة كلمة المرور عن المستند'
        : 'Password protection removed'
    );
  };

  const runConvert = (kind: 'img2pdf' | 'pdf2img' | 'txt2pdf') => {
    if (kind === 'img2pdf') {
      const img = imgDocs[0];
      onAddDoc({
        ...(pdfDocs[0] ?? activeDocs[0]),
        id: `conv-img-${Date.now()}`,
        titleAr: 'صور محوّلة إلى PDF',
        titleEn: 'Converted_Images_Portfolio.pdf',
        authorAr: 'محوّل JObat',
        authorEn: 'JObat Converter',
        ext: 'pdf',
        category: 'pdf',
        pageCount: 1,
        currentPage: 1,
        sizeBytes: 1_240_000,
        password: undefined,
        addedMs: Date.now(),
        lastReadMs: Date.now(),
        pages: [
          {
            id: `cp-${Date.now()}`,
            headingAr: img?.titleAr ?? 'صورة محوّلة إلى PDF',
            headingEn: img?.titleEn ?? 'Converted Image Sheet',
            paragraphsAr: ['تم التحويل محليًا بجودة طباعة عالية عبر محرك JObat.'],
            paragraphsEn: ['Converted 100% offline at print resolution via JObat Engine.'],
            imageUrl: img?.coverStyle.imageUrl || '/images/sample-photo.jpg',
          },
        ],
      });
    } else if (kind === 'pdf2img') {
      onAddDoc({
        ...(imgDocs[0] ?? activeDocs[0]),
        id: `conv-png-${Date.now()}`,
        titleAr: 'صفحة PDF مصدّرة.webp',
        titleEn: 'Exported_PDF_Page_01.webp',
        ext: 'webp',
        category: 'image',
        sizeBytes: 620_000,
        pageCount: 1,
        currentPage: 1,
        addedMs: Date.now(),
        lastReadMs: Date.now(),
      });
    } else {
      const src = codeDocs[0];
      onAddDoc({
        ...(pdfDocs[0] ?? activeDocs[0]),
        id: `conv-md-${Date.now()}`,
        titleAr: `${src?.titleAr.replace(/\.\w+$/, '') ?? 'ملاحظات'} (محوّل PDF)`,
        titleEn: `${src?.titleEn.replace(/\.\w+$/, '') ?? 'Notes'}.pdf`,
        ext: 'pdf',
        category: 'pdf',
        sizeBytes: 410_000,
        pageCount: 1,
        currentPage: 1,
        password: undefined,
        addedMs: Date.now(),
        lastReadMs: Date.now(),
        pages: [
          {
            id: `mdpdf-${Date.now()}`,
            headingAr: src?.titleAr ?? 'مستند نصي محوّل',
            headingEn: src?.titleEn ?? 'Typeset Markdown PDF',
            paragraphsAr: (src?.rawCode ?? '').split('\n\n').filter(Boolean).slice(0, 5),
            paragraphsEn: (src?.rawCode ?? '').split('\n\n').filter(Boolean).slice(0, 5),
          },
        ],
      });
    }
    setModal(null);
    onNotify(isAr ? 'اكتمل التحويل وأُضيف الملف الجديد إلى المكتبة' : 'Conversion complete — added to Library');
  };

  const exportQuotesMarkdown = () => {
    const md = quotes
      .map((q) => `> "${q.text}"\n— **${q.docTitle}** (${q.author}, p.${q.page})${q.note ? `\n*Note:* ${q.note}` : ''}`)
      .join('\n\n---\n\n');
    const blob = new Blob([`# 𝒥𝒪 bat Excerpts & Quotes\n\n${md}\n`], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'jobat-excerpts.md';
    a.click();
    URL.revokeObjectURL(url);
    onNotify(isAr ? 'تم تصدير جميع الاقتباسات بصيغة Markdown' : 'Exported all excerpts as Markdown');
  };

  const downloadQuoteCardPng = (q: QuoteItem) => {
    const c = document.createElement('canvas');
    c.width = 720;
    c.height = 480;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#0B0C10';
    ctx.fillRect(0, 0, 720, 480);
    ctx.strokeStyle = '#D4B26A';
    ctx.lineWidth = 2;
    ctx.strokeRect(28, 28, 664, 424);
    ctx.fillStyle = '#D4B26A';
    ctx.font = 'italic 600 26px Georgia, serif';
    ctx.fillText('JObat — Obsidian & Champagne', 56, 78);
    ctx.fillStyle = '#F4F0E8';
    ctx.font = '22px Georgia, serif';
    const words = q.text.split(' ');
    let line = '';
    let y = 160;
    words.forEach((w) => {
      if ((line + w).length > 46) {
        ctx.fillText(line, 56, y);
        line = w + ' ';
        y += 36;
      } else line += w + ' ';
    });
    if (line) ctx.fillText(line, 56, y);
    ctx.fillStyle = '#9FA4B0';
    ctx.font = '16px sans-serif';
    ctx.fillText(`— ${q.author} • ${q.docTitle} (p.${q.page})`, 56, 412);
    const a = document.createElement('a');
    a.href = c.toDataURL('image/png');
    a.download = 'jobat-quote-card.png';
    a.click();
    onNotify(isAr ? 'تم تصدير بطاقة الاقتباس الفاخرة (PNG)' : 'Downloaded Obsidian & Champagne Quote Card');
  };

  const studioCards = [
    {
      icon: PenTool,
      title: isAr ? 'محرر PDF والتوقيع' : 'PDF Annotation Studio',
      sub: isAr ? 'تمييز، قلم، أختام، AcroForms' : 'Ink, stamps, sign & AcroForms',
      action: () => pdfDocs[0] && onLaunchPdfEditor(pdfDocs[0], 'annotate'),
    },
    {
      icon: Layers,
      title: isAr ? 'إدارة صفحات PDF' : 'PDF Page Manager',
      sub: isAr ? 'ترتيب، تدوير، استخراج، علامة مائية' : 'Reorder, rotate, extract, watermark',
      action: () => pdfDocs[0] && onLaunchPdfEditor(pdfDocs[0], 'pages'),
    },
    {
      icon: FileCode2,
      title: isAr ? 'محرر النصوص والكود' : 'Text & Code Editor',
      sub: isAr ? 'MD/HTML/XML/CSV + Regex' : 'Syntax highlight, Regex & preview',
      action: () => codeDocs[0] && onLaunchTextEditor(codeDocs[0]),
    },
    {
      icon: ImageIcon,
      title: isAr ? 'محرر الصور' : 'Image Editor',
      sub: isAr ? 'قص، ألوان، فلاتر، طمس وتصدير' : 'Crop, grade, filters, blur & export',
      action: () => imgDocs[0] && onLaunchImageEditor(imgDocs[0]),
    },
  ];

  const utilityCards = [
    { icon: Merge, label: isAr ? 'دمج PDF' : 'Merge PDF', onClick: () => setModal('merge') },
    { icon: Scissors, label: isAr ? 'تقسيم PDF' : 'Split PDF', onClick: () => setModal('split') },
    { icon: Minimize2, label: isAr ? 'ضغط الحجم' : 'Compress', onClick: () => setModal('compress') },
    { icon: Lock, label: isAr ? 'كلمة مرور' : 'Password', onClick: () => setModal('protect') },
    { icon: RefreshCw, label: isAr ? 'تحويل صيغ' : 'Convert', onClick: () => setModal('convert') },
    { icon: Quote, label: isAr ? `مقتطفات (${quotes.length})` : `Quotes (${quotes.length})`, onClick: () => setModal('quotes') },
    { icon: FolderArchive, label: isAr ? 'متصفح أرشيف' : 'ZIP/RAR/7z', onClick: () => archiveDoc && onOpenArchive(archiveDoc) },
    { icon: FileCheck2, label: isAr ? '٣٦+ صيغة' : '36+ Formats', onClick: () => setModal('formats') },
    {
      icon: Printer,
      label: isAr ? 'طباعة سريعة' : 'Print',
      onClick: () => {
        onNotify(isAr ? 'تم تجهيز المستند لخدمة طباعة النظام (PrintManager)' : 'Prepared document for Android PrintManager');
      },
    },
  ];

  return (
    <div className="relative h-full">
      <div className="h-full overflow-y-auto jb-scroll px-4 pt-3 pb-28 space-y-4">
        <div>
          <h2 className="jb-display text-[24px] font-semibold leading-tight">{isAr ? 'استوديو الأدوات' : 'Editing & Tools'}</h2>
          <p className="text-[11.5px]" style={{ color: 'var(--jb-text-secondary)' }}>
            {isAr ? 'تحرير احترافي ومعالجة مستندات محلية ١٠٠٪ دون اتصال' : '100% on-device editing, page utilities & conversion'}
          </p>
        </div>

        {/* 4 Primary Editors */}
        <div className="grid grid-cols-2 gap-2.5">
          {studioCards.map((c) => {
            const Icon = c.icon;
            return (
              <button
                key={c.title}
                onClick={c.action}
                className="p-3.5 rounded-2xl text-start flex flex-col gap-2 transition-all hover:scale-[1.01] cursor-pointer"
                style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center"
                  style={{ background: 'var(--jb-accent-soft)', border: '1px solid var(--jb-border-strong)' }}
                >
                  <Icon size={16} style={{ color: 'var(--jb-accent)' }} strokeWidth={1.7} />
                </div>
                <div>
                  <h3 className="text-[12.5px] font-semibold leading-snug">{c.title}</h3>
                  <p className="text-[10.5px] mt-0.5 line-clamp-1" style={{ color: 'var(--jb-text-secondary)' }}>
                    {c.sub}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* PDF & Document Operations Grid */}
        <div>
          <h3 className="text-[11.5px] font-semibold uppercase tracking-wider mb-2.5" style={{ color: 'var(--jb-text-secondary)' }}>
            {isAr ? 'أدوات PDF والتحويل والأرشيف' : 'PDF Operations, Conversion & Quotes'}
          </h3>
          <div className="grid grid-cols-3 gap-2">
            {utilityCards.map((u) => {
              const Icon = u.icon;
              return (
                <button
                  key={u.label}
                  onClick={u.onClick}
                  className="p-3 rounded-2xl flex flex-col items-center justify-center gap-1.5 text-center transition-colors cursor-pointer"
                  style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
                >
                  <Icon size={17} style={{ color: 'var(--jb-accent)' }} strokeWidth={1.6} />
                  <span className="text-[11px] font-medium leading-tight">{u.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Interactive Tool Modals */}
      {modal && (
        <div onClick={() => setModal(null)} className="absolute inset-0 z-30 bg-black/60 flex items-end">
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-h-[82%] overflow-y-auto jb-scroll rounded-t-3xl p-5 space-y-3.5 jb-sheet-in"
            style={{ background: 'var(--jb-surface-elevated)', borderTop: '1px solid var(--jb-border-strong)' }}
          >
            <div className="flex items-center justify-between">
              <h4 className="text-[14px] font-semibold" style={{ color: 'var(--jb-accent)' }}>
                {modal === 'merge' && (isAr ? 'دمج ملفات PDF' : 'Merge PDF Files')}
                {modal === 'split' && (isAr ? 'تقسيم صفحات PDF' : 'Split PDF Range')}
                {modal === 'compress' && (isAr ? 'ضغط وتقليص حجم PDF' : 'Compress PDF Size')}
                {modal === 'protect' && (isAr ? 'حماية / إزالة كلمة مرور PDF' : 'Encrypt / Unlock PDF')}
                {modal === 'convert' && (isAr ? 'محوّل الصيغ المحلي' : 'Offline Format Converter')}
                {modal === 'quotes' && (isAr ? 'المقتطفات وبطاقة الاقتباس' : 'Excerpts & Quote Card Studio')}
                {modal === 'formats' && (isAr ? 'الصيغ المدعومة فعليًا (٣٦+)' : 'Natively Supported Formats (36+)')}
              </h4>
              <button onClick={() => setModal(null)} className="p-1 cursor-pointer"><X size={15} /></button>
            </div>

            {modal === 'merge' && (
              <>
                <p className="text-[11.5px]" style={{ color: 'var(--jb-text-secondary)' }}>
                  {isAr ? 'اختر ملفين أو أكثر لدمجها في ملف PDF واحد:' : 'Select 2 or more documents to combine:'}
                </p>
                <div className="space-y-1.5">
                  {pdfDocs.map((d) => {
                    const checked = selectedIds.includes(d.id);
                    return (
                      <button
                        key={d.id}
                        onClick={() =>
                          setSelectedIds((prev) => (checked ? prev.filter((x) => x !== d.id) : [...prev, d.id]))
                        }
                        className="w-full p-2.5 rounded-xl flex items-center justify-between text-[12px] text-start cursor-pointer"
                        style={{ background: checked ? 'var(--jb-accent-soft)' : 'var(--jb-surface)' }}
                      >
                        <span className="truncate">{isAr ? d.titleAr : d.titleEn}</span>
                        {checked && <Check size={14} style={{ color: 'var(--jb-accent)' }} />}
                      </button>
                    );
                  })}
                </div>
                <button disabled={selectedIds.length < 2} onClick={runMerge} className="jb-gold-btn w-full py-2.5 rounded-xl text-[12px] font-semibold disabled:opacity-40 cursor-pointer">
                  {isAr ? `دمج ${selectedIds.length} ملفات الآن` : `Merge ${selectedIds.length} Files`}
                </button>
              </>
            )}

            {modal === 'split' && (
              <>
                <select
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl text-[12px] outline-none"
                  style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
                >
                  {pdfDocs.map((d) => (
                    <option key={d.id} value={d.id}>
                      {(isAr ? d.titleAr : d.titleEn)} ({d.pageCount}p)
                    </option>
                  ))}
                </select>
                <div className="grid grid-cols-2 gap-2 text-[11.5px]">
                  <label>
                    <span>{isAr ? 'من صفحة' : 'From page'}</span>
                    <input type="number" min={1} value={splitFrom} onChange={(e) => setSplitFrom(Number(e.target.value))} className="mt-1 w-full h-9 px-3 rounded-xl" style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)' }} />
                  </label>
                  <label>
                    <span>{isAr ? 'إلى صفحة' : 'To page'}</span>
                    <input type="number" min={1} value={splitTo} onChange={(e) => setSplitTo(Number(e.target.value))} className="mt-1 w-full h-9 px-3 rounded-xl" style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)' }} />
                  </label>
                </div>
                <button onClick={runSplit} className="jb-gold-btn w-full py-2.5 rounded-xl text-[12px] font-semibold cursor-pointer">
                  {isAr ? 'استخراج النطاق كملف PDF' : 'Extract Range to PDF'}
                </button>
              </>
            )}

            {modal === 'compress' && (
              <>
                <select
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl text-[12px]"
                  style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
                >
                  {pdfDocs.map((d) => (
                    <option key={d.id} value={d.id}>
                      {(isAr ? d.titleAr : d.titleEn)} — {formatBytes(d.sizeBytes)}
                    </option>
                  ))}
                </select>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { v: 0.75, ar: 'خفيف (-25%)', en: 'Light -25%' },
                      { v: 0.52, ar: 'متوازن (-48%)', en: 'Balanced -48%' },
                      { v: 0.35, ar: 'أقصى (-65%)', en: 'Max -65%' },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.v}
                      onClick={() => setCompressLevel(opt.v)}
                      className="py-2 px-2 rounded-xl text-[11px] cursor-pointer"
                      style={{
                        background: compressLevel === opt.v ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                        color: compressLevel === opt.v ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                      }}
                    >
                      {isAr ? opt.ar : opt.en}
                    </button>
                  ))}
                </div>
                <button onClick={runCompress} className="jb-gold-btn w-full py-2.5 rounded-xl text-[12px] font-semibold cursor-pointer">
                  {isAr ? 'ضغط وحفظ الملف' : 'Compress PDF Now'}
                </button>
              </>
            )}

            {modal === 'protect' && (
              <>
                <select
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl text-[12px]"
                  style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
                >
                  {pdfDocs.map((d) => (
                    <option key={d.id} value={d.id}>
                      {(isAr ? d.titleAr : d.titleEn)} {d.password ? '🔒' : ''}
                    </option>
                  ))}
                </select>
                <input
                  type="password"
                  value={pwdValue}
                  onChange={(e) => setPwdValue(e.target.value)}
                  placeholder={isAr ? 'كلمة مرور جديدة (أو فارغ لإزالة القفل)' : 'New password (leave blank to unlock)'}
                  className="w-full h-10 px-3 rounded-xl text-[12px] outline-none"
                  style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border-strong)' }}
                />
                <button onClick={runProtect} className="jb-gold-btn w-full py-2.5 rounded-xl text-[12px] font-semibold cursor-pointer">
                  {isAr ? 'تطبيق إعداد الحماية' : 'Apply Security Setting'}
                </button>
              </>
            )}

            {modal === 'convert' && (
              <div className="space-y-2">
                {[
                  { id: 'img2pdf' as const, ar: 'صور (JPG/PNG/WEBP/HEIC) ← PDF', en: 'Images (JPG/PNG/WEBP/HEIC) → PDF' },
                  { id: 'pdf2img' as const, ar: 'صفحات PDF ← صور WEBP عالية الدقة', en: 'PDF Pages → High-Res WEBP Images' },
                  { id: 'txt2pdf' as const, ar: 'نصوص (TXT / Markdown / HTML) ← PDF', en: 'TXT / Markdown / HTML → Typeset PDF' },
                ].map((c) => (
                  <button
                    key={c.id}
                    onClick={() => runConvert(c.id)}
                    className="w-full p-3 rounded-xl flex items-center justify-between text-[12px] cursor-pointer"
                    style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
                  >
                    <span>{isAr ? c.ar : c.en}</span>
                    <span style={{ color: 'var(--jb-accent)' }}>→</span>
                  </button>
                ))}
              </div>
            )}

            {modal === 'quotes' && (
              <div className="space-y-3">
                {quoteCard && (
                  <div
                    className="p-4 rounded-2xl space-y-2"
                    style={{
                      background: 'linear-gradient(145deg, #13151B 0%, #0B0C10 100%)',
                      border: '1px solid rgba(212,178,106,0.42)',
                      color: '#F4F0E8',
                    }}
                  >
                    <div className="flex justify-between items-center text-[10px] tracking-widest uppercase text-[#D4B26A]">
                      <span>𝒥𝒪 bat Quote Card</span>
                      <span>p.{quoteCard.page}</span>
                    </div>
                    <p className="text-[13px] leading-relaxed" style={{ fontFamily: "'Amiri', Georgia, serif" }}>
                      «{quoteCard.text}»
                    </p>
                    <p className="text-[10.5px] text-[#9FA4B0]">
                      — {quoteCard.author} • {quoteCard.docTitle}
                    </p>
                  </div>
                )}

                <div className="space-y-1.5 max-h-40 overflow-y-auto jb-scroll">
                  {quotes.map((q) => (
                    <button
                      key={q.id}
                      onClick={() => setQuoteCard(q)}
                      className="w-full p-2.5 rounded-xl text-start text-[11.5px] cursor-pointer"
                      style={{
                        background: quoteCard?.id === q.id ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                        borderInlineStart: `3px solid ${q.color}`,
                      }}
                    >
                      <p className="line-clamp-2">{q.text}</p>
                    </button>
                  ))}
                </div>

                <div className="flex gap-2">
                  <button onClick={exportQuotesMarkdown} className="flex-1 py-2 rounded-xl text-[11.5px] inline-flex items-center justify-center gap-1 cursor-pointer" style={{ background: 'var(--jb-surface)' }}>
                    <Download size={12} />
                    <span>{isAr ? 'تصدير MD' : 'Export MD'}</span>
                  </button>
                  {quoteCard && (
                    <button onClick={() => downloadQuoteCardPng(quoteCard)} className="jb-gold-btn flex-1 py-2 rounded-xl text-[11.5px] font-semibold inline-flex items-center justify-center gap-1 cursor-pointer">
                      <Download size={12} />
                      <span>{isAr ? 'حفظ بطاقة PNG' : 'Save Quote PNG'}</span>
                    </button>
                  )}
                </div>
              </div>
            )}

            {modal === 'formats' && (
              <div className="space-y-3">
                {ALL_SUPPORTED_FORMATS.map((g) => (
                  <div key={g.groupEn}>
                    <p className="text-[11px] font-semibold mb-1.5" style={{ color: 'var(--jb-text-secondary)' }}>
                      {isAr ? g.groupAr : g.groupEn}
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {g.list.map((fmt) => (
                        <span
                          key={fmt}
                          className="px-2 py-0.5 rounded-md text-[10.5px] jb-mono"
                          style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)', color: 'var(--jb-accent)' }}
                        >
                          {fmt}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
