import React, { useRef, useState } from 'react';
import {
  Palette,
  Globe,
  Sparkles,
  Fingerprint,
  Download,
  Upload,
  BarChart3,
  Scale,
  ArrowLeft,
  ArrowRight,
  Flame,
  Target,
  BookOpen,
  Code2,
  Play,
  ScanLine,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { AppTheme, DailyStat, DocItem, Lang } from '../types';
import { CircularProgress, JobatWordmark } from './BrandVisuals';

interface SettingsScreenProps {
  lang: Lang;
  theme: AppTheme;
  reduceMotion: boolean;
  haptics: boolean;
  biometricLock: boolean;
  continueDoc?: DocItem;
  onThemeChange: (t: AppTheme) => void;
  onLangChange: (l: Lang) => void;
  onReduceMotionChange: (v: boolean) => void;
  onHapticsChange: (v: boolean) => void;
  onBiometricChange: (v: boolean) => void;
  onExportBackup: () => void;
  onImportBackup: (file: File) => void;
  onOpenStats: () => void;
  onOpenLicenses: () => void;
  onReplayOnboarding: () => void;
  onOpenCodeInspector: () => void;
  onOpenScanner: () => void;
  onOpenDoc: (doc: DocItem) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  lang,
  theme,
  reduceMotion,
  haptics,
  biometricLock,
  continueDoc,
  onThemeChange,
  onLangChange,
  onReduceMotionChange,
  onHapticsChange,
  onBiometricChange,
  onExportBackup,
  onImportBackup,
  onOpenStats,
  onOpenLicenses,
  onReplayOnboarding,
  onOpenCodeInspector,
  onOpenScanner,
  onOpenDoc,
}) => {
  const isAr = lang === 'ar';
  const restoreRef = useRef<HTMLInputElement>(null);

  const themes: { id: AppTheme; ar: string; en: string; swatch: string; ring: string }[] = [
    { id: 'dark', ar: 'أوبسيديان', en: 'Obsidian', swatch: '#0B0C10', ring: '#D4B26A' },
    { id: 'light', ar: 'عاجي', en: 'Ivory', swatch: '#F6F1E7', ring: '#9E7631' },
    { id: 'amoled', ar: 'AMOLED', en: 'AMOLED', swatch: '#000000', ring: '#D4B26A' },
    { id: 'sepia', ar: 'سيبيا', en: 'Sepia', swatch: '#EFE4CE', ring: '#8F6224' },
    { id: 'dynamic', ar: 'ديناميكي', en: 'Dynamic', swatch: '#161C22', ring: '#8EBCDA' },
  ];

  const Toggle: React.FC<{ on: boolean; onToggle: () => void }> = ({ on, onToggle }) => (
    <button
      onClick={onToggle}
      role="switch"
      aria-checked={on}
      className="w-10 h-6 rounded-full p-0.5 transition-colors cursor-pointer shrink-0"
      style={{ background: on ? 'var(--jb-accent)' : 'var(--jb-border-strong)' }}
    >
      <div
        className="w-5 h-5 rounded-full transition-transform"
        style={{
          background: on ? 'var(--jb-accent-on)' : 'var(--jb-text)',
          transform: on ? (isAr ? 'translateX(-16px)' : 'translateX(16px)') : 'translateX(0)',
        }}
      />
    </button>
  );

  return (
    <div className="h-full overflow-y-auto jb-scroll px-4 pt-3 pb-28 space-y-3.5">
      <input
        ref={restoreRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onImportBackup(f);
          e.currentTarget.value = '';
        }}
      />

      <div>
        <h2 className="jb-display text-[24px] font-semibold leading-tight">{isAr ? 'الإعدادات' : 'Settings'}</h2>
        <p className="text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
          {isAr ? 'Obsidian & Champagne • com.jobat.reader v1.0.0' : 'Obsidian & Champagne • com.jobat.reader v1.0.0'}
        </p>
      </div>

      {/* Reading Analytics Quick Card */}
      <button
        onClick={onOpenStats}
        className="w-full p-3.5 rounded-2xl flex items-center justify-between cursor-pointer"
        style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border-strong)' }}
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'var(--jb-accent-soft)' }}>
            <BarChart3 size={17} style={{ color: 'var(--jb-accent)' }} />
          </div>
          <div className="text-start">
            <p className="text-[12.5px] font-semibold">{isAr ? 'إحصائيات وأهداف القراءة' : 'Reading Analytics & Goals'}</p>
            <p className="text-[10.5px]" style={{ color: 'var(--jb-text-secondary)' }}>
              {isAr ? 'سلسلة ١٤ يومًا • الرسوم البيانية الأسبوعية' : '14-day streak • Weekly reading charts'}
            </p>
          </div>
        </div>
        {isAr ? <ChevronLeft size={16} style={{ color: 'var(--jb-accent)' }} /> : <ChevronRight size={16} style={{ color: 'var(--jb-accent)' }} />}
      </button>

      {/* Design Tokens Theme Selector */}
      <div className="p-3.5 rounded-2xl space-y-2.5" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
        <div className="flex items-center gap-2 text-[12px] font-semibold">
          <Palette size={14} style={{ color: 'var(--jb-accent)' }} />
          <span>{isAr ? 'الثيم (Design Tokens)' : 'Theme (Design Tokens)'}</span>
        </div>
        <div className="grid grid-cols-5 gap-1.5">
          {themes.map((t) => {
            const active = theme === t.id;
            return (
              <button
                key={t.id}
                onClick={() => onThemeChange(t.id)}
                className="p-2 rounded-xl flex flex-col items-center gap-1.5 cursor-pointer"
                style={{
                  background: active ? 'var(--jb-accent-soft)' : 'var(--jb-bg)',
                  border: `1px solid ${active ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                }}
              >
                <span className="w-5 h-5 rounded-full" style={{ background: t.swatch, border: `2px solid ${t.ring}` }} />
                <span className="text-[9.5px] font-medium truncate w-full text-center">{isAr ? t.ar : t.en}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Language & RTL/LTR */}
      <div className="p-3.5 rounded-2xl flex items-center justify-between" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
        <div className="flex items-center gap-2 text-[12px] font-medium">
          <Globe size={15} style={{ color: 'var(--jb-accent)' }} />
          <span>{isAr ? 'اللغة والاتجاه' : 'Language & Layout'}</span>
        </div>
        <div className="flex rounded-xl p-0.5" style={{ background: 'var(--jb-bg)' }}>
          <button
            onClick={() => onLangChange('ar')}
            className="px-2.5 py-1 rounded-lg text-[11px] cursor-pointer"
            style={{ background: isAr ? 'var(--jb-accent-soft)' : 'transparent', color: isAr ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
          >
            العربية RTL
          </button>
          <button
            onClick={() => onLangChange('en')}
            className="px-2.5 py-1 rounded-lg text-[11px] cursor-pointer"
            style={{ background: !isAr ? 'var(--jb-accent-soft)' : 'transparent', color: !isAr ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
          >
            English LTR
          </button>
        </div>
      </div>

      {/* Motion, Haptics & Biometric Switches */}
      <div className="p-3.5 rounded-2xl space-y-3" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
        <div className="flex items-center justify-between text-[12px]">
          <span className="inline-flex items-center gap-2">
            <Sparkles size={14} style={{ color: 'var(--jb-accent)' }} />
            {isAr ? 'تقليل الحركة (Reduce Motion)' : 'Reduce Motion'}
          </span>
          <Toggle on={reduceMotion} onToggle={() => onReduceMotionChange(!reduceMotion)} />
        </div>
        <div className="flex items-center justify-between text-[12px]">
          <span className="inline-flex items-center gap-2">
            <Fingerprint size={14} style={{ color: 'var(--jb-accent)' }} />
            {isAr ? 'قفل التطبيق بالبصمة (BiometricPrompt)' : 'Biometric App Lock'}
          </span>
          <Toggle on={biometricLock} onToggle={() => onBiometricChange(!biometricLock)} />
        </div>
        <div className="flex items-center justify-between text-[12px]">
          <span className="inline-flex items-center gap-2">
            <ShieldCheck size={14} style={{ color: 'var(--jb-accent)' }} />
            {isAr ? 'استجابة لمسية ناعمة (Haptics)' : 'Subtle Haptic Feedback'}
          </span>
          <Toggle on={haptics} onToggle={() => onHapticsChange(!haptics)} />
        </div>
      </div>

      {/* Glance Home Widget & Quick Settings Tile Live Preview */}
      <div className="p-3.5 rounded-2xl space-y-2.5" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
        <p className="text-[11px] font-semibold" style={{ color: 'var(--jb-text-secondary)' }}>
          {isAr ? 'أداة الشاشة الرئيسية (Glance Widget) وزر الماسح السريع' : 'Glance Home Widget & Quick Settings Tile'}
        </p>
        <div className="flex gap-2">
          {continueDoc && (
            <button
              onClick={() => onOpenDoc(continueDoc)}
              className="flex-1 p-3 rounded-2xl text-start cursor-pointer"
              style={{ background: '#0B0C10', border: '1px solid rgba(212,178,106,0.32)', color: '#F4F0E8' }}
            >
              <span className="text-[10px] text-[#D4B26A] font-semibold">𝒥𝒪 bat Widget</span>
              <p className="text-[11.5px] font-medium truncate mt-0.5">
                {isAr ? continueDoc.titleAr : continueDoc.titleEn}
              </p>
              <p className="text-[10px] text-[#9FA4B0] mt-0.5">
                {Math.round((continueDoc.currentPage / Math.max(1, continueDoc.pageCount)) * 100)}%
              </p>
            </button>
          )}
          <button
            onClick={onOpenScanner}
            className="w-24 p-3 rounded-2xl flex flex-col items-center justify-center gap-1 cursor-pointer"
            style={{ background: 'var(--jb-accent-soft)', border: '1px solid var(--jb-border-strong)', color: 'var(--jb-accent)' }}
          >
            <ScanLine size={18} />
            <span className="text-[9.5px] font-semibold">{isAr ? 'QS الماسح' : 'QS Scan'}</span>
          </button>
        </div>
      </div>

      {/* Single-File Backup & Restore */}
      <div className="p-3.5 rounded-2xl space-y-2.5" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
        <p className="text-[12px] font-semibold">{isAr ? 'النسخ الاحتياطي والاستعادة الكاملة' : 'Full Single-File Backup & Restore'}</p>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onExportBackup}
            className="jb-gold-btn py-2 rounded-xl text-[11.5px] font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Download size={13} />
            <span>{isAr ? 'تصدير نسخة' : 'Export .json'}</span>
          </button>
          <button
            onClick={() => restoreRef.current?.click()}
            className="py-2 rounded-xl text-[11.5px] inline-flex items-center justify-center gap-1.5 cursor-pointer"
            style={{ background: 'var(--jb-surface-elevated)', border: '1px solid var(--jb-border)' }}
          >
            <Upload size={13} />
            <span>{isAr ? 'استعادة' : 'Restore'}</span>
          </button>
        </div>
      </div>

      {/* Onboarding, Android Architecture & GPL-3.0 Licenses */}
      <div className="space-y-2">
        <button
          onClick={onReplayOnboarding}
          className="w-full p-3 rounded-2xl flex items-center justify-between text-[12px] cursor-pointer"
          style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
        >
          <span className="inline-flex items-center gap-2">
            <Play size={14} style={{ color: 'var(--jb-accent)' }} />
            {isAr ? 'عرض شاشات الترحيب والأذونات (Onboarding)' : 'Replay 3-Screen Onboarding'}
          </span>
          <span style={{ color: 'var(--jb-text-tertiary)' }}>→</span>
        </button>

        <button
          onClick={onOpenCodeInspector}
          className="w-full p-3 rounded-2xl flex items-center justify-between text-[12px] cursor-pointer"
          style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
        >
          <span className="inline-flex items-center gap-2">
            <Code2 size={14} style={{ color: 'var(--jb-accent)' }} />
            {isAr ? 'هيكل مشروع Android وتقرير الحجم (JObat/)' : 'Android Project & APK Size Report (JObat/)'}
          </span>
          <span className="text-[10.5px] jb-mono" style={{ color: 'var(--jb-accent)' }}>24.8 MB</span>
        </button>

        <button
          onClick={onOpenLicenses}
          className="w-full p-3 rounded-2xl flex items-center justify-between text-[12px] cursor-pointer"
          style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
        >
          <span className="inline-flex items-center gap-2">
            <Scale size={14} style={{ color: 'var(--jb-accent)' }} />
            {isAr ? 'عن التطبيق والتراخيص المفتوحة (GPL-3.0)' : 'About & Open-Source Licenses (GPL-3.0)'}
          </span>
          <span style={{ color: 'var(--jb-text-tertiary)' }}>→</span>
        </button>
      </div>
    </div>
  );
};

export const StatsOverlay: React.FC<{
  lang: Lang;
  stats: DailyStat[];
  dailyGoal: number;
  docsCount: number;
  quotesCount: number;
  onGoalChange: (m: number) => void;
  onClose: () => void;
}> = ({ lang, stats, dailyGoal, docsCount, quotesCount, onGoalChange, onClose }) => {
  const isAr = lang === 'ar';
  const [selectedIdx, setSelectedIdx] = useState(stats.length - 1);
  const today = stats[stats.length - 1] ?? { minutes: 42, pages: 33, dayAr: 'اليوم', dayEn: 'Today' };
  const maxMin = Math.max(...stats.map((s) => s.minutes), dailyGoal, 30);
  const totalWeekMin = stats.reduce((a, b) => a + b.minutes, 0);

  return (
    <div className="absolute inset-0 z-30 flex flex-col" style={{ background: 'var(--jb-bg)', color: 'var(--jb-text)' }}>
      <div className="px-4 py-3 flex items-center gap-3" style={{ background: 'var(--jb-surface)', borderBottom: '1px solid var(--jb-border)' }}>
        <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
          {isAr ? <ArrowRight size={15} /> : <ArrowLeft size={15} />}
        </button>
        <h3 className="text-[14px] font-semibold">{isAr ? 'إحصائيات وأهداف القراءة' : 'Reading Analytics & Goals'}</h3>
      </div>

      <div className="flex-1 overflow-y-auto jb-scroll p-4 space-y-4">
        {/* Daily Goal Ring */}
        <div className="p-4 rounded-3xl flex items-center gap-4" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border-strong)' }}>
          <CircularProgress value={today.minutes / dailyGoal} size={76} stroke={5} />
          <div className="flex-1">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold" style={{ color: 'var(--jb-accent)' }}>
              <Target size={13} />
              <span>{isAr ? 'هدف القراءة اليومي' : 'Daily Reading Goal'}</span>
            </div>
            <p className="text-[20px] font-bold tabular-nums mt-0.5">
              {today.minutes} <span className="text-[12px] font-normal" style={{ color: 'var(--jb-text-secondary)' }}>/ {dailyGoal} {isAr ? 'دقيقة' : 'min'}</span>
            </p>
            <input
              type="range"
              min={15}
              max={120}
              step={5}
              value={dailyGoal}
              onChange={(e) => onGoalChange(Number(e.target.value))}
              className="w-full jb-range mt-2"
            />
          </div>
        </div>

        {/* KPI Pills */}
        <div className="grid grid-cols-3 gap-2">
          <div className="p-3 rounded-2xl text-center" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
            <Flame size={16} className="mx-auto mb-1" style={{ color: 'var(--jb-accent)' }} />
            <p className="text-[16px] font-bold tabular-nums">14</p>
            <p className="text-[10px]" style={{ color: 'var(--jb-text-secondary)' }}>{isAr ? 'يوم متتالي' : 'Day Streak'}</p>
          </div>
          <div className="p-3 rounded-2xl text-center" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
            <BookOpen size={16} className="mx-auto mb-1" style={{ color: 'var(--jb-accent)' }} />
            <p className="text-[16px] font-bold tabular-nums">{(totalWeekMin / 60).toFixed(1)}h</p>
            <p className="text-[10px]" style={{ color: 'var(--jb-text-secondary)' }}>{isAr ? 'هذا الأسبوع' : 'This Week'}</p>
          </div>
          <div className="p-3 rounded-2xl text-center" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
            <Sparkles size={16} className="mx-auto mb-1" style={{ color: 'var(--jb-accent)' }} />
            <p className="text-[16px] font-bold tabular-nums">{docsCount}/{quotesCount}</p>
            <p className="text-[10px]" style={{ color: 'var(--jb-text-secondary)' }}>{isAr ? 'كتب/اقتباس' : 'Docs/Quotes'}</p>
          </div>
        </div>

        {/* 7-Day Interactive Bar Chart */}
        <div className="p-4 rounded-3xl space-y-3" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
          <div className="flex items-center justify-between text-[12px]">
            <span className="font-semibold">{isAr ? 'نشاط آخر ٧ أيام' : 'Last 7 Days'}</span>
            <span style={{ color: 'var(--jb-accent)' }} className="tabular-nums text-[11px]">
              {isAr ? stats[selectedIdx]?.dayAr : stats[selectedIdx]?.dayEn}: {stats[selectedIdx]?.minutes}m • {stats[selectedIdx]?.pages}p
            </span>
          </div>
          <div className="h-36 flex items-end justify-between gap-2 pt-4">
            {stats.map((s, idx) => {
              const hPct = Math.max(10, Math.round((s.minutes / maxMin) * 100));
              const active = idx === selectedIdx;
              return (
                <button
                  key={s.dayEn}
                  onClick={() => setSelectedIdx(idx)}
                  className="flex-1 h-full flex flex-col items-center justify-end gap-1.5 cursor-pointer"
                >
                  <div
                    className="w-full max-w-[26px] rounded-t-xl transition-all"
                    style={{
                      height: `${hPct}%`,
                      background: active ? 'var(--jb-champagne-grad)' : 'var(--jb-accent-soft)',
                      border: active ? 'none' : '1px solid var(--jb-border-strong)',
                    }}
                  />
                  <span className="text-[9.5px]" style={{ color: active ? 'var(--jb-accent)' : 'var(--jb-text-tertiary)' }}>
                    {isAr ? s.dayAr : s.dayEn}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export const LicensesOverlay: React.FC<{ lang: Lang; onClose: () => void }> = ({ lang, onClose }) => {
  const isAr = lang === 'ar';
  const libs = [
    { name: 'Librera Reader (Core Fork Base)', lic: 'GPL-3.0-or-later', role: 'EPUB/FB2/MOBI/CBZ engine, FTS & TTS orchestration' },
    { name: 'Artifex MuPDF (C/NDK Fitz)', lic: 'AGPL-3.0 / GPL-3.0', role: 'Native PDF/XPS rendering, AcroForms, annotation save' },
    { name: 'DjVuLibre', lic: 'GPL-2.0-or-later', role: 'High-compression scanned DJVU manuscript decoder' },
    { name: 'Tesseract OCR (tesseract4android)', lic: 'Apache-2.0', role: '100% offline OCR with on-demand .traineddata packs' },
    { name: 'AndroidX Compose, Room, WorkManager, CameraX, Glance', lic: 'Apache-2.0', role: 'Material 3 UI, FTS4 DB, Scanner, Home Widget' },
    { name: 'Coil & Apache Commons Compress', lic: 'Apache-2.0', role: 'Cover cache, SVG/AVIF/WEBP & ZIP/7z streaming' },
  ];

  return (
    <div className="absolute inset-0 z-30 flex flex-col" style={{ background: 'var(--jb-bg)', color: 'var(--jb-text)' }}>
      <div className="px-4 py-3 flex items-center gap-3" style={{ background: 'var(--jb-surface)', borderBottom: '1px solid var(--jb-border)' }}>
        <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
          {isAr ? <ArrowRight size={15} /> : <ArrowLeft size={15} />}
        </button>
        <h3 className="text-[14px] font-semibold">{isAr ? 'عن التطبيق والتراخيص (GPL-3.0)' : 'About & GPL-3.0 Licenses'}</h3>
      </div>

      <div className="flex-1 overflow-y-auto jb-scroll p-4 space-y-4">
        <div className="p-4 rounded-3xl text-center space-y-2" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border-strong)' }}>
          <div className="flex justify-center"><JobatWordmark size="md" /></div>
          <p className="text-[11px] jb-mono" style={{ color: 'var(--jb-accent)' }}>com.jobat.reader • v1.0.0 • GNU GPL-3.0</p>
          <p className="text-[11.5px] leading-relaxed" style={{ color: 'var(--jb-text-secondary)' }}>
            {isAr
              ? 'برنامج حر ومفتوح المصدر مرخّص بموجب رخصة GNU GPL-3.0. أُزيلت جميع حزم الإعلانات والتتبع (Firebase / Crashlytics / AdMob) بالكامل. يعمل محليًا 100% دون اتصال.'
              : 'Free and open-source software licensed under GNU GPL-3.0-or-later. All ads, Firebase, Crashlytics, and telemetry are permanently stripped. 100% Offline.'}
          </p>
        </div>

        <div className="space-y-2">
          {libs.map((l) => (
            <div key={l.name} className="p-3 rounded-2xl" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[12px] font-semibold">{l.name}</span>
                <span className="px-2 py-0.5 rounded text-[9.5px] jb-mono" style={{ background: 'var(--jb-accent-soft)', color: 'var(--jb-accent)' }}>
                  {l.lic}
                </span>
              </div>
              <p className="text-[11px] mt-1" style={{ color: 'var(--jb-text-secondary)' }}>{l.role}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
