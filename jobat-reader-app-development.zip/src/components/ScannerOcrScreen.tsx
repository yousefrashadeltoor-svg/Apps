import React, { useRef, useState } from 'react';
import {
  Camera,
  ScanText,
  Download,
  Check,
  FilePlus2,
  Copy,
  Sparkles,
  Upload,
  Trash2,
  Maximize2,
} from 'lucide-react';
import { Lang } from '../types';

interface ScannerOcrScreenProps {
  lang: Lang;
  onCreateScannedPdf: (title: string, pageCount: number, ocrText: string, imageUrl: string) => void;
  onNotify: (msg: string) => void;
}

interface OcrModel {
  code: string;
  label: string;
  sizeMb: string;
  installed: boolean;
  downloading?: boolean;
}

export const ScannerOcrScreen: React.FC<ScannerOcrScreenProps> = ({
  lang,
  onCreateScannedPdf,
  onNotify,
}) => {
  const isAr = lang === 'ar';
  const [mode, setMode] = useState<'scan' | 'ocr'>('scan');
  const [scanImage, setScanImage] = useState('/images/sample-scan.jpg');
  const [enhance, setEnhance] = useState<'magic' | 'bw' | 'gray' | 'orig'>('magic');
  const [straightened, setStraightened] = useState(false);
  const [batch, setBatch] = useState<{ id: string; url: string; filter: string }[]>([
    { id: 'pg-1', url: '/images/sample-scan.jpg', filter: 'magic' },
  ]);

  // Draggable 4-corner perspective polygon (percentages)
  const [corners, setCorners] = useState([
    { x: 14, y: 12 },
    { x: 86, y: 10 },
    { x: 90, y: 88 },
    { x: 11, y: 89 },
  ]);
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // Offline OCR Models (downloaded on demand to keep APK < 25 MB)
  const [models, setModels] = useState<OcrModel[]>([
    { code: 'ara', label: 'العربية (Arabic)', sizeMb: '4.2 MB', installed: true },
    { code: 'eng', label: 'English (Latin)', sizeMb: '3.8 MB', installed: true },
    { code: 'fra', label: 'Français', sizeMb: '3.5 MB', installed: false },
    { code: 'deu', label: 'Deutsch', sizeMb: '3.6 MB', installed: false },
  ]);
  const [activeLang, setActiveLang] = useState('ara');
  const [ocrRunning, setOcrRunning] = useState(false);
  const [ocrResult, setOcrResult] = useState('');

  const filterCss =
    enhance === 'bw'
      ? 'grayscale(1) contrast(1.75) brightness(1.12)'
      : enhance === 'gray'
      ? 'grayscale(1) contrast(1.2)'
      : enhance === 'magic'
      ? 'contrast(1.26) brightness(1.06) saturate(1.08)'
      : 'none';

  const onCornerMove = (e: React.PointerEvent) => {
    if (dragIdx === null || !frameRef.current) return;
    const r = frameRef.current.getBoundingClientRect();
    const x = Math.min(96, Math.max(4, ((e.clientX - r.left) / r.width) * 100));
    const y = Math.min(96, Math.max(4, ((e.clientY - r.top) / r.height) * 100));
    setCorners((prev) => prev.map((c, i) => (i === dragIdx ? { x, y } : c)));
  };

  const capturePage = () => {
    setBatch((prev) => [...prev, { id: `pg-${Date.now()}`, url: scanImage, filter: enhance }]);
    setStraightened(true);
    onNotify(isAr ? `تم التقاط وتحسين الصفحة رقم ${batch.length + 1}` : `Captured & enhanced page #${batch.length + 1}`);
  };

  const installModel = (code: string) => {
    setModels((prev) => prev.map((m) => (m.code === code ? { ...m, downloading: true } : m)));
    setTimeout(() => {
      setModels((prev) => prev.map((m) => (m.code === code ? { ...m, downloading: false, installed: true } : m)));
      setActiveLang(code);
      onNotify(isAr ? `تم تنزيل نموذج اللغة (${code}.traineddata) للعمل دون اتصال` : `Downloaded ${code}.traineddata for offline OCR`);
    }, 650);
  };

  const runOfflineOcr = () => {
    setOcrRunning(true);
    setTimeout(() => {
      setOcrRunning(false);
      const sampleOut =
        activeLang === 'ara'
          ? 'اتفاقية الاستشارات المعمارية — رقم 2026/14\n\nالبند الأول: يقر الطرفان باعتماد المخططات الهندسية النهائية لقاعة القراءة والمخطوطات وفق معايير الإضاءة الطبيعية والعزل الصوتي.\n\nالبند الثاني: تم استخراج هذا النص محليًا عبر محرك JObat Offline OCR بدقة 99.1% مع طبقة نص قابلة للبحث داخل PDF.'
          : 'ARCHITECTURAL CONSULTANCY AGREEMENT — REF 2026/14\n\nSection 1: Both parties hereby approve the final lighting, acoustic, and stone specification schedules for the Private Reading Room.\n\nSection 2: Recognized 100% on-device via JObat Offline OCR Engine (99.2% confidence) with embedded searchable PDF text layer.';
      setOcrResult(sampleOut);
      onNotify(isAr ? 'اكتمل التعرف الضوئي Offline OCR بنجاح' : 'Offline OCR text recognition completed');
    }, 600);
  };

  const compilePdf = (withSearchableOcr: boolean) => {
    const text =
      ocrResult ||
      (isAr
        ? 'مستند ممسوح ضوئيًا ومصحح المنظور عبر كاميرا JObat مع تحسين التباين التلقائي.'
        : 'Perspective-corrected document scanned via JObat CameraX studio with adaptive contrast.');
    const title = withSearchableOcr
      ? isAr
        ? `مستند ممسوح قابل للبحث (OCR) — ${batch.length} ص`
        : `Searchable OCR Scan — ${batch.length}p`
      : isAr
      ? `مسح ضوئي محسّن — ${batch.length} ص`
      : `Enhanced Document Scan — ${batch.length}p`;
    onCreateScannedPdf(title, batch.length, text, scanImage);
  };

  const polyPoints = corners.map((c) => `${c.x},${c.y}`).join(' ');

  return (
    <div className="h-full overflow-y-auto jb-scroll px-4 pt-3 pb-28 space-y-3.5">
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const reader = new FileReader();
          reader.onload = () => {
            if (typeof reader.result === 'string') setScanImage(reader.result);
          };
          reader.readAsDataURL(f);
        }}
      />

      {/* Header & Mode Switch */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="jb-display text-[23px] font-semibold leading-tight">{isAr ? 'الماسح وOCR' : 'Scanner & OCR'}</h2>
          <p className="text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
            {isAr ? 'CameraX كشف الحواف • OCR دون اتصال' : 'CameraX Edge Warp • On-Device OCR'}
          </p>
        </div>
        <div className="flex rounded-xl p-0.5" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
          <button
            onClick={() => setMode('scan')}
            className="px-3 py-1.5 rounded-lg text-[11px] font-medium cursor-pointer"
            style={{ background: mode === 'scan' ? 'var(--jb-accent-soft)' : 'transparent', color: mode === 'scan' ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
          >
            {isAr ? 'الماسح' : 'Scan'}
          </button>
          <button
            onClick={() => setMode('ocr')}
            className="px-3 py-1.5 rounded-lg text-[11px] font-medium cursor-pointer"
            style={{ background: mode === 'ocr' ? 'var(--jb-accent-soft)' : 'transparent', color: mode === 'ocr' ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
          >
            OCR
          </button>
        </div>
      </div>

      {mode === 'scan' ? (
        <>
          {/* Interactive CameraX Viewfinder with 4-Corner Perspective Crop */}
          <div
            ref={frameRef}
            onPointerMove={onCornerMove}
            onPointerUp={() => setDragIdx(null)}
            onPointerLeave={() => setDragIdx(null)}
            className="relative w-full aspect-[4/4.6] rounded-3xl overflow-hidden select-none touch-none shadow-xl"
            style={{ background: '#07080A', border: '1px solid var(--jb-border-strong)' }}
          >
            <img
              src={scanImage}
              alt="Document viewfinder"
              className="w-full h-full object-cover transition-all duration-300"
              style={{
                filter: filterCss,
                transform: straightened ? 'scale(1.16) perspective(600px) rotateX(0deg)' : 'scale(1)',
              }}
            />

            {!straightened && (
              <>
                <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 w-full h-full">
                  <polygon
                    points={polyPoints}
                    fill="rgba(212, 178, 106, 0.12)"
                    stroke="#D4B26A"
                    strokeWidth="0.7"
                  />
                </svg>
                {corners.map((c, idx) => (
                  <button
                    key={idx}
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setDragIdx(idx);
                    }}
                    aria-label={`Corner ${idx + 1}`}
                    style={{ left: `${c.x}%`, top: `${c.y}%` }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-[#D4B26A] border-2 border-[#0B0C10] shadow-lg cursor-grab active:scale-125 transition-transform"
                  />
                ))}
              </>
            )}

            {/* Top HUD Pills */}
            <div className="absolute top-3 inset-x-3 flex items-center justify-between">
              <span className="px-2.5 py-1 rounded-full text-[10px] font-medium bg-black/65 text-[#D4B26A] backdrop-blur-md">
                {straightened ? (isAr ? '✓ صُحّح المنظور' : '✓ Perspective Fixed') : isAr ? 'اسحب الزوايا لضبط الحواف' : 'Drag corners to refine crop'}
              </span>
              <button
                onClick={() => setStraightened((s) => !s)}
                className="px-2.5 py-1 rounded-full text-[10px] bg-black/65 text-[#F4F0E8] inline-flex items-center gap-1 cursor-pointer"
              >
                <Maximize2 size={10} />
                <span>{straightened ? (isAr ? 'الحواف' : 'Edges') : isAr ? 'تصحيح' : 'Dewarp'}</span>
              </button>
            </div>
          </div>

          {/* Enhancement Modes */}
          <div className="flex items-center gap-1.5 overflow-x-auto jb-no-scrollbar">
            {(
              [
                { id: 'magic', ar: 'تحسين ذكي', en: 'Magic Crisp' },
                { id: 'bw', ar: 'أبيض وأسود', en: 'Doc B&W' },
                { id: 'gray', ar: 'رمادي', en: 'Grayscale' },
                { id: 'orig', ar: 'أصلي', en: 'Original' },
              ] as const
            ).map((f) => (
              <button
                key={f.id}
                onClick={() => setEnhance(f.id)}
                className="flex-1 py-1.5 px-2.5 rounded-xl text-[11px] whitespace-nowrap cursor-pointer"
                style={{
                  background: enhance === f.id ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                  color: enhance === f.id ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                  border: `1px solid ${enhance === f.id ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                }}
              >
                {isAr ? f.ar : f.en}
              </button>
            ))}
          </div>

          {/* Shutter + Import Camera Photo + Batch Compile */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => fileRef.current?.click()}
              className="h-11 px-3 rounded-2xl inline-flex items-center gap-1.5 text-[11.5px] cursor-pointer"
              style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
            >
              <Upload size={14} style={{ color: 'var(--jb-accent)' }} />
              <span>{isAr ? 'كاميرا/صورة' : 'Photo'}</span>
            </button>

            <button
              onClick={capturePage}
              className="flex-1 h-11 rounded-2xl inline-flex items-center justify-center gap-1.5 text-[12px] font-medium cursor-pointer"
              style={{ background: 'var(--jb-surface-elevated)', border: '1px solid var(--jb-border-strong)', color: 'var(--jb-accent)' }}
            >
              <Camera size={15} />
              <span>{isAr ? `التقاط (${batch.length})` : `Capture (${batch.length})`}</span>
            </button>

            <button
              onClick={() => compilePdf(false)}
              className="jb-gold-btn h-11 px-4 rounded-2xl inline-flex items-center gap-1.5 text-[12px] font-semibold cursor-pointer"
            >
              <FilePlus2 size={15} />
              <span>PDF</span>
            </button>
          </div>

          {/* Multi-Page Batch Strip */}
          {batch.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto jb-no-scrollbar pt-1">
              {batch.map((item, idx) => (
                <div key={item.id} className="relative w-14 h-18 rounded-xl overflow-hidden shrink-0" style={{ border: '1px solid var(--jb-border-strong)' }}>
                  <img src={item.url} alt={`Scan ${idx + 1}`} className="w-full h-full object-cover" />
                  <span className="absolute bottom-0.5 left-1 text-[9px] font-bold px-1 rounded bg-black/75 text-[#D4B26A]">
                    {idx + 1}
                  </span>
                  {batch.length > 1 && (
                    <button
                      onClick={() => setBatch((prev) => prev.filter((x) => x.id !== item.id))}
                      className="absolute top-0.5 right-0.5 w-4 h-4 rounded bg-black/75 text-red-300 flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 size={9} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      ) : (
        /* OFFLINE OCR & ON-DEMAND MODELS */
        <div className="space-y-3.5 jb-anim-in">
          <div className="p-3.5 rounded-2xl space-y-2.5" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}>
            <div className="flex items-center justify-between">
              <span className="text-[12px] font-semibold">{isAr ? 'نماذج اللغات عند الطلب (Offline)' : 'On-Demand OCR Models (Offline)'}</span>
              <span className="text-[10px]" style={{ color: 'var(--jb-accent)' }}>Tesseract 5</span>
            </div>
            <p className="text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
              {isAr
                ? 'تُنزَّل حزم اللغات حسب الطلب لإبقاء حجم التطبيق الأساسي أقل من 25 ميجابايت.'
                : 'Language packs download on demand so the base APK remains under 25 MB.'}
            </p>
            <div className="grid grid-cols-2 gap-2">
              {models.map((m) => {
                const selected = activeLang === m.code && m.installed;
                return (
                  <button
                    key={m.code}
                    onClick={() => (m.installed ? setActiveLang(m.code) : installModel(m.code))}
                    className="p-2.5 rounded-xl flex items-center justify-between text-start cursor-pointer"
                    style={{
                      background: selected ? 'var(--jb-accent-soft)' : 'var(--jb-bg)',
                      border: `1px solid ${selected ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                    }}
                  >
                    <div className="min-w-0">
                      <p className="text-[11.5px] font-medium truncate">{m.label}</p>
                      <p className="text-[10px]" style={{ color: 'var(--jb-text-tertiary)' }}>
                        {m.downloading ? (isAr ? 'جارٍ التنزيل…' : 'Downloading…') : m.sizeMb}
                      </p>
                    </div>
                    {m.installed ? (
                      <Check size={14} style={{ color: 'var(--jb-accent)' }} />
                    ) : (
                      <Download size={13} style={{ color: 'var(--jb-text-secondary)' }} />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <button
            onClick={runOfflineOcr}
            className="jb-gold-btn w-full h-11 rounded-2xl text-[12.5px] font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            {ocrRunning ? <Sparkles size={15} className="animate-spin" /> : <ScanText size={15} />}
            <span>
              {ocrRunning
                ? isAr
                  ? 'جارٍ استخراج النص محليًا…'
                  : 'Extracting text offline…'
                : isAr
                ? `استخراج النص من الصفحات (${activeLang.toUpperCase()})`
                : `Extract Text Offline (${activeLang.toUpperCase()})`}
            </span>
          </button>

          {ocrResult && (
            <div className="p-3.5 rounded-2xl space-y-2.5 jb-anim-in" style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border-strong)' }}>
              <textarea
                value={ocrResult}
                onChange={(e) => setOcrResult(e.target.value)}
                rows={6}
                className="w-full bg-transparent text-[12px] leading-relaxed outline-none resize-none"
                dir="auto"
              />
              <div className="flex items-center justify-between gap-2 pt-2" style={{ borderTop: '1px solid var(--jb-border)' }}>
                <button
                  onClick={() => {
                    navigator.clipboard?.writeText(ocrResult);
                    onNotify(isAr ? 'نُسخ نص OCR إلى الحافظة' : 'Copied OCR text');
                  }}
                  className="px-3 py-1.5 rounded-xl text-[11px] inline-flex items-center gap-1.5 cursor-pointer"
                  style={{ background: 'var(--jb-surface-elevated)' }}
                >
                  <Copy size={12} />
                  <span>{isAr ? 'نسخ النص' : 'Copy'}</span>
                </button>
                <button
                  onClick={() => compilePdf(true)}
                  className="jb-gold-btn px-3.5 py-1.5 rounded-xl text-[11px] font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <FilePlus2 size={13} />
                  <span>{isAr ? 'حفظ PDF قابل للبحث' : 'Save Searchable PDF'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
