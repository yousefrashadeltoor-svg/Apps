import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Undo2,
  Redo2,
  Search,
  Eye,
  Code2,
  Download,
  CheckCircle2,
  FileUp,
} from 'lucide-react';
import { DocItem, Lang } from '../types';

interface TextEditorScreenProps {
  lang: Lang;
  doc: DocItem;
  onUpdateDoc: (id: string, patch: Partial<DocItem>) => void;
  onConvertToPdf: (title: string, content: string) => void;
  onClose: () => void;
  onNotify: (msg: string) => void;
}

export const TextEditorScreen: React.FC<TextEditorScreenProps> = ({
  lang,
  doc,
  onUpdateDoc,
  onConvertToPdf,
  onClose,
  onNotify,
}) => {
  const isAr = lang === 'ar';
  const initial = useMemo(
    () =>
      doc.rawCode ??
      doc.pages
        .map((p) => `# ${isAr ? p.headingAr : p.headingEn}\n\n${(isAr ? p.paragraphsAr : p.paragraphsEn).join('\n\n')}`)
        .join('\n\n'),
    [doc, isAr]
  );

  const [history, setHistory] = useState<string[]>([initial]);
  const [ptr, setPtr] = useState(0);
  const code = history[ptr] ?? '';

  const [showFind, setShowFind] = useState(false);
  const [findStr, setFindStr] = useState('');
  const [replaceStr, setReplaceStr] = useState('');
  const [useRegex, setUseRegex] = useState(true);
  const [preview, setPreview] = useState(false);
  const [savedStamp, setSavedStamp] = useState(true);

  const commitChange = (next: string) => {
    const sliced = history.slice(0, ptr + 1);
    sliced.push(next);
    setHistory(sliced);
    setPtr(sliced.length - 1);
    setSavedStamp(true);
    onUpdateDoc(doc.id, {
      rawCode: next,
      sizeBytes: new Blob([next]).size,
      lastReadMs: Date.now(),
    });
  };

  const matchCount = useMemo(() => {
    if (!findStr) return 0;
    try {
      const rx = useRegex ? new RegExp(findStr, 'gm') : new RegExp(findStr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gm');
      return (code.match(rx) ?? []).length;
    } catch {
      return 0;
    }
  }, [code, findStr, useRegex]);

  const handleReplaceAll = () => {
    if (!findStr) return;
    try {
      const rx = useRegex ? new RegExp(findStr, 'gm') : new RegExp(findStr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gm');
      const next = code.replace(rx, replaceStr);
      commitChange(next);
      onNotify(isAr ? `تم استبدال ${matchCount} تطابقًا` : `Replaced ${matchCount} matches`);
    } catch {
      onNotify(isAr ? 'تعبير Regex غير صالح' : 'Invalid regular expression');
    }
  };

  const downloadFile = () => {
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${doc.titleEn.replace(/[^a-z0-9._-]+/gi, '_')}.${doc.ext}`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify(isAr ? 'تم تصدير الملف بنجاح' : 'Exported file successfully');
  };

  const lines = useMemo(() => code.split('\n'), [code]);

  const highlightLine = (line: string, ext: string): React.ReactNode => {
    if (ext === 'md') {
      if (/^#{1,6}\s/.test(line)) return <span style={{ color: '#D4B26A', fontWeight: 600 }}>{line}</span>;
      if (/^\s*[-*]\s/.test(line)) return <span style={{ color: '#C8D4E3' }}>{line}</span>;
      if (/^```/.test(line)) return <span style={{ color: '#6BB88B' }}>{line}</span>;
      if (/\b(val|fun|when|is|class|return)\b/.test(line)) return <span style={{ color: '#8EBCDA' }}>{line}</span>;
    }
    if (ext === 'html' || ext === 'xml' || ext === 'xhtml') {
      if (/[<>]/.test(line)) return <span style={{ color: '#D4B26A' }}>{line}</span>;
    }
    if (ext === 'csv') {
      return line.split(',').map((cell, idx) => (
        <span key={idx} style={{ color: idx === 0 ? '#D4B26A' : idx % 2 === 0 ? '#8EBCDA' : 'var(--jb-text)' }}>
          {idx > 0 ? ',' : ''}
          {cell}
        </span>
      ));
    }
    return line;
  };

  const renderMarkdownPreview = (md: string) => {
    const blocks = md.split('\n');
    return (
      <div className="space-y-2.5 text-[13px] leading-relaxed" dir="auto">
        {blocks.map((line, i) => {
          if (line.startsWith('# '))
            return (
              <h1 key={i} className="jb-display text-[22px] font-semibold" style={{ color: 'var(--jb-accent)' }}>
                {line.slice(2)}
              </h1>
            );
          if (line.startsWith('## '))
            return (
              <h2 key={i} className="text-[15px] font-semibold pt-2" style={{ color: 'var(--jb-text)' }}>
                {line.slice(3)}
              </h2>
            );
          if (line.startsWith('- '))
            return (
              <li key={i} className="ms-4 list-disc" style={{ color: 'var(--jb-text-secondary)' }}>
                {line.slice(2)}
              </li>
            );
          if (line.startsWith('```')) return null;
          if (!line.trim()) return <div key={i} className="h-1" />;
          return (
            <p key={i} style={{ color: 'var(--jb-text)' }}>
              {line}
            </p>
          );
        })}
      </div>
    );
  };

  const renderCsvTable = (csv: string) => {
    const rows = csv
      .trim()
      .split('\n')
      .map((r) => r.split(','));
    const [head, ...body] = rows;
    return (
      <div className="overflow-x-auto rounded-xl" style={{ border: '1px solid var(--jb-border)' }}>
        <table className="w-full text-[11.5px] text-left" dir="ltr">
          <thead style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-accent)' }}>
            <tr>
              {head?.map((h, i) => (
                <th key={i} className="px-2.5 py-2 font-semibold whitespace-nowrap">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {body.map((r, ri) => (
              <tr key={ri} style={{ borderTop: '1px solid var(--jb-border)' }}>
                {r.map((c, ci) => (
                  <td key={ci} className="px-2.5 py-1.5 whitespace-nowrap">
                    {c}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col" style={{ background: 'var(--jb-bg)', color: 'var(--jb-text)' }}>
      {/* Top Bar */}
      <div className="px-3 py-2.5 flex items-center justify-between gap-1.5" style={{ background: 'var(--jb-surface)', borderBottom: '1px solid var(--jb-border)' }}>
        <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
          {isAr ? <ArrowRight size={15} /> : <ArrowLeft size={15} />}
        </button>

        <div className="flex-1 min-w-0 px-1">
          <p className="text-[12px] font-semibold truncate">{isAr ? doc.titleAr : doc.titleEn}</p>
          <p className="text-[10px] inline-flex items-center gap-1" style={{ color: 'var(--jb-success)' }}>
            <CheckCircle2 size={10} />
            <span>
              {savedStamp ? (isAr ? 'محفوظ تلقائيًا' : 'Auto-saved') : '...'} • {lines.length} {isAr ? 'سطر' : 'lines'}
            </span>
          </p>
        </div>

        <div className="flex items-center gap-1">
          <button disabled={ptr <= 0} onClick={() => setPtr((p) => p - 1)} className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
            <Undo2 size={13} />
          </button>
          <button disabled={ptr >= history.length - 1} onClick={() => setPtr((p) => p + 1)} className="w-7 h-7 rounded-lg flex items-center justify-center disabled:opacity-30 cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
            <Redo2 size={13} />
          </button>
          <button onClick={() => setShowFind((s) => !s)} className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer" style={{ background: showFind ? 'var(--jb-accent-soft)' : 'var(--jb-surface-elevated)', color: showFind ? 'var(--jb-accent)' : 'var(--jb-text)' }}>
            <Search size={13} />
          </button>
          <button
            onClick={() => setPreview((p) => !p)}
            className="jb-gold-btn h-7 px-2.5 rounded-lg text-[10.5px] font-semibold inline-flex items-center gap-1 cursor-pointer"
          >
            {preview ? <Code2 size={12} /> : <Eye size={12} />}
            <span>{preview ? (isAr ? 'الكود' : 'Code') : isAr ? 'معاينة' : 'Preview'}</span>
          </button>
        </div>
      </div>

      {/* Regex Find & Replace Bar */}
      {showFind && (
        <div className="p-2.5 space-y-2" style={{ background: 'var(--jb-surface-elevated)', borderBottom: '1px solid var(--jb-border-strong)' }}>
          <div className="flex items-center gap-1.5">
            <input
              value={findStr}
              onChange={(e) => setFindStr(e.target.value)}
              placeholder={useRegex ? 'Regex (e.g. \\b[A-Z]+\\b)' : isAr ? 'بحث…' : 'Find…'}
              className="flex-1 h-8 px-2.5 rounded-lg text-[11.5px] jb-mono outline-none"
              style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
              dir="ltr"
            />
            <button
              onClick={() => setUseRegex((r) => !r)}
              className="h-8 px-2 rounded-lg text-[10.5px] jb-mono font-semibold cursor-pointer"
              style={{
                background: useRegex ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                color: useRegex ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
              }}
            >
              .*
            </button>
            <span className="text-[10.5px] tabular-nums px-1" style={{ color: 'var(--jb-accent)' }}>
              {matchCount}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <input
              value={replaceStr}
              onChange={(e) => setReplaceStr(e.target.value)}
              placeholder={isAr ? 'استبدال بـ…' : 'Replace with…'}
              className="flex-1 h-8 px-2.5 rounded-lg text-[11.5px] jb-mono outline-none"
              style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
              dir="ltr"
            />
            <button onClick={handleReplaceAll} className="jb-gold-btn h-8 px-3 rounded-lg text-[11px] font-semibold cursor-pointer">
              {isAr ? 'استبدال الكل' : 'Replace All'}
            </button>
          </div>
        </div>
      )}

      {/* Editor or Live Preview Body */}
      <div className="flex-1 overflow-y-auto jb-scroll">
        {preview ? (
          <div className="p-4">
            {doc.ext === 'csv' ? (
              renderCsvTable(code)
            ) : doc.ext === 'html' || doc.ext === 'xhtml' ? (
              <iframe
                title="HTML Live Preview"
                sandbox=""
                srcDoc={`<!doctype html><html><body style="margin:12px;background:transparent;color:#F4F0E8">${code}</body></html>`}
                className="w-full h-[460px] rounded-2xl border-0 bg-[#0B0C10]"
              />
            ) : (
              renderMarkdownPreview(code)
            )}
          </div>
        ) : (
          <div className="flex min-h-full jb-mono text-[12px] leading-[1.7]" dir="ltr">
            {/* Line Numbers Gutter */}
            <div
              className="py-3 px-2.5 text-right select-none shrink-0"
              style={{
                background: 'var(--jb-surface)',
                color: 'var(--jb-text-tertiary)',
                borderRight: '1px solid var(--jb-border)',
              }}
            >
              {lines.map((_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>

            {/* Layered Syntax Highlight + Editable Textarea */}
            <div className="relative flex-1 min-w-0">
              <pre
                aria-hidden="true"
                className="pointer-events-none p-3 m-0 whitespace-pre-wrap break-words font-inherit text-[12px] leading-[1.7]"
              >
                {lines.map((ln, idx) => (
                  <div key={idx}>{highlightLine(ln, doc.ext) || ' '}</div>
                ))}
              </pre>
              <textarea
                value={code}
                spellCheck={false}
                onChange={(e) => commitChange(e.target.value)}
                className="absolute inset-0 w-full h-full p-3 bg-transparent text-transparent caret-[#D4B26A] resize-none outline-none whitespace-pre-wrap break-words font-inherit text-[12px] leading-[1.7]"
              />
            </div>
          </div>
        )}
      </div>

      {/* Bottom Status & Convert/Export Bar */}
      <div className="px-3.5 py-2 flex items-center justify-between text-[11px]" style={{ background: 'var(--jb-surface)', borderTop: '1px solid var(--jb-border)' }}>
        <span className="jb-mono uppercase" style={{ color: 'var(--jb-text-secondary)' }}>
          {doc.ext} • UTF-8 • {code.length} chars
        </span>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onConvertToPdf(isAr ? doc.titleAr : doc.titleEn, code)}
            className="px-2.5 py-1 rounded-lg inline-flex items-center gap-1 cursor-pointer"
            style={{ background: 'var(--jb-accent-soft)', color: 'var(--jb-accent)' }}
          >
            <FileUp size={12} />
            <span>→ PDF</span>
          </button>
          <button
            onClick={downloadFile}
            className="px-2.5 py-1 rounded-lg inline-flex items-center gap-1 cursor-pointer"
            style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-text)' }}
          >
            <Download size={12} />
            <span>{isAr ? 'تصدير' : 'Export'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
