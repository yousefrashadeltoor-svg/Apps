import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  FlipHorizontal,
  FlipVertical,
  Crop,
  Sliders,
  Sparkles,
  PenTool,
  Download,
  Save,
  RotateCcw,
} from 'lucide-react';
import { DocItem, Lang } from '../types';

interface ImageEditorScreenProps {
  lang: Lang;
  doc: DocItem;
  onSaveEditedImage: (docId: string, dataUrl: string, sizeBytes: number) => void;
  onClose: () => void;
  onNotify: (msg: string) => void;
}

const FILTERS = [
  { id: 'none', label: 'Original', css: '' },
  { id: 'noir', label: 'Obsidian B&W', css: 'grayscale(1) contrast(1.25)' },
  { id: 'champagne', label: 'Champagne', css: 'sepia(0.28) saturate(1.18) brightness(1.04)' },
  { id: 'doc', label: 'Crisp Doc', css: 'grayscale(0.85) contrast(1.55) brightness(1.12)' },
  { id: 'sepia', label: 'Warm Sepia', css: 'sepia(0.68) contrast(1.06)' },
  { id: 'vivid', label: 'Vivid', css: 'saturate(1.42) contrast(1.1)' },
];

export const ImageEditorScreen: React.FC<ImageEditorScreenProps> = ({
  lang,
  doc,
  onSaveEditedImage,
  onClose,
  onNotify,
}) => {
  const isAr = lang === 'ar';
  const srcUrl = doc.coverStyle.imageUrl || doc.pages[0]?.imageUrl || '/images/sample-photo.jpg';
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);

  const [panel, setPanel] = useState<'adjust' | 'filters' | 'crop' | 'draw' | 'export'>('adjust');
  const [rotation, setRotation] = useState(0);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);
  const [cropRatio, setCropRatio] = useState<'full' | '1:1' | '4:3' | '3:4' | '16:9'>('full');
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [warmth, setWarmth] = useState(0);
  const [blurPx, setBlurPx] = useState(0);
  const [filterId, setFilterId] = useState('none');
  const [caption, setCaption] = useState('');
  const [strokes, setStrokes] = useState<{ color: string; pts: { x: number; y: number }[] }[]>([]);
  const [drawMode, setDrawMode] = useState<'pen' | 'blur'>('pen');
  const [blurSpots, setBlurSpots] = useState<{ x: number; y: number }[]>([]);
  const [drawing, setDrawing] = useState(false);
  const [format, setFormat] = useState<'image/jpeg' | 'image/png' | 'image/webp'>('image/jpeg');
  const [quality, setQuality] = useState(90);

  const renderCanvas = () => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let sx = 0,
      sy = 0,
      sw = img.naturalWidth,
      sh = img.naturalHeight;
    const ratioMap: Record<string, number> = { '1:1': 1, '4:3': 4 / 3, '3:4': 3 / 4, '16:9': 16 / 9 };
    const target = ratioMap[cropRatio];
    if (target) {
      const cur = sw / sh;
      if (cur > target) {
        sw = sh * target;
        sx = (img.naturalWidth - sw) / 2;
      } else {
        sh = sw / target;
        sy = (img.naturalHeight - sh) / 2;
      }
    }

    const scale = Math.min(640 / sw, 640 / sh, 1);
    const dw = Math.round(sw * scale);
    const dh = Math.round(sh * scale);
    const swapped = rotation % 180 !== 0;
    canvas.width = swapped ? dh : dw;
    canvas.height = swapped ? dw : dh;

    ctx.save();
    const presetCss = FILTERS.find((f) => f.id === filterId)?.css ?? '';
    ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) ${blurPx > 0 ? `blur(${blurPx}px)` : ''} ${presetCss}`.trim();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
    ctx.drawImage(img, sx, sy, sw, sh, -dw / 2, -dh / 2, dw, dh);
    ctx.restore();

    // Warmth / Temperature tint
    if (warmth !== 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'soft-light';
      ctx.fillStyle = warmth > 0 ? `rgba(235, 168, 72, ${warmth / 180})` : `rgba(80, 150, 235, ${Math.abs(warmth) / 180})`;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.restore();
    }

    // Spot Privacy Blur regions
    blurSpots.forEach((spot) => {
      const bx = spot.x * canvas.width;
      const by = spot.y * canvas.height;
      ctx.save();
      ctx.beginPath();
      ctx.arc(bx, by, 26, 0, Math.PI * 2);
      ctx.clip();
      ctx.filter = 'blur(8px)';
      ctx.drawImage(canvas, 0, 0);
      ctx.restore();
    });

    // Freehand Strokes
    strokes.forEach((st) => {
      if (st.pts.length < 2) return;
      ctx.save();
      ctx.strokeStyle = st.color;
      ctx.lineWidth = 3.2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(st.pts[0].x * canvas.width, st.pts[0].y * canvas.height);
      st.pts.slice(1).forEach((p) => ctx.lineTo(p.x * canvas.width, p.y * canvas.height));
      ctx.stroke();
      ctx.restore();
    });

    // Caption Text Overlay
    if (caption.trim()) {
      ctx.save();
      ctx.fillStyle = 'rgba(11, 12, 16, 0.68)';
      ctx.fillRect(0, canvas.height - 42, canvas.width, 42);
      ctx.fillStyle = '#F4F0E8';
      ctx.font = '600 16px Georgia, serif';
      ctx.textAlign = 'center';
      ctx.fillText(caption, canvas.width / 2, canvas.height - 15);
      ctx.restore();
    }
  };

  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      imgRef.current = img;
      renderCanvas();
    };
    img.src = srcUrl;
  }, [srcUrl]);

  useEffect(() => {
    renderCanvas();
  }, [rotation, flipH, flipV, cropRatio, brightness, contrast, saturation, warmth, blurPx, filterId, caption, strokes, blurSpots]);

  const onCanvasDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (panel !== 'draw') return;
    const r = e.currentTarget.getBoundingClientRect();
    const pt = { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
    setDrawing(true);
    if (drawMode === 'blur') setBlurSpots((prev) => [...prev, pt]);
    else setStrokes((prev) => [...prev, { color: '#D4B26A', pts: [pt] }]);
  };

  const onCanvasMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing || panel !== 'draw') return;
    const r = e.currentTarget.getBoundingClientRect();
    const pt = { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
    if (drawMode === 'blur') setBlurSpots((prev) => [...prev, pt]);
    else
      setStrokes((prev) => {
        const copy = [...prev];
        const last = copy[copy.length - 1];
        if (last) copy[copy.length - 1] = { ...last, pts: [...last.pts, pt] };
        return copy;
      });
  };

  const resetAll = () => {
    setRotation(0);
    setFlipH(false);
    setFlipV(false);
    setCropRatio('full');
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setWarmth(0);
    setBlurPx(0);
    setFilterId('none');
    setCaption('');
    setStrokes([]);
    setBlurSpots([]);
  };

  const handleSave = (download: boolean) => {
    const c = canvasRef.current;
    if (!c) return;
    const dataUrl = c.toDataURL(format, quality / 100);
    const approxBytes = Math.round((dataUrl.length * 3) / 4);
    onSaveEditedImage(doc.id, dataUrl, approxBytes);
    if (download) {
      const ext = format === 'image/png' ? 'png' : format === 'image/webp' ? 'webp' : 'jpg';
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `jobat-edited.${ext}`;
      a.click();
    }
    onNotify(isAr ? `تم حفظ الصورة بجودة ${quality}%` : `Image saved at ${quality}% quality`);
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col" style={{ background: 'var(--jb-bg)', color: 'var(--jb-text)' }}>
      {/* Top Bar */}
      <div className="px-3 py-2.5 flex items-center justify-between" style={{ background: 'var(--jb-surface)', borderBottom: '1px solid var(--jb-border)' }}>
        <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
          {isAr ? <ArrowRight size={15} /> : <ArrowLeft size={15} />}
        </button>
        <span className="text-[12.5px] font-semibold">{isAr ? 'محرر الصور الاحترافي' : 'Image Studio'}</span>
        <div className="flex items-center gap-1">
          <button onClick={resetAll} title="Reset" className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}>
            <RotateCcw size={13} />
          </button>
          <button onClick={() => handleSave(false)} className="jb-gold-btn h-7 px-2.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer">
            <Save size={12} />
            <span>{isAr ? 'حفظ' : 'Save'}</span>
          </button>
        </div>
      </div>

      {/* Canvas Viewport */}
      <div className="flex-1 flex items-center justify-center p-4 overflow-hidden bg-black/40">
        <canvas
          ref={canvasRef}
          onPointerDown={onCanvasDown}
          onPointerMove={onCanvasMove}
          onPointerUp={() => setDrawing(false)}
          onPointerLeave={() => setDrawing(false)}
          className={`max-w-full max-h-full rounded-xl shadow-2xl touch-none ${panel === 'draw' ? 'cursor-crosshair' : ''}`}
        />
      </div>

      {/* Active Tool Controls */}
      <div className="p-3.5 space-y-2.5" style={{ background: 'var(--jb-surface)', borderTop: '1px solid var(--jb-border)' }}>
        {panel === 'adjust' && (
          <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-[10.5px]">
            <div>
              <div className="flex justify-between"><span>{isAr ? 'السطوع' : 'Brightness'}</span><span>{brightness}%</span></div>
              <input type="range" min={50} max={150} value={brightness} onChange={(e) => setBrightness(Number(e.target.value))} className="w-full jb-range" />
            </div>
            <div>
              <div className="flex justify-between"><span>{isAr ? 'التباين' : 'Contrast'}</span><span>{contrast}%</span></div>
              <input type="range" min={50} max={170} value={contrast} onChange={(e) => setContrast(Number(e.target.value))} className="w-full jb-range" />
            </div>
            <div>
              <div className="flex justify-between"><span>{isAr ? 'التشبع' : 'Saturation'}</span><span>{saturation}%</span></div>
              <input type="range" min={0} max={180} value={saturation} onChange={(e) => setSaturation(Number(e.target.value))} className="w-full jb-range" />
            </div>
            <div>
              <div className="flex justify-between"><span>{isAr ? 'الحرارة' : 'Warmth'}</span><span>{warmth}</span></div>
              <input type="range" min={-50} max={50} value={warmth} onChange={(e) => setWarmth(Number(e.target.value))} className="w-full jb-range" />
            </div>
          </div>
        )}

        {panel === 'filters' && (
          <div className="flex items-center gap-1.5 overflow-x-auto jb-no-scrollbar">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterId(f.id)}
                className="px-3 py-1.5 rounded-xl text-[11px] shrink-0 cursor-pointer"
                style={{
                  background: filterId === f.id ? 'var(--jb-accent-soft)' : 'var(--jb-surface-elevated)',
                  color: filterId === f.id ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                  border: `1px solid ${filterId === f.id ? 'var(--jb-border-strong)' : 'transparent'}`,
                }}
              >
                {f.label}
              </button>
            ))}
          </div>
        )}

        {panel === 'crop' && (
          <div className="flex items-center justify-between gap-1.5 flex-wrap">
            <div className="flex items-center gap-1">
              {(['full', '1:1', '4:3', '3:4', '16:9'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setCropRatio(r)}
                  className="px-2 py-1 rounded-lg text-[10.5px] cursor-pointer"
                  style={{
                    background: cropRatio === r ? 'var(--jb-accent-soft)' : 'var(--jb-surface-elevated)',
                    color: cropRatio === r ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                  }}
                >
                  {r.toUpperCase()}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1">
              <button onClick={() => setRotation((r) => (r + 90) % 360)} className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}><RotateCw size={13} /></button>
              <button onClick={() => setFlipH((v) => !v)} className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}><FlipHorizontal size={13} /></button>
              <button onClick={() => setFlipV((v) => !v)} className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer" style={{ background: 'var(--jb-surface-elevated)' }}><FlipVertical size={13} /></button>
            </div>
          </div>
        )}

        {panel === 'draw' && (
          <div className="space-y-2">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setDrawMode('pen')}
                className="px-2.5 py-1 rounded-lg text-[11px] cursor-pointer"
                style={{ background: drawMode === 'pen' ? 'var(--jb-accent-soft)' : 'var(--jb-surface-elevated)', color: drawMode === 'pen' ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
              >
                {isAr ? 'قلم ذهبي' : 'Gold Pen'}
              </button>
              <button
                onClick={() => setDrawMode('blur')}
                className="px-2.5 py-1 rounded-lg text-[11px] cursor-pointer"
                style={{ background: drawMode === 'blur' ? 'var(--jb-accent-soft)' : 'var(--jb-surface-elevated)', color: drawMode === 'blur' ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
              >
                {isAr ? 'فرشاة طمس (Blur)' : 'Privacy Blur'}
              </button>
              <input
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder={isAr ? 'كتابة نص على الصورة…' : 'Caption overlay…'}
                className="flex-1 h-7 px-2.5 rounded-lg text-[11px] outline-none"
                style={{ background: 'var(--jb-bg)', border: '1px solid var(--jb-border)', color: 'var(--jb-text)' }}
              />
            </div>
          </div>
        )}

        {panel === 'export' && (
          <div className="space-y-2 text-[11px]">
            <div className="flex items-center justify-between gap-2">
              <div className="flex gap-1">
                {(
                  [
                    { mime: 'image/jpeg', label: 'JPG' },
                    { mime: 'image/webp', label: 'WEBP' },
                    { mime: 'image/png', label: 'PNG' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.mime}
                    onClick={() => setFormat(f.mime)}
                    className="px-2.5 py-1 rounded-lg cursor-pointer"
                    style={{ background: format === f.mime ? 'var(--jb-accent-soft)' : 'var(--jb-surface-elevated)', color: format === f.mime ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
              <button onClick={() => handleSave(true)} className="jb-gold-btn px-3 py-1 rounded-lg font-semibold inline-flex items-center gap-1 cursor-pointer">
                <Download size={12} />
                <span>{isAr ? `تنزيل (${quality}%)` : `Download (${quality}%)`}</span>
              </button>
            </div>
            <input type="range" min={20} max={100} value={quality} onChange={(e) => setQuality(Number(e.target.value))} className="w-full jb-range" />
          </div>
        )}

        {/* Mode Switcher */}
        <div className="flex items-center justify-between pt-1" style={{ borderTop: '1px solid var(--jb-border)' }}>
          {(
            [
              { id: 'adjust', icon: Sliders, ar: 'تعديل', en: 'Adjust' },
              { id: 'filters', icon: Sparkles, ar: 'فلاتر', en: 'Filters' },
              { id: 'crop', icon: Crop, ar: 'قص وتدوير', en: 'Crop' },
              { id: 'draw', icon: PenTool, ar: 'رسم وطمس', en: 'Draw/Blur' },
              { id: 'export', icon: Download, ar: 'تصدير', en: 'Export' },
            ] as const
          ).map((m) => {
            const Icon = m.icon;
            const active = panel === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setPanel(m.id)}
                className="flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg text-[10px] cursor-pointer"
                style={{ color: active ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }}
              >
                <Icon size={14} />
                <span>{isAr ? m.ar : m.en}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
