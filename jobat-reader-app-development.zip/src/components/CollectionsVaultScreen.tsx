import React, { useMemo, useState } from 'react';
import {
  FolderHeart,
  Heart,
  Tag,
  Shield,
  Archive,
  Trash2,
  Plus,
  Fingerprint,
  Lock,
  Unlock,
  RotateCcw,
} from 'lucide-react';
import { DocItem, Lang } from '../types';
import { formatBytes } from '../data/sampleData';
import { BookCover } from './BrandVisuals';

interface CollectionsVaultScreenProps {
  lang: Lang;
  docs: DocItem[];
  collections: string[];
  onCreateCollection: (name: string) => void;
  onOpenDoc: (doc: DocItem) => void;
  onUpdateDoc: (id: string, patch: Partial<DocItem>) => void;
  onDeleteForever: (id: string) => void;
  onNotify: (msg: string) => void;
}

type Section = 'collections' | 'favorites' | 'tags' | 'vault' | 'archive' | 'trash';

export const CollectionsVaultScreen: React.FC<CollectionsVaultScreenProps> = ({
  lang,
  docs,
  collections,
  onCreateCollection,
  onOpenDoc,
  onUpdateDoc,
  onDeleteForever,
  onNotify,
}) => {
  const isAr = lang === 'ar';
  const [section, setSection] = useState<Section>('collections');
  const [activeCol, setActiveCol] = useState<string | null>(null);
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [newColName, setNewColName] = useState('');
  const [addingCol, setAddingCol] = useState(false);

  // BiometricPrompt + AES-256 Vault
  const [vaultOpen, setVaultOpen] = useState(false);
  const [verifyingBio, setVerifyingBio] = useState(false);

  const allTags = useMemo(() => {
    const s = new Set<string>();
    docs.filter((d) => !d.trashed && !d.vaultLocked).forEach((d) => d.tags.forEach((t) => s.add(t)));
    return Array.from(s);
  }, [docs]);

  const triggerBiometricUnlock = () => {
    setVerifyingBio(true);
    setTimeout(() => {
      setVerifyingBio(false);
      setVaultOpen(true);
      onNotify(isAr ? 'تم التحقق عبر BiometricPrompt وفتح الخزنة AES-256' : 'Biometric verified — AES-256 Vault unlocked');
    }, 520);
  };

  const tabs: { id: Section; icon: React.FC<{ size?: number }>; ar: string; en: string }[] = [
    { id: 'collections', icon: FolderHeart, ar: 'المجموعات', en: 'Collections' },
    { id: 'favorites', icon: Heart, ar: 'المفضلة', en: 'Favorites' },
    { id: 'tags', icon: Tag, ar: 'الوسوم', en: 'Tags' },
    { id: 'vault', icon: Shield, ar: 'الخزنة', en: 'Vault' },
    { id: 'archive', icon: Archive, ar: 'الأرشيف', en: 'Archive' },
    { id: 'trash', icon: Trash2, ar: 'المحذوفات', en: 'Trash' },
  ];

  const renderDocRow = (d: DocItem, extraAction?: React.ReactNode) => (
    <div
      key={d.id}
      className="p-2.5 rounded-2xl flex items-center gap-3"
      style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
    >
      <div onClick={() => onOpenDoc(d)} className="cursor-pointer">
        <BookCover doc={d} lang={lang} compact className="w-10 h-13 rounded-lg" />
      </div>
      <div onClick={() => onOpenDoc(d)} className="flex-1 min-w-0 cursor-pointer">
        <p className="text-[12.5px] font-medium truncate">{isAr ? d.titleAr : d.titleEn}</p>
        <p className="text-[10.5px] truncate" style={{ color: 'var(--jb-text-secondary)' }}>
          {d.ext.toUpperCase()} • {formatBytes(d.sizeBytes)}
        </p>
      </div>
      {extraAction}
    </div>
  );

  const favDocs = docs.filter((d) => d.favorite && !d.trashed && !d.vaultLocked);
  const vaultDocs = docs.filter((d) => d.vaultLocked && !d.trashed);
  const archDocs = docs.filter((d) => d.archived && !d.trashed);
  const trashDocs = docs.filter((d) => d.trashed);

  return (
    <div className="h-full overflow-y-auto jb-scroll px-4 pt-3 pb-28 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="jb-display text-[24px] font-semibold leading-tight">
            {isAr ? 'المجموعات والخزنة' : 'Collections & Vault'}
          </h2>
          <p className="text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
            {isAr ? 'تنظيم ذكي وخزنة مشفرة بالبصمة' : 'Curated shelves, tags & biometric Keystore vault'}
          </p>
        </div>
        {section === 'collections' && (
          <button
            onClick={() => setAddingCol((v) => !v)}
            className="jb-gold-btn h-8 px-3 rounded-xl text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer"
          >
            <Plus size={13} />
            <span>{isAr ? 'جديدة' : 'New'}</span>
          </button>
        )}
      </div>

      {/* Section Switcher */}
      <div className="flex items-center gap-1.5 overflow-x-auto jb-no-scrollbar pb-0.5">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = section === t.id;
          return (
            <button
              key={t.id}
              onClick={() => {
                setSection(t.id);
                setActiveCol(null);
              }}
              className="px-3 py-1.5 rounded-full text-[11px] font-medium inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
              style={{
                background: active ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                color: active ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                border: `1px solid ${active ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
              }}
            >
              <Icon size={12} />
              <span>{isAr ? t.ar : t.en}</span>
            </button>
          );
        })}
      </div>

      {addingCol && section === 'collections' && (
        <div className="flex gap-2 jb-anim-in">
          <input
            autoFocus
            value={newColName}
            onChange={(e) => setNewColName(e.target.value)}
            placeholder={isAr ? 'اسم المجموعة الجديدة…' : 'Collection name…'}
            className="flex-1 h-9 px-3 rounded-xl text-[12px] outline-none"
            style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border-strong)' }}
          />
          <button
            onClick={() => {
              if (newColName.trim()) {
                onCreateCollection(newColName.trim());
                setNewColName('');
                setAddingCol(false);
              }
            }}
            className="jb-gold-btn px-4 h-9 rounded-xl text-[11.5px] font-semibold cursor-pointer"
          >
            {isAr ? 'إنشاء' : 'Create'}
          </button>
        </div>
      )}

      {/* COLLECTIONS */}
      {section === 'collections' && !activeCol && (
        <div className="grid grid-cols-2 gap-2.5 jb-anim-in">
          {collections.map((col) => {
            const count = docs.filter((d) => !d.trashed && !d.vaultLocked && d.collections.includes(col)).length;
            return (
              <button
                key={col}
                onClick={() => setActiveCol(col)}
                className="p-4 rounded-2xl text-start flex flex-col justify-between gap-4 cursor-pointer hover:scale-[1.01] transition-transform"
                style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border)' }}
              >
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'var(--jb-accent-soft)' }}>
                  <FolderHeart size={17} style={{ color: 'var(--jb-accent)' }} />
                </div>
                <div>
                  <h3 className="text-[13px] font-semibold truncate">{col}</h3>
                  <p className="text-[11px]" style={{ color: 'var(--jb-text-secondary)' }}>
                    {count} {isAr ? 'مستندات' : 'items'}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {section === 'collections' && activeCol && (
        <div className="space-y-2.5 jb-anim-in">
          <div className="flex items-center justify-between">
            <h3 className="text-[13.5px] font-semibold" style={{ color: 'var(--jb-accent)' }}>
              {activeCol}
            </h3>
            <button onClick={() => setActiveCol(null)} className="text-[11px] cursor-pointer" style={{ color: 'var(--jb-text-secondary)' }}>
              {isAr ? 'كل المجموعات ←' : '← All Collections'}
            </button>
          </div>
          {docs
            .filter((d) => !d.trashed && !d.vaultLocked && d.collections.includes(activeCol))
            .map((d) => renderDocRow(d))}
        </div>
      )}

      {/* FAVORITES */}
      {section === 'favorites' && (
        <div className="space-y-2 jb-anim-in">
          {favDocs.length === 0 ? (
            <p className="text-center py-10 text-[12px]" style={{ color: 'var(--jb-text-secondary)' }}>
              {isAr ? 'لا توجد كتب في المفضلة بعد.' : 'No favorites yet.'}
            </p>
          ) : (
            favDocs.map((d) =>
              renderDocRow(
                d,
                <button onClick={() => onUpdateDoc(d.id, { favorite: false })} className="p-1.5 cursor-pointer" style={{ color: 'var(--jb-accent)' }}>
                  <Heart size={14} fill="currentColor" />
                </button>
              )
            )
          )}
        </div>
      )}

      {/* TAGS */}
      {section === 'tags' && (
        <div className="space-y-3 jb-anim-in">
          <div className="flex flex-wrap gap-1.5">
            {allTags.map((t) => (
              <button
                key={t}
                onClick={() => setActiveTag(activeTag === t ? null : t)}
                className="px-3 py-1 rounded-full text-[11.5px] cursor-pointer"
                style={{
                  background: activeTag === t ? 'var(--jb-accent-soft)' : 'var(--jb-surface)',
                  color: activeTag === t ? 'var(--jb-accent)' : 'var(--jb-text-secondary)',
                  border: `1px solid ${activeTag === t ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                }}
              >
                #{t}
              </button>
            ))}
          </div>
          <div className="space-y-2">
            {docs
              .filter((d) => !d.trashed && !d.vaultLocked && (!activeTag || d.tags.includes(activeTag)))
              .map((d) => renderDocRow(d))}
          </div>
        </div>
      )}

      {/* ENCRYPTED BIOMETRIC VAULT */}
      {section === 'vault' && (
        <div className="jb-anim-in">
          {!vaultOpen ? (
            <div
              className="p-6 rounded-3xl flex flex-col items-center text-center gap-4"
              style={{ background: 'var(--jb-surface)', border: '1px solid var(--jb-border-strong)' }}
            >
              <button
                onClick={triggerBiometricUnlock}
                className="w-20 h-20 rounded-full flex items-center justify-center transition-transform active:scale-95 cursor-pointer"
                style={{
                  background: 'var(--jb-accent-soft)',
                  border: '1.5px solid var(--jb-accent)',
                  boxShadow: verifyingBio ? '0 0 28px rgba(212,178,106,0.35)' : undefined,
                }}
              >
                <Fingerprint size={36} style={{ color: 'var(--jb-accent)' }} className={verifyingBio ? 'animate-pulse' : ''} />
              </button>
              <div>
                <h3 className="text-[15px] font-semibold">{isAr ? 'الخزنة المشفرة (AES-256-GCM)' : 'Encrypted Keystore Vault'}</h3>
                <p className="text-[11.5px] mt-1 max-w-[240px]" style={{ color: 'var(--jb-text-secondary)' }}>
                  {isAr
                    ? `تحتوي على ${vaultDocs.length} ملفات حساسة مشفرة عبر Android Keystore. المس مستشعر البصمة للفتح.`
                    : `${vaultDocs.length} confidential file(s) sealed via EncryptedFile. Touch biometric sensor to authenticate.`}
                </p>
              </div>
              <button onClick={triggerBiometricUnlock} className="jb-gold-btn px-5 py-2.5 rounded-full text-[12px] font-semibold cursor-pointer">
                {verifyingBio ? (isAr ? 'جارٍ التحقق الحيوي…' : 'Authenticating…') : isAr ? 'فتح بالبصمة / الوجه' : 'Authenticate Biometric'}
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between p-3 rounded-2xl" style={{ background: 'var(--jb-accent-soft)', border: '1px solid var(--jb-border-strong)' }}>
                <span className="text-[11.5px] font-medium inline-flex items-center gap-1.5" style={{ color: 'var(--jb-accent)' }}>
                  <Unlock size={13} />
                  {isAr ? 'الخزنة مفتوحة مؤقتًا' : 'Vault Session Active'}
                </span>
                <button
                  onClick={() => {
                    setVaultOpen(false);
                    onNotify(isAr ? 'أُغلقت الخزنة ومُسحت الذاكرة المؤقتة' : 'Vault locked & temp buffers wiped');
                  }}
                  className="px-2.5 py-1 rounded-lg text-[11px] inline-flex items-center gap-1 cursor-pointer"
                  style={{ background: 'var(--jb-bg)', color: 'var(--jb-text)' }}
                >
                  <Lock size={11} />
                  <span>{isAr ? 'قفل الآن' : 'Lock'}</span>
                </button>
              </div>
              {vaultDocs.map((d) =>
                renderDocRow(
                  d,
                  <button
                    onClick={() => {
                      onUpdateDoc(d.id, { vaultLocked: false });
                      onNotify(isAr ? 'أُعيد الملف إلى المكتبة العامة' : 'Restored file to Library');
                    }}
                    className="px-2.5 py-1 rounded-lg text-[10.5px] cursor-pointer"
                    style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-accent)' }}
                  >
                    {isAr ? 'إخراج' : 'Unseal'}
                  </button>
                )
              )}
            </div>
          )}
        </div>
      )}

      {/* ARCHIVE */}
      {section === 'archive' && (
        <div className="space-y-2 jb-anim-in">
          {archDocs.length === 0 ? (
            <p className="text-center py-10 text-[12px]" style={{ color: 'var(--jb-text-secondary)' }}>
              {isAr ? 'الأرشيف فارغ حاليًا.' : 'Archive is empty.'}
            </p>
          ) : (
            archDocs.map((d) =>
              renderDocRow(
                d,
                <button
                  onClick={() => onUpdateDoc(d.id, { archived: false })}
                  className="p-2 rounded-lg cursor-pointer"
                  style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-accent)' }}
                >
                  <RotateCcw size={13} />
                </button>
              )
            )
          )}
        </div>
      )}

      {/* TRASH */}
      {section === 'trash' && (
        <div className="space-y-2 jb-anim-in">
          {trashDocs.length === 0 ? (
            <p className="text-center py-10 text-[12px]" style={{ color: 'var(--jb-text-secondary)' }}>
              {isAr ? 'سلة المحذوفات نظيفة تمامًا.' : 'Trash is empty.'}
            </p>
          ) : (
            trashDocs.map((d) =>
              renderDocRow(
                d,
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      onUpdateDoc(d.id, { trashed: false });
                      onNotify(isAr ? 'تمت استعادة الملف' : 'Document restored');
                    }}
                    className="p-1.5 rounded-lg cursor-pointer"
                    style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-success)' }}
                  >
                    <RotateCcw size={13} />
                  </button>
                  <button
                    onClick={() => {
                      onDeleteForever(d.id);
                      onNotify(isAr ? 'حُذف الملف نهائيًا' : 'Deleted permanently');
                    }}
                    className="p-1.5 rounded-lg cursor-pointer"
                    style={{ background: 'var(--jb-surface-elevated)', color: 'var(--jb-danger)' }}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              )
            )
          )}
        </div>
      )}
    </div>
  );
};
