import React, { useState } from 'react';
import { BookOpen, PenTool, ShieldCheck, FolderCheck, Camera, Fingerprint, Check, ChevronLeft, ChevronRight } from 'lucide-react';
import { Lang } from '../types';
import { JobatEmblem, JobatWordmark } from './BrandVisuals';

export const SplashScreen: React.FC<{ lang: Lang; onFinish: () => void }> = ({ lang, onFinish }) => {
  return (
    <div
      onClick={onFinish}
      className="absolute inset-0 z-50 flex flex-col items-center justify-between py-14 px-8 cursor-pointer select-none"
      style={{
        background: 'radial-gradient(circle at 50% 42%, rgba(212,178,106,0.10) 0%, var(--jb-bg) 62%)',
      }}
    >
      <div className="text-[10px] tracking-[0.26em] uppercase" style={{ color: 'var(--jb-text-tertiary)' }}>
        OBSIDIAN &amp; CHAMPAGNE
      </div>

      <div className="flex flex-col items-center gap-5 jb-splash-in">
        <JobatEmblem size={76} />
        <JobatWordmark size="lg" showEmblem={false} />
        <p className="text-[12.5px] text-center max-w-[240px] leading-relaxed" style={{ color: 'var(--jb-text-secondary)' }}>
          {lang === 'ar'
            ? 'قارئ ومحرر مستندات فاخر يعمل دون اتصال بالكامل'
            : 'Quiet-luxury offline document reader & editing studio'}
        </p>
        <div className="w-28 h-[2px] rounded-full overflow-hidden mt-2" style={{ background: 'var(--jb-border)' }}>
          <div className="h-full w-full jb-shimmer" style={{ background: 'var(--jb-champagne-grad)' }} />
        </div>
      </div>

      <div className="text-[10.5px] tracking-wide" style={{ color: 'var(--jb-text-tertiary)' }}>
        {lang === 'ar' ? 'نواة Librera + MuPDF • رخصة GPL-3.0' : 'Librera + MuPDF Core • GPL-3.0'}
      </div>
    </div>
  );
};

export const OnboardingScreen: React.FC<{
  lang: Lang;
  onComplete: (perms: { saf: boolean; camera: boolean; biometric: boolean }) => void;
}> = ({ lang, onComplete }) => {
  const [step, setStep] = useState(0);
  const [perms, setPerms] = useState({ saf: true, camera: true, biometric: true });
  const isAr = lang === 'ar';

  const slides = [
    {
      icon: BookOpen,
      tag: isAr ? '٠١ — النواة الأصلية' : '01 — NATIVE CORE',
      title: isAr ? '٣٦+ صيغة في مكتبة واحدة هادئة' : '36+ Formats in One Serene Library',
      desc: isAr
        ? 'مبني على نواة MuPDF C/NDK وLibrera المعدّلة لفتح PDF وEPUB وDJVU وCBZ وملفات Office والكود والصور والأرشيفات بسرعة فائقة وبدون إنترنت.'
        : 'Powered by native MuPDF C/NDK & Librera core for instant offline PDF, EPUB, DJVU, CBZ, Office, code, high-res images & archives.',
      pills: ['PDF', 'EPUB 3', 'DJVU', 'MOBI', 'CBZ', 'DOCX', 'MD', 'AVIF', '7z'],
    },
    {
      icon: PenTool,
      tag: isAr ? '٠٢ — استوديو التحرير' : '02 — EDITING STUDIO',
      title: isAr ? 'تحرير PDF ونصوص وصور وماسح OCR' : 'PDF, Code & Image Studio + OCR',
      desc: isAr
        ? 'تمييز ورسم وتوقيع محفوظ وتعبئة نماذج ودمج وتقسيم، محرر كود مع Regex ومعاينة حية، محرر صور، وماسح CameraX مع OCR دون اتصال.'
        : 'Annotate, sign, fill AcroForms, merge & reorder pages, edit Markdown/HTML/CSV with Regex, retouch images, and scan with offline OCR.',
      pills: isAr
        ? ['توقيع محفوظ', 'Undo لا محدود', 'ماسح CameraX', 'OCR عربي/إنجليزي']
        : ['Saved Signatures', 'Unlimited Undo', 'CameraX Scan', 'Offline OCR'],
    },
    {
      icon: ShieldCheck,
      tag: isAr ? '٠٣ — الخصوصية والأذونات' : '03 — SMART PERMISSIONS',
      title: isAr ? 'صفر إعلانات. صفر تتبع. أذونات بيدك.' : 'Zero Ads. Zero Tracking. Scoped Access.',
      desc: isAr
        ? 'لا نطلب صلاحية الوصول الشامل للتخزين. اختر فقط الصلاحيات التي تناسب استخدامك ويمكنك تعديلها في أي وقت.'
        : 'Strict Android Scoped Storage with zero telemetry. Enable only the optional capabilities you need.',
      pills: [],
    },
  ];

  const cur = slides[step];
  const Icon = cur.icon;

  return (
    <div
      className="absolute inset-0 z-40 flex flex-col justify-between p-6 jb-anim-in"
      style={{ background: 'var(--jb-bg)' }}
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-2">
        <JobatWordmark size="sm" />
        <button
          onClick={() => onComplete(perms)}
          className="text-xs px-3 py-1.5 rounded-full transition-colors cursor-pointer"
          style={{ color: 'var(--jb-text-secondary)', background: 'var(--jb-surface)' }}
        >
          {isAr ? 'تخطي' : 'Skip'}
        </button>
      </div>

      {/* Center Content */}
      <div key={step} className="flex flex-col gap-4 my-auto jb-anim-in">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center"
          style={{ background: 'var(--jb-accent-soft)', border: '1px solid var(--jb-border-strong)' }}
        >
          <Icon size={26} style={{ color: 'var(--jb-accent)' }} strokeWidth={1.6} />
        </div>

        <span className="text-[11px] font-medium tracking-[0.18em]" style={{ color: 'var(--jb-accent)' }}>
          {cur.tag}
        </span>
        <h2 className="jb-display text-[28px] leading-tight font-semibold" style={{ color: 'var(--jb-text)' }}>
          {cur.title}
        </h2>
        <p className="text-[13.5px] leading-relaxed" style={{ color: 'var(--jb-text-secondary)' }}>
          {cur.desc}
        </p>

        {cur.pills.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-2">
            {cur.pills.map((p) => (
              <span
                key={p}
                className="px-2.5 py-1 rounded-lg text-[11px] font-medium"
                style={{
                  background: 'var(--jb-surface)',
                  border: '1px solid var(--jb-border)',
                  color: 'var(--jb-text)',
                }}
              >
                {p}
              </span>
            ))}
          </div>
        )}

        {step === 2 && (
          <div className="flex flex-col gap-2.5 pt-2">
            {[
              {
                key: 'saf' as const,
                icon: FolderCheck,
                title: isAr ? 'مجلد الكتب (Scoped Storage SAF)' : 'Books Folder (Scoped Storage SAF)',
                sub: isAr ? 'فهرسة تلقائية بالخلفية عبر WorkManager' : 'Background indexing via WorkManager',
              },
              {
                key: 'camera' as const,
                icon: Camera,
                title: isAr ? 'الكاميرا لماسح المستندات (اختياري)' : 'Camera for Document Scanner (Optional)',
                sub: isAr ? 'تعمل فقط عند فتح شاشة الماسح' : 'Active strictly inside CameraX scanner',
              },
              {
                key: 'biometric' as const,
                icon: Fingerprint,
                title: isAr ? 'البصمة والخزنة المشفرة AES-256' : 'Biometric & AES-256 Keystore Vault',
                sub: isAr ? 'حماية الملفات الحساسة عبر BiometricPrompt' : 'Lock confidential files via BiometricPrompt',
              },
            ].map((item) => {
              const PIcon = item.icon;
              const active = perms[item.key];
              return (
                <button
                  key={item.key}
                  onClick={() => setPerms((prev) => ({ ...prev, [item.key]: !prev[item.key] }))}
                  className="flex items-center gap-3 p-3 rounded-2xl text-start transition-all cursor-pointer"
                  style={{
                    background: 'var(--jb-surface)',
                    border: `1px solid ${active ? 'var(--jb-border-strong)' : 'var(--jb-border)'}`,
                  }}
                >
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: active ? 'var(--jb-accent-soft)' : 'var(--jb-surface-elevated)' }}
                  >
                    <PIcon size={17} style={{ color: active ? 'var(--jb-accent)' : 'var(--jb-text-secondary)' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[12.5px] font-medium truncate" style={{ color: 'var(--jb-text)' }}>
                      {item.title}
                    </div>
                    <div className="text-[11px] truncate" style={{ color: 'var(--jb-text-secondary)' }}>
                      {item.sub}
                    </div>
                  </div>
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center shrink-0"
                    style={{
                      background: active ? 'var(--jb-accent)' : 'transparent',
                      border: `1.5px solid ${active ? 'var(--jb-accent)' : 'var(--jb-text-tertiary)'}`,
                    }}
                  >
                    {active && <Check size={12} style={{ color: 'var(--jb-accent-on)' }} strokeWidth={2.5} />}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom Indicator & Action */}
      <div className="flex items-center justify-between pt-4">
        <div className="flex items-center gap-1.5">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setStep(idx)}
              aria-label={`Slide ${idx + 1}`}
              className="h-1.5 rounded-full transition-all cursor-pointer"
              style={{
                width: idx === step ? 26 : 7,
                background: idx === step ? 'var(--jb-accent)' : 'var(--jb-border-strong)',
              }}
            />
          ))}
        </div>

        <button
          onClick={() => {
            if (step < 2) setStep(step + 1);
            else onComplete(perms);
          }}
          className="jb-gold-btn px-5 py-2.5 rounded-full text-[13px] font-semibold inline-flex items-center gap-1.5 shadow-lg cursor-pointer active:scale-95 transition-transform"
        >
          <span>{step < 2 ? (isAr ? 'التالي' : 'Continue') : isAr ? 'ابدأ القراءة' : 'Enter Library'}</span>
          {isAr ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
        </button>
      </div>
    </div>
  );
};
