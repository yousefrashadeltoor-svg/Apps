import React from 'react';
import { Lock, Heart, Shield } from 'lucide-react';
import { DocItem, Lang } from '../types';

export const JobatEmblem: React.FC<{ size?: number; className?: string }> = ({ size = 34, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <defs>
      <linearGradient id="jbGoldEmblem" x1="10" y1="8" x2="54" y2="56" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#E4C988" />
        <stop offset="50%" stopColor="#D4B26A" />
        <stop offset="100%" stopColor="#B8914A" />
      </linearGradient>
    </defs>
    <rect x="2" y="2" width="60" height="60" rx="16" fill="#0B0C10" stroke="url(#jbGoldEmblem)" strokeOpacity="0.38" strokeWidth="1.2" />
    {/* Subtle origami bat-wing paired with fountain-pen nib */}
    <path
      d="M11 37.5C16.5 25.5 24.5 23 32 29.5C39.5 23 47.5 25.5 53 37.5C45.2 34 38.2 35.2 32 42C25.8 35.2 18.8 34 11 37.5Z"
      stroke="url(#jbGoldEmblem)"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M32 15L35.2 29.5L32 49L28.8 29.5L32 15Z"
      fill="url(#jbGoldEmblem)"
      fillOpacity="0.16"
      stroke="url(#jbGoldEmblem)"
      strokeWidth="1.35"
      strokeLinejoin="round"
    />
    <circle cx="32" cy="31" r="1.6" fill="url(#jbGoldEmblem)" />
  </svg>
);

export const JobatWordmark: React.FC<{ size?: 'sm' | 'md' | 'lg'; showEmblem?: boolean }> = ({
  size = 'md',
  showEmblem = true,
}) => {
  const textCls =
    size === 'lg'
      ? 'text-[38px] leading-none'
      : size === 'sm'
      ? 'text-[20px] leading-none'
      : 'text-[26px] leading-none';
  const emblemSize = size === 'lg' ? 54 : size === 'sm' ? 26 : 32;

  return (
    <div className="inline-flex items-center gap-2.5 select-none" dir="ltr">
      {showEmblem && <JobatEmblem size={emblemSize} />}
      <span className={`jb-display font-semibold tracking-tight ${textCls}`}>
        <span
          className="italic font-semibold bg-clip-text text-transparent pr-0.5"
          style={{ backgroundImage: 'var(--jb-champagne-grad)' }}
        >
          𝒥𝒪
        </span>{' '}
        <span style={{ color: 'var(--jb-text)' }} className="font-medium tracking-[0.02em]">
          bat
        </span>
      </span>
    </div>
  );
};

export const CircularProgress: React.FC<{
  value: number; // 0..1
  size?: number;
  stroke?: number;
  label?: string;
}> = ({ value, size = 54, stroke = 3.2, label }) => {
  const pct = Math.max(0, Math.min(1, value));
  const r = (size - stroke * 2) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - pct);

  return (
    <div className="relative inline-flex items-center justify-center shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="var(--jb-border)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="var(--jb-accent)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 360ms var(--jb-ease-spring)' }}
        />
      </svg>
      <span className="absolute text-[11px] font-semibold tabular-nums" style={{ color: 'var(--jb-text)' }}>
        {label ?? `${Math.round(pct * 100)}%`}
      </span>
    </div>
  );
};

export const BookCover: React.FC<{
  doc: DocItem;
  lang: Lang;
  compact?: boolean;
  className?: string;
}> = ({ doc, lang, compact = false, className = '' }) => {
  const { bgFrom, bgTo, accent, pattern, imageUrl } = doc.coverStyle;
  const title = lang === 'ar' ? doc.titleAr : doc.titleEn;
  const author = lang === 'ar' ? doc.authorAr : doc.authorEn;

  return (
    <div
      className={`relative overflow-hidden select-none ${className}`}
      style={{
        background: `linear-gradient(155deg, ${bgFrom} 0%, ${bgTo} 100%)`,
        border: '1px solid rgba(212, 178, 106, 0.22)',
      }}
    >
      {imageUrl ? (
        <>
          <img
            src={imageUrl}
            alt={title}
            className="absolute inset-0 w-full h-full object-cover"
            loading="lazy"
          />
          <div
            className="absolute inset-0"
            style={{
              background: compact
                ? 'linear-gradient(180deg, rgba(11,12,16,0.12) 0%, rgba(11,12,16,0.55) 100%)'
                : 'linear-gradient(180deg, rgba(11,12,16,0.18) 0%, rgba(11,12,16,0.82) 100%)',
            }}
          />
        </>
      ) : (
        <svg className="absolute inset-0 w-full h-full opacity-30" viewBox="0 0 120 168" fill="none" aria-hidden="true">
          {/* Book spine crease */}
          <line x1="10" y1="0" x2="10" y2="168" stroke={accent} strokeOpacity="0.35" strokeWidth="0.7" />
          {pattern === 'manuscript' && (
            <>
              <rect x="16" y="12" width="92" height="144" rx="4" stroke={accent} strokeOpacity="0.55" strokeWidth="0.8" />
              <circle cx="62" cy="84" r="24" stroke={accent} strokeOpacity="0.45" strokeWidth="0.7" />
              <path d="M62 54L69 77L92 84L69 91L62 114L55 91L32 84L55 77Z" stroke={accent} strokeOpacity="0.45" strokeWidth="0.7" />
            </>
          )}
          {pattern === 'arch' && (
            <>
              <path d="M26 156V68C26 44 42 28 62 28C82 28 98 44 98 68V156" stroke={accent} strokeOpacity="0.55" strokeWidth="0.9" />
              <path d="M36 156V74C36 56 47 42 62 42C77 42 88 56 88 74V156" stroke={accent} strokeOpacity="0.32" strokeWidth="0.7" />
            </>
          )}
          {pattern === 'geometric' && (
            <>
              <circle cx="62" cy="84" r="34" stroke={accent} strokeOpacity="0.4" strokeWidth="0.8" />
              <rect x="38" y="60" width="48" height="48" stroke={accent} strokeOpacity="0.35" strokeWidth="0.7" />
              <rect x="38" y="60" width="48" height="48" transform="rotate(45 62 84)" stroke={accent} strokeOpacity="0.35" strokeWidth="0.7" />
            </>
          )}
          {pattern === 'code' && (
            <>
              <path d="M22 44H74M22 56H92M22 68H60M22 80H86M22 92H52" stroke={accent} strokeOpacity="0.45" strokeWidth="1.2" strokeLinecap="round" />
            </>
          )}
          {pattern === 'minimal' && (
            <rect x="18" y="14" width="88" height="140" rx="2" stroke={accent} strokeOpacity="0.4" strokeWidth="0.7" />
          )}
        </svg>
      )}

      {/* Top badge row */}
      {!compact && (
        <div className="relative z-10 flex items-center justify-between px-2.5 pt-2.5">
          <span
            className="px-1.5 py-0.5 rounded text-[9px] font-semibold uppercase tracking-wider backdrop-blur-sm"
            style={{
              background: 'rgba(11, 12, 16, 0.72)',
              color: accent,
              border: `1px solid ${accent}44`,
            }}
          >
            {doc.ext}
          </span>
          <div className="flex items-center gap-1">
            {doc.password && <Lock size={11} style={{ color: accent }} />}
            {doc.vaultLocked && <Shield size={11} style={{ color: accent }} />}
            {doc.favorite && <Heart size={11} fill={accent} style={{ color: accent }} />}
          </div>
        </div>
      )}

      {/* Bottom title foil inside cover */}
      {!compact && (
        <div className="absolute inset-x-0 bottom-0 z-10 p-3 flex flex-col justify-end">
          <p className="jb-display text-[13px] leading-snug font-semibold text-[#F4F0E8] line-clamp-2 drop-shadow-sm">
            {title}
          </p>
          <p className="text-[10px] text-[#C8C2B4]/80 mt-0.5 truncate">{author}</p>
        </div>
      )}

      {compact && (
        <div className="absolute inset-0 z-10 flex items-center justify-center">
          {!imageUrl && (
            <span className="text-[9px] font-bold uppercase tracking-wider" style={{ color: accent }}>
              {doc.ext}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
